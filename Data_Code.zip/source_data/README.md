# Scientific source data

This directory preserves the frozen scientific numerical tables, nine numbered workbooks, accepted result exports, implementation/configuration and molecular/laboratory originals. The repository root README and `DATA_COVERAGE.csv` control the public coverage description; copied historical provenance documents are source snapshots.

The large original trajectory and archive paths in `ORIGINAL_LARGE_DATA_POINTERS.csv` are **not** included bytes or public download URLs. The per-case/per-residue accepted exports are included, with 747 recorded cases in total. No previous computation, submission or cleanup transaction was replayed.

Original laboratory XLS/XLSX/Prism PZFX files from the project `exp_result` folder supplement the report, image originals and transcribed well tables. Existing NPZ/metadata inputs are under `original_input_arrays/`; all matrix values match the current SI14 wide CSV exactly. Existing strong/stress/merged equal-budget reporting is under `additional_reporting/`; its original bytes and source hashes are retained.

All source numerical files are unchanged. Excluded packaging/editorial documents and actual included files are itemized in the repository audit/provenance. Amber binaries, model weights, third-party journal PDFs and private author-query documents are absent.
