#!/usr/bin/env python3
"""Restyle the Figure 2 supplements onto the frozen series style.

Nothing about the science changes: every panel is drawn by the original
build_figure2_si.py panel function, reading the same published source tables.
Only the presentation layer is replaced -- type sizes, rule weights, spines,
palette, panel letters and the supplementary title -- so the supplements match
the main figures, which are built on the same frozen module.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent             # FigureN/Supplementary_Figures/rebuild
FS = HERE.parents[2]                               # release root (FigureandSI)
STYLE_DIR = FS / "Shared/style"                    # figure2_style.py, si_style.py, si_paths.py
sys.path.insert(0, str(STYLE_DIR))
sys.dont_write_bytecode = True                     # no __pycache__ inside the release
import si_paths as P                               # noqa: E402

GROUP = "2"
STAGE = P.STAGE_ROOT / f"Figure{GROUP}"
OUTDIR = Path(os.environ.get("SI_RESTYLE_OUT", P.STAGE_ROOT / "out")) / f"Figure{GROUP}"
SRC_SCRIPT = HERE / f"build_figure{GROUP}_si.py"


def stage() -> Path:
    """Recreate the layout the build script expects, from published tables."""
    import shutil
    root = STAGE / "root"
    tables = root / f"draft/Figure/{GROUP}/SI/tables"
    rebuild = root / f"draft/Figure/{GROUP}/rebuild"
    tables.mkdir(parents=True, exist_ok=True)
    rebuild.mkdir(parents=True, exist_ok=True)
    n = 0
    pub = P.stage_published_tables(int(GROUP), STAGE / "published")
    for p in pub.rglob("*"):
        if p.is_file() and p.suffix.lower() in (".csv", ".json"):
            dst = tables / p.name
            if not dst.exists():
                shutil.copyfile(p, dst)
            n += 1
    # the main-figure rebuild module (supplement 4 borrows its panel drawing)
    # the main-figure rebuild folder, with its derived-data subfolders
    shutil.copytree(P.main_rebuild(int(GROUP)), rebuild, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    print(f"staged {n} tables -> {tables}")
    return root


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    root = stage()
    os.environ["AAK1_ROOT"] = str(root)
    # figure2_style.py and si_style.py must be importable
    sys.path.insert(0, str(STYLE_DIR))

    import si_style as S

    mod = load_module(SRC_SCRIPT, "build_fig2_si")

    # ---- re-point output and source ------------------------------------
    OUTDIR.mkdir(parents=True, exist_ok=True)
    mod.FIG = OUTDIR
    mod.SOURCE = root / f"draft/Figure/{GROUP}/SI/tables"
    # folders the panel functions write side tables into, inside the stage
    for d in (mod.TAB, mod.SRC, mod.SCRIPTS, mod.QA):
        Path(d).mkdir(parents=True, exist_ok=True)

    # ---- presentation layer --------------------------------------------
    mod.configure_style = S.apply_si_style
    mod.panel_label = lambda ax, label: S.panel_letter(ax, label)
    mod.clean = lambda ax: S.clean(ax)
    # frozen ink / greys / cohort palette in place of the local restatements
    mod.INK = "black"
    mod.MUTED = S.ANNOT_GREY
    mod.GRID = S.GRID_GREY
    mod.COHORT = dict(S.COHORT_COLORS)

    # the script sets its own suptitle text per figure; suppress it and stamp
    # the unified public title at save time instead.
    import matplotlib.figure as mfig
    orig_suptitle = mfig.Figure.suptitle
    mfig.Figure.suptitle = lambda self, *a, **k: None

    saved = {}

    def save_figure(fig, stem):
        S.strip_legacy_titles(fig)
        n = S.PUBLIC_NUMBER[stem]
        S.stamp_heading(fig, n)
        out = S.save_si(fig, OUTDIR, stem)
        saved[stem] = out
        print(f"  rendered {S.public_stem(stem)}  ({len(out)} formats)")

    mod.save_figure = save_figure

    S.apply_si_style()

    # Supplement 4 is drawn by the main figure's own module, which saves itself
    # directly instead of calling save_figure.  Intercept its save, keep the
    # figure, then title and write it through the same path as the others.
    DELEGATED = {"figure_s4": "Figure2_S4_current_perturbation_response"}

    for fn in ("figure_s1", "figure_s2", "figure_s3", "figure_s4", "figure_s5", "figure_s6"):
        f = getattr(mod, fn, None)
        if f is None:
            print(f"  [skip] {fn} not defined")
            continue
        # seaborn draws strip-plot jitter from numpy's global generator; a fixed
        # seed per supplement makes every rebuild pixel-identical
        __import__("numpy").random.seed(0)
        try:
            if fn in DELEGATED:
                import matplotlib.pyplot as plt
                grabbed = {}
                real = plt.Figure.savefig

                def grab(self, *a, **k):
                    grabbed.setdefault("fig", self)
                    return None

                plt.Figure.savefig = grab
                try:
                    f()
                finally:
                    plt.Figure.savefig = real
                fig = grabbed.get("fig")
                if fig is None:
                    print(f"  [FAIL] {fn}: delegated module produced no figure")
                else:
                    save_figure(fig, DELEGATED[fn])
            else:
                f()
        except Exception as e:
            print(f"  [FAIL] {fn}: {type(e).__name__}: {e}")
            traceback.print_exc(limit=3)

    print(f"\n{len(saved)} of 6 Figure 2 supplements restyled -> {OUTDIR}")


if __name__ == "__main__":
    main()
