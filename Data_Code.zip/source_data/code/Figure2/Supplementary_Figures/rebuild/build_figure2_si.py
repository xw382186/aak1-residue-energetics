#!/usr/bin/env python3
"""Build the current, identity-corrected Figure 2 Supporting Information.

This script deliberately reads only the active 2026-09-24 Figure 2 SI tables.
It never reads the rendered, pre-correction SI figures.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


ROOT = Path(os.environ.get("AAK1_ROOT",
                          "/Users/wxmacbookpro/Desktop/project/AAK1"))
SOURCE = ROOT / "draft/Figure/2/SI/tables"
OUT = ROOT / "draft/Figure/2/SI/current_20260929"
# supplement 4 is drawn by the main figure's own module, which lives here
MAIN_REBUILD = ROOT / "draft/Figure/2/rebuild"
FIG = OUT / "figures"
TAB = OUT / "tables"
SRC = TAB / "source_csv"
SCRIPTS = OUT / "scripts"
QA = OUT / "qa"

INK = "#222222"
MUTED = "#6B7280"
GRID = "#D9D9D9"
BLUE = "#4878D0"
ORANGE = "#EE854A"
GREEN = "#6ACC64"
RED = "#D65F5F"
PURPLE = "#956CB4"
LIGHT = "#E5E7EB"
COHORT = {"strong": "#5B84BD", "stress": "#BB5E5D", "other": "#D9DCE5"}
VARIANT = {"WT": BLUE, "Pair2A": PURPLE, "Triad3A": RED, "Pocket16A": GREEN}
METHODS = ["Boltz-2", "MM/GBSA", "ASGB total dH", "ASGBIE total dG", "Glide gscore"]
METHOD_LABEL = {
    "Boltz-2": "Boltz-2",
    "MM/GBSA": "MM/GBSA",
    "ASGB total dH": "ASGB dH",
    "ASGBIE total dG": "ASGBIE dG",
    "Glide gscore": "Glide",
}


INPUTS = [
    "S01_all_cohort_summaries.csv",
    "S01_all_compound_potency.csv",
    "S01_errors_by_group.csv",
    "S01_group_landscape.csv",
    "S02_calibration_points.csv",
    "S02_calibration_summary.csv",
    "S02_error_points.csv",
    "S03_global_primary_and_hierarchical_CI.csv",
    "S10_leave_one_group_out.csv",
    "S07_stress_secondary_seed_points.csv",
    "S07_stress_secondary_seed_summary.csv",
    "S08_all_geometry_and_pairs.csv",
    "S08_all_geometry_summary.csv",
    "S08_strong_residue_mutation_map.csv",
    "S08_stress_residue_mutation_map.csv",
    "S08_strong_variants.json",
    "S08_stress_variants.json",
    "S08_strong_experiment.json",
    "S08_stress_experiment.json",
    "S11_PCA_coordinates.csv",
    "S11_PCA_variance.csv",
    "S11_descriptor_comparison.csv",
    "S11_identity_scaffold_overlap.csv",
    "S11_exact_overlap_exclusion_sensitivity.csv",
    "S11_butina_cluster_summary.csv",
    "S11_nearest_neighbor_summary.csv",
    "S11_source_permutation_summary.csv",
    "S11_compound_structures_and_descriptors_N353.csv",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
            "mathtext.fontset": "custom",
            "mathtext.rm": "Arial",
            "mathtext.it": "Arial:italic",
            "mathtext.bf": "Arial:bold",
            "font.size": 7.2,
            "axes.titlesize": 8.2,
            "axes.labelsize": 7.6,
            "xtick.labelsize": 6.7,
            "ytick.labelsize": 6.7,
            "legend.fontsize": 6.5,
            "axes.linewidth": 0.7,
            "lines.linewidth": 1.2,
            "patch.linewidth": 0.7,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )
    sns.set_style("whitegrid", {"grid.color": GRID, "grid.linewidth": 0.45})


def panel_label(ax, label: str) -> None:
    ax.text(-0.16, 1.08, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top", color=INK)


def clean(ax) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(width=0.65, length=3)


def save_figure(fig: plt.Figure, stem: str) -> None:
    for ext in ("pdf", "svg"):
        fig.savefig(FIG / f"{stem}.{ext}")
    fig.savefig(FIG / f"{stem}.png", dpi=600)
    fig.savefig(FIG / f"{stem}.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


def read(name: str) -> pd.DataFrame:
    return pd.read_csv(SOURCE / name)


def figure_s1() -> None:
    landscape = read("S01_group_landscape.csv")
    potency = read("S01_all_compound_potency.csv")
    calibration = read("S02_calibration_points.csv")
    errors = read("S01_errors_by_group.csv")

    fig, axs = plt.subplots(2, 2, figsize=(8.7476, 6.35), gridspec_kw={"hspace": 0.42, "wspace": 0.34})

    ax = axs[0, 0]
    d = landscape.sort_values("n_compounds", ascending=True)
    y = np.arange(len(d))
    ax.barh(y, d["n_compounds"], color=[COHORT.get(x, "#B7BDC8") for x in d["cohort_label"]], edgecolor=INK, linewidth=0.45)
    ax.set_yticks(y, d["group_id"])
    ax.set_xlabel("Compounds per literature source")
    ax.set_title("N = 1,434 across 19 source groups", loc="left", fontweight="bold")
    for yi, n, frac in zip(y, d["n_compounds"], d["active_fraction_100nM"]):
        ax.text(n + 2, yi, f"{int(n)}  ({frac*100:.0f}% active)", va="center", fontsize=5.6, color=MUTED)
    clean(ax); panel_label(ax, "A")

    ax = axs[0, 1]
    order = ["strong", "stress", "other"]
    sns.violinplot(data=potency, x="cohort_label", y="experimental_pic50", order=order, palette=COHORT,
                   inner=None, cut=0, linewidth=0.6, ax=ax, saturation=0.85)
    sns.boxplot(data=potency, x="cohort_label", y="experimental_pic50", order=order, width=0.18,
                showfliers=False, color="white", linecolor=INK, linewidth=0.65, ax=ax)
    counts = potency.groupby("cohort_label").size()
    ax.set_xticklabels([f"{x}\nN={counts[x]}" for x in order])
    ax.axhline(7.0, color=MUTED, ls=(0, (2, 2)), lw=0.8)
    ax.text(2.48, 7.04, "100 nM", ha="right", va="bottom", fontsize=6.2, color=MUTED)
    ax.set_xlabel(""); ax.set_ylabel("Experimental pIC$_{50}$")
    ax.set_title("Potency differs across prespecified cohorts", loc="left", fontweight="bold")
    clean(ax); panel_label(ax, "B")

    ax = axs[1, 0]
    hb = ax.hexbin(calibration["experimental_pic50"], calibration["boltz_predicted_pic50"], gridsize=38,
                   mincnt=1, cmap="Blues", linewidths=0, bins="log")
    lo = min(calibration["experimental_pic50"].min(), calibration["boltz_predicted_pic50"].min())
    hi = max(calibration["experimental_pic50"].max(), calibration["boltz_predicted_pic50"].max())
    ax.plot([lo, hi], [lo, hi], color=INK, ls=(0, (3, 2)), lw=0.8)
    cbar = fig.colorbar(hb, ax=ax, fraction=0.05, pad=0.02)
    cbar.set_label("Hexbin density (log)", fontsize=6.5)
    ax.set_xlabel("Experimental pIC$_{50}$"); ax.set_ylabel("Boltz-2 predicted pIC$_{50}$")
    ax.set_title("Historical global calibration", loc="left", fontweight="bold")
    ax.text(0.02, 0.97, "N=1,434", transform=ax.transAxes, va="top", fontsize=6.4,
            bbox=dict(boxstyle="round,pad=.2", fc="white", ec=GRID, lw=.5))
    clean(ax); panel_label(ax, "C")

    ax = axs[1, 1]
    for cohort, dd in errors.groupby("cohort_label"):
        ax.scatter(dd["N"], dd["spearman_rho"], s=22 + 0.8 * dd["N"], color=COHORT.get(cohort, "#B7BDC8"),
                   edgecolor=INK, linewidth=0.45, alpha=0.9, label=cohort)
        for _, r in dd.iterrows():
            ax.text(r["N"] + 1.8, r["spearman_rho"], r["group_id"], fontsize=5.2, va="center", color=MUTED)
    ax.axhline(0, color=MUTED, lw=0.7)
    ax.set_xlim(left=0); ax.set_ylim(-0.15, 1.02)
    ax.set_xlabel("Compounds in source group"); ax.set_ylabel("Within-group Spearman $\\rho$")
    ax.set_title("Source-level association is heterogeneous", loc="left", fontweight="bold")
    ax.legend(frameon=False, title="Cohort", title_fontsize=6.5, loc="lower right")
    clean(ax); panel_label(ax, "D")

    fig.suptitle("Figure 2—figure supplement 1 | Cohort composition and historical calibration", x=0.01, y=0.995,
                 ha="left", fontsize=10, fontweight="bold")
    save_figure(fig, "Figure2_S1_current_cohort_calibration")


def forest(ax, d: pd.DataFrame, statistic: str, title: str, label: str) -> None:
    dd = d[d["statistic"] == statistic].copy()
    dd["method"] = pd.Categorical(dd["method"], categories=METHODS, ordered=True)
    dd = dd.sort_values(["method", "cohort"])
    ybase = np.arange(len(METHODS))[::-1]
    offset = {"strong": 0.12, "stress": -0.12}
    for cohort, color in [("strong", COHORT["strong"]), ("stress", COHORT["stress"])]:
        sub = dd[dd["cohort"] == cohort].set_index("method").reindex(METHODS)
        y = ybase + offset[cohort]
        x = sub["estimate"].to_numpy(float)
        low = sub["ci_low"].to_numpy(float)
        high = sub["ci_high"].to_numpy(float)
        ax.errorbar(x, y, xerr=np.vstack([x-low, high-x]), fmt="o", ms=4.0, color=color, mec=INK, mew=.45,
                    capsize=2.2, lw=.9, label=f"{cohort} (N={int(sub['N'].dropna().iloc[0])})")
    ax.axvline(0, color=MUTED, lw=.7)
    ax.set_yticks(ybase, [METHOD_LABEL[m] for m in METHODS])
    ax.set_xlim(-0.28, 1.0); ax.set_xlabel("Spearman $\\rho$ (95% source-stratified CI)")
    ax.set_title(title, loc="left", fontweight="bold"); ax.legend(frameon=False, loc="lower right")
    clean(ax); panel_label(ax, label)


def figure_s2() -> None:
    global_ci = read("S03_global_primary_and_hierarchical_CI.csv")
    logo = read("S10_leave_one_group_out.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.7476, 6.35), gridspec_kw={"hspace": 0.42, "wspace": 0.38})
    forest(axs[0, 0], global_ci, "pooled_rho", "Global association", "A")
    forest(axs[0, 1], global_ci, "within_source_rho", "Within-source association", "B")

    ax = axs[1, 0]
    marker = {"Boltz-2": "o", "MM/GBSA": "s", "ASGB total dH": "^", "ASGBIE total dG": "D", "Glide gscore": "v"}
    for cohort, color in [("strong", COHORT["strong"]), ("stress", COHORT["stress"])]:
        for method in METHODS:
            dd = logo[(logo["cohort"] == cohort) & (logo["method"] == method)]
            ax.scatter(dd["full_pooled_rho"], dd["omitted_pooled_rho"], color=color, marker=marker[method], s=25,
                       edgecolor=INK, linewidth=.4, alpha=.82)
    ax.plot([-0.25, 1], [-0.25, 1], color=MUTED, lw=.8, ls=(0, (3, 2)))
    ax.set_xlim(-0.22, .98); ax.set_ylim(-0.22, .98)
    ax.set_xlabel("Full-cohort pooled $\\rho$"); ax.set_ylabel("Leave-one-source-out pooled $\\rho$")
    ax.set_title("Every source exclusion is shown", loc="left", fontweight="bold")
    ax.text(.02, .98, "blue: strong; red: stress", transform=ax.transAxes, va="top", fontsize=6.2, color=MUTED)
    clean(ax); panel_label(ax, "C")

    ax = axs[1, 1]
    heat = logo.copy()
    heat["method_short"] = heat["method"].map(METHOD_LABEL)
    heat["fold"] = heat["cohort"] + " / " + heat["omitted_group"]
    heat["delta"] = heat["omitted_pooled_rho"] - heat["full_pooled_rho"]
    piv = heat.pivot(index="method_short", columns="fold", values="delta")
    piv = piv.reindex([METHOD_LABEL[m] for m in METHODS])
    cols = [c for c in piv.columns if c.startswith("strong")] + [c for c in piv.columns if c.startswith("stress")]
    piv = piv[cols]
    vmax = max(abs(np.nanmin(piv.to_numpy())), abs(np.nanmax(piv.to_numpy())))
    sns.heatmap(piv, cmap="vlag", center=0, vmin=-vmax, vmax=vmax, linewidths=.4, linecolor="white",
                cbar_kws={"label": "$\\Delta\\rho$ after source exclusion", "shrink": .78}, ax=ax)
    ax.set_xlabel("Omitted cohort / source group"); ax.set_ylabel("")
    ax.set_xticklabels([x.replace("strong / ", "S ").replace("stress / ", "T ") for x in cols], rotation=45, ha="right")
    ax.set_title("LOGO sensitivity relative to the full cohort", loc="left", fontweight="bold")
    panel_label(ax, "D")

    fig.suptitle("Figure 2—figure supplement 2 | Current global estimates and source-group robustness", x=.01, y=.995,
                 ha="left", fontsize=10, fontweight="bold")
    save_figure(fig, "Figure2_S2_current_global_and_LOGO_robustness")

    out = heat[["cohort", "method", "omitted_group", "full_pooled_rho", "omitted_pooled_rho", "delta"]]
    out.to_csv(TAB / "Figure2_S2_LOGO_pooled_delta.csv", index=False)


def figure_s3() -> None:
    d = read("S07_stress_secondary_seed_points.csv")
    s = read("S07_stress_secondary_seed_summary.csv")
    variants = ["WT", "Pair2A", "Triad3A", "Pocket16A"]
    fig, axs = plt.subplots(1, 3, figsize=(8.7476, 3.25), gridspec_kw={"wspace": .43, "width_ratios": [1.15, 1, .95]})

    ax = axs[0]
    lo = min(d["affinity_pred_value_seed1"].min(), d["affinity_pred_value_seed2"].min())
    hi = max(d["affinity_pred_value_seed1"].max(), d["affinity_pred_value_seed2"].max())
    for v in variants:
        dd = d[d["variant"] == v]
        ax.scatter(dd["affinity_pred_value_seed1"], dd["affinity_pred_value_seed2"], s=31, color=VARIANT[v],
                   edgecolor=INK, linewidth=.45, alpha=.88, label=v.replace("A", ""))
    ax.plot([lo, hi], [lo, hi], color=MUTED, ls=(0, (3, 2)), lw=.8)
    ax.set_xlabel("Seed 1 affinity output (log$_{10}$ µM)")
    ax.set_ylabel("Seed 2 affinity output (log$_{10}$ µM)")
    ax.set_title("Prediction-only repeat seed", loc="left", fontweight="bold")
    ax.legend(frameon=False, ncol=2, loc="lower right")
    clean(ax); panel_label(ax, "A")

    ax = axs[1]
    sns.boxplot(data=d, x="variant", y="seed2_minus_seed1_affinity_log10_uM", order=variants,
                palette=VARIANT, width=.5, showfliers=False, linewidth=.65, ax=ax)
    sns.stripplot(data=d, x="variant", y="seed2_minus_seed1_affinity_log10_uM", order=variants,
                  color=INK, size=2.5, jitter=.13, alpha=.75, ax=ax)
    ax.axhline(0, color=MUTED, lw=.8, ls=(0, (2, 2)))
    ax.set_xticklabels([x.replace("A", "") for x in variants], rotation=30, ha="right")
    ax.set_xlabel(""); ax.set_ylabel("Seed 2 − seed 1 (log$_{10}$ µM)")
    ax.set_title("Case-level signed change", loc="left", fontweight="bold")
    clean(ax); panel_label(ax, "B")

    ax = axs[2]
    ss = s.set_index("variant").reindex(variants).reset_index()
    y = np.arange(len(ss))[::-1]
    ax.barh(y, ss["median_absolute"], color=[VARIANT[v] for v in ss["variant"]], edgecolor=INK, linewidth=.5)
    for yi, med, ab in zip(y, ss["median"], ss["median_absolute"]):
        ax.text(ab + .005, yi, f"|Δ|={ab:.2f}; median={med:+.2f}", va="center", fontsize=6.0)
    ax.set_yticks(y, [v.replace("A", "") for v in ss["variant"]])
    ax.set_xlabel("Median absolute seed change (log$_{10}$ µM)")
    ax.set_title("N=10 compounds per variant", loc="left", fontweight="bold")
    ax.set_xlim(0, max(ss["median_absolute"]) * 1.85)
    clean(ax); panel_label(ax, "C")

    fig.suptitle("Figure 2—figure supplement 3 | Ten-compound secondary-seed sensitivity", x=.01, y=.995,
                 ha="left", fontsize=10, fontweight="bold")
    save_figure(fig, "Figure2_S3_current_secondary_seed_sensitivity")


def geometry_panel(ax, d, metric, title, ylabel, label, log=False):
    order = ["Pair2A", "Triad3A", "Pocket16A"]
    sns.boxplot(data=d, x="variant", y=metric, hue="cohort", order=order, hue_order=["strong", "stress"],
                palette={"strong": COHORT["strong"], "stress": COHORT["stress"]}, width=.65, showfliers=False, linewidth=.65, ax=ax)
    ax.set_xticklabels(["Pair", "Triad", "Pocket-16"])
    ax.set_xlabel(""); ax.set_ylabel(ylabel); ax.set_title(title, loc="left", fontweight="bold")
    if log: ax.set_yscale("log")
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ["strong (139)", "stress (214)"] if len(labels)==2 else labels, frameon=False, loc="upper left")
    clean(ax); panel_label(ax, label)


def figure_s4() -> None:
    """The alanine-perturbation response -- the two panels the main figure moved.

    Drawn by `make_figure2_si_perturbation`, which calls the main figure's own
    `panel_roc` and `panel_geometry`, so the arm colours, markers, type and page
    width are the main figure's and not a second set invented here.  That module
    installs the main figure's style -- including a tight save box, which would
    silently crop every later supplement -- so the whole rcParam state is
    snapshotted and put back, not just this package's own settings.
    """
    import sys
    saved = mpl.rcParams.copy()
    try:
        sys.path.insert(0, str(MAIN_REBUILD))
        import make_figure2_si_perturbation as pert
        pert.OUT, pert.TABLES = FIG, SRC
        pert.build()
    finally:
        mpl.rcParams.update(saved)


def figure_s5() -> None:
    d = read("S08_all_geometry_and_pairs.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.7476, 6.25), gridspec_kw={"hspace": .42, "wspace": .34})
    geometry_panel(axs[0,0], d, "protein_ca_rmsd_A", "Global protein displacement", "Cα RMSD (Å)", "A")
    geometry_panel(axs[0,1], d, "pocket_ca_rmsd_after_global_fit_A", "Pocket displacement after global fit", "Pocket Cα RMSD (Å)", "B")
    geometry_panel(axs[1,0], d, "ligand_centroid_displacement_after_global_fit_A", "Ligand-centroid displacement", "Centroid shift (Å, log scale)", "C", log=True)

    ax = axs[1,1]
    for v in ["Pair2A", "Triad3A", "Pocket16A"]:
        dd = d[d["variant"] == v]
        ax.scatter(dd["protein_ca_rmsd_A"], dd["ligand_centroid_displacement_after_global_fit_A"],
                   s=8, alpha=.28, color=VARIANT[v], edgecolor="none", label=v.replace("A", ""))
    ax.set_yscale("log")
    ax.set_xlabel("Protein Cα RMSD (Å)"); ax.set_ylabel("Ligand-centroid shift (Å, log scale)")
    ax.set_title("Coordinate-level coupling across 1,059 pairs", loc="left", fontweight="bold")
    ax.legend(frameon=False, loc="upper left")
    clean(ax); panel_label(ax, "D")
    fig.suptitle("Figure 2—figure supplement 5 | Geometry and perturbation-design audit", x=.01, y=.995,
                 ha="left", fontsize=10, fontweight="bold")
    save_figure(fig, "Figure2_S5_current_geometry_design_audit")


def figure_s6() -> None:
    pca = read("S11_PCA_coordinates.csv")
    var = read("S11_PCA_variance.csv")
    desc = read("S11_descriptor_comparison.csv")
    ident = read("S11_identity_scaffold_overlap.csv")
    sens = read("S11_exact_overlap_exclusion_sensitivity.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.7476, 6.25), gridspec_kw={"hspace": .46, "wspace": .37})

    ax = axs[0,0]
    dd = pca[pca["representation"] == "Morgan2048_centered"]
    for cohort, color in [("strong", COHORT["strong"]), ("stress", COHORT["stress"])]:
        x = dd[dd["cohort"] == cohort]
        ax.scatter(x["PC1"], x["PC2"], s=15, color=color, alpha=.60, edgecolor="white", linewidth=.2,
                   label=f"{cohort} (N={len(x)})")
    vx = var[(var["representation"] == "Morgan2048_centered") & (var["component"] == 1)]["explained_variance_ratio"].iloc[0]
    vy = var[(var["representation"] == "Morgan2048_centered") & (var["component"] == 2)]["explained_variance_ratio"].iloc[0]
    ax.set_xlabel(f"Morgan PC1 ({vx*100:.1f}%)"); ax.set_ylabel(f"Morgan PC2 ({vy*100:.1f}%)")
    ax.set_title("Fingerprint chemical space", loc="left", fontweight="bold"); ax.legend(frameon=False)
    clean(ax); panel_label(ax, "A")

    ax = axs[0,1]
    desc = desc.sort_values("standardized_mean_difference_strong_minus_stress")
    y = np.arange(len(desc))
    vals = desc["standardized_mean_difference_strong_minus_stress"].to_numpy()
    ax.barh(y, vals, color=[COHORT["strong"] if x > 0 else COHORT["stress"] for x in vals], edgecolor=INK, linewidth=.4)
    ax.axvline(0, color=INK, lw=.7)
    ax.set_yticks(y, [x.replace("rotatable_bonds", "RotB").replace("heavy_atoms", "Heavy atoms").replace("fraction_CSP3", "Fsp³").replace("ring_count", "Rings") for x in desc["descriptor"]])
    ax.set_xlabel("Standardized mean difference (strong − stress)")
    ax.set_title("Descriptor shifts are descriptive", loc="left", fontweight="bold")
    clean(ax); panel_label(ax, "B")

    ax = axs[1,0]
    labmap = {
        "canonical_isomeric_smiles": "Exact stereochemical structure",
        "full_standard_inchikey": "Full InChIKey",
        "canonical_nonisomeric_smiles": "Non-stereo structure",
        "legacy_scaffold_id": "Legacy scaffold",
        "murcko_smiles": "Murcko scaffold",
        "murcko_isomeric_smiles": "Stereo Murcko scaffold",
        "generic_murcko_smiles": "Generic Murcko scaffold",
    }
    ii = ident.copy(); ii["label"] = ii["identity_basis"].map(labmap); ii = ii.sort_values("jaccard")
    y = np.arange(len(ii))
    ax.barh(y, ii["jaccard"], color=PURPLE, edgecolor=INK, linewidth=.45)
    ax.set_yticks(y, ii["label"]); ax.set_xlabel("Strong–stress Jaccard overlap")
    ax.set_title("Identity and scaffold overlap", loc="left", fontweight="bold")
    for yi, val, shared in zip(y, ii["jaccard"], ii["shared_unique"]):
        ax.text(val + .006, yi, f"{val:.2f} ({int(shared)} shared)", va="center", fontsize=5.8)
    ax.set_xlim(0, max(ii["jaccard"])*1.42)
    clean(ax); panel_label(ax, "C")

    ax = axs[1,1]
    scenarios = list(dict.fromkeys(sens["scenario"]))
    short = {
        "primary_all_records": "All records",
        "unique_isomeric_structure_within_each_cohort": "Unique within cohort",
        "exclude_stress_records_exactly_shared_with_strong": "Exclude shared from stress",
        "exclude_exact_shared_records_from_both_cohorts": "Exclude shared from both",
    }
    x = np.arange(len(scenarios))
    for cohort, color, off in [("strong", COHORT["strong"], -.12), ("stress", COHORT["stress"], .12)]:
        ss = sens[sens["cohort"] == cohort].set_index("scenario").reindex(scenarios)
        ax.plot(x+off, ss["median_nearest_opposite"], "o-", color=color, mec=INK, mew=.4, ms=4,
                lw=.9, label=cohort)
    ax.set_xticks(x, [short[z] for z in scenarios], rotation=24, ha="right")
    ax.set_ylabel("Median nearest opposite-cohort Tanimoto")
    ax.set_title("Exact-overlap exclusion sensitivity", loc="left", fontweight="bold")
    ax.legend(frameon=False); ax.set_ylim(0, .7)
    clean(ax); panel_label(ax, "D")

    fig.suptitle("Figure 2—figure supplement 6 | Chemical-space context (353 source records)", x=.01, y=.995,
                 ha="left", fontsize=10, fontweight="bold")
    save_figure(fig, "Figure2_S6_current_chemical_space_context")


def make_workbook() -> None:
    index_rows = []
    workbook = TAB / "Figure2_SI_current_tables_20260929.xlsx"
    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        for i, name in enumerate(INPUTS):
            if not name.endswith(".csv"):
                continue
            d = pd.read_csv(SOURCE / name)
            sheet = name.removesuffix(".csv").replace("Figure2_", "")[:31]
            # Guarantee uniqueness after Excel's 31-character limit.
            base = sheet; k = 1
            while sheet in [x["sheet"] for x in index_rows]:
                suffix = f"_{k}"; sheet = base[:31-len(suffix)] + suffix; k += 1
            d.to_excel(writer, sheet_name=sheet, index=False)
            index_rows.append({
                "sheet": sheet, "source_file": name, "rows": len(d), "columns": len(d.columns),
                "blank_cells": int(d.isna().sum().sum()), "sha256": sha256(SOURCE/name),
            })
        pd.DataFrame(index_rows).to_excel(writer, sheet_name="INDEX", index=False)
    # Reorder INDEX first and freeze/header-format every sheet.
    from openpyxl import load_workbook
    wb = load_workbook(workbook)
    wb._sheets.insert(0, wb._sheets.pop(wb.sheetnames.index("INDEX")))
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.font = cell.font.copy(bold=True, color="FFFFFF")
            cell.fill = cell.fill.copy(fill_type="solid", fgColor="343A46")
        for col in ws.columns:
            width = min(48, max(10, max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200]) + 2))
            ws.column_dimensions[col[0].column_letter].width = width
    wb.save(workbook)


def write_docs() -> None:
    captions = """# Figure 2 Supporting Information captions — current release 2026-09-29

## Figure 2—figure supplement 1. Cohort composition and historical calibration

**A,** Compound counts and 100 nM active fractions for all 19 literature source groups (1,434 measurements). Colours mark the prespecified strong, stress and other cohorts. **B,** Experimental pIC50 distributions. The 100 nM boundary is pIC50=7. **C,** Historical Boltz-2 calibration over all 1,434 literature measurements; the diagonal is identity and hexbin colour reports density. **D,** Source-level Spearman association versus source-group sample size. Point area scales with group size. Source heterogeneity and sample-size association are descriptive and are not evidence of causation.

## Figure 2—figure supplement 2. Current global estimates and source-group robustness

**A–B,** Pooled and within-source Spearman correlations for the strong cohort (N=139) and the identity-corrected stress cohort (N=213). Horizontal intervals are source-stratified compound-bootstrap 95% intervals. **C,** Every leave-one-source-group-out pooled estimate versus its full-cohort estimate. **D,** Change in pooled correlation after each source exclusion. LOGO values are sensitivity estimates, not confidence intervals. Glide is included as a comparator; score orientation follows the accepted source tables.

## Figure 2—figure supplement 3. Ten-compound secondary-seed sensitivity

**A,** Affinity output for the first and second structure-prediction seeds, shown for WT and three perturbation variants. **B,** Case-level seed-2 minus seed-1 changes. **C,** Median absolute and signed changes. This is a prediction-only pilot of ten stress compounds per variant and does not represent all 213 endpoint-linked or 214 structure-only stress records. Probability-head outputs are not interpreted as 100 nM activity probabilities.

## Figure 2—figure supplement 4. Alanine-perturbation response

The two readouts of the alanine ladder that the six-panel main figure does not carry, drawn from the same tables and in the same style as the panels that remain there. **A,** Spearman ρ between each perturbed prediction and the same-batch WT prediction, drawn as the fall from 1, for the strong (N=139) and structure-only stress (N=214) cohorts; the dashed line at 1 is a reference, not an observation, because a ranking compared with itself is 1 by construction, so no marker is drawn on it. This is prediction against prediction and no experimental label enters, so a high value means the order was retained and **not** that the model failed to respond to the sequence — main panel E shows that it did. Intervals are 5,000 source-stratified paired draws with indices shared across arms and compounds. **B,** Pocket Cα RMSD against ligand-centroid displacement, both after a global Cα fit to the same compound's WT prediction, for all 1,059 compound–arm pairs of the structure-only cohorts (strong 139, stress 214); the cross is each arm's median with its interval on both axes, and the ligand axis is logarithmic from 0.005 Å, below the smallest value in the data. Read across the arms the two metrics look tightly coupled (ρ=+0.80); within any single arm they are much weaker (+0.19 to +0.50), so most of the apparent coupling is arm identity. Centroid displacement is not a ligand heavy-atom RMSD and neither axis measures agreement with a crystal pose; coordinate fits are inherited from the validated remote collection and no local refit was performed.

## Figure 2—figure supplement 5. Geometry and perturbation-design audit

**A–C,** Protein Cα RMSD, pocket Cα RMSD after global fitting, and ligand-centroid displacement for the strong (N=139) and structure-only stress (N=214) cohorts. **D,** Joint protein and ligand displacement across all 1,059 WT–variant coordinate pairs. Values are the validated remote-collector fits; no independent local coordinate refit was performed. These coordinate diagnostics do not establish experimental effects and should not be read as a protein superposition.

## Figure 2—figure supplement 6. Chemical-space context

**A,** Morgan-fingerprint PCA for 353 source records (139 strong, 214 structure-only stress). **B,** Standardized descriptor mean differences; positive values indicate larger strong-cohort means. **C,** Cross-cohort overlap under exact-identity and scaffold definitions. **D,** Nearest opposite-cohort similarity under exact-overlap exclusion scenarios. The 353 entries are source records rather than 353 unique chemicals. Descriptor comparisons and exact source-level permutation p values are exploratory; none of the source-permutation descriptor tests remains below 0.05 after BH adjustment.
"""
    (OUT / "CAPTIONS.md").write_text(captions)

    source_map = """# Source map

This release was rebuilt from the active CSV files in `../tables/` on 2026-09-29. No pre-correction rendered figure was read or copied.

| SI figure | Direct numerical sources | Scope |
|---|---|---|
| S1 cohort/calibration | S01_group_landscape; S01_all_compound_potency; S01_errors_by_group; S02_calibration_points | literature 1,434; endpoint-linked stress N=213 where cohort labels are summarized |
| S2 global/LOGO | S03_global_primary_and_hierarchical_CI; S10_leave_one_group_out | strong N=139; endpoint-linked stress N=213 |
| S3 seed sensitivity | S07_stress_secondary_seed_points; S07_stress_secondary_seed_summary | prediction-only 10 compounds × 4 variants |
| S4 perturbation response | the main figure's own `Figure2_moved_to_SI_rank_retention`, `_geometry_summary` and `_geometry_points`, copied into `tables/source_csv/` as `Figure2_S4_*` | both structure-only: strong 139, stress 214; 1,059 WT–variant pairs |
| S5 geometry/design | S08_all_geometry_and_pairs; S08_all_geometry_summary; S08 experiment/variant/map audit files | structure-only strong 139 + stress 214 = 353 records; 1,059 WT–variant pairs |
| S6 chemical space | S11_PCA_coordinates; S11_PCA_variance; S11_descriptor_comparison; S11_identity_scaffold_overlap; S11_exact_overlap_exclusion_sensitivity | 353 source records, not 353 unique chemicals |

Exact copies of all listed source tables are in `tables/source_csv/`; SHA-256 values are in `MANIFEST_SHA256.csv` and the workbook INDEX.
"""
    (OUT / "SOURCE_MAP.md").write_text(source_map)

    scope = """# Scope assertions

1. Endpoint-linked stress analyses use **N=213** after excluding `1-7-6`, whose simulated structure could not be linked to the registered 940 nM experiment.
2. Strong endpoint analyses use **N=139**.
3. Historical calibration uses **1,434** literature measurements across 19 source groups.
4. Coordinate and chemical-space analyses are structure-only and retain the registered stress **N=214**, giving **N=353 source records** with strong N=139. These are not 353 unique chemicals.
5. The secondary-seed analysis is a prediction-only **10-compound pilot** per variant. It is neither the endpoint N=213 set nor a complete repeat of all 214 stress structures.
6. Bootstrap intervals in S2 A–B are source-stratified compound-bootstrap intervals. LOGO folds in S2 C–D are sensitivity estimates, not confidence intervals.
6a. S4 A is **prediction against prediction**: no experimental label enters it, so a retained ranking is not evidence that the model ignored the sequence, and the dashed reference at 1 is a construction, not an observation. Its paired intervals are 5,000 source-stratified paired draws with indices shared across arms. The label-based view of the same perturbation is main panel F, where five of the six paired AUC changes include zero — a failure to detect a change, not a demonstration of equivalence.
6b. S4 B's pooled correlation between score change and structural change is not evidence that the two move together: it reverses within every arm, and the within-arm range is quoted beside it.
7. Geometry values are validated remote-collector fits. No independent local coordinate refit or protein-superposition claim is made.
8. Chemical-space p values are exploratory; no causal interpretation is assigned to cohort composition.
"""
    (OUT / "SCOPE_ASSERTIONS.md").write_text(scope)

    withheld = """# Withheld analyses

The following older SI analyses were **not** regenerated because a current identity-corrected numerical table was not available in the active Figure 2 SI directory. They remain excluded instead of being filled with older values or guesses:

- molecular-size controls linked to refreshed physics values;
- paired method-difference bootstrap tables;
- recovery curves and recovery metrics;
- historical label-threshold/association panels;
- probability-head versus endpoint association analyses;
- strict-identity Glide subset and five-method paired differences.

The active package includes only the five supplements that can be rebuilt from accepted current tables. Pre-2026-09-24 rendered figures remain style references and are not publication inputs.
"""
    (OUT / "WITHHELD_ANALYSES.md").write_text(withheld)

    readme = """# Figure 2 Supporting Information — current 2026-09-29 release

This is the publication-facing Figure 2 SI package rebuilt after the `1-7-6` identity exclusion, and reissued on 2026-09-29 when the main figure went from eight panels to six. It contains six current figures, their exact numerical tables, a formatted Excel workbook, captions, scope assertions, source mapping, a withheld-analysis ledger and machine-readable QA.

## Contents

- `figures/`: each figure as vector PDF/SVG and 600-dpi PNG/TIF.
- `tables/source_csv/`: byte-for-byte copies of accepted source tables.
- `tables/Figure2_SI_current_tables_20260929.xlsx`: current data workbook with INDEX first.
- `scripts/`: exact build scripts and runtime record. Supplement 4 is drawn by
  `make_figure2_si_perturbation.py`, which imports the main figure's frozen
  style, layout and panel modules from `../../rebuild/`; the other five
  supplements are drawn by `build_figure2_si.py` alone.
- `qa/`: table/figure checks and visual-contact sheet.
- `CAPTIONS.md`, `SOURCE_MAP.md`, `SCOPE_ASSERTIONS.md`, `WITHHELD_ANALYSES.md`.

Supplement 4 is new in this release and supplements 5 and 6 are the 2026-09-27 release's 4 and 5 under their new numbers; 1 to 3 are unchanged in content. The old sibling `../figures/` exports were not reused because several were rendered before the identity correction.
"""
    (OUT / "README.md").write_text(readme)


def copy_inputs() -> None:
    for name in INPUTS:
        src = SOURCE / name
        if not src.exists():
            raise FileNotFoundError(src)
        shutil.copy2(src, SRC / name)


def qa_and_manifest() -> None:
    # Numerical scope checks that must fail loudly if the active tables change.
    summaries = read("S01_all_cohort_summaries.csv").set_index("scope")
    assert int(summaries.loc["all_literature", "N"]) == 1434
    assert int(summaries.loc["strong", "N"]) == 139
    assert int(summaries.loc["stress", "N"]) == 213
    g = read("S03_global_primary_and_hierarchical_CI.csv")
    assert set(g[g.cohort == "stress"].N) == {213}
    assert set(g[g.cohort == "strong"].N) == {139}
    logo = read("S10_leave_one_group_out.csv")
    assert len(logo) == 40 and set(logo.method) == set(METHODS)
    seed = read("S07_stress_secondary_seed_points.csv")
    assert len(seed) == 40 and seed.groupby("variant").size().eq(10).all()
    geom = read("S08_all_geometry_and_pairs.csv")
    assert len(geom) == 1059 and geom[geom.cohort == "stress"].compound_id.nunique() == 214
    pca = read("S11_PCA_coordinates.csv")
    assert len(pca[pca.representation == "Morgan2048_centered"]) == 353

    required_plot_cols = {
        "S03_global_primary_and_hierarchical_CI.csv": ["estimate", "ci_low", "ci_high", "N"],
        "S10_leave_one_group_out.csv": ["full_pooled_rho", "omitted_pooled_rho"],
        "S07_stress_secondary_seed_points.csv": ["affinity_pred_value_seed1", "affinity_pred_value_seed2", "seed2_minus_seed1_affinity_log10_uM"],
        "S08_all_geometry_and_pairs.csv": ["protein_ca_rmsd_A", "pocket_ca_rmsd_after_global_fit_A", "ligand_centroid_displacement_after_global_fit_A"],
        "S11_PCA_coordinates.csv": ["PC1", "PC2"],
    }
    table_checks = []
    for name, cols in required_plot_cols.items():
        d = read(name)
        missing = int(d[cols].isna().sum().sum())
        table_checks.append({"file": name, "rows": len(d), "required_columns": ";".join(cols), "missing_required": missing, "pass": missing == 0})
        if missing:
            raise AssertionError(f"{name} has {missing} missing required plotted values")
    pd.DataFrame(table_checks).to_csv(QA / "TABLE_QA.csv", index=False)

    expected_stems = [
        "Figure2_S1_current_cohort_calibration",
        "Figure2_S2_current_global_and_LOGO_robustness",
        "Figure2_S3_current_secondary_seed_sensitivity",
        "Figure2_S4_current_perturbation_response",
        "Figure2_S5_current_geometry_design_audit",
        "Figure2_S6_current_chemical_space_context",
    ]
    rows = []
    from PIL import Image
    for stem in expected_stems:
        for ext in ["pdf", "svg", "png", "tif"]:
            path = FIG / f"{stem}.{ext}"
            rec = {"figure": stem, "format": ext, "exists": path.exists(), "bytes": path.stat().st_size if path.exists() else 0}
            if ext in {"png", "tif"} and path.exists():
                with Image.open(path) as im:
                    rec["width_px"], rec["height_px"] = im.size
                    rec["dpi_x"] = round(float(im.info.get("dpi", (0, 0))[0]))
            rows.append(rec)
    fq = pd.DataFrame(rows)
    if not fq["exists"].all() or (fq["bytes"] <= 0).any():
        raise AssertionError("missing or empty figure export")
    if (fq[fq.format.isin(["png", "tif"])]["dpi_x"] < 590).any():
        raise AssertionError("raster export below 600 dpi tolerance")
    fq.to_csv(QA / "FIGURE_EXPORT_QA.csv", index=False)

    report = {
        "status": "PASS",
        "release": "2026-09-29",
        "figures": len(expected_stems),
        "exports": len(rows),
        "scope": {"literature": 1434, "strong_endpoint": 139, "stress_endpoint": 213, "stress_structure": 214, "structure_total": 353},
        "pre_correction_renders_reused": False,
        "withheld_analyses_documented": True,
    }
    (QA / "QA_SUMMARY.json").write_text(json.dumps(report, indent=2))

    # A compact visual-QA sheet is built from the release PNGs, never from the
    # superseded sibling figures.
    from PIL import Image, ImageDraw
    cards = []
    for stem in expected_stems:
        im = Image.open(FIG / f"{stem}.png").convert("RGB")
        im.thumbnail((1200, 850))
        card = Image.new("RGB", (1240, 930), "white")
        card.paste(im, ((1240 - im.width) // 2, 50))
        ImageDraw.Draw(card).text((20, 15), stem, fill="black")
        cards.append(card)
    sheet = Image.new("RGB", (2480, 930 * math.ceil(len(cards) / 2)), "white")
    for i, card in enumerate(cards):
        sheet.paste(card, ((i % 2) * 1240, (i // 2) * 930))
    sheet.save(QA / "CONTACT_SHEET.png", dpi=(150, 150))
    (QA / "VISUAL_QA.md").write_text(
        "# Visual QA\n\n"
        "PASS after inspection of `CONTACT_SHEET.png`: all six figures have visible panel labels, "
        "titles, axes and legends; no panel overlap or clipping was observed. Small labels are reserved "
        "for source IDs or annotations and remain available as vector text in PDF/SVG. The contact sheet "
        "is for review only; publication rasters are 600 dpi.\n"
    )

    records = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.name != "MANIFEST_SHA256.csv":
            records.append({"relative_path": str(path.relative_to(OUT)), "bytes": path.stat().st_size, "sha256": sha256(path)})
    pd.DataFrame(records).to_csv(OUT / "MANIFEST_SHA256.csv", index=False)


def main() -> None:
    for d in [FIG, TAB, SRC, SCRIPTS, QA]:
        d.mkdir(parents=True, exist_ok=True)
    configure_style()
    copy_inputs()
    figure_s1(); figure_s2(); figure_s3()
    figure_s4(); figure_s5(); figure_s6()
    make_workbook(); write_docs()
    shutil.copy2(Path(__file__), SCRIPTS / Path(__file__).name)
    shutil.copy2(MAIN_REBUILD / "make_figure2_si_perturbation.py",
                 SCRIPTS / "make_figure2_si_perturbation.py")
    (SCRIPTS / "RUNTIME.txt").write_text(
        "Python: /Users/wxmacbookpro/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3\n"
        f"matplotlib={mpl.__version__}\npandas={pd.__version__}\nnumpy={np.__version__}\nseaborn={sns.__version__}\n"
    )
    qa_and_manifest()
    print(OUT)


if __name__ == "__main__":
    main()
