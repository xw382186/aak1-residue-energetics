#!/usr/bin/env python3
"""Figure 2 -- what a pocket perturbation moves, and what it leaves alone.

Eight data panels on the shared 222.19 mm page, laid out by the same engine and
drawn from the same frozen style module as Figures 3 and 4.  Each answers one
question, and takes the form that answers it.

  A  how heterogeneous is literature ranking performance, source by source?
  B  what are the two cohorts' denominators, potency range and active fraction?
  C  are the two cohorts actually two chemical spaces?
  D  how strongly does each readout rank the cohort, pooled across sources?
  E  does the absolute prediction respond to the perturbation at all?
  F  how much WT-label discrimination survives the perturbation?

E and F run one alanine ladder: 2, 3 and all 16 pocket residues replaced, each
arm nested inside the next.  E asks whether the predicted affinity moves at all
and F asks whether a perturbed input still separates the compounds WT
experiments call active; the two answers do not agree, which is the point of the
pair.  Rank retention -- prediction against prediction, no experimental label --
and the geometry/score scatter ask the same question of two further readouts and
are in the supplement, drawn from the same tables.

A, C and D are the figure's other argument, and they agree with each other: the
literature source group, not the strong/stress label, is the level at which this
study varies.  A shows ranking performance differing group by group, C shows the
chemistry doing the same, and D shows what happens to a correlation when the
groups are pooled anyway.

Whether any of this is dominated by one large source group is asked in the
supporting figures (S3C), where every leave-one-source-group-out fold is drawn:
it is the same story panel D tells, and the main page states it once.

Every number is read from Figure2_derived_data_R3/, which build_figure2_data_R3.py
writes from the handoff package.  Nothing here is typed by hand.

    python3 make_figure2.py
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, FancyBboxPatch, Patch, Rectangle
from scipy.stats import gaussian_kde, spearmanr

import figure2_style as st
import figure_layout as fl

st.apply_style()

HERE = Path(__file__).resolve().parent
DATA = HERE / "Figure2_derived_data_R3"
OUT = HERE / "figure2_output"
PANELS = OUT / "panels"
PLOTTED = OUT / "panel_source_data"
for d in (OUT, PANELS, PLOTTED):
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- style refs
FS_LETTER, FS_LABEL = st.FS_LETTER, st.FS_LABEL
FS_TICK, FS_NOTE, FS_ANNOT = st.FS_TICK, st.FS_NOTE, st.FS_ANNOT
FS_TICK_DENSE, FS_LEGEND_DENSE = st.FS_TICK_DENSE, st.FS_LEGEND_DENSE
LW_EDGE, LW_ZERO, LW_GRID = st.LW_EDGE, st.LW_ZERO, st.LW_GRID
LW_REF, LW_CURVE = st.LW_REF, st.LW_CURVE
EDGE, ANNOT_GREY, GRID_GREY, REF_GREY = st.EDGE, st.ANNOT_GREY, st.GRID_GREY, st.REF_GREY
COHORT_COLORS = st.COHORT_COLORS
ERR_KW = st.ERR_KW

RULE_GREY = "#C8CCD2"
BLOCK_INK = "#22262C"

METHODS = ["Boltz-2", "Glide gscore", "MM/GBSA", "ASGB total dH",
           "ASGBIE total dG"]
METHOD_MARKERS = {"Boltz-2": "o", "Glide gscore": "P", "MM/GBSA": "s",
                  "ASGB total dH": "D", "ASGBIE total dG": "^"}

# The audited docking baseline is a fifth readout, and the frozen style module
# carries four.  Like the ALA ramp below, its colour is declared here rather
# than added to the fingerprint.
#
# Olive, and chosen by measurement rather than by eye.  A first attempt at brown
# (#8C613C) failed twice: its chroma was 0.076, under the 0.10 floor, so it read
# grey; and it sat dE 10.0 from the stress cohort's red, which a reader carries
# across from panels A and B.  This one is dE 19.8 or better from all four
# frozen method colours, 15.6 from the stress red, has chroma 0.10, and its
# relative luminance 0.124 is 0.069 clear of the nearest method, so the five
# rows stay separable in greyscale.  It adds no new worst pair: panel D's
# tightest pairs are the frozen purple/blue and red/orange, which are the same
# with and without it and are carried by the distinct markers.
# verify_figure2.py asserts each of those numbers.
GLIDE_COLOR = "#796006"
METHOD_COLORS = dict(st.METHOD_COLORS, **{"Glide gscore": GLIDE_COLOR})
COHORTS = ["strong", "stress"]
COHORT_LABEL = {"strong": "strong", "stress": "stress"}

# ------------------------------------------------------- the ALA arm palette
# NEW in this figure, and deliberately NOT added to figure2_style.py: the frozen
# style fingerprint covers Figures 2-4 as they were shipped, and a mapping
# introduced here has not earned a place in it.  It is declared once, here, and
# verify_figure2.py asserts every ALA mark uses it.
#
# The four arms are an ordered ladder -- 0, 2, 3 and 16 side chains replaced by
# alanine -- so they take a single-hue sequential ramp, light to dark, rather
# than four categorical hues.  WT is the reference rather than a rung, so it is
# the near-black ink the figure already uses for emphasis.  The ramp is teal:
# far from every method hue in C, so a reader never reads an arm as a method.
#
# Validated, not eyeballed: worst pair separation across all four is dE 13.8
# under protanopia and 12.2 under tritanopia (target >= 8), and the relative
# luminances 0.019 / 0.122 / 0.265 / 0.473 stay monotone in the ladder's own
# order, so the panel survives greyscale printing.  Each arm also carries its
# own marker, so identity is never colour alone.
ALA_COLORS = {"WT": "#22262C", "Pair2A": "#62CA9D",
              "Triad3A": "#009E90", "Pocket16A": "#006D74"}
ALA_MARKERS = {"WT": "o", "Pair2A": "s", "Triad3A": "^", "Pocket16A": "D"}
ARMS = ["WT", "Pair2A", "Triad3A", "Pocket16A"]
VARIANTS = ["Pair2A", "Triad3A", "Pocket16A"]

# Named for what was done to the protein, not for an internal codename.  A row
# label has to survive on its own in a small panel, so it carries the count; the
# residues themselves are spelled out once, in the figure-level key below, and
# again in the annotations.
#
# Residues are numbered as in Figure 3 -- L26, F102, Q107, the 4WSQ construct
# numbering -- so one paper does not use two schemes.  The package's mutation
# map gives the UniProt Q2M2I8 equivalents (L52, F128, Q133); the annotations
# record both.
ARM_LABEL = {"WT": "WT", "Pair2A": "2 key residues", "Triad3A": "3 key residues",
             "Pocket16A": "all 16 pocket"}
ARM_RESIDUES = {"WT": "unmutated", "Pair2A": "L26A, F102A",
                "Triad3A": "L26A, F102A, Q107A", "Pocket16A": "whole ATP-site set"}
ARM_KEY = {"WT": "WT  (unmutated)",
           "Pair2A": "2 key residues → Ala   L26A, F102A",
           "Triad3A": "3 key residues → Ala   + Q107A",
           "Pocket16A": "all 16 pocket residues → Ala"}

# Panel A prints denominators; they are read from the scope file, never typed,
# so the schematic cannot drift away from the panels it introduces.
SCOPE_DEFAULT = {"strong_N": 139, "stress_N_verified_endpoint": 213,
                 "stress_N_registered_structures": 214,
                 "strong_WT_active": 97,
                 "stress_WT_active": 98, "n_pocket_positions": 16,
                 "n_ala_WT": 0, "n_ala_Pair2A": 2, "n_ala_Triad3A": 3,
                 "n_ala_Pocket16A": 16}

METRIC_SHORT = {"pocket_ca_rmsd_after_global_fit_A": "Pocket C$\\alpha$ RMSD",
                "ligand_centroid_displacement_after_global_fit_A":
                    "Ligand centroid shift"}
METRICS = list(METRIC_SHORT)


# ------------------------------------------------------------------ helpers
def load():
    """Every table the panels draw, plus the scope the denominators come from."""
    r = lambda n: pd.read_csv(DATA / n)
    return {
        "groups": r("Figure2_group_landscape.csv"),
        "pot_pts": r("Figure2_potency_points.csv"),
        "pot_sum": r("Figure2_potency_summary.csv"),
        "global": r("Figure2_global_readouts.csv"),
        "logo": r("Figure2_leave_one_group_out.csv"),
        "delta_pts": r("Figure2_delta_points.csv"),
        "delta_sum": r("Figure2_delta_summary.csv"),
        "auc": r("Figure2_wt_label_auc.csv"),
        "roc": r("Figure2_roc_curves.csv"),
        "rank": r("Figure2_rank_retention.csv"),
        "geom_sum": r("Figure2_geometry_summary.csv"),
        "geom_pts": r("Figure2_geometry_points.csv"),
        "chem_pts": r("Figure2_chem_space_points.csv"),
        "chem_grp": r("Figure2_chem_space_groups.csv"),
        "chem_ctx": json.loads(
            (DATA / "Figure2_chem_space_context.json").read_text()),
        "variants": {v["variant"]: v for v in json.loads(
            (HERE / "Figure2_R3_source_package" / "02_SI" / "S08_geometry_design"
             / "strong_variants.json").read_text())},
        "mutmap": pd.read_csv(
            HERE / "Figure2_R3_source_package" / "02_SI" / "S08_geometry_design"
            / "strong_residue_mutation_map.csv"),
        "scope": json.loads((DATA / "Figure2_scope.json").read_text()),
        "layers": r("Figure2_scope_layers.csv"),
    }


def coupling_frame(D):
    """Every paired compound with both its score change and its geometry.

    One row per compound and arm: the join is what lets panel F ask whether the
    two moved together, which neither table can answer alone.
    """
    g = D["geom_pts"].pivot_table(index=["compound_id", "cohort", "variant"],
                                  columns="metric", values="value_A").reset_index()
    g.columns.name = None
    return D["delta_pts"].merge(g, on=["compound_id", "cohort", "variant"],
                                how="inner")


def bare(ax):
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_xticks([]), ax.set_yticks([])


def asym(v, lo, hi):
    """Error-bar lengths from an interval, never negative through rounding."""
    v, lo, hi = np.asarray(v, float), np.asarray(lo, float), np.asarray(hi, float)
    return np.vstack([np.maximum(v - lo, 0.0), np.maximum(hi - v, 0.0)])


def fix(x, dp=2):
    """An unsigned number with a real minus sign, not a hyphen."""
    return f"{x:.{dp}f}".replace("-", "−")


def sgn(x, dp=3):
    """A signed number with a real minus sign, not a hyphen."""
    return f"{x:+.{dp}f}".replace("-", "−")


def block_rows(n_blocks, per_block, gap=1.0):
    """Row centres for stacked cohort blocks, top block first.

    Returns one list of y values per block, descending, so a panel reads top to
    bottom in the same order the cohorts are named everywhere else.  `per_block`
    is one count for every block, or a list when the blocks differ -- panel C's
    do, because the two cohorts are drawn from three and five source groups.
    """
    counts = ([per_block] * n_blocks if isinstance(per_block, int)
              else list(per_block))
    if len(counts) != n_blocks:
        raise ValueError(f"{n_blocks} blocks, {len(counts)} row counts")
    ys, y = [], 0.0
    for n in counts:
        rows = [y - i for i in range(n)]
        ys.append(rows)
        y = rows[-1] - gap
    return ys


def split_axes(ax, n, gap_mm=None, ratios=None):
    """Carve one panel block into n facets that share its slot.

    The facets are cut out of the block the engine already allocated, so the
    panel can never grow past its column -- the same trick Figure 3's heatmap
    uses for its colour bar.

    The gap between facets defaults to the same width as the gap between
    panels, so the page has one spacing value rather than two: a reader should
    not be able to tell a within-panel split from a between-panel one by the
    size of the white space.
    """
    fig = ax.figure
    pos = ax.get_position()
    bare(ax)
    ax.set_navigate(False)
    if gap_mm is None:
        gap_mm = GRID.col_gap * GRID.fig_w * 25.4
    gap = gap_mm / 25.4 / fig.get_figwidth()
    span = pos.width - gap * (n - 1)
    r = list(ratios) if ratios else [1.0] * n
    ws = [span * v / sum(r) for v in r]
    out, x = [], pos.x0
    for w in ws:
        out.append(fig.add_axes([x, pos.y0, w, pos.height]))
        x += w + gap
    return out


def panel_N(D, letter, cohort):
    """The denominator this panel is bound to, from the scope-layer table.

    Figure 2 carries two stress denominators -- 213 where a panel needs an
    experimental endpoint and 214 where it does not -- so no single global
    stress_N is a correct thing for this module to hold.  Exactly one layer
    may claim a letter, so a panel can never silently fall back to a default.
    """
    claims = [r for r in D["layers"].itertuples()
              if letter in [t.strip() for t in str(r.panels).split(";")]]
    assert len(claims) == 1, (
        f"panel {letter}: {len(claims)} scope layers claim it")
    return int(getattr(claims[0], f"{cohort}_N"))


def block_label(ax, y, text, n):
    """A cohort's name and denominator, above its block of rows."""
    ax.text(0.011, y, f"{text}  n = {n}", transform=ax.get_yaxis_transform(),
            ha="left", va="bottom", fontsize=FS_NOTE, fontweight="bold",
            color=BLOCK_INK, clip_on=False)


# ==========================================================================
# A -- how heterogeneous is literature ranking performance?     (forest)
# ==========================================================================
def panel_landscape(ax, D):
    """Every source group the study draws on, ranked by its own Boltz-2 rho.

    Bars, from a real zero: rho has a meaningful origin, one of the nineteen
    groups is negative, and a bar makes both the sign and the magnitude of the
    spread readable at a glance.  Ranked on the signed value rather than on
    |rho| -- folding the negatives onto the positive side would hide exactly the
    groups the stress cohort is built from.  Each tick carries the group and its
    own N, so the denominator behind every interval is on the panel.
    """
    g = D["groups"]
    x = np.arange(len(g))
    for i, r in enumerate(g.itertuples()):
        ax.bar(i, r.boltz_spearman_rho, width=0.68,
               color=COHORT_COLORS[r.cohort_label], edgecolor=EDGE,
               linewidth=LW_EDGE, zorder=2)
        ax.errorbar([i], [r.boltz_spearman_rho],
                    yerr=asym([r.boltz_spearman_rho], [r.rho_ci_low],
                              [r.rho_ci_high]), fmt="none", zorder=3, **ERR_KW)
    ax.axhline(0, color=EDGE, lw=st.LW_AXIS, zorder=4)
    ax.set_xlim(-0.72, len(g) - 0.28)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{r.group_id}\n{r.n_compounds}" for r in g.itertuples()],
                       fontsize=FS_TICK_DENSE, linespacing=1.30)
    ax.tick_params(axis="x", length=0, pad=1.5)
    ax.set_ylim(-0.82, 1.08)
    ax.set_yticks([-0.5, 0, 0.5, 1.0])
    ax.spines["left"].set_bounds(-0.5, 1.0)
    ax.spines["bottom"].set_visible(False)
    ax.set_ylabel("Boltz-2 Spearman $\\rho$")
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)
    ax.legend(handles=[Patch(facecolor=COHORT_COLORS[c], edgecolor=EDGE,
                             linewidth=LW_EDGE, label=lab)
                       for c, lab in [("strong", "strong cohort"),
                                      ("stress", "stress cohort"),
                                      ("other", "not in MD follow-up")]],
              loc="lower left", fontsize=FS_LEGEND_DENSE, handlelength=1.0,
              handleheight=0.8, labelspacing=0.24, borderaxespad=0.25,
              handletextpad=0.45, ncol=3, columnspacing=1.1)


# ==========================================================================
# B -- what do the two cohorts contain?                    (box + strip)
# ==========================================================================
def panel_potency(ax, D):
    """Measured potency in each cohort, against the rule that defines active.

    Jitter is on the categorical axis only, so every point keeps its true pIC50.
    """
    pts, s = D["pot_pts"], D["pot_sum"].set_index("scope")
    rng = np.random.default_rng(11)
    ax.axvline(7.0, color=REF_GREY, lw=LW_REF, ls="--", zorder=1)
    for i, c in enumerate(COHORTS):
        y = 1 - i
        row = s.loc[c]
        p = pts[pts["cohort_label"] == c]["experimental_pic50"].to_numpy()
        ax.scatter(p, y + rng.uniform(-0.185, 0.185, len(p)), s=3.6,
                   color=COHORT_COLORS[c], alpha=0.55, linewidths=0, zorder=2)
        ax.plot([row.lower_boxplot_whisker, row.upper_boxplot_whisker], [y, y],
                color=EDGE, lw=0.8, zorder=3, solid_capstyle="butt")
        # Unfilled: the compounds inside the interquartile range are the ones
        # a filled box would hide, and they are the bulk of the cohort.
        ax.add_patch(Rectangle((row.q1_pic50, y - 0.29),
                               row.q3_pic50 - row.q1_pic50, 0.58,
                               facecolor="none", edgecolor=EDGE, linewidth=0.8,
                               zorder=4))
        ax.plot([row.median_pic50] * 2, [y - 0.29, y + 0.29], color=EDGE, lw=1.4,
                zorder=5)
        ax.text(4.62, y + 0.36,
                f"{c}   n = {int(row.N)}   {int(row.n_active_100nM)} active "
                f"({row.active_fraction_100nM * 100:.0f}%)",
                ha="left", va="bottom", fontsize=FS_NOTE, fontweight="bold",
                color=BLOCK_INK, zorder=6)
    ax.set_ylim(-0.78, 1.82)
    ax.set_yticks([])
    ax.spines["left"].set_visible(False)
    ax.set_xlim(4.55, 9.85)
    ax.set_xticks([5, 6, 7, 8, 9])
    ax.set_xlabel("Experimental p$IC_{50}$  (WT)")
    ax.text(7.06, -0.74, " 100 nM", ha="left", va="bottom", fontsize=FS_NOTE,
            color=ANNOT_GREY)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", color=GRID_GREY, lw=LW_GRID, zorder=0)



# ==========================================================================
# C -- are the two cohorts actually two chemical spaces?    (split strip)
# ==========================================================================
def panel_chem_space(ax, D):
    """How far each literature source group sits from the other cohort.

    One row per source group, one point per compound: the Tanimoto between that
    compound and its most similar molecule in the OTHER cohort.  The question
    the panel answers is whether "strong" and "stress" name two chemical spaces,
    and the answer is that they do not name them cleanly -- strong's 2-1 and
    stress's 2-2 are the same chemistry, while stress's 1-4, 1-7 and 1-10 sit
    far from anything in strong.  The organising level is the source group, not
    the cohort label, which is what panels A and D find in the ranking.

    Chosen over a projection plot on purpose.  The package's own two fingerprint
    PCA axes carry 30.6% of the variance, so clusters in such a plot would be an
    artefact of the projection as much as of the chemistry; a per-group neighbour
    distribution needs no projection and shows the within-cohort spread that a
    cluster picture hides.  No UMAP was computed, here or in the package.

    Three things this panel is not.  Tanimoto on a fingerprint is a similarity
    between registered structures, not an experimental identity confirmation and
    not a measure of novelty.  The bar is the interquartile range, a spread --
    every other horizontal bar in this figure is a 95% interval, so this one is
    drawn as a translucent shaft rather than a capped rule, and the key says
    which it is.  And the fingerprint ignores stereochemistry, so Tanimoto = 1
    is not the same molecule: 75 records sit at 1, of which 65 are structures
    that genuinely occur in both cohorts and 10 are not.  Only the 65 are ringed.
    """
    pts, grp, ctx = D["chem_pts"], D["chem_grp"], D["chem_ctx"]
    order = {c: grp[grp["cohort"] == c]["group_id"].tolist() for c in COHORTS}
    blocks = block_rows(len(COHORTS), [len(order[c]) for c in COHORTS], gap=1.62)
    g = grp.set_index(["cohort", "group_id"])
    rng = np.random.default_rng(st.JITTER_SEED)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", color=GRID_GREY, lw=LW_GRID, zorder=0)
    for bi, c in enumerate(COHORTS):
        col = COHORT_COLORS[c]
        # The cohort's own median, across that block only.  No source group sits
        # on it: pooling the cohort produces a summary that describes none of
        # the groups it is made of -- the artefact panels D and H also find.
        m = ctx[f"cohort_median_{c}"]
        ax.plot([m, m], [blocks[bi][-1] - 0.20, blocks[bi][0] + 0.46],
                color=REF_GREY, lw=st.LW_REF_THIN, ls="--", zorder=1)
        for gi, gid in enumerate(order[c]):
            y, r = blocks[bi][gi], g.loc[(c, gid)]
            d = pts[(pts["cohort"] == c) & (pts["group_id"] == gid)]
            v = d["tanimoto_to_opposite_cohort"].to_numpy(float)
            shared = d["exact_shared"].to_numpy(bool)
            ax.plot([r.q25, r.q75], [y, y], color=col, lw=1.4, alpha=0.45,
                    solid_capstyle="round", zorder=2)
            # Ordinary compounds above the row line, compounds whose registered
            # structure also occurs in the other cohort below it.  The vertical
            # position carries no quantity, so splitting it costs nothing, and
            # it keeps the pile at Tanimoto = 1 readable: the reader can see
            # that the pile is mostly, but not only, the shared structures.
            up = y + rng.uniform(0.06, 0.38, int((~shared).sum()))
            dn = y - rng.uniform(0.06, 0.38, int(shared.sum()))
            ax.scatter(v[~shared], up, s=2.6, color=col, alpha=0.46,
                       linewidths=0, zorder=3)
            ax.scatter(v[shared], dn, s=4.2, facecolors="none", edgecolors=col,
                       linewidths=0.45, alpha=0.80, zorder=4)
            ax.scatter([r["median"]], [y], s=22, color=col, marker="o",
                       edgecolors=EDGE, linewidths=LW_EDGE, zorder=5)
            ax.text(1.045, y, f"{int(r.n)}", transform=ax.get_yaxis_transform(),
                    ha="right", va="center", fontsize=FS_NOTE, color=ANNOT_GREY,
                    clip_on=False, zorder=6)
        block_label(ax, blocks[bi][0] + 0.45, COHORT_LABEL[c],
                    panel_N(D, "C", c))
    ys = [y for b in blocks for y in b]
    ax.set_ylim(min(ys) - 0.62, max(ys) + 1.16)
    ax.set_yticks(ys)
    ax.set_yticklabels([gid for c in COHORTS for gid in order[c]],
                       fontsize=FS_TICK)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(0, 1.045)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xlabel("Tanimoto to nearest cross-cohort neighbour")
    ax.text(1.045, max(ys) + 1.16, "n", transform=ax.get_yaxis_transform(),
            ha="right", va="bottom", fontsize=FS_NOTE, color=ANNOT_GREY,
            clip_on=False)
    # Everything the panel draws is named here rather than tagged in place:
    # the two rules and the block labels leave no clear room for floating text,
    # and four short entries in one key are easier to read than four asides.
    ax.legend(handles=[
        Line2D([], [], lw=0, marker="o", ms=3.6, color=ANNOT_GREY, mec=EDGE,
               mew=LW_EDGE, label="group median"),
        Line2D([], [], lw=1.4, color=ANNOT_GREY, alpha=0.45, label="IQR"),
        Line2D([], [], lw=st.LW_REF_THIN, ls="--", color=REF_GREY,
               label="cohort median"),
        Line2D([], [], lw=0, marker="o", ms=3.0, mfc="none", mec=ANNOT_GREY,
               mew=0.45, label="same structure in both cohorts "
                               f"({ctx['n_shared_structures']})")],
        loc="lower right", fontsize=FS_LEGEND_DENSE, handlelength=1.2,
        labelspacing=0.20, borderaxespad=0.22, handletextpad=0.45,
        # The only opaque key in the figure, and for one reason: the stress
        # block's reference rule runs behind it.  White on white, no frame --
        # the rule is interrupted, and nothing else changes.
        frameon=True, facecolor="white", edgecolor="none", framealpha=1.0)


# ==========================================================================
# D -- does the association depend on source composition?    (dumbbell)
# ==========================================================================
def methods_in(D):
    """The global readouts the data actually carries, in the frozen order.

    Read from the table rather than hard-coded, so the audited Glide baseline
    becomes a fifth method by arriving in the data -- no edit here, and the
    verifier checks the panel against whatever the table holds.
    """
    have = list(D["global"]["method"].unique())
    known = [m for m in METHODS if m in have]
    return known + [m for m in have if m not in known]


def global_frame(D):
    g = D["global"]
    w = g.pivot_table(index=["cohort", "method"], columns="statistic",
                      values=["estimate", "ci_low", "ci_high"]).reset_index()
    w.columns = ["_".join(c).strip("_") for c in w.columns]
    return w


def panel_pooled_rho(ax, D):
    """Global rank association, one bar per readout, from a real zero.

    Bars, and the pooled estimate alone: the panel is read as "how well does
    each readout rank this cohort", and a bar makes that comparison in one pass
    at the size this panel is printed.  rho has a meaningful origin, so the bar
    starts at zero -- the same reason panel A is drawn as bars.

    What a pooled bar cannot say is how much of its length was source
    composition.  That question is the supplement's: the same five readouts are
    there with their within-source estimates and both sets of intervals, and any
    sentence that turns on the difference -- Glide gscore's 0.46 on the strong
    cohort falling to -0.03 once the sources are rank-standardised -- has to cite
    it rather than this page.  The within-source column still ships in this
    panel's own source-data table, so nothing left the package with the mark.
    """
    ms = methods_in(D)
    w = global_frame(D).set_index(["cohort", "method"])
    blocks = block_rows(2, len(ms), gap=1.62)
    ax.axvline(0, color=REF_GREY, lw=LW_ZERO, ls="--", zorder=1)
    for bi, c in enumerate(COHORTS):
        for mi, m in enumerate(ms):
            y, r = blocks[bi][mi], w.loc[(c, m)]
            v = r["estimate_pooled_rho"]
            ax.barh(y, v, height=0.62, color=METHOD_COLORS.get(m, "#7D8590"),
                    edgecolor=EDGE, linewidth=LW_EDGE, zorder=3)
            ax.text(1.045, y, fix(v), transform=ax.get_yaxis_transform(),
                    ha="left", va="center", fontsize=FS_NOTE, clip_on=False,
                    zorder=6)
        block_label(ax, blocks[bi][0] + 0.45, COHORT_LABEL[c],
                    panel_N(D, "D", c))
    ys = [y for b in blocks for y in b]
    ax.set_ylim(min(ys) - 0.62, max(ys) + 1.16)
    ax.set_yticks(ys)
    ax.set_yticklabels([m for _ in COHORTS for m in ms], fontsize=FS_TICK)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(-0.16, 1.0)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xlabel("Spearman $\\rho$ vs experimental p$IC_{50}$")
    # The estimate the bars are, said once, where the eye leaves the panel.
    ax.text(0.995, min(ys) - 0.56, "pooled across sources ",
            transform=ax.get_yaxis_transform(), ha="right", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# E -- does the absolute prediction respond?                 (ridgeline)
# ==========================================================================
def panel_ridge(ax, D):
    """The whole distribution of the score change, not a summary of it.

    The median alone would say the ladder shifts the score; what it would hide
    is that the shift comes with a spread that widens with it, so a single
    compound's predicted affinity becomes progressively less pinned down.
    """
    pts = D["delta_pts"]
    s = D["delta_sum"].set_index(["cohort", "variant"])
    grid = np.linspace(-1.6, 3.4, 512)
    height, step, block_gap = 1.15, 1.0, 0.75
    bases, rows, y = {}, [], 0.0
    for c in COHORTS:
        for v in VARIANTS:
            bases[(c, v)] = y
            rows.append((c, v))
            y -= step
        y -= block_gap
    top = {c: bases[(c, VARIANTS[0])] for c in COHORTS}

    ax.axvline(0, color=REF_GREY, lw=LW_ZERO, ls="--", zorder=1)
    for i, (c, v) in enumerate(rows):
        base = bases[(c, v)]
        x = pts[(pts["cohort"] == c) & (pts["variant"] == v)]["delta_log10_ic50"]
        dens = gaussian_kde(x)(grid)
        dens = dens / dens.max() * height
        ax.fill_between(grid, base, base + dens, facecolor=ALA_COLORS[v],
                        alpha=0.42, linewidth=0, zorder=2 + i)
        ax.plot(grid, base + dens, color=ALA_COLORS[v], lw=1.0, zorder=2 + i,
                solid_capstyle="round")
        ax.plot([grid[0], grid[-1]], [base, base], color="#C8CCD2", lw=0.6,
                zorder=1)
    for c, v in rows:
        base, r = bases[(c, v)], s.loc[(c, v)]
        ax.plot([r.ci_low, r.ci_high], [base, base], color=EDGE, lw=1.6,
                solid_capstyle="butt", zorder=20)
        ax.scatter([r.estimate], [base], s=24, color=ALA_COLORS[v],
                   marker=ALA_MARKERS[v], edgecolors=EDGE, linewidths=LW_EDGE,
                   zorder=21)
    for c in COHORTS:
        ax.text(0.011, top[c] + 0.30,
                f"{COHORT_LABEL[c]}  n = {panel_N(D, 'E', c)}",
                transform=ax.get_yaxis_transform(), ha="left", va="bottom",
                fontsize=FS_NOTE, fontweight="bold", color=BLOCK_INK,
                clip_on=False, zorder=22)
    ax.set_yticks([bases[r] for r in rows])
    ax.set_yticklabels([ARM_LABEL[v] for _, v in rows], fontsize=FS_TICK)
    ax.tick_params(axis="y", length=0)
    ax.set_ylim(min(bases.values()) - 0.28, height + 0.62)
    ax.set_xlim(-1.6, 3.4)
    ax.set_xticks([-1, 0, 1, 2, 3])
    ax.set_xlabel("$\\Delta$ predicted log$_{10}$ $IC_{50}$  (mutant $-$ WT)")
    ax.text(3.34, height + 0.56, "weaker binding predicted →", ha="right",
            va="top", fontsize=FS_NOTE, color=ANNOT_GREY)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# F -- how much WT-label discrimination survives?           (ROC, 2 facets)
# ==========================================================================
def panel_roc(ax, D):
    """The full ROC curve for each arm, the two cohorts side by side.

    The curves rather than the four numbers they reduce to: an AUC hides where
    the separation is won, and here the arms differ mostly in the first tenth of
    the false-positive axis.  The AUC is printed anyway, with the paired change
    against the same-batch WT, because two overlapping curves are not a test of
    a difference.

    Labels are WT measurements throughout, so this is the ranking's usefulness
    under perturbation -- not accuracy against mutant experiments, which do not
    exist.
    """
    roc, f = D["roc"], D["auc"].set_index(["cohort", "variant"])
    axes = split_axes(ax, 2)
    for k, (a, c) in enumerate(zip(axes, COHORTS)):
        a.plot([0, 1], [0, 1], color="#9AA1AC", lw=st.LW_REF_THIN, ls="--",
               zorder=1)
        for arm in ARMS:
            d = roc[(roc["cohort"] == c) & (roc["variant"] == arm)] \
                .sort_values(["fpr", "tpr"])
            a.plot(d["fpr"], d["tpr"], color=ALA_COLORS[arm], lw=1.35, zorder=3)
        a.set_xlim(0, 1), a.set_ylim(0, 1)
        a.set_xticks([0, 0.5, 1.0]), a.set_yticks([0, 0.5, 1.0])
        a.set_xlabel("False-positive rate")
        a.set_ylabel("True-positive rate" if k == 0 else "")
        if k:
            a.set_yticklabels([])
        a.text(0.5, 1.005, f"{COHORT_LABEL[c]}  n = {int(f.loc[(c, 'WT'), 'N'])}",
               transform=a.transAxes, ha="center", va="bottom", fontsize=FS_NOTE,
               fontweight="bold", color=BLOCK_INK, clip_on=False)
        a.text(0.560, 0.505, "random", fontsize=FS_NOTE, color=ANNOT_GREY,
               rotation=39, rotation_mode="anchor", ha="left", va="top")
        # AUC, and the paired change against WT, in the arm's own colour: four
        # curves, four rows, no key to look up.  Two right-aligned columns, both
        # inside the axes, so neither runs into the facet beside it.
        col_mark, col_auc, col_delta = 0.300, 0.615, 1.000
        a.text(col_auc, 0.330, "AUC", ha="right", va="bottom", fontsize=FS_NOTE,
               color=ANNOT_GREY, transform=a.transAxes)
        a.text(col_delta, 0.330, "$\\Delta$ vs WT", ha="right", va="bottom",
               fontsize=FS_NOTE, color=ANNOT_GREY, transform=a.transAxes)
        for i, arm in enumerate(ARMS):
            r = f.loc[(c, arm)]
            y = 0.262 - i * 0.068
            a.plot([col_mark], [y + 0.022], marker=ALA_MARKERS[arm], ms=3.2,
                   color=ALA_COLORS[arm], mec=EDGE, mew=LW_EDGE, zorder=5,
                   transform=a.transAxes, clip_on=False)
            a.text(col_auc, y, f"{r.auc:.3f}", ha="right", va="bottom",
                   fontsize=FS_NOTE, color=ALA_COLORS[arm], transform=a.transAxes)
            if arm != "WT":
                clear = (r.paired_delta_ci_low > 0) or (r.paired_delta_ci_high < 0)
                a.text(col_delta, y, sgn(r.paired_delta_auc_vs_fresh_WT, 3),
                       ha="right", va="bottom", fontsize=FS_NOTE,
                       transform=a.transAxes,
                       color=BLOCK_INK if clear else ANNOT_GREY,
                       fontweight="bold" if clear else "normal")
        a.set_axisbelow(True)
        a.grid(True, color=GRID_GREY, lw=LW_GRID, zorder=0)
    return axes


# ==========================================================================
# G -- how much does the ranking itself change?              (dumbbell)
# ==========================================================================
def panel_retention(ax, D):
    """The perturbed ranking against the same batch's WT ranking.

    Drawn as the distance from 1, because that is the quantity: a ranking
    compared with itself is 1 by construction.  That 1 is a reference line and
    nothing else -- it is not a sixth and seventh observation, so no marker is
    drawn on it, and the stems make the fall from it the thing the eye measures.  Prediction against prediction -- no experimental
    label enters -- so a high value means the order was retained, not that the
    model failed to respond to the sequence.  Panel E shows that it did.
    """
    g = D["rank"].set_index(["cohort", "variant"])
    blocks = block_rows(2, len(VARIANTS), gap=1.62)
    ax.axvline(1.0, color=REF_GREY, lw=LW_REF, ls="--", zorder=1)
    for bi, c in enumerate(COHORTS):
        for vi, v in enumerate(VARIANTS):
            y, r = blocks[bi][vi], g.loc[(c, v)]
            ax.plot([r.estimate, 1.0], [y, y], color=ALA_COLORS[v], lw=1.4,
                    alpha=0.45, solid_capstyle="round", zorder=2)
            ax.errorbar([r.estimate], [y],
                        xerr=asym([r.estimate], [r.ci_low], [r.ci_high]),
                        fmt="none", zorder=3, **ERR_KW)
            ax.scatter([r.estimate], [y], s=30, color=ALA_COLORS[v],
                       marker=ALA_MARKERS[v], edgecolors=EDGE,
                       linewidths=LW_EDGE, zorder=5)
            ax.text(1.055, y, f"{r.estimate:.2f}",
                    transform=ax.get_yaxis_transform(), ha="left", va="center",
                    fontsize=FS_NOTE, clip_on=False, zorder=6)
        # This panel is in the supplement from v2.1 on, so it has no letter to
        # bind a denominator to.  Its own table carries one -- the registered
        # 214, never the endpoint 213 -- which is what B and the ROC already do.
        block_label(ax, blocks[bi][0] + 0.45, COHORT_LABEL[c],
                    int(g.loc[(c, VARIANTS[0])].N))
    ys = [y for b in blocks for y in b]
    ax.set_ylim(min(ys) - 0.62, max(ys) + 1.16)
    ax.set_yticks(ys)
    ax.set_yticklabels([ARM_LABEL[v] for _ in COHORTS for v in VARIANTS],
                       fontsize=FS_TICK)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(0.25, 1.04)
    ax.set_xticks([0.4, 0.6, 0.8, 1.0])
    ax.set_xlabel("Spearman $\\rho$, mutant vs same-batch WT prediction")
    ax.text(0.995, min(ys) - 0.56, "unchanged ranking ", ha="right", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# H -- does the structure move too?                  (strips, 2 facets)
# ==========================================================================
def geometry_frame(D):
    """One row per compound and arm, with both geometry metrics side by side."""
    g = D["geom_pts"].pivot_table(index=["compound_id", "cohort", "variant"],
                                  columns="metric", values="value_A").reset_index()
    g.columns.name = None
    return g


def panel_geometry(ax, D):
    """How far the predicted structure moves, both metrics on one plane.

    The two quantities are not interchangeable and are not summaries of each
    other, so they get an axis each rather than two facets of the same picture:
    pocket backbone displacement across, ligand displacement up.  Every one of
    the 1,059 compound-arm pairs is a point, and the cross is that arm's
    published median with its interval on both axes.

    Read across the arms the two look tightly coupled (rho = 0.80).  Within any
    single arm they are much weaker (0.19 to 0.50): most of the apparent
    coupling is arm identity, the same artefact panel D finds in the
    source-pooled correlations.  Both numbers are printed, so the panel cannot
    be read as the pooled one alone.

    The ligand axis is logarithmic and starts below the smallest value in the
    data (0.0088 A), because a floor at 0.02 would silently drop two compounds;
    the pocket axis is linear and reaches past the largest (1.83 A).  Neither is
    a crystal-pose accuracy, and the ligand metric is a centroid displacement,
    not a heavy-atom RMSD.
    """
    m = geometry_frame(D)
    RM, CE = METRICS[0], METRICS[1]
    s_ = D["geom_sum"].set_index(["metric", "cohort", "variant"])
    for c in COHORTS:
        for v in VARIANTS:
            d = m[(m["cohort"] == c) & (m["variant"] == v)]
            ax.scatter(d[RM], d[CE], s=3.0, color=ALA_COLORS[v], alpha=0.32,
                       linewidths=0, zorder=2)
    for c in COHORTS:
        for v in VARIANTS:
            rx = s_.loc[(RM, c, v)]
            ry = s_.loc[(CE, c, v)]
            ax.errorbar([rx["median"]], [ry["median"]],
                        xerr=asym([rx["median"]], [rx.ci_low], [rx.ci_high]),
                        yerr=asym([ry["median"]], [ry.ci_low], [ry.ci_high]),
                        fmt="none", zorder=4, **ERR_KW)
            ax.scatter([rx["median"]], [ry["median"]], s=30, color=ALA_COLORS[v],
                       marker=ALA_MARKERS[v], edgecolors=EDGE,
                       linewidths=LW_EDGE, zorder=5)
    ax.set_yscale("log")
    ax.set_ylim(0.005, 50)
    ax.set_yticks([0.01, 0.1, 1, 10])
    ax.set_yticklabels(["0.01", "0.1", "1", "10"])
    ax.set_xlim(0, 2.0)
    ax.set_xticks([0, 0.5, 1.0, 1.5, 2.0])
    ax.set_xlabel("Pocket C$\\alpha$ RMSD (Å)")
    ax.set_ylabel("Ligand centroid shift (Å)")
    pooled = spearmanr(m[RM], m[CE]).statistic
    within = [spearmanr(d[RM], d[CE]).statistic for _, d in m.groupby("variant")]
    ax.text(0.030, 0.975, f"across arms  $\\rho$ = {pooled:+.2f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=FS_NOTE,
            fontweight="bold", color=BLOCK_INK, zorder=6)
    ax.text(0.030, 0.878,
            f"within arm  $\\rho$ = {min(within):+.2f} to {max(within):+.2f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=FS_NOTE,
            color=ANNOT_GREY, zorder=6)
    ax.text(0.970, 0.035, "after global C$\\alpha$ fit; not a crystal-pose\n"
            "accuracy, and not a heavy-atom RMSD", transform=ax.transAxes,
            ha="right", va="bottom", fontsize=FS_NOTE, color=ANNOT_GREY,
            linespacing=1.35, zorder=6)
    ax.set_axisbelow(True)
    ax.grid(True, color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# Assembly
# ==========================================================================
# Letters only.  Every heading below is kept verbatim in FIGURE2_ANNOTATIONS.md
# and the verifier asserts it is still there.
TITLES = {k: (None, None) for k in "ABCDEF"}
TITLES["_rail"] = (None, None)
CAPTION_HEADINGS = {
    "A": ("Source-group ranking landscape", "19 groups; N, rho and 95% CI"),
    "B": ("Potency coverage", "WT measurements; 100 nM rule"),
    "C": ("Chemical space by source group",
          "cross-cohort nearest-neighbour Tanimoto; median and IQR"),
    "D": ("Global rank association", "pooled across sources; rho only"),
    "E": ("Absolute response to perturbation", "distribution; median and 95% CI"),
    "F": ("WT-label discrimination", "ROC; AUC and paired change vs WT"),
}
# The two panels the supplement carries keep their wording here, so the
# supplement and the page say the same thing about the same mark.
MOVED_TO_SI_HEADINGS = {
    "rank_retention": ("Prediction-rank retention",
                       "mutant vs WT prediction"),
    "geometry": ("Structural response",
                 "pocket Ca RMSD; ligand centroid shift"),
}


def arm_key(fig, y):
    """The alanine ladder, spelled out once for the two panels that use it."""
    fig.legend(handles=[Line2D([], [], lw=0, marker=ALA_MARKERS[a], ms=4.4,
                               color=ALA_COLORS[a], mec=EDGE, mew=LW_EDGE,
                               label=ARM_KEY[a]) for a in ARMS],
               loc="upper center", bbox_to_anchor=(0.52, y), ncol=4,
               frameon=False, fontsize=FS_LEGEND_DENSE, handlelength=1.0,
               columnspacing=2.0, handletextpad=0.45, borderpad=0.0)


LAYOUT = [
    [("A", panel_landscape, 2.32), ("B", panel_potency, 1.00)],
    [("C", panel_chem_space, 1.06), ("D", panel_pooled_rho, 1.24)],
    [("E", panel_ridge, 1.00), ("F", panel_roc, 1.30)],
]

PAGE_H_MM = 168.00
# (title baseline, axes top, axes bottom) in figure fractions.  The engine only
# insets a panel left and right, so every panel's x-label room lives in the gap
# between one band's bottom and the next band's title.  The arm key sits in the
# gap under row 2, above the two panels that use it.
# Spacing is Figure 3's, value for value, and v1.1's: 32.00 mm of axes per row,
# 2.53 mm from the letter's baseline to the axes top, 16.85 and 20.39 mm between
# rows, 7.19 mm of head margin and 18.45 mm of foot.  The page height that falls
# out is 168.00 mm -- Figure 3's exactly.  Dropping two panels emptied no row, so
# not one of these values had to move.
BANDS = [
    (0.9568, 0.9416, 0.7494),
    (0.6482, 0.6329, 0.4407),
    (0.3182, 0.3030, 0.1108),
]
# The arm key sits in the gap between rows 2 and 3, where Figure 3 puts its own
# method key, and at the same height in the gap.  In v1.1 it introduced four
# panels; it now introduces the two below it, and has not moved.
ARM_KEY_Y = 0.3721

GRID = fl.Grid(page_h_mm=PAGE_H_MM, rows=LAYOUT, bands=BANDS, titles=TITLES,
               rail_letter="_rail", rail_fn=None,
               left=0.0080, right=0.9940, col_gap=0.021,
               legend_y=ARM_KEY_Y, legend_fn=arm_key)


def write_plotted_values(D):
    """The numbers behind every mark, one CSV per panel."""
    D["groups"].to_csv(PLOTTED / "Figure2_panelA_plotted_values.csv", index=False)
    D["pot_sum"].to_csv(PLOTTED / "Figure2_panelB_plotted_values.csv", index=False)
    D["pot_pts"].to_csv(PLOTTED / "Figure2_panelB_points.csv", index=False)
    D["chem_grp"].to_csv(PLOTTED / "Figure2_panelC_plotted_values.csv", index=False)
    D["chem_pts"].to_csv(PLOTTED / "Figure2_panelC_points.csv", index=False)
    global_frame(D).to_csv(PLOTTED / "Figure2_panelD_plotted_values.csv",
                           index=False)
    D["delta_sum"].to_csv(PLOTTED / "Figure2_panelE_plotted_values.csv", index=False)
    D["delta_pts"].to_csv(PLOTTED / "Figure2_panelE_points.csv", index=False)
    D["auc"].to_csv(PLOTTED / "Figure2_panelF_plotted_values.csv", index=False)
    D["roc"].to_csv(PLOTTED / "Figure2_panelF_curves.csv", index=False)
    pd.DataFrame([D["scope"]]).to_csv(PLOTTED / "Figure2_scope.csv", index=False)
    D["layers"].to_csv(PLOTTED / "Figure2_scope_layers.csv", index=False)
    # Tables whose panel is in the supplement.  They still ship beside the
    # figure, under a name that says where the panel went, so nothing left the
    # package with the letter.  NOTE: Figure2_panelF_plotted_values.csv is the
    # WT-label AUC table in v1.1 and again from v2.1 on; for the length of v2.0
    # it held the rank-retention table, which is now
    # Figure2_moved_to_SI_rank_retention.csv.
    D["rank"].to_csv(PLOTTED / "Figure2_moved_to_SI_rank_retention.csv",
                     index=False)
    D["geom_sum"].to_csv(PLOTTED / "Figure2_moved_to_SI_geometry_summary.csv",
                         index=False)
    D["geom_pts"].to_csv(PLOTTED / "Figure2_moved_to_SI_geometry_points.csv",
                         index=False)
    D["logo"].to_csv(PLOTTED / "Figure2_moved_to_SI_leave_one_group_out.csv",
                     index=False)


def main():
    st.apply_style()
    for d in (PANELS, PLOTTED):
        for f in d.iterdir():
            f.unlink()
    D = load()
    pads = GRID.measure_all(D)
    rects = GRID.build(D, pads, 0.0, OUT, "Figure2",
                       exts=("pdf", "png", "svg"))
    GRID.build_panels(D, pads, rects, PANELS, "Figure2")
    write_plotted_values(D)
    print("wrote", OUT)


if __name__ == "__main__":
    main()


# ==========================================================================
# The frozen format
# ==========================================================================
# From here on the data changes and this does not.  A new data release should
# move numbers only: the page, the panel set and their order, the form each
# panel takes, the palettes, the markers, the arm naming and every spacing
# value are recorded below and hashed.  verify_figure2.py recomputes the hash
# from the live values and fails if it moves, naming the field that drifted.
#
# To take a new data release: point build_figure2_data_R2.py at the new package
# and rebuild.  Nothing in this block should need editing.  If a release
# genuinely requires a format change -- a panel added, a form replaced -- change
# it here deliberately, bump FORMAT_VERSION, and paste the new hash the verifier
# prints.  That is the only way the fingerprint moves, and it leaves a record.
#
# It has moved twice.  v1.0 was seven panels; v1.1 is eight, because the R3
# release added a chemical-space section and a panel drawn from it was asked
# for.  Inserting it third moved five letters, so `panels` and `rows` changed
# and row 2's block weights were resplit three ways -- and nothing else did.
#
# v2.1 is six, and the two moves are one story.  v2.0 sent the WT-label ROC and
# the geometry/score scatter to the supplement and kept rank retention on the
# page; v2.1 put the ROC back in F and sent rank retention the other way,
# because the page reads better when its two alanine panels are the absolute
# score and the label-based discrimination -- prediction against prediction is a
# question the supplement can hold.  Panel D changed form in v2.0 too: the
# dumbbell carrying the pooled and within-source estimates became bars of the
# pooled estimate alone.  The three rows survive as three rows of two through
# both moves, which is why the page, the bands, every gap and margin and all
# three palettes are identical to v1.1 value for value: the fields that moved
# are `panels`, `rows` and `version`, the same three v1.1 moved.
#
# Each move re-bound the scope-layer table, because Figure 2 binds its two
# stress denominators by panel letter.  F is the ROC and therefore on the
# endpoint-linked 213; rank retention and geometry read the registered 214 off
# their own tables, so no letter binds them and no panel can fall back to a
# default.  The acceptance script asserts all of that off the drawn text.
FORMAT_VERSION = "AAK1-Fig2-sixpanel-v2.1-frozen"


def _mm(v_frac, along="h"):
    return round(v_frac * (GRID.fig_h if along == "h" else GRID.fig_w) * 25.4, 2)


def figure2_format():
    """Every format decision this figure makes, as plain values."""
    return {
        "version": FORMAT_VERSION,
        "style_version": st.STYLE_VERSION,
        # -- the page
        "page_w_mm": round(fl.PAGE_W_MM, 2),
        "page_h_mm": round(PAGE_H_MM, 2),
        "grid_left": round(GRID.left, 4),
        "grid_right": round(GRID.right, 4),
        "col_gap_frac": round(GRID.col_gap, 4),
        "col_gap_mm": _mm(GRID.col_gap, "w"),
        "bands": [[round(v, 4) for v in b] for b in BANDS],
        "arm_key_y": round(ARM_KEY_Y, 4),
        # -- the spacing those bands produce, in millimetres
        "row_axes_height_mm": [_mm(t - b) for _, t, b in BANDS],
        "letter_offset_mm": [_mm(t - top) for t, top, _ in BANDS],
        "row_gap_mm": [_mm(BANDS[i][2] - BANDS[i + 1][0])
                       for i in range(len(BANDS) - 1)],
        "head_margin_mm": _mm(1 - BANDS[0][0]),
        "foot_margin_mm": _mm(BANDS[-1][2]),
        # -- the panel set: letter, the form it takes, and its block weight
        "panels": [[l, fn.__name__, round(w, 3)]
                   for row in LAYOUT for l, fn, w in row],
        "rows": [[l for l, _, _ in row] for row in LAYOUT],
        # -- what carries meaning
        "methods": list(METHODS),
        "method_colors": sorted(METHOD_COLORS.items()),
        "method_markers": sorted(METHOD_MARKERS.items()),
        "cohort_colors": sorted(COHORT_COLORS.items()),
        "arms": list(ARMS),
        "ala_colors": sorted(ALA_COLORS.items()),
        "ala_markers": sorted(ALA_MARKERS.items()),
        "glide_color": GLIDE_COLOR,
        # -- the words on the figure surface
        "arm_label": sorted(ARM_LABEL.items()),
        "arm_key": sorted(ARM_KEY.items()),
        "metric_short": sorted(METRIC_SHORT.items()),
        "titles_are_letters_only": all(t == (None, None) for t in TITLES.values()),
    }


def format_fingerprint():
    return hashlib.sha256(
        json.dumps(figure2_format(), sort_keys=True,
                   ensure_ascii=False).encode("utf-8")).hexdigest()


# Recorded when the format was frozen.  Do not edit either of these to make a
# check pass -- edit the format above, deliberately, and let the verifier print
# the new hash.
FORMAT_FINGERPRINT = "a6432dd66e6f98486afeeceddcac2a64da80f2624fe43c657bf7a5696d76a727"

FROZEN_FORMAT = {   'ala_colors': [   ('Pair2A', '#62CA9D'),
                      ('Pocket16A', '#006D74'),
                      ('Triad3A', '#009E90'),
                      ('WT', '#22262C')],
    'ala_markers': [   ('Pair2A', 's'),
                       ('Pocket16A', 'D'),
                       ('Triad3A', '^'),
                       ('WT', 'o')],
    'arm_key': [   ('Pair2A', '2 key residues → Ala   L26A, F102A'),
                   ('Pocket16A', 'all 16 pocket residues → Ala'),
                   ('Triad3A', '3 key residues → Ala   + Q107A'),
                   ('WT', 'WT  (unmutated)')],
    'arm_key_y': 0.3721,
    'arm_label': [   ('Pair2A', '2 key residues'),
                     ('Pocket16A', 'all 16 pocket'),
                     ('Triad3A', '3 key residues'),
                     ('WT', 'WT')],
    'arms': ['WT', 'Pair2A', 'Triad3A', 'Pocket16A'],
    'bands': [   [0.9568, 0.9416, 0.7494],
                 [0.6482, 0.6329, 0.4407],
                 [0.3182, 0.303, 0.1108]],
    'cohort_colors': [   ('other', '#D9DCE5'),
                         ('stress', '#BB5E5D'),
                         ('strong', '#5B84BD')],
    'col_gap_frac': 0.021,
    'col_gap_mm': 4.63,
    'foot_margin_mm': 18.45,
    'glide_color': '#796006',
    'grid_left': 0.008,
    'grid_right': 0.994,
    'head_margin_mm': 7.19,
    'letter_offset_mm': [2.53, 2.55, 2.53],
    'method_colors': [   ('ASGB total dH', '#956CB4'),
                         ('ASGBIE total dG', '#D65F5F'),
                         ('Boltz-2', '#4878D0'),
                         ('Glide gscore', '#796006'),
                         ('MM/GBSA', '#EE854A')],
    'method_markers': [   ('ASGB total dH', 'D'),
                          ('ASGBIE total dG', '^'),
                          ('Boltz-2', 'o'),
                          ('Glide gscore', 'P'),
                          ('MM/GBSA', 's')],
    'methods': [   'Boltz-2',
                   'Glide gscore',
                   'MM/GBSA',
                   'ASGB total dH',
                   'ASGBIE total dG'],
    'metric_short': [   (   'ligand_centroid_displacement_after_global_fit_A',
                            'Ligand centroid shift'),
                        (   'pocket_ca_rmsd_after_global_fit_A',
                            'Pocket C$\\alpha$ RMSD')],
    'page_h_mm': 168.0,
    'page_w_mm': 222.19,
    'panels': [   ['A', 'panel_landscape', 2.32],
                  ['B', 'panel_potency', 1.0],
                  ['C', 'panel_chem_space', 1.06],
                  ['D', 'panel_pooled_rho', 1.24],
                  ['E', 'panel_ridge', 1.0],
                  ['F', 'panel_roc', 1.3]],
    'row_axes_height_mm': [32.0, 32.0, 32.0],
    'row_gap_mm': [16.85, 20.39],
    'rows': [['A', 'B'], ['C', 'D'], ['E', 'F']],
    'style_version': 'AAK1-Fig2-FoldBench-v1.1-frozen',
    'titles_are_letters_only': True,
    'version': 'AAK1-Fig2-sixpanel-v2.1-frozen'}


def format_drift(frozen=None):
    """Which format fields differ from the frozen record, if any.

    Returns a list of (field, frozen value, live value).  An empty list is the
    only acceptable result for a data-only update.
    """
    if frozen is None:
        frozen = FROZEN_FORMAT
    live = figure2_format()
    return [(k, frozen.get(k), live.get(k))
            for k in sorted(set(frozen) | set(live))
            if frozen.get(k) != live.get(k)]
