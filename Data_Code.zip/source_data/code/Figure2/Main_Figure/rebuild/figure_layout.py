#!/usr/bin/env python3
"""
The layout engine shared by Figure 2 and Figure 3.

Both figures are built from the same three things, so that "they look alike" is
a property of the code rather than of two sets of hand-tuned numbers:

  * a fixed page whose width is identical for both figures, so a journal scales
    them by the same factor and the frozen type sizes stay frozen on paper;
  * rows of panel blocks whose axes are inset by exactly the room each panel's
    own labels need -- measured on an oversized scratch canvas, never guessed,
    because matplotlib clips get_tightbbox at the canvas edge and a snug canvas
    silently loses whatever hangs over the side;
  * a header block per panel: letter, bold title, grey sub-line, left-aligned at
    the block edge, so no title is centred over an axes and no column of the
    page is spent on a letter gutter.

Typography and rule weights come from figure2_style and are never set here.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox

import figure2_style as st
from figure2_style import ANNOT_GREY, FS_LETTER, FS_NOTE, FS_TITLE

# Both figures render at exactly this width.  Changing it changes both.
PAGE_W_MM = 222.19

LETTER_W = 0.0225                # space the bold letter takes before the title
SUBTITLE_DY = 0.0158             # grey sub-line, below the title baseline
TITLE_TO_AXES_IN = 0.345         # title baseline down to the axes top
LETTER_ASCENDER_IN = 0.183
PANEL_MARGIN_IN = 0.05
LETTER_PAD_IN = 0.12
RULE_GREY = "#C8CCD2"


def bare(ax):
    """No ticks, no spines, no background: a panel that is a drawing."""
    ax.set_xticks([]); ax.set_yticks([])
    ax.patch.set_visible(False)
    for sp in ax.spines.values():
        sp.set_visible(False)


def ink_boxes(fig, renderer):
    """Every drawn box, in inches, measured artist by artist.

    Axes.get_tightbbox clips an axis label to the axes' own span, so a centred
    x label wider than its axes is invisible to it.  Collecting the label,
    title, tick-label and annotation artists directly is the only way to learn
    how much room a panel actually needs.
    """
    inv = fig.dpi_scale_trans.inverted()
    out = []

    def add(artist):
        try:
            bb = artist.get_window_extent(renderer)
        except Exception:
            return
        if bb is None or bb.width <= 0 or bb.height <= 0:
            return
        (x0, y0), (x1, y1) = inv.transform(bb.get_points())
        out.append((x0, y0, x1, y1))

    for ax in fig.axes:
        bb = ax.get_tightbbox(renderer)
        if bb is not None:
            (x0, y0), (x1, y1) = inv.transform(bb.get_points())
            out.append((x0, y0, x1, y1))
        for a in (ax.title, ax.xaxis.label, ax.yaxis.label, ax.get_legend()):
            if a is not None:
                add(a)
        for a in ax.texts:
            add(a)
    for a in list(fig.texts) + list(fig.legends):
        add(a)
    return out


def measure_panel(fn, data, w_in, h_in, slack=3.0):
    """How far a panel's ink reaches outside its own axes rectangle, in inches."""
    fig = plt.figure(figsize=(w_in + 2 * slack, h_in + 2 * slack))
    fw, fh = fig.get_size_inches()
    ax = fig.add_axes([slack / fw, slack / fh, w_in / fw, h_in / fh])
    fn(ax, data)
    fig.canvas.draw()
    b = ink_boxes(fig, fig.canvas.get_renderer())
    pads = (slack - min(v[0] for v in b), max(v[2] for v in b) - (slack + w_in),
            slack - min(v[1] for v in b), max(v[3] for v in b) - (slack + h_in))
    plt.close(fig)
    return tuple(max(p, 0.0) for p in pads)


@dataclass
class Grid:
    """One figure's page: a left rail, a divider, and rows of panel blocks.

    `rows` is a list of rows; each row is a list of (letter, draw_fn, weight).
    `bands` is the matching list of (title baseline, axes top, axes bottom) in
    figure fractions.  Every panel's title, sub-line and letter come from
    `titles`, keyed by letter.

    `build` and `build_panels` take an optional `exts`; it defaults to the
    ("pdf", "png") the callers have always written, so adding "svg" for a
    figure that ships one changes nothing for a figure that does not.
    """

    page_h_mm: float
    rows: list
    bands: list
    titles: dict
    rail: tuple = (0.008, 0.135)
    divider_x: float = 0.1460
    left: float = 0.1580
    right: float = 0.9940
    col_gap: float = 0.021
    rail_letter: str = "A"
    rail_fn: object = None
    legend_y: float | None = None
    legend_fn: object = None
    letters: dict = field(default_factory=dict)

    # ---------------------------------------------------------------- page
    @property
    def fig_w(self):
        return PAGE_W_MM / 25.4 - 2 * st.SAVEFIG_PAD_IN

    @property
    def fig_h(self):
        return self.page_h_mm / 25.4 - 2 * st.SAVEFIG_PAD_IN

    @property
    def rail_top(self):
        return self.bands[0][1]

    def rail_aspect(self, rail_bottom):
        """x runs 0-1 over the rail's own width while y runs in figure
        fractions, so a shape drawn as a circle needs this factor."""
        return ((self.rail[1] - self.rail[0]) * self.fig_w) / \
               ((self.rail_top - rail_bottom) * self.fig_h)

    # -------------------------------------------------------------- blocks
    def block_widths(self, row):
        weights = [w for _, _, w in row]
        span = (self.right - self.left) - self.col_gap * (len(row) - 1)
        return [span * w / sum(weights) for w in weights]

    def block_left(self, letter):
        for row in self.rows:
            x = self.left
            for (l, _, _), bw in zip(row, self.block_widths(row)):
                if l == letter:
                    return x
                x += bw + self.col_gap
        return self.rail[0]

    def nominal_sizes(self):
        out = {}
        for row, (_, top, bottom) in zip(self.rows, self.bands):
            for (letter, _, _), bw in zip(row, self.block_widths(row)):
                out[letter] = (bw * self.fig_w, (top - bottom) * self.fig_h)
        return out

    def measure_all(self, data):
        """One measuring pass, at each panel's real size, before anything is drawn."""
        nominal = self.nominal_sizes()
        fns = {l: f for row in self.rows for l, f, _ in row}
        return {l: measure_panel(fns[l], data, *nominal[l]) for l in nominal}

    def rects(self, pads, rail_bottom):
        """Axes rectangles in figure fractions, one per panel letter.

        A block gets its share of the row; the axes then sits inside its block,
        inset by exactly the room that panel's own labels need.  Nothing is
        guessed, so the panels are as wide as the page can make them.
        """
        out = {self.rail_letter: (self.rail[0], rail_bottom,
                                  self.rail[1] - self.rail[0],
                                  self.rail_top - rail_bottom)}
        for row, (_, top, bottom) in zip(self.rows, self.bands):
            x = self.left
            for (letter, _, _), bw in zip(row, self.block_widths(row)):
                pl, pr, _, _ = pads[letter]
                out[letter] = (x + pl / self.fig_w, bottom,
                               bw - (pl + pr) / self.fig_w, top - bottom)
                x += bw + self.col_gap
        return out

    # -------------------------------------------------------------- header
    def header(self, fig, letter, x, y):
        """Letter, and -- when the figure carries them -- a bold title and a grey
        sub-line, left-aligned at the block edge.

        A `titles` entry of (None, None) means the panel is identified by its
        letter alone, because everything else lives in the caption.
        """
        title, sub = self.titles[letter]
        fig.text(x, y, letter, ha="left", va="baseline", fontsize=FS_LETTER,
                 fontweight="bold")
        if title:
            fig.text(x + LETTER_W, y, title, ha="left", va="baseline",
                     fontsize=FS_TITLE, fontweight="bold")
        if sub:
            fig.text(x + LETTER_W, y - SUBTITLE_DY, sub, ha="left", va="baseline",
                     fontsize=FS_NOTE, color=ANNOT_GREY)
        self.letters[letter] = (x, y)

    # ------------------------------------------------------------- compose
    def build(self, data, pads, rail_bottom, out_dir, stem,
              exts=("pdf", "png")):
        fig = plt.figure(figsize=(self.fig_w, self.fig_h))
        rects = self.rects(pads, rail_bottom)
        self.letters.clear()

        if self.rail_fn is not None:
            self.rail_fn(fig.add_axes(rects[self.rail_letter]), data)
            self.header(fig, self.rail_letter, self.rail[0], self.bands[0][0])
            fig.lines.append(plt.Line2D(
                [self.divider_x, self.divider_x],
                [rail_bottom, self.bands[0][0] + 0.010],
                transform=fig.transFigure, color=RULE_GREY, lw=0.8, zorder=0))

        for row, (title_y, _, _) in zip(self.rows, self.bands):
            for letter, fn, _ in row:
                fn(fig.add_axes(rects[letter]), data)
                self.header(fig, letter, self.block_left(letter), title_y)

        if self.legend_fn is not None and self.legend_y is not None:
            self.legend_fn(fig, self.legend_y)

        # Trim is pinned to the canvas rather than to the ink, so the printed
        # width is deterministic and identical between the two figures.
        pad = st.SAVEFIG_PAD_IN      # explicit: a Bbox is not padded by savefig
        box = Bbox.from_bounds(-pad, -pad, self.fig_w + 2 * pad,
                               self.fig_h + 2 * pad)
        for ext in exts:
            fig.savefig(out_dir / f"{stem}.{ext}", dpi=st.DPI, bbox_inches=box)
        plt.close(fig)
        return rects

    def build_panels(self, data, pads, rects, out_dir, stem,
                     exts=("pdf", "png")):
        """Every panel on its own, with its axes at exactly the composite's size."""
        fns = {self.rail_letter: self.rail_fn}
        fns.update({l: f for row in self.rows for l, f, _ in row})
        for letter, fn in fns.items():
            if fn is None:
                continue
            _, _, w, h = rects[letter]
            aw, ah = w * self.fig_w, h * self.fig_h
            pl, pr, pb, pt = pads.get(letter, (0.0, 0.0, 0.0, 0.0))
            m = PANEL_MARGIN_IN
            left = max(pl, LETTER_PAD_IN) + m
            top = max(pt, 0.34) + m
            fw, fh = left + aw + pr + m, top + ah + pb + m
            fig = plt.figure(figsize=(fw, fh))
            fn(fig.add_axes([left / fw, (pb + m) / fh, aw / fw, ah / fh]), data)
            title, sub = self.titles[letter]
            fig.text(m / fw, 1 - (m + 0.16) / fh, letter, ha="left",
                     va="baseline", fontsize=FS_LETTER, fontweight="bold")
            if title:
                fig.text((m + 0.19) / fw, 1 - (m + 0.16) / fh, title, ha="left",
                         va="baseline", fontsize=FS_TITLE, fontweight="bold")
            if sub:
                fig.text((m + 0.19) / fw, 1 - (m + 0.30) / fh, sub, ha="left",
                         va="baseline", fontsize=FS_NOTE, color=ANNOT_GREY)
            for ext in exts:
                fig.savefig(out_dir / f"{stem}_panel{letter}.{ext}", dpi=st.DPI,
                            bbox_inches=Bbox.from_bounds(0, 0, fw, fh))
            plt.close(fig)
