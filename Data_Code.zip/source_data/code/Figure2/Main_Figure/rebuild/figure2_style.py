#!/usr/bin/env python3
"""
FROZEN figure style for the AAK1 Figure 2 series.

STYLE_VERSION is fixed for the duration of this work. Every figure, panel and
future revision must import from this module rather than restating a number
inline, so that font, font sizes, line widths, colours and axis conventions
cannot drift between renders. verify_figure2.py asserts STYLE_FINGERPRINT, so
an accidental edit here fails the verification pass instead of silently
producing an inconsistent figure.

Provenance of every value
-------------------------
All of it is measured from the publication the user supplied as the style
reference, not chosen freely:

    Xu S, Feng Q, Qiao L, Wu H, Shen T, Cheng Y, Zheng S, Sun S.
    "Benchmarking all-atom biomolecular structure prediction with FoldBench."
    Nature Communications (2026) 17:442.  doi:10.1038/s41467-025-67127-3

  typeface     ArialMT / Arial-BoldMT are the embedded fonts in the article,
               and Arial is used here, including for mathtext, so rho and IC50
               do not fall back to a second typeface.  Liberation Sans, its
               metric twin, stands behind it in the stack: a machine without
               Arial renders the same layout rather than a different one.
  bar / pie    seaborn "vlag" ramp. Published 5-step sampling reads
               #7896C1 #BDC6D7 #FAF5F4 #E1B9B6 #C67875 (pixel-sampled from
               Fig 3A). The 9-step ends are used here for separation.
  line / mark  seaborn "muted" ramp, pixel-sampled from Fig 3F/3G:
               #4878D0 #EE854A #6ACC64 #D65F5F #956CB4. Four of the five are
               used; the green is dropped because green-orange separates by
               only dE 4.0 under deuteranopia.
  axes         left + bottom spines only, ticks pointing outward (Fig 3A).
  error bars   black, capped, 95% CI (Fig 3A, 4C, 6A).
  box plots    median centre line, IQR box, whiskers to 1.5 x IQR, outliers
               omitted -- the convention stated verbatim in the Fig 3D caption.
  grid         faint grey, cumulative-curve panels only (Fig 3G).
  reference    grey dashed rules with a short text tag (Fig 3E "2 A", Fig 4B).
"""

from __future__ import annotations

import matplotlib as mpl

STYLE_VERSION = "AAK1-Fig2-FoldBench-v1.1-frozen"

# ---------------------------------------------------------------- typeface
FONT_STACK = ["Arial", "Liberation Sans", "Helvetica", "DejaVu Sans"]
MATH_FONT = "Arial"

# ---------------------------------------------------------------- type sizes (pt)
FS_LETTER = 11.0        # bold panel letter
FS_TITLE = 8.0          # panel title above the axes
FS_LABEL = 7.5          # axis labels
FS_TICK = 7.0           # tick labels
FS_LEGEND = 7.0         # legend text
FS_ANNOT = 6.5          # in-panel annotation
FS_TICK_DENSE = 6.0     # Panel A: 19 two-line category labels
FS_LEGEND_DENSE = 6.2   # Panel E: five-entry in-panel legend
FS_NOTE = 6.0           # sub-panel note text

# ---------------------------------------------------------------- line weights (pt)
LW_AXIS = 0.9           # spines
LW_TICK = 0.9
LW_EDGE = 0.7           # bar / wedge / box outlines
LW_ERR = 0.9            # error-bar shaft
LW_ERR_CAP = 0.9
LW_CURVE = 1.5          # recovery curves, trend lines
LW_TREND = 1.5
LW_REF = 0.9            # grey dashed reference rules
LW_REF_THIN = 0.8
LW_ZERO = 0.8           # y = 0 baseline
LW_GRID = 0.6
LW_MEDIAN = 1.1         # box-plot median line
LW_BRACKET = 1.8        # Panel A cohort brackets

TICK_LEN = 2.8
CAPSIZE = 2.2

# ---------------------------------------------------------------- colours
# cohort identity, seaborn "vlag" (bar / pie / box fills)
COHORT_COLORS = {"strong": "#5B84BD", "stress": "#BB5E5D", "other": "#D9DCE5"}
# cohort identity, seaborn "muted" (saturated marks on a dense scatter)
COHORT_MARK_COLORS = {"strong": "#4878D0", "stress": "#EE854A", "other": "#C9CDD4"}
# readout identity, seaborn "muted" -- validated: all colour-vision checks pass
METHOD_COLORS = {
    "Boltz-2": "#4878D0",
    "MM/GBSA": "#EE854A",
    "ASGB total dH": "#956CB4",
    "ASGBIE total dG": "#D65F5F",
}
EDGE = "black"
REF_GREY = "#7F7F7F"     # dashed reference rules
ANNOT_GREY = "#4D4D4D"   # secondary annotation ink
GRID_GREY = "#E8E8E8"
OTHER_BRACKET_GREY = "#9AA3B0"

# ---------------------------------------------------------------- marks
ALPHA_BAND = 0.16        # bootstrap CI band on curves
ALPHA_STRIP = 0.50       # jittered strip points
ALPHA_BOX = 0.85         # box fill
ALPHA_SCATTER_FG = 0.70  # cohort points on Panel C
ALPHA_SCATTER_BG = 0.55  # background "other" points on Panel C
MS_STRIP = 7.0           # strip point area (pt^2)
MS_SCATTER_FG = 9.0
MS_SCATTER_BG = 5.0

# ---------------------------------------------------------------- canvas
FIG_W_IN = 8.91 # 226 mm: a wide-format figure, deliberately past the 180 mm double-column
# measure. See README for what that means at print size.
DPI = 600
JITTER_SEED = 20260903   # audit package master seed; keeps the strip reproducible

# ---------------------------------------------------------------- naming
METHODS = ["Boltz-2", "MM/GBSA", "ASGB total dH", "ASGBIE total dG"]
METHOD_DISPLAY = {
    "Boltz-2": "Boltz-2",
    "MM/GBSA": "MM/GBSA",
    "ASGB total dH": "ASGB total ΔH",
    "ASGBIE total dG": "ASGBIE total ΔG",
}
COHORT_LABEL = {
    "strong": "Strong cohort",
    "stress": "Stress cohort",
    "other": "Not in MD follow-up",
}

# ---------------------------------------------------------------- the freeze
# Type sizes and rule weights are FROZEN at this version, by explicit request.
# Layout parameters -- canvas size, margins, column and band ratios -- live in
# make_figure2.py and stay free to retune; nothing below does. Keeping the two
# apart matters: a fingerprint that also covered the canvas would fire on every
# layout tweak, and a guard that cries wolf stops being read.
#
# typography_drift() names whatever moved, so a stray edit fails loudly and
# specifically instead of shipping a figure whose type no longer matches the
# rest of the series.
TYPOGRAPHY_FROZEN = {
    "font": "Arial",
    "math_font": "Arial",
    # type sizes, pt
    "FS_LETTER": 11.0, "FS_TITLE": 8.0, "FS_LABEL": 7.5, "FS_TICK": 7.0,
    "FS_LEGEND": 7.0, "FS_ANNOT": 6.5, "FS_TICK_DENSE": 6.0,
    "FS_LEGEND_DENSE": 6.2, "FS_NOTE": 6.0,
    # rule and frame weights, pt
    "LW_AXIS": 0.9, "LW_TICK": 0.9, "LW_EDGE": 0.7, "LW_ERR": 0.9,
    "LW_ERR_CAP": 0.9, "LW_CURVE": 1.5, "LW_TREND": 1.5, "LW_REF": 0.9,
    "LW_REF_THIN": 0.8, "LW_ZERO": 0.8, "LW_GRID": 0.6, "LW_MEDIAN": 1.1,
    "LW_BRACKET": 1.8,
    # tick and cap geometry, pt
    "TICK_LEN": 2.8, "CAPSIZE": 2.2,
}


def typography_drift():
    """[(name, frozen, current)] for anything that moved. Empty means frozen."""
    live = dict(globals())
    live["font"] = FONT_STACK[0]
    live["math_font"] = MATH_FONT
    return [(k, v, live.get(k)) for k, v in TYPOGRAPHY_FROZEN.items()
            if live.get(k) != v]


# Trim to the drawn content, then re-add this margin.  Named so a figure that
# needs an exact page width can compute its canvas from it instead of guessing.
SAVEFIG_PAD_IN = 0.03

ERR_KW = dict(ecolor=EDGE, elinewidth=LW_ERR, capsize=CAPSIZE, capthick=LW_ERR_CAP)

# A change to any of these fails verification rather than shipping quietly.
STYLE_FINGERPRINT = {
    "version": STYLE_VERSION,
    "font": FONT_STACK[0],
    "math_font": MATH_FONT,
    "sizes": [FS_LETTER, FS_TITLE, FS_LABEL, FS_TICK, FS_LEGEND, FS_ANNOT,
              FS_TICK_DENSE, FS_LEGEND_DENSE, FS_NOTE],
    "widths": [LW_AXIS, LW_TICK, LW_EDGE, LW_ERR, LW_ERR_CAP, LW_CURVE, LW_TREND,
               LW_REF, LW_REF_THIN, LW_ZERO, LW_GRID, LW_MEDIAN, LW_BRACKET],
    "ticks": [TICK_LEN, CAPSIZE],
    "cohort": sorted(COHORT_COLORS.items()),
    "cohort_mark": sorted(COHORT_MARK_COLORS.items()),
    "method": sorted(METHOD_COLORS.items()),
    "greys": [REF_GREY, ANNOT_GREY, GRID_GREY, OTHER_BRACKET_GREY],
    "alphas": [ALPHA_BAND, ALPHA_STRIP, ALPHA_BOX,
               ALPHA_SCATTER_FG, ALPHA_SCATTER_BG],
    "marks": [MS_STRIP, MS_SCATTER_FG, MS_SCATTER_BG],
    "canvas": [FIG_W_IN, DPI, JITTER_SEED],
}


def apply_style() -> None:
    """Install the frozen style. Call once, before building any figure."""
    mpl.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": FONT_STACK,
        "mathtext.fontset": "custom",
        "mathtext.rm": MATH_FONT,
        "mathtext.it": f"{MATH_FONT}:italic",
        "mathtext.bf": f"{MATH_FONT}:bold",
        "mathtext.sf": MATH_FONT,
        "mathtext.tt": MATH_FONT,
        "mathtext.cal": f"{MATH_FONT}:italic",   # silences the 'cursive' fallback
        "mathtext.default": "it",
        "pdf.fonttype": 42,      # text stays editable text in the PDF
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "axes.linewidth": LW_AXIS,
        "axes.edgecolor": EDGE,
        "axes.labelsize": FS_LABEL,
        "axes.titlesize": FS_TITLE,
        "axes.titleweight": "normal",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.labelsize": FS_TICK,
        "ytick.labelsize": FS_TICK,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": TICK_LEN,
        "ytick.major.size": TICK_LEN,
        "xtick.major.width": LW_TICK,
        "ytick.major.width": LW_TICK,
        "legend.fontsize": FS_LEGEND,
        "legend.frameon": False,
        "legend.handletextpad": 0.5,
        "legend.columnspacing": 1.1,
        "legend.borderpad": 0.2,
        "figure.dpi": 120,
        "savefig.dpi": DPI,
        "savefig.bbox": "tight",
        "savefig.pad_inches": SAVEFIG_PAD_IN,
    })


def panel_letter(ax, letter: str, dx: float, dy: float) -> None:
    ax.text(dx, dy, letter, transform=ax.transAxes,
            fontsize=FS_LETTER, fontweight="bold", va="top", ha="left")
