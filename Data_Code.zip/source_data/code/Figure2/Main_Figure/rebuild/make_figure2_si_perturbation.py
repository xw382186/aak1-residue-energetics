#!/usr/bin/env python3
"""Figure 2 supplement -- the two alanine-ladder readouts that are not on the page.

v2.1 of the main figure keeps the ladder's absolute-score response (E) and its
WT-label discrimination (F) and holds these two here: rank retention, which is
prediction against prediction with no experimental label, and the coordinate
coupling between pocket displacement and ligand displacement.

The panels are drawn by the main figure's own functions, unchanged, from the
same tables, so a reader who follows the caption from the main page to this one
meets the same marks in the same colours: the alanine ramp, the arm markers and
the frozen type are the main figure's, not a second set invented for the
supplement.  The page is the main figure's width to the millimetre; only the
axes are taller, because a supplement has the room.

    python3 make_figure2_si_perturbation.py
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox

import figure2_style as st
import figure_layout as fl
import make_figure2_v2 as mf

HERE = Path(__file__).resolve().parent
# Both are module attributes so the SI build script can point them at its own
# release folders without a copy step.
OUT = HERE / "figure2_si_output"          # the four figure exports
TABLES = OUT                              # the values behind every mark

STEM = "Figure2_S4_current_perturbation_response"
SUPTITLE = ("Figure 2—figure supplement 4 | Alanine-perturbation response: "
            "prediction-rank retention and coordinate coupling")

# The page, in millimetres.  Width is the main figure's, so the two scale by the
# same factor and the frozen type sizes stay frozen on paper.
SUP_MM     = 7.20     # canvas top to the supplement title's baseline
HEAD_MM    = 8.60     # title baseline to the panel letter's baseline
LETTER_MM  = 2.53     # letter baseline to the axes top -- the main figure's
AXES_MM    = 56.00    # taller than the main page's 32.00: one row, more room
KEY_DROP_MM = 15.40   # axes bottom to the arm key, clear of the x labels
FOOT_MM    = 7.60

PANELS = [("A", mf.panel_retention, 1.00), ("B", mf.panel_geometry, 1.02)]
LEFT, RIGHT, COL_GAP = 0.0080, 0.9940, 0.021


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    st.apply_style()
    D = mf.load()

    fig_w = fl.PAGE_W_MM / 25.4 - 2 * st.SAVEFIG_PAD_IN
    fig_h_mm = SUP_MM + HEAD_MM + LETTER_MM + AXES_MM + KEY_DROP_MM + FOOT_MM
    fig_h = fig_h_mm / 25.4

    span = (RIGHT - LEFT) - COL_GAP * (len(PANELS) - 1)
    total = sum(w for _, _, w in PANELS)
    widths = [span * w / total for _, _, w in PANELS]

    # the room each panel's own labels need, measured at its real size
    pads = {l: fl.measure_panel(fn, D, bw * fig_w, AXES_MM / 25.4)
            for (l, fn, _), bw in zip(PANELS, widths)}

    top_f = 1 - (SUP_MM + HEAD_MM + LETTER_MM) / fig_h_mm
    bottom_f = top_f - AXES_MM / fig_h_mm
    letter_f = 1 - (SUP_MM + HEAD_MM) / fig_h_mm
    key_f = bottom_f - KEY_DROP_MM / fig_h_mm

    fig = plt.figure(figsize=(fig_w, fig_h))
    fig.text(0.008, 1 - SUP_MM / fig_h_mm, SUPTITLE, ha="left", va="baseline",
             fontsize=10.0, fontweight="bold")
    x = LEFT
    for (letter, fn, _), bw in zip(PANELS, widths):
        pl, pr, _, _ = pads[letter]
        fn(fig.add_axes((x + pl / fig_w, bottom_f,
                         bw - (pl + pr) / fig_w, top_f - bottom_f)), D)
        fig.text(x, letter_f, letter, ha="left", va="baseline",
                 fontsize=st.FS_LETTER, fontweight="bold")
        x += bw + COL_GAP
    mf.arm_key(fig, key_f)

    pad = st.SAVEFIG_PAD_IN
    box = Bbox.from_bounds(-pad, -pad, fig_w + 2 * pad, fig_h + 2 * pad)
    for ext in ("pdf", "svg"):
        fig.savefig(OUT / f"{STEM}.{ext}", bbox_inches=box)
    fig.savefig(OUT / f"{STEM}.png", dpi=st.DPI, bbox_inches=box)
    fig.savefig(OUT / f"{STEM}.tif", dpi=st.DPI, bbox_inches=box,
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    # the values behind every mark, beside the figure
    D["rank"].to_csv(TABLES / f"{STEM}_panelA_plotted_values.csv", index=False)
    D["geom_sum"].to_csv(TABLES / f"{STEM}_panelB_plotted_values.csv", index=False)
    D["geom_pts"].to_csv(TABLES / f"{STEM}_panelB_points.csv", index=False)
    print("wrote", OUT, f"({fl.PAGE_W_MM:.2f} x {fig_h_mm + 2 * st.SAVEFIG_PAD_IN * 25.4:.2f} mm)")


if __name__ == "__main__":
    build()
