#!/usr/bin/env python3
"""Build the current Figure 4 supplementary-information package.

Only corrected N=213 method tables, the unaffected N=143 complete-case
residue-panel table, and the accepted 2-2-109/2-2-103 case sources are used.
Historical N=214 files are intentionally excluded from rendered outputs.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import shutil
import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image


WORK = Path("/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2")
SRC = WORK / "outputs/AAK1_FIGURE4_RAW_DATA_20260924"
LEGACY_ASSET_ROOT = (
    WORK
    / "outputs/AAK1_FIGURE4_R2_MECHANISM_20260924/contacts/"
    "boltz109_103_strict_analysis/figure_assets"
)
OUT = Path("/Users/wxmacbookpro/Desktop/project/AAK1/draft/Figure/4/SI/current_20260927")

FIG = OUT / "figures"
TAB = OUT / "tables"
SCR = OUT / "scripts"
AST = OUT / "assets"
QA_DIR = OUT / "qa"

INK = "#222222"
BLUE = "#4878D0"
ORANGE = "#EE854A"
GREEN = "#6ACC64"
RED = "#D65F5F"
PURPLE = "#956CB4"
TEAL = "#137A6E"
GRAY = "#9AA0A6"
LIGHT = "#E7E9EE"
ROUTE_COLORS = {"Boltz": BLUE, "Docking": ORANGE}
PANEL_MARKERS = {"Pair": "D", "Triad": "^"}


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
            "mathtext.fontset": "custom",
            "mathtext.rm": "Arial",
            "mathtext.it": "Arial:italic",
            "mathtext.bf": "Arial:bold",
            "font.size": 7.0,
            "axes.labelsize": 7.5,
            "axes.titlesize": 8.0,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 6.3,
            "axes.linewidth": 0.75,
            "lines.linewidth": 1.15,
            "lines.markersize": 4.0,
            "xtick.major.width": 0.65,
            "ytick.major.width": 0.65,
            "xtick.major.size": 2.8,
            "ytick.major.size": 2.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.edgecolor": INK,
            "axes.labelcolor": INK,
            "text.color": INK,
            "xtick.color": INK,
            "ytick.color": INK,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def panel(ax, label: str, x: float = -0.13, y: float = 1.07) -> None:
    ax.text(x, y, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")


def clean(ax, grid: str | None = "y") -> None:
    if grid:
        ax.grid(axis=grid, color="#D9DDE3", linewidth=0.55, alpha=0.8)
        ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def save_all(fig: plt.Figure, stem: str) -> list[Path]:
    FIG.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for ext in ("pdf", "svg"):
        p = FIG / f"{stem}.{ext}"
        fig.savefig(p, bbox_inches="tight", pad_inches=0.035)
        paths.append(p)
    png = FIG / f"{stem}.png"
    fig.savefig(png, dpi=600, bbox_inches="tight", pad_inches=0.035)
    paths.append(png)
    tif = FIG / f"{stem}.tif"
    with Image.open(png) as im:
        im.save(tif, dpi=(600, 600), compression="tiff_lzw")
    paths.append(tif)
    plt.close(fig)
    return paths


def read_csv(rel: str) -> pd.DataFrame:
    return pd.read_csv(SRC / rel)


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_sources() -> dict[str, str]:
    """Copy publication-facing source tables with descriptive stable names."""
    mapping = {
        "Figure4_S1_threshold_scan_N213_all44.csv": "si_tables/current_N213_all44_energy_thresholds.csv",
        "Figure4_S2_IC50_energy_grid_N213_all440.csv": "si_tables/current_N213_full440_IC50_energy_grid.csv",
        "Figure4_S2_posthoc_positive_cells_N213.csv": "si_tables/current_N213_four_exploratory_positive_cells.csv",
        "Figure4_S3_fixed_gate_pass_fail_N213.csv": "main_plot_tables/B_fixed_gate_pass_vs_fail.csv",
        "Figure4_S3_crossroute_gate_2x2_N213.csv": "main_plot_tables/E_crossroute_gate_2x2_N213.csv",
        "Figure4_S3_crossroute_performance_N213.csv": "si_tables/current_N213_crossroute_performance.csv",
        "Figure4_S3_crossroute_energy_N213.csv": "si_tables/current_N213_crossroute_energy_statistics.csv",
        "Figure4_S3_gate_membership_N213.csv": "si_tables/current_N213_gate_membership.csv",
        "Figure4_S4_residue_panel_context_N143_K43_all43.csv": "si_tables/N143_all43_methods_K43.csv",
        "Figure4_S5_case_compound_scores.csv": "main_plot_tables/G_H_case_two_compounds_SMILES_energies.csv",
        "Figure4_S5_case_pair_identity_gate.csv": "main_plot_tables/G_H_case_pair_identity_and_gate.csv",
        "Figure4_S5_case_residue_components.csv": "main_plot_tables/H_case_two_compounds_residue_components.csv",
        "Figure4_S5_case_contacts_main.csv": "main_plot_tables/I_case_contact_plot_data.csv",
        "Figure4_S5_case_IE_windows_all40.csv": "si_tables/case_four_scores_ten_IE_windows.csv",
        "Figure4_S5_case_IE_window_direction_summary.csv": "si_tables/case_IE_window_direction_summary.csv",
        "Figure4_S5_case_selection_all10785_pairs.csv": "si_tables/case_all10785_pairs_with_failures.csv",
        "Figure4_S5_case_primary_source_verification.csv": "source_records/case_primary_source_verification.csv",
    }
    for dst, rel in mapping.items():
        copy_file(SRC / rel, TAB / dst)

    for cid in ("2-2-109", "2-2-103"):
        for name in (
            "contacts_summary.csv",
            "contacts_10windows.csv",
            "Hbond_residue_any_summary.csv",
            "Hbond_all_10windows.csv",
            "Hbond_all_chemically_valid_candidates.csv",
            "analysis_QA.json",
            "representative_selection.json",
        ):
            src = SRC / "si_tables/case_geometry" / cid / name
            copy_file(src, TAB / "case_geometry" / cid / name)
        for name in ("representative_complex_heavy.pdb", "representative_ligand.sdf"):
            src = SRC / "structure_sources" / cid / name
            copy_file(src, AST / cid / name)
    copy_file(SRC / "structure_sources/medoid_interaction_geometry.json", AST / "medoid_interaction_geometry.json")
    copy_file(SRC / "source_records/case_trajectory_export_6000frames.zip", AST / "case_trajectory_export_6000frames.zip")
    copy_file(LEGACY_ASSET_ROOT / "case_109_103_medoid_comparison.png", AST / "validated_medoid_render.png")
    copy_file(LEGACY_ASSET_ROOT / "asset_source_manifest.json", AST / "validated_medoid_render_source_manifest.json")
    copy_file(LEGACY_ASSET_ROOT / "medoid_image_crop_QA.json", AST / "validated_medoid_render_crop_QA.json")
    return mapping


def figure_s1() -> None:
    d = read_csv("si_tables/current_N213_all44_energy_thresholds.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.75, 6.0), constrained_layout=True)
    metrics = [
        ("precision", "Hit rate among retained (%)", "A"),
        ("K", "Retained compounds (K)", "B"),
        ("recall", "Active compounds recovered (%)", "C"),
        ("matched_gain_pp", "Gain over same-K Boltz-2 (pp)", "D"),
    ]
    for ax, (metric, ylabel, lab) in zip(axs.flat, metrics):
        for (route, pan), g in d.groupby(["route", "panel"], sort=False):
            g = g.sort_values("threshold_E_strict_lt", ascending=False)
            x = -g["threshold_E_strict_lt"].to_numpy()
            y = g[metric].to_numpy(dtype=float)
            if metric in {"precision", "recall"}:
                y *= 100
            ax.plot(
                x,
                y,
                marker=PANEL_MARKERS[pan],
                color=ROUTE_COLORS[route],
                linestyle="-" if pan == "Pair" else "--",
                markerfacecolor="white" if route == "Docking" else ROUTE_COLORS[route],
                markeredgecolor=ROUTE_COLORS[route],
                label=f"{route}-start {pan}",
            )
        if metric == "precision":
            ax.axhline(d["random_precision"].iloc[0] * 100, color="#777", ls=":", lw=1.0)
            ax.text(0.99, 0.04, "random = 46.0%", transform=ax.transAxes, ha="right", color="#666")
        if metric == "matched_gain_pp":
            ax.axhline(0, color="#666", lw=0.9)
        ax.axvline(2, color=PURPLE, ls=":", lw=0.9, alpha=0.8)
        ax.axvline(3, color=RED, ls=":", lw=0.9, alpha=0.8)
        ax.set_xlabel(r"Absolute energy cutoff, $|E|$ (kcal mol$^{-1}$)")
        ax.set_ylabel(ylabel)
        ax.set_xlim(0.8, 7.2)
        clean(ax)
        panel(ax, lab)
    handles, labels = axs[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.53, 1.025), ncol=4, frameon=False)
    fig.suptitle("Figure 4—supplement 1 | Full threshold scan exposes the precision–coverage trade-off", y=1.045, fontsize=10, fontweight="bold")
    fig.text(
        0.5,
        -0.015,
        "N = 213; activity defined as IC$_{50}$ ≤ 100 nM. Vertical guides mark the historical Pair (2) and Triad (3) cutoffs. All 44 evaluated route × panel × threshold rows are shown.",
        ha="center",
        fontsize=6.5,
    )
    save_all(fig, "Figure4_S1_full_threshold_tradeoff_N213")


def figure_s2() -> None:
    d = read_csv("si_tables/current_N213_full440_IC50_energy_grid.csv")
    pos = read_csv("si_tables/current_N213_four_exploratory_positive_cells.csv")
    fig, axs = plt.subplots(2, 2, figsize=(8.75, 6.25), constrained_layout=True)
    vmax = float(np.nanmax(np.abs(d["matched_gain_pp"])))
    vmax = max(10.0, math.ceil(vmax / 5) * 5)
    im = None
    for ax, ((route, pan), g), lab in zip(
        axs.flat,
        d.groupby(["route", "panel"], sort=False),
        list("ABCD"),
    ):
        piv = g.pivot(index="threshold_E_strict_lt", columns="IC50_cutoff_le_nM", values="matched_gain_pp").sort_index(ascending=False)
        im = ax.imshow(piv.to_numpy(), aspect="auto", cmap="RdBu_r", vmin=-vmax, vmax=vmax, interpolation="nearest")
        ax.set_xticks(np.arange(len(piv.columns)))
        ax.set_xticklabels([str(int(x)) for x in piv.columns])
        ax.set_yticks(np.arange(len(piv.index)))
        ax.set_yticklabels([f"{abs(x):g}" for x in piv.index])
        ax.set_xlabel(r"Activity cutoff, IC$_{50}$ ≤ (nM)")
        ax.set_ylabel(r"Absolute energy cutoff, $|E|$ (kcal mol$^{-1}$)")
        ax.set_title(f"{route}-start · {pan}", fontweight="bold", color=ROUTE_COLORS[route])
        panel(ax, lab)
        # Mark the only cells whose post-hoc simultaneous lower bound is positive.
        q = pos[(pos.route == route) & (pos.panel == pan)]
        for _, row in q.iterrows():
            yy = list(piv.index).index(row.threshold_E_strict_lt)
            xx = list(piv.columns).index(row.IC50_cutoff_le_nM)
            ax.plot(xx, yy, marker="*", ms=8, mfc="none", mec=INK, mew=0.9)
        for sp in ax.spines.values():
            sp.set_visible(True)
            sp.set_linewidth(0.55)
            sp.set_color("white")
    assert im is not None
    cbar = fig.colorbar(im, ax=axs, shrink=0.82, pad=0.018)
    cbar.set_label("Hit-rate gain over same-K Boltz-2 (pp)")
    fig.suptitle("Figure 4—supplement 2 | Full IC$_{50}$ × energy scan", y=1.035, fontsize=10, fontweight="bold")
    fig.text(
        0.5,
        -0.025,
        "N = 213. Stars identify four post-hoc Docking-start cells with positive exploratory simultaneous lower bounds (IC$_{50}$ ≤ 25/50 nM; Pair |E| > 4 or Triad |E| > 6). They do not validate the historical 100 nM gates.",
        ha="center",
        fontsize=6.5,
    )
    save_all(fig, "Figure4_S2_full_IC50_energy_grid_N213")


def figure_s3() -> None:
    pf = read_csv("main_plot_tables/B_fixed_gate_pass_vs_fail.csv")
    cr = read_csv("main_plot_tables/E_crossroute_gate_2x2_N213.csv")
    perf = read_csv("si_tables/current_N213_crossroute_performance.csv")
    fig = plt.figure(figsize=(8.75, 5.3), constrained_layout=True)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.2, 1.0, 1.25])
    ax1, ax2, ax3 = [fig.add_subplot(gs[0, i]) for i in range(3)]

    # A: within-cohort gate separation.
    labels = [f"{r.route}\n{r.panel}" for _, r in pf.iterrows()]
    x = np.arange(len(pf))
    w = 0.34
    passv = pf["pass_active_fraction"].to_numpy() * 100
    failv = pf["fail_active_fraction"].to_numpy() * 100
    ax1.bar(x - w / 2, passv, width=w, color=[ROUTE_COLORS[r] for r in pf.route], edgecolor=INK, lw=0.65, label="gate+")
    ax1.bar(x + w / 2, failv, width=w, color="white", edgecolor=[ROUTE_COLORS[r] for r in pf.route], lw=0.9, hatch="//", label="gate−")
    for i, row in pf.iterrows():
        ax1.text(i - w / 2, passv[i] + 2, f"{row.TP}/{row.K}", ha="center", fontsize=5.8)
        ax1.text(i + w / 2, failv[i] + 2, f"{row.FN}/{row.n_fail}", ha="center", fontsize=5.8)
    ax1.axhline(98 / 213 * 100, color="#777", ls=":", lw=1)
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, rotation=35, ha="right")
    ax1.set_ylabel("Active fraction (%)")
    ax1.set_ylim(0, 74)
    ax1.legend(frameon=False, loc="upper left")
    clean(ax1)
    panel(ax1, "A")

    # B: exact route agreement composition.
    cats = ["both −", "Boltz only +", "Docking only +", "both +"]
    cols = [LIGHT, BLUE, ORANGE, TEAL]
    fields = ["both_negative", "boltz_only_positive", "docking_only_positive", "both_positive"]
    y = np.arange(len(cr))
    left = np.zeros(len(cr))
    for cat, col, field in zip(cats, cols, fields):
        vals = cr[field].to_numpy()
        ax2.barh(y, vals, left=left, color=col, edgecolor="white", lw=0.7, label=cat)
        for j, v in enumerate(vals):
            if v >= 14:
                ax2.text(left[j] + v / 2, j, str(int(v)), ha="center", va="center", fontsize=6, color=INK)
        left += vals
    ax2.set_yticks(y)
    ax2.set_yticklabels(cr.panel)
    ax2.set_xlabel("Compounds (N = 213)")
    ax2.set_xlim(0, 213)
    ax2.invert_yaxis()
    ax2.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2)
    clean(ax2, "x")
    panel(ax2, "B")

    # C: Docking minus Boltz route differences, expressed in pp.
    q = perf.copy()
    q["estimate_pp"] = q["estimate"] * 100
    q["lo_pp"] = q["ci_low"] * 100
    q["hi_pp"] = q["ci_high"] * 100
    # risk_difference_pp and matched_gain_pp are already percentage points.
    is_pp = q.metric.isin(["risk_difference_pp", "matched_gain_pp"])
    q.loc[is_pp, ["estimate_pp", "lo_pp", "hi_pp"]] = q.loc[is_pp, ["estimate", "ci_low", "ci_high"]].to_numpy()
    order = ["precision", "recall", "retention", "risk_difference_pp", "matched_gain_pp"]
    ybase = np.arange(len(order))[::-1]
    for pan, off, col, mark in [("Pair", -0.12, PURPLE, "D"), ("Triad", 0.12, RED, "^")]:
        qq = q[q.panel == pan].set_index("metric").loc[order]
        yy = ybase + off
        ax3.errorbar(
            qq.estimate_pp,
            yy,
            xerr=[qq.estimate_pp - qq.lo_pp, qq.hi_pp - qq.estimate_pp],
            fmt=mark,
            color=col,
            mfc=col,
            mec=INK,
            mew=0.5,
            capsize=2,
            label=pan,
        )
    ax3.axvline(0, color="#666", lw=0.9)
    ax3.set_yticks(ybase)
    ax3.set_yticklabels(["precision", "recall", "retention", "gate+ vs gate−", "vs same-K Boltz"])
    ax3.set_xlabel("Docking-start minus Boltz-start (pp)")
    ax3.legend(frameon=False, loc="lower right")
    clean(ax3, "x")
    panel(ax3, "C")

    fig.suptitle("Figure 4—supplement 3 | Fixed-gate separation and route dependence", y=1.04, fontsize=10, fontweight="bold")
    fig.text(
        0.5,
        -0.02,
        "Historical strict gates: Pair E < −2 and Triad E < −3 kcal mol$^{-1}$. The Boltz- and Docking-start routes differ in starting pose and preparation; this is not a pose-only perturbation.",
        ha="center",
        fontsize=6.5,
    )
    save_all(fig, "Figure4_S3_gate_separation_crossroute_N213")


def short_method(name: str) -> str:
    return (
        name.replace("Pair_plus_", "+")
        .replace("Triad_plus_", "+")
        .replace("Strong117_order_size", "size ")
        .replace("Boltz_affinity", "Boltz-2")
        .replace("All16_equal_weight", "all 16")
    )


def figure_s4() -> None:
    d = read_csv("si_tables/N143_all43_methods_K43.csv")
    fixed = d[d.role.isin(["fixed_baseline", "fixed"])].copy()
    pair_add = d[d.role == "all14_third_residues_exploratory"].copy()
    triad_add = d[d.role == "all13_Triad_additions_exploratory"].copy()
    larger = d[~d.index.isin(fixed.index) & ~d.index.isin(pair_add.index) & ~d.index.isin(triad_add.index)].copy()
    assert len(fixed) + len(pair_add) + len(triad_add) + len(larger) == 43

    fig, axs = plt.subplots(1, 3, figsize=(8.75, 5.9), gridspec_kw={"width_ratios": [0.85, 1.25, 1.25]}, constrained_layout=True)
    groups = [
        (fixed, "Fixed references", "A", GRAY),
        (pair_add, "Pair + one residue", "B", PURPLE),
        (triad_add, "Triad + one residue", "C", RED),
    ]
    for ax, (g, title, lab, col) in zip(axs, groups):
        g = g.copy()
        g["hit_rate"] = g.TP / g.K * 100
        g = g.sort_values(["hit_rate", "method"], ascending=[True, True])
        y = np.arange(len(g))
        colors = [BLUE if m == "Boltz_affinity" else (ORANGE if m == "L26" else col) for m in g.method]
        ax.hlines(y, 0, g.hit_rate, color="#D4D7DD", lw=1.0)
        ax.scatter(g.hit_rate, y, c=colors, s=24, edgecolor=INK, linewidth=0.55, zorder=3)
        ax.axvline(70 / 143 * 100, color="#777", ls=":", lw=0.9)
        ax.axvline(33 / 43 * 100, color=RED, ls="--", lw=0.9)
        ax.set_yticks(y)
        ax.set_yticklabels([short_method(m) for m in g.method])
        ax.set_xlim(45, 84)
        ax.set_xlabel("Actives among top 43 (%)")
        ax.set_title(title, fontweight="bold")
        clean(ax, "x")
        panel(ax, lab, x=-0.18 if lab == "A" else -0.15)
    # Replace panel C with combined Triad additions + larger panels by plotting larger as a second inset-like section.
    ax = axs[2]
    ax.clear()
    triad_add = triad_add.copy()
    larger = larger.copy()
    both = pd.concat([triad_add.assign(section="Triad + residue"), larger.assign(section="Larger panels")], ignore_index=True)
    both["hit_rate"] = both.TP / both.K * 100
    both = both.sort_values(["section", "hit_rate", "method"], ascending=[True, True, True])
    y = np.arange(len(both))
    cols = [RED if s == "Triad + residue" else GREEN for s in both.section]
    ax.hlines(y, 0, both.hit_rate, color="#D4D7DD", lw=0.9)
    ax.scatter(both.hit_rate, y, c=cols, s=20, edgecolor=INK, linewidth=0.5, zorder=3)
    ax.axvline(70 / 143 * 100, color="#777", ls=":", lw=0.9)
    ax.axvline(33 / 43 * 100, color=RED, ls="--", lw=0.9)
    ax.set_yticks(y)
    ax.set_yticklabels([short_method(m) for m in both.method], fontsize=5.5)
    ax.set_xlim(45, 84)
    ax.set_xlabel("Actives among top 43 (%)")
    ax.set_title("Triad additions and larger panels", fontweight="bold")
    clean(ax, "x")
    panel(ax, "C")
    ax.legend(
        [Patch(facecolor=RED, edgecolor=INK), Patch(facecolor=GREEN, edgecolor=INK)],
        ["Triad + one residue", "training-ordered / all-16"],
        frameon=False,
        loc="lower right",
    )

    fig.suptitle("Figure 4—supplement 4 | Complete N = 143 residue-panel context at fixed K = 43", y=1.025, fontsize=10, fontweight="bold")
    fig.text(
        0.5,
        -0.015,
        "Dotted line: random active fraction (70/143). Dashed red line: unmodified Triad (33/43).\n"
        "All 43 precomputed methods are shown; residue additions are post hoc, and no fourth-residue gain has a positive simultaneous lower bound.",
        ha="center",
        fontsize=6.5,
    )
    save_all(fig, "Figure4_S4_residue_panel_context_N143_K43")


def figure_s5() -> None:
    comps = read_csv("main_plot_tables/H_case_two_compounds_residue_components.csv")
    win = read_csv("si_tables/case_four_scores_ten_IE_windows.csv")
    contacts = read_csv("main_plot_tables/I_case_contact_plot_data.csv")
    medoid_png = LEGACY_ASSET_ROOT / "case_109_103_medoid_comparison.png"

    fig = plt.figure(figsize=(8.75, 8.0), constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.35, 1.0, 1.0])
    ax_img = fig.add_subplot(gs[0, :])
    ax_e = fig.add_subplot(gs[1, 0])
    ax_w = fig.add_subplot(gs[1, 1])
    ax_c = fig.add_subplot(gs[2, 0])
    ax_q = fig.add_subplot(gs[2, 1])

    im = mpimg.imread(medoid_png)
    # Retain the actual molecular render and frame labels, while removing the
    # older caption block; the current caption below states the limitations.
    im = im[: int(im.shape[0] * 0.77), :, :]
    ax_img.imshow(im)
    ax_img.axis("off")
    panel(ax_img, "A", x=-0.02, y=1.0)

    # B: per-residue energy contributions, explicitly retaining the contrary Q107 direction.
    labels = ["L26", "F102", "Q107"]
    x = np.arange(3)
    width = 0.18
    offsets = [-1.5, -0.5, 0.5, 1.5]
    combos = [
        ("Boltz", "2-2-109", TEAL, ""),
        ("Boltz", "2-2-103", GRAY, ""),
        ("Docking", "2-2-109", TEAL, "//"),
        ("Docking", "2-2-103", GRAY, "//"),
    ]
    for off, (route, cid, color, hatch) in zip(offsets, combos):
        g = comps[(comps.route == route) & (comps.compound_id == cid)].set_index("residue").loc[labels]
        ax_e.bar(x + off * width, g.display_E, width=width, color=color, edgecolor=INK, lw=0.55, hatch=hatch, label=f"{cid} · {route}")
    ax_e.axhline(0, color=INK, lw=0.8)
    ax_e.set_xticks(x)
    ax_e.set_xticklabels(labels)
    ax_e.set_ylabel(r"Single-residue display energy, $E$ (kcal mol$^{-1}$)")
    ax_e.legend(frameon=False, ncol=2, loc="lower left", fontsize=5.5)
    clean(ax_e)
    panel(ax_e, "B")
    ax_e.text(2.0, -2.02, "Q107 energy favors weak 103", ha="center", va="top", fontsize=6, color=RED)

    # C: within-trajectory 3 ns window directional differences (weak minus potent E).
    rows = []
    for route in ["Boltz", "Docking"]:
        for pan in ["Pair", "Triad"]:
            p = win[(win.route == route) & (win.compound_id == "2-2-109")].set_index("window")[f"{pan}_E"]
            w = win[(win.route == route) & (win.compound_id == "2-2-103")].set_index("window")[f"{pan}_E"]
            for k, val in (w - p).items():
                rows.append({"route": route, "panel": pan, "window": k, "delta": val})
    wd = pd.DataFrame(rows)
    xpos = np.arange(4)
    combos2 = [("Boltz", "Pair"), ("Boltz", "Triad"), ("Docking", "Pair"), ("Docking", "Triad")]
    rng = np.random.default_rng(20260927)
    for i, (route, pan) in enumerate(combos2):
        vals = wd[(wd.route == route) & (wd.panel == pan)].delta.to_numpy()
        jitter = rng.uniform(-0.08, 0.08, len(vals))
        ax_w.scatter(i + jitter, vals, s=13, color=ROUTE_COLORS[route], marker=PANEL_MARKERS[pan], edgecolor=INK, linewidth=0.35, alpha=0.9)
        ax_w.plot([i - 0.18, i + 0.18], [np.mean(vals), np.mean(vals)], color=INK, lw=1.1)
    ax_w.axhline(0, color="#666", lw=0.9)
    ax_w.set_xticks(xpos)
    ax_w.set_xticklabels(["Boltz\nPair", "Boltz\nTriad", "Docking\nPair", "Docking\nTriad"])
    ax_w.set_ylabel(r"Window $E_{103}-E_{109}$ (kcal mol$^{-1}$)")
    ax_w.text(0.02, 0.97, "positive = correct potency direction", transform=ax_w.transAxes, va="top", fontsize=6.2)
    clean(ax_w)
    panel(ax_w, "C")

    # D: all-frame contact / H-bond occupancies.
    order = ["L26_contact", "F102_contact", "Q107_HB_3.0A", "Q107_HB_3.5A"]
    labels2 = ["L26 contact ≤4 Å", "F102 contact ≤4 Å", "Q107 H-bond ≤3.0 Å", "Q107 H-bond ≤3.5 Å"]
    y = np.arange(4)
    for off, cid, color in [(-0.12, "2-2-109", TEAL), (0.12, "2-2-103", GRAY)]:
        q = contacts[contacts.compound == cid].set_index("metric").loc[order]
        ax_c.scatter(q.occupancy_percent, y + off, s=30, color=color, edgecolor=INK, lw=0.55, label=f"{cid} ({6 if cid.endswith('109') else 1340} nM)")
    ax_c.set_yticks(y)
    ax_c.set_yticklabels(labels2)
    ax_c.set_xlim(-3, 103)
    ax_c.set_xlabel("Frames holding interaction (%)")
    ax_c.invert_yaxis()
    ax_c.legend(frameon=False, loc="lower right", fontsize=5.8)
    clean(ax_c, "x")
    panel(ax_c, "D")

    # E: explicit geometry-energy contradiction for Q107.
    q107 = comps[comps.residue == "Q107"].pivot(index="route", columns="compound_id", values="display_E")
    energy_delta = q107["2-2-103"] - q107["2-2-109"]
    hb = contacts[contacts.metric == "Q107_HB_3.5A"].set_index("compound").occupancy_percent
    hb_delta = hb["2-2-109"] - hb["2-2-103"]
    ax_q.bar([0, 1], energy_delta.loc[["Boltz", "Docking"]], color=[ROUTE_COLORS["Boltz"], ROUTE_COLORS["Docking"]], edgecolor=INK, lw=0.6)
    ax_q.axhline(0, color=INK, lw=0.8)
    ax_q.set_xticks([0, 1])
    ax_q.set_xticklabels(["Q107 energy\nBoltz", "Q107 energy\nDocking"])
    ax_q.set_ylabel(r"$E_{103}-E_{109}$ (kcal mol$^{-1}$)")
    ax_q2 = ax_q.twinx()
    ax_q2.scatter([2], [hb_delta], s=38, marker="o", color=TEAL, edgecolor=INK, lw=0.6)
    ax_q2.set_ylabel("109−103 H-bond occupancy (pp)", color=TEAL)
    ax_q2.tick_params(axis="y", colors=TEAL)
    ax_q.set_xlim(-0.6, 2.6)
    ax_q.set_xticks([0, 1, 2])
    ax_q.set_xticklabels(["Q107 energy\nBoltz", "Q107 energy\nDocking", "Q107 H-bond\n≤3.5 Å"])
    clean(ax_q)
    panel(ax_q, "E")
    ax_q.text(0.02, 0.97, "energy < 0 favors weak 103", transform=ax_q.transAxes, va="top", fontsize=6.0, color=RED)

    fig.suptitle("Figure 4—supplement 5 | Retrospective case robustness and explicit mechanism limits", y=1.02, fontsize=10, fontweight="bold")
    fig.text(
        0.5,
        -0.012,
        "2-2-109 (6 nM) and 2-2-103 (1,340 nM) form a post-hoc, two-site substituent exchange—not a matched molecular pair.\n"
        "Ten contiguous 3 ns windows come from the same trajectory and are not independent MD replicates. Geometry was analyzed only for the Boltz-start route.",
        ha="center",
        fontsize=6.4,
    )
    save_all(fig, "Figure4_S5_case_robustness_109_vs_103")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_docs(source_mapping: dict[str, str]) -> None:
    readme = """# Figure 4 supplementary-information package — current 2026-09-27

This is the publication-facing SI package paired with the corrected Figure 4. It uses **N=213 (98 active at IC50 ≤100 nM)** for threshold and route analyses, and the separate complete-case **N=143 (70 active; K=43)** cohort for the residue-panel context. The known `1-7-6` structure/experimental-value mismatch is excluded from N=213; that record was already absent from N=143. No historical N=214 result appears in a rendered SI figure.

## Contents

- `Figure4_S1`: all 44 N=213 energy-threshold rows, including precision, retained K, recall and same-K Boltz-2 gain.
- `Figure4_S2`: the complete 440-cell IC50 × energy scan; four post-hoc positive cells are marked without presenting them as validated gates.
- `Figure4_S3`: historical-gate pass/fail separation, exact route membership and paired route contrasts.
- `Figure4_S4`: all 43 N=143/K=43 residue-panel methods, including negative and tied additions and larger panels.
- `Figure4_S5`: the retrospective 2-2-109 / 2-2-103 case, its real medoid structures, residue energies, ten same-trajectory IE windows, and full-frame contact/H-bond occupancy.

Every figure is exported as vector PDF/SVG and 600 dpi PNG/TIF. Tables retain raw numeric precision. `CAPTIONS.md`, `SOURCE_MAP.csv`, `SCOPE_ASSERTIONS.md`, `MANIFEST_SHA256.csv`, and `qa/QA.json` define interpretation and verification boundaries.
"""
    (OUT / "README.md").write_text(readme, encoding="utf-8")

    captions = """# Figure 4 supplementary captions

## Figure 4—figure supplement 1. Full energy-threshold trade-off in the corrected stress cohort.
All 44 evaluated route × panel × threshold rows are shown for N=213 compounds (98 active at IC50≤100 nM). Precision, number retained, active-compound recall and precision-point gain over same-K Boltz-2 are plotted together. The vertical guides mark the historical strict gates Pair E<−2 and Triad E<−3 kcal mol−1. Tightening a gate can raise the retained-set hit rate while reducing K and active-compound recall; the scan is exploratory rather than a newly validated cutoff selection.

## Figure 4—figure supplement 2. Complete IC50-threshold × energy-threshold sensitivity surface.
Heatmaps show the precision-point difference from same-K Boltz-2 for all 440 combinations (2 routes × 2 panels × 11 energy cutoffs × 10 IC50 activity cutoffs) in N=213. Stars mark four post-hoc Docking-start cells with positive exploratory simultaneous lower bounds at IC50≤25/50 nM (Pair |E|>4 or Triad |E|>6). These cells do not validate the historical 100 nM gate, and the family was inspected retrospectively.

## Figure 4—figure supplement 3. Historical-gate separation and cross-route dependence.
(A) Active fractions among compounds that pass or fail the strict historical gate; labels are active/total. This is a within-cohort separation and is not a matched-budget test. (B) Exact Boltz-start/Docking-start gate-membership overlap. (C) Paired Docking-minus-Boltz differences with 95% bootstrap intervals. The two routes change both input pose and molecular preparation, so the contrast is not a pose-only experiment.

## Figure 4—figure supplement 4. Complete residue-panel context in the N=143 complete-case cohort.
All 43 precomputed methods are evaluated on the same N=143 compounds (70 active) at fixed K=43. The dotted line is random prevalence and the dashed line is the unmodified Triad hit rate (33/43). Single-residue additions, training-ordered larger panels and the equal-weight all-16 panel are post-hoc analyses. L157 is the highest observed Triad addition (35/43), but no fourth-residue improvement has a positive simultaneous lower bound.

## Figure 4—figure supplement 5. Retrospective case robustness and mechanism limits.
(A) Real medoids selected from 100 evenly spaced frames of the corrected Boltz-start 20–50 ns production trajectories, after fitting the protein pocket backbone; medoid selection did not optimize an interaction or energy. (B) Single-residue display energies E=−(dH+dIE3S) for L26, F102 and Q107 in both routes. (C) Weak-minus-potent Pair and Triad energy differences in ten contiguous 3 ns IE windows, with full-window dH fixed. These windows are correlated samples from the same trajectory, not independent MD replicates. (D) L26/F102 side-chain contact occupancy and Q107 hydrogen-bond occupancy across all 6,000 Boltz-start frames. (E) Q107 geometry and energy disagree: Q107 hydrogen-bond occupancy favors potent 2-2-109, whereas the isolated Q107 display energy favors weaker 2-2-103 in both routes. The 6→1,340 nM pair is a post-hoc two-site substituent exchange, not a matched molecular pair; the occupancy difference is descriptive and is not a causal energetic explanation.
"""
    (OUT / "CAPTIONS.md").write_text(captions, encoding="utf-8")

    assertions = """# Scope assertions and non-negotiable interpretation boundaries

1. **Current denominator:** Figure 4 SI method panels use N=213 and 98 actives at IC50≤100 nM. N=143/70-active/K=43 is a separate complete-case residue-panel cohort and is labelled wherever used.
2. **Identity mismatch:** `1-7-6` is excluded from N=213 because the simulated structure does not match the registered 940 nM measurement. The record was already absent from N=143. No source file was relabelled.
3. **Exploratory scans:** threshold, IC50-grid and residue-addition analyses are post hoc. Pointwise/bootstrap intervals do not convert them into independently validated gates.
4. **Coverage trade-off:** increased precision at stricter gates must be read together with retained K and recall. Small-K tails are retained in SI.
5. **Route contrast:** Boltz-start and Docking-start differ in pose and preparation. Cross-route results are not a pose-only test.
6. **Case selection:** 2-2-109 versus 2-2-103 is retrospective, spans 6→1,340 nM, and is a two-site substituent exchange. It is not a one-site matched molecular pair or a simple molecular-growth series.
7. **Window dependence:** the ten 3 ns IE windows are contiguous windows from one trajectory per compound. They are not ten independent simulations and keep full-window dH fixed.
8. **Geometry scope:** contact and H-bond geometry was computed for corrected Boltz-start trajectories only. Per-frame measurements are temporally correlated and are descriptive.
9. **Q107 contradiction:** Q107 H-bond occupancy favors the potent compound, while the isolated Q107 ASGBIE display energy favors the weaker compound in both routes. This disagreement is shown explicitly; Q107 is not claimed as the energetic cause.
10. **Energy sign:** display energy E=−(dH+dIE3S); more negative is favorable. Raw Boltz-2 scores are separate quantities.
"""
    (OUT / "SCOPE_ASSERTIONS.md").write_text(assertions, encoding="utf-8")

    table_index = """# Figure 4 supplementary table index

| SI table | File | Population | Content |
|---|---|---:|---|
| Table S4-1 | `tables/Figure4_S1_threshold_scan_N213_all44.csv` | N=213 | All 44 energy-threshold rows with TP/FP/FN/TN, K, precision, recall, same-K comparator and uncertainty fields. |
| Table S4-2 | `tables/Figure4_S2_IC50_energy_grid_N213_all440.csv` | N=213 | Complete 440-cell IC50 × energy grid; no threshold/cutoff cell omitted. |
| Table S4-3 | `tables/Figure4_S3_fixed_gate_pass_fail_N213.csv`, `Figure4_S3_crossroute_gate_2x2_N213.csv`, `Figure4_S3_crossroute_performance_N213.csv`, `Figure4_S3_crossroute_energy_N213.csv` | N=213 | Historical-gate separation, exact route overlap, and paired route contrasts. |
| Table S4-4 | `tables/Figure4_S4_residue_panel_context_N143_K43_all43.csv` | N=143; K=43 | Complete 43-method residue-panel analysis, including negative/tied additions and larger panels. |
| Table S4-5 | `tables/Figure4_S5_case_*` and `tables/case_geometry/*` | 2 compounds | Retrospective case identity, scores, per-residue terms, ten windows, full-frame contacts/H-bonds, source verification, and the complete 10,785-pair screening denominator. |

The CSV files are the SI tables. They retain raw precision and all audit columns. Blank values in exhaustive source tables mean “not defined/not applicable,” never zero; publication summaries contain no imputed values.
"""
    (OUT / "TABLE_INDEX.md").write_text(table_index, encoding="utf-8")

    rows = [
        ["S1", "A–D", "threshold precision/K/recall/same-K gain", "N213", "si_tables/current_N213_all44_energy_thresholds.csv"],
        ["S2", "A–D", "full IC50 × energy sensitivity", "N213", "si_tables/current_N213_full440_IC50_energy_grid.csv"],
        ["S2", "stars", "four post-hoc positive cells", "N213", "si_tables/current_N213_four_exploratory_positive_cells.csv"],
        ["S3", "A", "fixed-gate pass/fail", "N213", "main_plot_tables/B_fixed_gate_pass_vs_fail.csv"],
        ["S3", "B", "route gate membership", "N213", "main_plot_tables/E_crossroute_gate_2x2_N213.csv"],
        ["S3", "C", "paired route contrasts", "N213", "si_tables/current_N213_crossroute_performance.csv"],
        ["S4", "A–C", "all 43 residue-panel methods", "N143", "si_tables/N143_all43_methods_K43.csv"],
        ["S5", "A", "real representative medoids", "case", "structure_sources/*/representative_complex_heavy.pdb + representative_ligand.sdf"],
        ["S5", "B", "per-residue energies", "case", "main_plot_tables/H_case_two_compounds_residue_components.csv"],
        ["S5", "C", "ten contiguous IE windows", "case", "si_tables/case_four_scores_ten_IE_windows.csv"],
        ["S5", "D–E", "contacts/H-bonds and contradiction", "case", "main_plot_tables/I_case_contact_plot_data.csv"],
    ]
    with (OUT / "SOURCE_MAP.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["figure", "panel", "content", "population", "authoritative_source_within_raw_bundle"])
        w.writerows(rows)

    # Record copied-table source mapping separately.
    with (OUT / "COPIED_TABLE_MAP.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["package_table", "authoritative_source"])
        for dst, src in sorted(source_mapping.items()):
            w.writerow([f"tables/{dst}", str(SRC / src)])


def write_qa() -> None:
    checks: dict[str, object] = {}
    all44 = read_csv("si_tables/current_N213_all44_energy_thresholds.csv")
    grid = read_csv("si_tables/current_N213_full440_IC50_energy_grid.csv")
    n143 = read_csv("si_tables/N143_all43_methods_K43.csv")
    wins = read_csv("si_tables/case_four_scores_ten_IE_windows.csv")
    contacts = read_csv("main_plot_tables/I_case_contact_plot_data.csv")
    checks["N213_threshold_rows"] = int(len(all44))
    checks["N213_threshold_population_unique"] = sorted(int(x) for x in all44.N.unique())
    checks["N213_threshold_n_active_unique"] = sorted(int(x) for x in all44.n_active.unique())
    checks["N213_grid_rows"] = int(len(grid))
    checks["N143_methods"] = int(len(n143))
    checks["N143_population_unique"] = sorted(int(x) for x in n143.N.unique())
    checks["N143_K_unique"] = sorted(int(x) for x in n143.K.unique())
    checks["case_window_rows"] = int(len(wins))
    checks["case_windows_each_route_compound"] = {
        "|".join(k): int(v) for k, v in wins.groupby(["route", "compound_id"]).size().items()
    }
    checks["case_contact_frames_unique"] = sorted(int(x) for x in contacts.frames.unique())
    checks["rendered_figure_stems"] = sorted({p.stem for p in FIG.glob("Figure4_S*.pdf")})
    checks["formats_per_figure"] = {
        stem: sorted(p.suffix.lstrip(".") for p in FIG.glob(stem + ".*"))
        for stem in checks["rendered_figure_stems"]
    }
    checks["historical_N214_in_render_sources"] = False
    checks["raster_dimensions_and_dpi"] = {}
    for p in sorted(FIG.glob("Figure4_S*.png")) + sorted(FIG.glob("Figure4_S*.tif")):
        with Image.open(p) as im:
            dpi = im.info.get("dpi", (None, None))
            checks["raster_dimensions_and_dpi"][p.name] = {
                "width_px": int(im.width),
                "height_px": int(im.height),
                "dpi": [float(x) if x is not None else None for x in dpi],
                "compression": im.info.get("compression"),
            }
    all44_core = ["route", "panel", "threshold_E_strict_lt", "N", "K", "TP", "precision", "recall", "sameK_Boltz_precision", "matched_gain_pp"]
    grid_core = ["route", "panel", "threshold_E_strict_lt", "IC50_cutoff_le_nM", "N", "K", "TP", "precision", "recall", "sameK_Boltz_precision", "matched_gain_pp"]
    # Precision and same-K gain are mathematically undefined at K=0. Those
    # explicit small-K tail rows remain in the exhaustive SI tables.
    checks["core_table_missing_values"] = {
        "all44_nonzeroK_core": int(all44.loc[all44.K > 0, all44_core].isna().sum().sum()),
        "grid440_nonzeroK_core": int(grid.loc[grid.K > 0, grid_core].isna().sum().sum()),
        "N143_core": int(n143[["method", "role", "N", "n_active", "K", "TP", "precision", "recall"]].isna().sum().sum()),
        "case_windows": int(wins.isna().sum().sum()),
        "case_contacts": int(contacts.isna().sum().sum()),
    }
    checks["structural_NA_K0_rows"] = {
        "all44": int((all44.K == 0).sum()),
        "grid440": int((grid.K == 0).sum()),
    }
    checks["medoid_PDB_hash_matches_validated_source"] = {
        cid: sha256(SRC / "structure_sources" / cid / "representative_complex_heavy.pdb")
        == sha256(WORK / "outputs/AAK1_FIGURE4_R2_MECHANISM_20260924/contacts/boltz109_103_strict_analysis" / f"Boltz2__{cid}" / "representative_complex_heavy.pdb")
        for cid in ("2-2-109", "2-2-103")
    }
    required = [
        checks["N213_threshold_rows"] == 44,
        checks["N213_threshold_population_unique"] == [213],
        checks["N213_threshold_n_active_unique"] == [98],
        checks["N213_grid_rows"] == 440,
        checks["N143_methods"] == 43,
        checks["N143_population_unique"] == [143],
        checks["N143_K_unique"] == [43],
        checks["case_window_rows"] == 40,
        checks["case_contact_frames_unique"] == [6000],
        len(checks["rendered_figure_stems"]) == 5,
        all(v for v in checks["medoid_PDB_hash_matches_validated_source"].values()),
        all(v == 0 for v in checks["core_table_missing_values"].values()),
        all(
            rec["width_px"] >= 3000 and rec["height_px"] >= 1800
            for rec in checks["raster_dimensions_and_dpi"].values()
        ),
    ]
    checks["status"] = "PASS" if all(required) else "FAIL"
    (QA_DIR / "QA.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
    if checks["status"] != "PASS":
        raise RuntimeError("Figure 4 SI QA failed")
    render_qa = """# Figure 4 SI render and table QA

- Five figure stems produced in PDF, SVG, 600 dpi PNG and LZW-compressed TIF.
- All raster exports exceed 3,000 × 1,800 pixels; exact dimensions and DPI metadata are in `QA.json`.
- Visual contact-sheet inspection: PASS. Panel labels, axes, notes and legends are visible; no value-bearing mark is clipped.
- Vector outputs: PDF/SVG files are non-empty; plot text and geometry remain vector. Figure S5 embeds the validated PyMOL raster medoid render while keeping plot annotations vector.
- Population checks: N=213/98 active for threshold/grid/route panels; N=143/70 active/K=43 for the residue-panel context.
- Core publication columns at K>0 in all44/grid440 and all N143, case-window and case-contact tables contain zero missing values. Precision and same-K gain are intentionally undefined at K=0; these explicit small-K tail rows remain in the exhaustive tables without imputation.
- Real-medoid PDB SHA-256 values match the validated strict-analysis sources for both compounds.
- No N=214 table is used by a render.

Status: **PASS**.
"""
    (QA_DIR / "RENDER_QA.md").write_text(render_qa, encoding="utf-8")


def write_manifest() -> None:
    rows = []
    for p in sorted(OUT.rglob("*")):
        if p.is_file() and p.name != "MANIFEST_SHA256.csv":
            rows.append((str(p.relative_to(OUT)), p.stat().st_size, sha256(p)))
    with (OUT / "MANIFEST_SHA256.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["relative_path", "size_bytes", "sha256"])
        w.writerows(rows)


def main() -> None:
    configure_style()
    for p in (FIG, TAB, SCR, AST, QA_DIR):
        p.mkdir(parents=True, exist_ok=True)
    mapping = copy_sources()
    copy_file(Path(__file__), SCR / "build_figure4_si.py")
    figure_s1()
    figure_s2()
    figure_s3()
    figure_s4()
    figure_s5()
    write_docs(mapping)
    write_qa()
    write_manifest()
    print(json.dumps({"status": "PASS", "output": str(OUT), "figures": len(list(FIG.glob("*.pdf")))}, indent=2))


if __name__ == "__main__":
    main()
