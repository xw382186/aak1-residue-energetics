#!/usr/bin/env python3
"""Restyle the Figure 4 supplements onto the frozen series style.

Supplement 1 is the six-panel version (threshold trade-off A-D plus the merged
benchmark E and the AI-then-physics cascade F) and is rebuilt by its own
rebuild_S1_v2.py, not by build_figure4_si.figure_s1, which still draws the
superseded four-panel figure.  Supplements 2-5 come from build_figure4_si,
whose reader takes relative paths under a raw-data root that is no longer on
disk; that root is reconstituted from the published tables using the script's
own copy_sources() mapping, so every value is the published one.
"""
from __future__ import annotations

import importlib.util
import os
import re
import types
import shutil
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent             # FigureN/Supplementary_Figures/rebuild
FS = HERE.parents[2]                               # release root (FigureandSI)
STYLE_DIR = FS / "Shared/style"                    # figure2_style.py, si_style.py, si_paths.py
sys.path.insert(0, str(STYLE_DIR))
sys.dont_write_bytecode = True                     # no __pycache__ inside the release
import si_paths as P                               # noqa: E402

OUTDIR = Path(os.environ.get("SI_RESTYLE_OUT", P.STAGE_ROOT / "out")) / "Figure4"
TABLES = P.stage_published_tables(4, P.STAGE_ROOT / "Figure4/published")
ASSETS = P.raw_data(15)        # case structures, trajectories, validated medoid render
MAIN4 = P.stage_tree(P.main_rebuild(4), P.STAGE_ROOT / "Figure4/main_rebuild")
STAGE = P.STAGE_ROOT / "Figure4/src"


def load_s1():
    """rebuild_S1_v2.py creates its output folder at import from a hardcoded
    workspace path; point that literal into the stage before executing it."""
    path = MAIN4 / "rebuild_S1_v2.py"
    src = path.read_text().replace('F4 = HOME / "mnt/AAK1/draft/Figure/4"',
                                   f'F4 = Path(r"{STAGE / "s1_workspace"}")')
    m = types.ModuleType("fig4_s1_v2")
    m.__file__ = str(path)
    sys.modules["fig4_s1_v2"] = m
    exec(compile(src, str(path), "exec"), m.__dict__)
    return m


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def stage_src(script: Path) -> Path:
    """Rebuild the raw-data root from the published tables.

    copy_sources() in the build script maps published table name -> relative
    path under the raw root.  Inverting it puts every published table back
    where the reader expects to find it.
    """
    txt = script.read_text()
    block = re.search(r"mapping = \{(.*?)\n    \}", txt, re.S).group(1)
    pairs = re.findall(r'"([^"]+)":\s*"([^"]+)"', block)
    STAGE.mkdir(parents=True, exist_ok=True)
    n = 0
    for published, rel in pairs:
        src = TABLES / published
        if not src.exists():
            print(f"    [miss] {published}")
            continue
        dst = STAGE / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists():
            shutil.copyfile(src, dst)
        n += 1
    # case structures live in Supplementary Figure 15 raw_data/, keyed by compound
    for cid in ("2-2-109", "2-2-103"):
        srcd = ASSETS / cid
        if srcd.is_dir():
            dstd = STAGE / "si_tables/case_geometry" / cid
            dstd.mkdir(parents=True, exist_ok=True)
            for p in srcd.iterdir():
                if p.is_file() and not (dstd / p.name).exists():
                    shutil.copyfile(p, dstd / p.name)
    print(f"    staged {n} tables -> {STAGE}")
    return STAGE


def main() -> None:
    sys.path.insert(0, str(STYLE_DIR))
    sys.path.insert(0, str(MAIN4))
    import si_style as S
    import matplotlib.figure as mfig
    import matplotlib.pyplot as plt

    OUTDIR.mkdir(parents=True, exist_ok=True)
    orig_suptitle = mfig.Figure.suptitle
    mfig.Figure.suptitle = lambda self, *a, **k: None
    done = []

    def emit(fig, stem):
        S.strip_legacy_titles(fig)
        n = S.PUBLIC_NUMBER[stem]
        S.stamp_heading(fig, n)
        S.save_si(fig, OUTDIR, stem)
        done.append(stem)
        print(f"  rendered {S.public_stem(stem)}")

    S.apply_si_style()

    # ---- supplement 1: the current six-panel build -----------------------
    try:
        s1 = load_s1()
        s1.TAB = TABLES
        s1.CASC = TABLES / "Figure4_S1_cascade_N213.csv"
        s1.configure_style = S.apply_si_style
        s1.panel = lambda ax, label, x=-0.13, y=1.07: S.panel_letter(ax, label, x, y)
        s1.clean = lambda ax, grid="y": S.clean(ax, grid)
        s1.save_all = lambda fig, stem: emit(fig, stem)
        try:
            s1.main()
        except Exception as e:
            # main() writes a preview thumbnail into the old workspace after
            # saving; the figure itself is already emitted by then.
            if "Figure4_S1_full_threshold_tradeoff_N213" not in done:
                raise
            print(f"    (ignored post-save step: {type(e).__name__})")
    except Exception as e:
        print(f"  [FAIL] S1: {type(e).__name__}: {e}")
        traceback.print_exc(limit=4)

    # ---- supplements 2-5 -------------------------------------------------
    script = HERE / "build_figure4_si.py"
    root = stage_src(script)
    mod = load(script, "build_fig4_si")
    mod.SRC = root
    mod.FIG = OUTDIR
    mod.LEGACY_ASSET_ROOT = root / "legacy_assets"
    (root / "legacy_assets").mkdir(parents=True, exist_ok=True)
    medoid = ASSETS / "validated_medoid_render.png"
    tgt = root / "legacy_assets/case_109_103_medoid_comparison.png"
    if medoid.exists() and not tgt.exists():
        shutil.copyfile(medoid, tgt)

    mod.configure_style = S.apply_si_style
    mod.panel = lambda ax, label, x=-0.13, y=1.07: S.panel_letter(ax, label, x, y)
    mod.clean = lambda ax, grid="y": S.clean(ax, grid)

    STEMS = {
        "figure_s2": "Figure4_S2_full_IC50_energy_grid_N213",
        "figure_s3": "Figure4_S3_gate_separation_crossroute_N213",
        "figure_s4": "Figure4_S4_residue_panel_context_N143_K43",
        "figure_s5": "Figure4_S5_case_robustness_109_vs_103",
    }

    def save_all(fig, stem):
        emit(fig, stem)
        return []

    mod.save_all = save_all
    S.apply_si_style()

    for fn, stem in STEMS.items():
        f = getattr(mod, fn, None)
        if f is None:
            print(f"  [skip] {fn}")
            continue
        try:
            f()
        except Exception as e:
            print(f"  [FAIL] {fn}: {type(e).__name__}: {e}")
            traceback.print_exc(limit=4)

    print(f"\n{len(done)} of 5 Figure 4 supplements restyled -> {OUTDIR}")


if __name__ == "__main__":
    main()
