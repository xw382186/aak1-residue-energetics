#!/usr/bin/env python3
"""Figure 4, panel D, 2026-09-30 -- the full screening-budget curve.

The panel that was here compared thirteen candidate fourth residues at one
budget; it moves to the supplement.  What replaces it asks the screening
question across every budget at once, on the same 143 complete-case compounds:
if only K of them can go forward, how many are active when K is chosen by the
all-16 hotspot contribution sum, and how many when it is chosen by Boltz-2?

The canvas is drawn at exactly the rectangle the old panel occupied on the
frozen page, and its axes sit on the old axes' rectangle to the point, so the
panel is stamped back into the page without moving anything around it.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox

import figure2_style as st
from figure2_style import (ANNOT_GREY, FS_ANNOT, FS_LETTER, FS_NOTE, GRID_GREY,
                           LW_CURVE, LW_GRID, LW_REF, REF_GREY)

HERE = Path(__file__).resolve().parent
PKG = (Path.home() / "mnt/AAK1/draft/Figure/4/raw_data_N143_hotspot_20260930"
       / "AAK1_FIGURE3_HOTSPOT_GATE_EXTENSION_20260930")
OUT = HERE / "panelD_v2"
OUT.mkdir(exist_ok=True)

# ---- the slot on the frozen page, measured off Figure4.pdf (PDF points) ----
SLOT = (334.00, 180.20, 629.83, 320.00)      # x0, y0, x1, y1, top-left origin
AXES = (368.60, 197.40, 623.90, 293.00)      # the old panel's axes rectangle
LETTER_XY = (339.20, 190.26)                 # letter left edge, baseline

# All-16 hotspot sum is a new readout on this page, so it takes the next free
# colour in the same seaborn "muted" family the method palette is drawn from;
# blue stays Boltz-2, as everywhere else in Figures 2-5.
HOTSPOT_COLOR = "#6ACC64"
BOLTZ_COLOR = st.METHOD_COLORS["Boltz-2"]
K_BUDGET = 43
K_UNSTABLE = 20


def load():
    d = pd.read_csv(PKG / "data/figure_K_hit_rate_N143.csv")
    assert len(d) == 143 and d["K"].tolist() == list(range(1, 144))
    return d


def panel_topk(ax, D):
    """Active fraction among the top K, for every budget K = 1 to 143."""
    d = D["topk"]
    rand = float(d["random_hit_rate_pct"].iloc[0])

    ax.axvspan(1, K_UNSTABLE, color=GRID_GREY, alpha=0.55, lw=0, zorder=0)
    ax.axhline(rand, color=REF_GREY, lw=LW_REF, ls="--", zorder=2)
    ax.text(142, rand - 3.0, f"random, {rand:.1f}%", ha="right", va="top",
            fontsize=FS_NOTE, color=ANNOT_GREY, zorder=4)
    ax.axvline(K_BUDGET, color=ANNOT_GREY, lw=0.7, ls=":", zorder=2)
    ax.text(K_BUDGET, 103.0, f"K = {K_BUDGET}", ha="center", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY, zorder=4)

    ax.plot(d["K"], d["boltz_hit_rate_pct"], color=BOLTZ_COLOR, lw=LW_CURVE,
            zorder=3, solid_joinstyle="round")
    ax.plot(d["K"], d["hotspot_hit_rate_pct"], color=HOTSPOT_COLOR, lw=LW_CURVE,
            zorder=4, solid_joinstyle="round")

    # the two readings at the budget the rest of the page uses, stacked in the
    # band above both curves so neither label lands on a line
    r = d[d["K"] == K_BUDGET].iloc[0]
    for i, (val, colour, n) in enumerate((
            (r["hotspot_hit_rate_pct"], HOTSPOT_COLOR, r["hotspot_expected_active"]),
            (r["boltz_hit_rate_pct"], BOLTZ_COLOR, r["boltz_expected_active"]))):
        ax.plot([K_BUDGET], [val], marker="o", ms=3.6, mfc="white", mec=colour,
                mew=1.1, zorder=6)
        ax.text(K_BUDGET + 4.0, 99.0 - i * 7.6,
                f"{int(round(n))}/{K_BUDGET}  ({val:.1f}%)", ha="left", va="top",
                fontsize=FS_ANNOT, color=colour, zorder=6)

    # where the lead stops: reported in full rather than left to the eye
    lost = d[d["hotspot_minus_boltz_active"] < 0]
    worst = int(lost["boltz_expected_active"].sub(
        lost["hotspot_expected_active"]).max())
    ax.text(142, 10.5, f"Boltz-2 ahead at {len(lost)} of 143 budgets,",
            ha="right", va="bottom", fontsize=FS_NOTE, color=ANNOT_GREY, zorder=4)
    ax.text(142, 3.0, f"all K = {int(lost['K'].min())}\u2013{int(lost['K'].max())}, "
            f"never by more than {worst} compound", ha="right", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY, zorder=4)
    ax.text(3, 3.0, f"K < {K_UNSTABLE}: small sets", ha="left", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY, zorder=4)

    ax.set_xlim(1, 143)
    ax.set_xticks([1, 20, 43, 60, 80, 100, 120, 143])
    ax.set_ylim(0, 100)
    ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Screening budget, top K of 143")
    ax.set_ylabel("Hit rate of the top K  (%)")
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)
    ax.spines["left"].set_bounds(0, 100)
    ax.spines["bottom"].set_bounds(1, 143)

    ax.legend(handles=[Line2D([], [], color=HOTSPOT_COLOR, lw=LW_CURVE,
                              label="All-16 hotspot sum"),
                       Line2D([], [], color=BOLTZ_COLOR, lw=LW_CURVE,
                              label="Boltz-2")],
              loc="lower left", bbox_to_anchor=(0.012, 0.185), frameon=False,
              fontsize=FS_NOTE, handlelength=1.5, handletextpad=0.45,
              labelspacing=0.32, borderpad=0.0)


def build():
    st.apply_style()
    D = {"topk": load()}
    x0, y0, x1, y1 = SLOT
    w_pt, h_pt = x1 - x0, y1 - y0
    fig_w, fig_h = w_pt / 72, h_pt / 72

    ax_left = (AXES[0] - x0) / w_pt
    ax_width = (AXES[2] - AXES[0]) / w_pt
    ax_bottom = (y1 - AXES[3]) / h_pt
    ax_height = (AXES[3] - AXES[1]) / h_pt

    fig = plt.figure(figsize=(fig_w, fig_h))
    panel_topk(fig.add_axes((ax_left, ax_bottom, ax_width, ax_height)), D)
    fig.text((LETTER_XY[0] - x0) / w_pt, (y1 - LETTER_XY[1]) / h_pt, "D",
             ha="left", va="baseline", fontsize=FS_LETTER, fontweight="bold")

    box = Bbox.from_bounds(0, 0, fig_w, fig_h)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"Figure4_panelD_slot.{ext}", dpi=st.DPI,
                    bbox_inches=box)
    plt.close(fig)

    D["topk"].to_csv(OUT / "Figure4_panelD_plotted_values.csv", index=False)
    print(f"wrote {OUT}  slot {w_pt:.2f} x {h_pt:.2f} pt "
          f"({w_pt/72*25.4:.2f} x {h_pt/72*25.4:.2f} mm)")


if __name__ == "__main__":
    build()
