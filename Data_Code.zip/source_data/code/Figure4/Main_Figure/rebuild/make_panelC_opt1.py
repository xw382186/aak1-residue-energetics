#!/usr/bin/env python3
"""Figure 4 panel C, 2026-10-06: complementarity with Boltz-2.

At the selection budget panel A marks as widest-gap (Pair keep E < -3.5, K=54;
Triad keep E < -5.5, K=49), the gate and a same-size Boltz-2 pick disagree on
~40 compounds each way.  Among those *unique* picks, the residue gate's are
active far more often than Boltz-2's, on both starting routes: the physics gate
recovers actives the same-budget Boltz-2 selection misses -- orthogonal signal,
the basis for an AI-then-physics cascade.  Letter C is redrawn in the slot.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox
import figure2_style as st
from figure2_style import (ANNOT_GREY, EDGE, FS_LETTER, FS_ANNOT, FS_NOTE, FS_TICK,
                           GRID_GREY, LW_EDGE, LW_GRID, LW_REF, REF_GREY)

HERE=Path(__file__).resolve().parent
CORE=(Path.home()/"mnt/AAK1/draft/Figure/4/raw_data_pooled352_20261005"
      /"AAK1_STRESS_AND_POOLED_GATE_DATA_20261005/raw_data/02_stress213_core_scores.csv")
OUT=HERE/"panelC_opt1"; OUT.mkdir(exist_ok=True)
SLOT=(0.00,180.20,334.00,320.00)
LETTER_XY=(7.16,190.26)
PAIR_C=st.METHOD_COLORS["ASGB total dH"]; TRIAD_C=st.METHOD_COLORS["ASGBIE total dG"]; BOLTZ_C=st.METHOD_COLORS["Boltz-2"]
# facet axes boxes (page pts): Pair left, Triad right
AX={"Pair":(40.0,199.0,168.0,294.0,PAIR_C,-3.5),"Triad":(196.0,199.0,324.0,294.0,TRIAD_C,-5.5)}

def load():
    d=pd.read_csv(CORE); assert len(d)==213 and int(d.active_100nM.sum())==98
    return d

def disagreement(d,route,panel,t):
    lab=d.active_100nM.to_numpy(bool); N=len(d)
    E=d[f"{route}_{panel}_signed_E_kcalmol"].to_numpy(float)
    G=np.where(E<t)[0]; K=len(G)
    order=np.argsort(d.Boltz_raw_lower_is_stronger.to_numpy(float),kind="mergesort")
    B=set(order[:K].tolist()); Gs=set(G.tolist())
    gonly=sorted(Gs-B); bonly=sorted(B-Gs)
    def hr(ix): return (int(lab[ix].sum()),len(ix), (lab[ix].sum()/len(ix)*100 if ix else 0))
    return K,hr(gonly),hr(bonly)

def build():
    st.apply_style(); d=load()
    lab=d.active_100nM; RAND=lab.mean()*100
    x0,y0,x1,y1=SLOT; w,h=x1-x0,y1-y0
    def fx(X): return (X-x0)/w
    def fy(Y): return (y1-Y)/h
    fig=plt.figure(figsize=(w/72,h/72))
    # letter C
    fig.text(fx(LETTER_XY[0]),fy(LETTER_XY[1]),"C",fontsize=FS_LETTER,fontweight="bold",va="top",ha="left")
    # (panel carries the letter and data only; the sentence caption is written centrally)
    rows=[]
    for panel,(ax0,ay0,ax1,ay1,col,t) in AX.items():
        ax=fig.add_axes([fx(ax0),fy(ay1),(ax1-ax0)/w,(ay1-ay0)/h])
        ax.set_xlim(-0.6,4.0); ax.set_ylim(0,92)
        ax.axhline(RAND,color=REF_GREY,lw=LW_REF,ls=":",zorder=2)
        Ks=[]
        for ri,(route,fill) in enumerate([("Boltz",True),("Docking",False)]):
            K,go,bo=disagreement(d,route,panel,t); Ks.append(K)
            rows.append(dict(panel=panel,route=route,threshold=t,K=K,
                             gate_only_hits=go[0],gate_only_n=go[1],gate_only_hitrate=round(go[2],1),
                             boltz_only_hits=bo[0],boltz_only_n=bo[1],boltz_only_hitrate=round(bo[2],1),
                             rescued_actives=go[0]-bo[0]))
            base=ri*2.2
            for k,(val,cc) in enumerate([(go,col),(bo,BOLTZ_C)]):
                x=base+k*0.95
                ax.bar(x,val[2],0.82,color=(cc if fill else "white"),edgecolor=(EDGE if fill else cc),
                       linewidth=(LW_EDGE if fill else 1.1),zorder=3)
                ax.text(x,val[2]+1.5,f"{val[0]}/{val[1]}",ha="center",va="bottom",fontsize=5.4,color=ANNOT_GREY)
            resc=go[0]-bo[0]
            ax.text(base+0.47,6,("Boltz-start" if fill else "docking")+f"\nrescues {resc:+d}",
                    ha="center",va="bottom",fontsize=5.2,color=ANNOT_GREY)
        ax.set_xticks([0,0.95,2.2,3.15]); ax.set_xticklabels(["gate","Boltz-2","gate","Boltz-2"],fontsize=5.4)
        ax.tick_params(axis="x",length=0,pad=2); ax.set_yticks([0,46,92] if False else [0,25,50,75])
        ax.tick_params(axis="y",labelsize=FS_TICK)
        for s in ("top","right"): ax.spines[s].set_visible(False)
        ax.set_title(f"{panel} gate   K={Ks[0]}/{Ks[1]}",fontsize=FS_ANNOT,color=col,pad=2)
        if panel=="Pair": ax.set_ylabel("Active fraction of\nunique picks (%)",fontsize=FS_NOTE)
    box=Bbox.from_bounds(0,0,w/72,h/72)
    for ext in ("pdf","png"):
        fig.savefig(OUT/f"Figure4_panelC.{ext}",dpi=st.DPI,bbox_inches=box,transparent=True)
    plt.close(fig)
    pd.DataFrame(rows).to_csv(OUT/"Figure4_panelC_complementarity_values.csv",index=False)
    print(pd.DataFrame(rows).to_string(index=False))

if __name__=="__main__": build()
