#!/usr/bin/env python3
"""Rebuild Figure 4 supplement 1 as a 3x2 figure.

Panels A-D are reproduced byte-for-content from the frozen build
(build_figure4_si.py :: figure_s1), reading the identical N=213 all-44
threshold table, so their curves, markers, limits and labels are unchanged.
Two panels are added in supplement 1's own theme (gate vs same-size Boltz-2
at the selection level):

  E  the merged strong+stress benchmark (n=352, 195 active) that main panel C
     used to draw -- four gates x two routes, hit rate and actives kept, each
     against a same-size Boltz-2 selection and against chance.  This is the
     result evicted from main Figure 4c, preserved here as a figure.
  F  the AI-then-physics cascade: Boltz-2 prefilters the top M, physics reranks
     to the K=54 budget; actives recovered vs the physics budget M, in N=213.

Self-contained: reads only the current_20261005 SI tables and the cascade
table in rebuild/si_cascade.  Writes to rebuild/s1_v2/.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from PIL import Image

HOME = Path.home()
F4 = HOME / "mnt/AAK1/draft/Figure/4"
TAB = F4 / "SI/current_20261005/tables"
CASC = F4 / "rebuild/si_cascade/Figure4_S1_cascade_N213.csv"
OUT = F4 / "rebuild/s1_v2"
OUT.mkdir(parents=True, exist_ok=True)

INK = "#222222"
BLUE = "#4878D0"
ORANGE = "#EE854A"
RED = "#D65F5F"
PURPLE = "#956CB4"
GRAYLINE = "#8A93A6"
ROUTE_COLORS = {"Boltz": BLUE, "Docking": ORANGE}
PANEL_MARKERS = {"Pair": "D", "Triad": "^"}


def configure_style() -> None:
    mpl.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
        "mathtext.fontset": "custom",
        "mathtext.rm": "Arial",
        "mathtext.it": "Arial:italic",
        "mathtext.bf": "Arial:bold",
        "font.size": 7.0,
        "axes.labelsize": 7.5,
        "axes.titlesize": 8.0,
        "xtick.labelsize": 6.5,
        "ytick.labelsize": 6.5,
        "legend.fontsize": 6.3,
        "axes.linewidth": 0.75,
        "lines.linewidth": 1.15,
        "lines.markersize": 4.0,
        "xtick.major.width": 0.65,
        "ytick.major.width": 0.65,
        "xtick.major.size": 2.8,
        "ytick.major.size": 2.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": INK,
        "axes.labelcolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def panel(ax, label: str, x: float = -0.13, y: float = 1.07) -> None:
    ax.text(x, y, label, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")


def clean(ax, grid: str | None = "y") -> None:
    if grid:
        ax.grid(axis=grid, color="#D9DDE3", linewidth=0.55, alpha=0.8)
        ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


# ---------------------------------------------------------------- A-D (frozen)
def panels_ABCD(axs) -> tuple:
    d = pd.read_csv(TAB / "Figure4_S1_threshold_scan_N213_all44.csv")
    metrics = [
        ("precision", "Hit rate among retained (%)", "A"),
        ("K", "Retained compounds (K)", "B"),
        ("recall", "Active compounds recovered (%)", "C"),
        ("matched_gain_pp", "Gain over same-K Boltz-2 (pp)", "D"),
    ]
    for ax, (metric, ylabel, lab) in zip(axs, metrics):
        for (route, pan), g in d.groupby(["route", "panel"], sort=False):
            g = g.sort_values("threshold_E_strict_lt", ascending=False)
            x = -g["threshold_E_strict_lt"].to_numpy()
            y = g[metric].to_numpy(dtype=float)
            if metric in {"precision", "recall"}:
                y *= 100
            ax.plot(
                x, y,
                marker=PANEL_MARKERS[pan],
                color=ROUTE_COLORS[route],
                linestyle="-" if pan == "Pair" else "--",
                markerfacecolor="white" if route == "Docking" else ROUTE_COLORS[route],
                markeredgecolor=ROUTE_COLORS[route],
                label=f"{route}-start {pan}",
            )
        if metric == "precision":
            ax.axhline(d["random_precision"].iloc[0] * 100, color="#777", ls=":", lw=1.0)
            ax.text(0.99, 0.04, "random = 46.0%", transform=ax.transAxes, ha="right", color="#666")
        if metric == "matched_gain_pp":
            ax.axhline(0, color="#666", lw=0.9)
        ax.axvline(2, color=PURPLE, ls=":", lw=0.9, alpha=0.8)
        ax.axvline(3, color=RED, ls=":", lw=0.9, alpha=0.8)
        ax.set_xlabel(r"Absolute energy cutoff, $|E|$ (kcal mol$^{-1}$)")
        ax.set_ylabel(ylabel)
        ax.set_xlim(0.8, 7.2)
        clean(ax)
        panel(ax, lab)
    return axs[0].get_legend_handles_labels()


# ------------------------------------------------------------------- E (merged)
GATES = [("Pair", 2.0), ("Pair", 3.0), ("Triad", 3.0), ("Triad", 4.0)]
ROUTES = ["Boltz", "Docking"]
BW = 0.34


def e_bars(ax, T, col, bottom) -> None:
    for g, (pan, thr) in enumerate(GATES):
        c = PURPLE if pan == "Pair" else RED
        for k, route in enumerate(ROUTES):
            r = T[(T.panel == pan) & (T.thr == thr) & (T.route == route)].iloc[0]
            x = g + (k - 0.5) * BW * 1.08
            ax.bar(x, r[col], BW, color=c if route == "Boltz" else "white",
                   edgecolor=c, linewidth=0.75, zorder=3)
            ref = "boltz_hit_rate" if col == "hit_rate" else "boltz_recall"
            if col != "hit_rate":
                ax.plot([x - BW / 2, x + BW / 2], [r["retention"]] * 2,
                        color=GRAYLINE, lw=0.9, solid_capstyle="butt", zorder=5)
            ax.plot([x], [r[ref]], marker="o", ls="none",
                    mfc="white", mec=BLUE, mew=1.0, ms=3.6, zorder=6)
    ax.set_xlim(-0.60, len(GATES) - 0.40)
    ax.set_xticks(range(len(GATES)))
    if bottom:
        ax.set_xticklabels([f"{p} > {t:.0f}" for p, t in GATES], fontsize=6.3)
        for tk, (p, _) in zip(ax.get_xticklabels(), GATES):
            tk.set_color(PURPLE if p == "Pair" else RED)
    else:
        ax.set_xticklabels([])
    ax.tick_params(axis="x", length=0, pad=2.5)
    ax.set_ylim(0, 100)
    ax.set_yticks([0, 50, 100])
    ax.grid(True, axis="y", color="#D9DDE3", lw=0.55, alpha=0.8)
    ax.set_axisbelow(True)
    clean(ax, None)


def panels_E(ax_top, ax_bot) -> None:
    T = pd.read_csv(TAB / "Figure4_S1_pooled352_panelC_values.csv")
    e_bars(ax_top, T, "hit_rate", False)
    e_bars(ax_bot, T, "recall", True)
    ax_top.axhline(T.chance.iloc[0], color="#777", ls=(0, (1.6, 1.8)), lw=0.9, zorder=4)
    ax_top.set_ylabel("Hit rate of\nkept set (%)", fontsize=6.3, labelpad=2, linespacing=1.2)
    ax_bot.set_ylabel("Actives kept,\nof 195 (%)", fontsize=6.3, labelpad=2, linespacing=1.2)
    ax_top.text(0.5, 1.02, "Merged benchmark  n = 352  (strong + stress)",
                transform=ax_top.transAxes, ha="center", va="bottom",
                fontsize=6.2, color="#4D4D4D")
    leg = [
        Rectangle((0, 0), 1, 1, fc="#777", ec="#777", label="Boltz-start (filled)"),
        Rectangle((0, 0), 1, 1, fc="white", ec="#777", label="docking-start (open)"),
        Line2D([], [], marker="o", ls="none", mfc="white", mec=BLUE, mew=1.0, ms=3.6,
               label="same-size Boltz-2"),
        Line2D([], [], color=GRAYLINE, lw=0.9, label="library kept"),
        Line2D([], [], color="#777", lw=0.9, ls=(0, (1.6, 1.8)), label="random 55.4%"),
    ]
    ax_bot.legend(handles=leg, loc="upper center", bbox_to_anchor=(0.5, -0.34),
                  frameon=False, ncol=3, fontsize=5.4, handlelength=1.3,
                  handletextpad=0.42, columnspacing=1.05)


# ------------------------------------------------------------------- F (cascade)
def panel_F(ax) -> None:
    C = pd.read_csv(CASC)
    b2 = int(C.boltz2_alone.iloc[0])
    for pan, color in [("Pair", PURPLE), ("Triad", RED)]:
        g = C[(C.panel == pan) & (C.route == "Boltz")].sort_values("physics_budget_M")
        ax.plot(g.physics_fraction_pct, g.actives_recovered, marker="o", ms=4.2,
                color=color, lw=1.25, label=f"{pan} gate", zorder=4)
        end = g.iloc[-1]
        ax.annotate(f"{int(end.actives_recovered)}", (end.physics_fraction_pct, end.actives_recovered),
                    textcoords="offset points", xytext=(5, 0), va="center",
                    fontsize=6.6, color=color, fontweight="bold")
    ax.axhline(b2, color="#777", ls=":", lw=0.9, zorder=2)
    ax.text(0.015, b2 + 0.25, f"Boltz-2 alone ({b2})", fontsize=6.0, color="#555",
            va="bottom", ha="left", transform=ax.get_yaxis_transform())
    ax.set_xlim(20, 108)
    ax.set_ylim(30, 42)
    ax.set_yticks([30, 32, 34, 36, 38, 40, 42])
    ax.set_xlabel("Physics run on top M by Boltz-2  (% of 213)")
    ax.set_ylabel("Actives among final K = 54")
    ax.legend(frameon=False, loc="lower right", fontsize=6.3)
    clean(ax)
    panel(ax, "F", x=-0.145, y=1.07)


# --------------------------------------------------------------------- assemble
def save_all(fig, stem: str) -> None:
    for ext in ("pdf", "svg"):
        fig.savefig(OUT / f"{stem}.{ext}")
    png = OUT / f"{stem}.png"
    fig.savefig(png, dpi=600)
    with Image.open(png) as im:
        im.save(OUT / f"{stem}.tif", dpi=(600, 600), compression="tiff_lzw")
    plt.close(fig)


def main() -> None:
    configure_style()
    fig = plt.figure(figsize=(8.75, 9.7))
    gs = fig.add_gridspec(3, 2, left=0.085, right=0.975, top=0.912, bottom=0.115,
                          hspace=0.46, wspace=0.255, height_ratios=[1.0, 1.0, 1.12])
    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])
    axC = fig.add_subplot(gs[1, 0])
    axD = fig.add_subplot(gs[1, 1])
    gsE = gs[2, 0].subgridspec(2, 1, hspace=0.16)
    axEt = fig.add_subplot(gsE[0])
    axEb = fig.add_subplot(gsE[1])
    axF = fig.add_subplot(gs[2, 1])

    handles, labels = panels_ABCD([axA, axB, axC, axD])
    panels_E(axEt, axEb)
    panel(axEt, "E", x=-0.165, y=1.30)
    panel_F(axF)

    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.952),
               ncol=4, frameon=False)
    fig.suptitle("Figure 4—supplement 1 | Selection-level trade-off: gates versus same-size Boltz-2",
                 y=0.983, fontsize=10, fontweight="bold")
    fig.text(0.5, 0.013,
             "A-D: N=213 stress cohort (98 active at IC$_{50}$≤100 nM); all 44 route×panel×threshold rows; vertical guides mark the historical Pair (2) and Triad (3) cutoffs. "
             "E: merged strong+stress benchmark (n=352, 195 active; chance 55.4%); no gate beats the same-size Boltz-2 selection. "
             "F: Boltz-2 prefilters the top M, physics reranks to K=54 (N=213, Boltz-start).",
             ha="center", fontsize=6.1, wrap=True)
    save_all(fig, "Figure4_S1_full_threshold_tradeoff_N213")

    prev = F4 / "_s1_v2_preview.png"
    with Image.open(OUT / "Figure4_S1_full_threshold_tradeoff_N213.png") as im:
        im.convert("RGB").resize((int(im.width * 0.42), int(im.height * 0.42))).save(prev)
    print("saved", sorted(p.name for p in OUT.glob("Figure4_S1*")))
    print("preview", prev)


if __name__ == "__main__":
    main()
