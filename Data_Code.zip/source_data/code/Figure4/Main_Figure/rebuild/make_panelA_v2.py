#!/usr/bin/env python3
"""Figure 4 panel A, redrawn 2026-10-05 with a tighter y range.

Nothing in the panel's content changes: the same 24 drawn points, the same two
starting routes, the same two same-K Boltz-2 references, the same annotations.
The only change is the y window -- it used to run 34 to 88% and now runs 42 to
82%, so the empty band under the 46.0% chance rule is gone and the gaps between
the curves are read on a scale 1.35x larger.  The frozen page's own y-axis
title and panel letter sit outside the replaced rectangle and are untouched.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox

import figure2_style as st
from figure2_style import (ANNOT_GREY, EDGE, FS_ANNOT, FS_LABEL, FS_NOTE,
                           FS_TICK, GRID_GREY, LW_AXIS, LW_CURVE, LW_EDGE,
                           LW_GRID, LW_REF, LW_REF_THIN, REF_GREY, TICK_LEN)

HERE = Path(__file__).resolve().parent
SRC = Path.home() / "mnt/AAK1/draft/Figure/4/panel_source_data/Figure4_panelA_plotted_values.csv"
OUT = HERE / "panelA_v2"
OUT.mkdir(exist_ok=True)

SLOT = (17.00, 0.00, 355.00, 166.00)
AX_L = (32.70, 29.49, 177.46, 136.32)
AX_R = (198.43, 29.49, 343.19, 136.32)
XLIM = (-0.64, 6.64)
YLIM = (42.0, 82.0)
YTICKS = (50, 60, 70, 80)
K_MIN = 30                      # lanes under 30 compounds are not drawn

PAIR_C = st.METHOD_COLORS["ASGB total dH"]
TRIAD_C = st.METHOD_COLORS["ASGBIE total dG"]
BOLTZ_C = st.METHOD_COLORS["Boltz-2"]
DASH = (0, (3.2, 1.8))
MARK = {"Pair": "D", "Triad": "^"}
MS_GATE = {"Pair": (7.05, 5.73), "Triad": (4.78, 3.79)}     # filled, open
MS_BOLTZ = 3.79


def load():
    d = pd.read_csv(SRC)
    d["hit"] = 100 * d["precision"]
    d["ref"] = 100 * d["sameK_Boltz_precision"]
    return d


def sub(ax, d, panel, color, highlight):
    thr = sorted(d[d.panel == panel]["threshold_E_strict_lt"].unique())[::-1]
    pos = {t: i for i, t in enumerate(thr)}
    rand = 100 * d["random_precision"].iloc[0]

    ax.set_xlim(*XLIM)
    ax.set_ylim(*YLIM)
    for y in YTICKS:
        ax.axhline(y, color=GRID_GREY, lw=LW_GRID, zorder=0)
    ax.axvline(0, color=ANNOT_GREY, lw=LW_REF_THIN, ls=(0, (1.2, 1.4)), zorder=1)
    ax.axhline(rand, color=REF_GREY, lw=LW_REF, ls=(0, (1.6, 1.8)), zorder=1)

    for route, ls, fill in (("Boltz", "-", True), ("Docking", DASH, False)):
        r = d[(d.panel == panel) & (d.route == route) & (d.K >= K_MIN)]
        r = r.sort_values("threshold_E_strict_lt", ascending=False)
        x = [pos[t] for t in r["threshold_E_strict_lt"]]
        ax.plot(x, r["ref"], ls=ls, color=BOLTZ_C, lw=LW_CURVE, zorder=3,
                marker="o", ms=MS_BOLTZ, mfc="white", mec=BOLTZ_C, mew=0.9)
        ms = MS_GATE[panel][0 if fill else 1]
        ax.plot(x, r["hit"], ls=ls, color=color, lw=LW_CURVE, zorder=4,
                marker=MARK[panel], ms=ms,
                mfc=color if fill else "white",
                mec=EDGE if fill else color, mew=LW_EDGE if fill else 0.9)

    # the widest gain, printed where it happens
    h = d[(d.panel == panel) & (d.route == "Boltz")
          & (d["threshold_E_strict_lt"] == highlight)].iloc[0]
    xh = pos[highlight]
    ax.annotate("", xy=(xh, h["hit"]), xytext=(xh, h["ref"]),
                arrowprops=dict(arrowstyle="<->", color=EDGE, lw=0.9,
                                shrinkA=0, shrinkB=0, mutation_scale=5.6),
                zorder=6)
    ax.text(xh - 0.12, (h["hit"] + h["ref"]) / 2,
            f"+{h['matched_gain_pp']:.1f} pp", ha="right", va="center",
            fontsize=FS_NOTE, fontweight="bold", color=EDGE, zorder=7)
    top = YLIM[1]
    ax.text(xh, top - 1.2, f"K = {int(h['K'])}", ha="center", va="top",
            fontsize=FS_ANNOT, color=ANNOT_GREY)
    ax.text(xh, top - 3.9,
            f"{int(h['TP'])} of {int(h['n_active'])} actives "
            f"({100 * h['recall']:.0f}% recall)",
            ha="center", va="top", fontsize=FS_ANNOT, color=ANNOT_GREY)
    ax.text(0.14, YLIM[0] + 1.1, "locked", ha="left", va="bottom",
            fontsize=FS_ANNOT, color=ANNOT_GREY)

    ax.set_xticks(range(len(thr)))
    ax.set_xticklabels([f"−{abs(t):g}" for t in thr], fontsize=FS_TICK)
    ax.set_yticks(YTICKS)
    ax.set_yticklabels([str(y) for y in YTICKS], fontsize=FS_TICK)
    ax.tick_params(length=TICK_LEN, width=LW_AXIS, pad=2)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_linewidth(LW_AXIS)
    ax.set_axisbelow(True)
    ax.set_xlabel(f"{panel}: keep E < x   (x, kcal mol$^{{-1}}$)",
                  fontsize=FS_LABEL, labelpad=3.2)


def build():
    st.apply_style()
    d = load()
    x0, y0, x1, y1 = SLOT
    w, h = x1 - x0, y1 - y0
    fig = plt.figure(figsize=(w / 72, h / 72))

    def add(rect):
        return fig.add_axes(((rect[0] - x0) / w, (y1 - rect[3]) / h,
                             (rect[2] - rect[0]) / w, (rect[3] - rect[1]) / h))

    sub(add(AX_L), d, "Pair", PAIR_C, -3.5)
    sub(add(AX_R), d, "Triad", TRIAD_C, -5.5)

    box = Bbox.from_bounds(0, 0, w / 72, h / 72)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"Figure4_panelA_slot.{ext}", dpi=st.DPI, bbox_inches=box)
    plt.close(fig)

    # the single-panel export also carries the two frozen objects that sit left
    # of the slot on the page -- the letter and the y-axis title -- at exactly
    # their page positions, so the panel file reads like the page
    ex0, ey0, ex1, ey1 = 0.0, 0.0, SLOT[2], SLOT[3]
    ew, eh = ex1 - ex0, ey1 - ey0
    fig = plt.figure(figsize=(ew / 72, eh / 72))

    def addx(rect):
        return fig.add_axes(((rect[0] - ex0) / ew, (ey1 - rect[3]) / eh,
                             (rect[2] - rect[0]) / ew, (rect[3] - rect[1]) / eh))

    sub(addx(AX_L), d, "Pair", PAIR_C, -3.5)
    sub(addx(AX_R), d, "Triad", TRIAD_C, -5.5)
    fig.text((7.16 - ex0) / ew, (ey1 - 22.33) / eh, "A", ha="left", va="baseline",
             fontsize=st.FS_LETTER, fontweight="bold")
    fig.text((10.33 - ex0) / ew, (ey1 - 82.88) / eh, "Hit rate of the kept set  (%)",
             ha="center", va="center", rotation=90, fontsize=FS_LABEL)
    box = Bbox.from_bounds(0, 0, ew / 72, eh / 72)
    fig.savefig(OUT / "Figure4_panelA_export.pdf", dpi=st.DPI, bbox_inches=box)
    plt.close(fig)
    keep = d[d.K >= K_MIN]
    print(f"drawn points: {len(keep)} of {len(d)}  (K >= {K_MIN})")
    print(f"y window {YLIM[0]}-{YLIM[1]} (was 34-88); scale x{(88-34)/(YLIM[1]-YLIM[0]):.2f}")


if __name__ == "__main__":
    build()
