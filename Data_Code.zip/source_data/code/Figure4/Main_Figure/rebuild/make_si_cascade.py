#!/usr/bin/env python3
"""Figure 4 SI: the AI-then-physics cascade on the N=213 stress cohort.
Fixed final test budget K=54 (panel A's widest-gap Pair point). Boltz-2 gives a
cheap score to all; run the physics (residue strength) only on the top-M by
Boltz-2, then take the K strongest by physics. Yield rises from Boltz-2-alone to
physics-alone as the physics budget M grows -- most of the gain at a fraction of
the physics cost (speed x accuracy)."""
from pathlib import Path
import glob, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import figure2_style as st
from figure2_style import EDGE, FS_LABEL, FS_TICK, FS_ANNOT, FS_NOTE, LW_CURVE, LW_REF, REF_GREY, ANNOT_GREY, GRID_GREY, LW_GRID
HERE=Path(__file__).resolve().parent; OUT=HERE/"si_cascade"; OUT.mkdir(exist_ok=True)
F4=Path.home()/"mnt/AAK1/draft/Figure/4"
core=glob.glob(str(F4/"raw_data_pooled352_20261005/*/raw_data/02_stress213_core_scores.csv"))[0]
d=pd.read_csv(core); lab=d.active_100nM.to_numpy(bool); N=len(d)
boltz_order=np.argsort(d.Boltz_raw_lower_is_stronger.to_numpy(float),kind="mergesort")
K=54
PAN={"Pair":st.METHOD_COLORS["ASGB total dH"],"Triad":st.METHOD_COLORS["ASGBIE total dG"]}
rows=[]; curves={}
for panel,col in PAN.items():
    strength=d[f"Boltz_{panel}_strength_units"].to_numpy(float)
    Ms=list(range(K,N+1)); ys=[]
    for M in Ms:
        pre=boltz_order[:M]; sub=pre[np.argsort(-strength[pre],kind="mergesort")[:K]]
        ys.append(int(lab[sub].sum()))
    curves[panel]=(np.array(Ms),np.array(ys),col)
    phys_alone=int(lab[np.argsort(-strength,kind="mergesort")[:K]].sum())
    for M in [K,70,90,110,140,N]:
        pre=boltz_order[:M]; sub=pre[np.argsort(-strength[pre],kind="mergesort")[:K]]
        rows.append(dict(panel=panel,route="Boltz",final_K=K,physics_budget_M=M,
                         physics_fraction_pct=round(M/N*100,1),actives_recovered=int(lab[sub].sum()),
                         boltz2_alone=int(lab[boltz_order[:K]].sum()),physics_alone=phys_alone))
pd.DataFrame(rows).to_csv(OUT/"Figure4_S1_cascade_N213.csv",index=False)
B0=int(lab[boltz_order[:K]].sum())
st.apply_style()
fig,ax=plt.subplots(figsize=(2.9,2.0))
ax.axhline(B0,color=REF_GREY,lw=LW_REF,ls=":",zorder=2)
ax.text(N,B0-1.6,f"Boltz-2 alone  {B0}/{K}",ha="right",va="top",fontsize=FS_NOTE,color=ANNOT_GREY)
for panel,(Ms,ys,col) in curves.items():
    ax.plot(Ms/N*100,ys,color=col,lw=LW_CURVE,zorder=3,label=f"{panel} gate")
    ax.plot(Ms[-1]/N*100,ys[-1],marker="o",ms=4,markerfacecolor=col,markeredgecolor=EDGE,markeredgewidth=0.6,zorder=4)
    ax.text(101,ys[-1],f"{ys[-1]}",ha="left",va="center",fontsize=FS_NOTE,color=col)
ax.set_xlim(20,108); ax.set_ylim(30,42)
ax.set_xlabel("Physics run on the top M by Boltz-2  (% of library)",fontsize=FS_LABEL)
ax.set_ylabel(f"Actives found at K={K}",fontsize=FS_LABEL)
ax.tick_params(labelsize=FS_TICK)
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.legend(fontsize=FS_NOTE,frameon=False,loc="lower right",handlelength=1.3)
ax.set_title("AI-then-physics cascade: most of the gain at a fraction of the physics cost",fontsize=FS_NOTE)
fig.tight_layout(); fig.savefig(OUT/"cascade_panel.pdf",bbox_inches="tight"); fig.savefig(OUT/"cascade_panel.png",dpi=300,bbox_inches="tight")
print("Boltz-2 alone",B0,"| physics-alone Pair",curves["Pair"][1][-1],"Triad",curves["Triad"][1][-1])
print("cascade table rows",len(rows))
