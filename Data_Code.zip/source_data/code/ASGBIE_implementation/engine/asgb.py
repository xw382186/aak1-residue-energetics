#!/usr/bin/env python3
"""
ASGBIE - Alanine Scanning GB Interaction Entropy
Python implementation for Amber24 (no legacy Fortran required)

Replaces the original bash/Fortran workflow:
  - AlaScan_GetNearResidue  → get_near_residues()
  - AlaScan_GetMutPDB       → create_mutant_pdb()
  - AlaScan_GetMutMDCrd      → create_mutant_trajectory()
  - Step1~Step4 bash scripts → step1_wildtype() ~ step4_results()

Usage:
    python asgbie.py config.ini [--step 1234] [--parallel 4]

Requirements:
    - Amber24 (AmberTools): tleap, cpptraj, MMPBSA.py(.MPI)
    - Python packages: numpy (included in Amber24 Python)
    - Optional: pytraj, parmed (included in Amber24 Python)

Author: Rewritten for Amber24 compatibility
"""

import os
import sys
import re
import math
import subprocess
import shutil
import configparser
import argparse
import logging
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional, Set

import numpy as np

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("ASGBIE")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
STANDARD_AA: Set[str] = {
    "GLY", "ALA", "VAL", "LEU", "ILE", "PHE", "TRP", "TYR",
    "ASP", "ASH", "ASN", "GLU", "GLH", "LYS", "LYN", "GLN",
    "MET", "SER", "THR", "CYS", "CYX", "CYM", "HIE", "HID", "HIP",
    "ARG", "PRO",
}

# Atoms to KEEP when mutating any residue → ALA
BACKBONE_ATOMS: Set[str] = {"N", "H", "H1", "H2", "H3", "CA", "HA", "C", "O", "OXT"}
ALA_SIDECHAIN: Set[str] = {"CB", "HB1", "HB2", "HB3"}
KEEP_ATOMS: Set[str] = BACKBONE_ATOMS | ALA_SIDECHAIN

# Residues that cannot be mutated to ALA (already ALA or no sidechain)
SKIP_RESIDUES: Set[str] = {"GLY", "ALA"}


# ===========================================================================
# Configuration
# ===========================================================================
@dataclass
class ASGBIEConfig:
    """All parameters for an ASGBIE calculation."""

    # --- File names ---
    com_name: str = "cpx"               # Complex system name
    com_pdb: str = "cpx.pdb"            # Complex PDB file
    com_mdcrd: str = "md.nc"            # Wildtype complex trajectory (NetCDF, no water)
    rec_name: str = "protein_only"      # Receptor name
    rec_pdb: str = "protein_only.pdb"   # Receptor PDB
    lig_name: str = "lig"               # Ligand name
    lig_pdb: str = "lig.pdb"            # Ligand PDB
    lig_name_in_pdb: str = "MOL"        # 3-letter ligand residue name in PDB
    lig_mol2: str = "lig.mol2"          # Ligand mol2 (GAFF charges)
    lig_frcmod: str = "lig.frcmod"      # Ligand frcmod
    pb_radii: str = "mbondi2"           # GB radii set (igb=2 → mbondi2)
    res_diel_file: str = "ResidueDielectric.dat"  # Per-residue dielectric

    # --- Residue range ---
    rec_res_start: int = 1              # Receptor start residue ID
    rec_res_stop: int = -1              # Receptor stop residue ID (-1 = auto)
    lig_res_start: int = -1             # Ligand start residue ID (-1 = auto)
    lig_res_stop: int = -1              # Ligand stop residue ID (-1 = auto)

    # --- Calculation ---
    max_distance: float = 5.0           # Cutoff for near-residue search (Å)
    frame_start: int = 2001             # Trajectory first frame
    frame_stop: int = 5000              # Trajectory last frame
    frame_offset: int = 30              # Frame stride
    processors: int = 10                # MPI ranks for MMPBSA.py.MPI
    parallel_mutants: int = 1           # Concurrent mutant calculations

    # --- MMGBSA ---
    igb: int = 2
    extdiel: float = 80.0
    saltcon: float = 0.0
    surften: float = 0.00500
    surfoff: float = 0.00000

    # --- Amber24 options ---
    use_sander: int = 1                 # Per-residue intdiel workflow requires sander mdins
    intdiel_workaround: bool = True     # Retained for config compatibility; two-pass path is always used

    # --- Housekeeping ---
    remove_temp: bool = True
    work_dir: str = ""                  # Will be set at runtime
    near_residue_file: str = "NearResidue.dat"

    # --- Force field ---
    protein_ff: str = "leaprc.protein.ff14SB"
    gaff_ff: str = "leaprc.gaff2"
    old_ff: str = ""   # e.g. "oldff/leaprc.ff14SB" – leave empty for Amber24

    @property
    def total_frames(self) -> int:
        return (self.frame_stop - self.frame_start) // self.frame_offset + 1


def load_config(ini_path: str) -> ASGBIEConfig:
    """Load configuration from an INI file."""
    cp = configparser.ConfigParser()
    cp.read(ini_path)
    cfg = ASGBIEConfig()

    # Map INI sections/keys → dataclass fields
    type_map = {f.name: f.type for f in cfg.__dataclass_fields__.values()}
    for section in cp.sections():
        for key, val in cp.items(section):
            key = key.strip().lower()
            if key not in type_map:
                raise ValueError(f"{ini_path}: [{section}] {key} is not a setting of this program")
            ftype = type_map[key]
            if ftype is bool or ftype == "bool":
                setattr(cfg, key, cp.getboolean(section, key))
            elif ftype is int or ftype == "int":
                setattr(cfg, key, int(val))
            elif ftype is float or ftype == "float":
                setattr(cfg, key, float(val))
            else:
                setattr(cfg, key, val)
    return cfg


# ===========================================================================
# PDB Utilities
# ===========================================================================
def parse_pdb(pdb_file: str) -> List[dict]:
    """Parse PDB file → list of atom dicts."""
    atoms = []
    with open(pdb_file) as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            atom = {
                "record":  line[:6].strip(),
                "serial":  int(line[6:11]),
                "name":    line[12:16].strip(),
                "altloc":  line[16],
                "resname": line[17:20].strip(),
                "chainid": line[21],
                "resid":   int(line[22:26]),
                "icode":   line[26],
                "x": float(line[30:38]),
                "y": float(line[38:46]),
                "z": float(line[46:54]),
                "occ":  float(line[54:60]) if line[54:60].strip() else 1.0,
                "bfac": float(line[60:66]) if line[60:66].strip() else 0.0,
                "elem": line[76:78].strip() if len(line) > 76 else "",
            }
            atoms.append(atom)
    return atoms


def write_pdb(atoms: List[dict], out_file: str) -> None:
    """
    Write atom list to PDB file with proper TER records at chain breaks.

    A TER is inserted whenever:
      - chainid changes between consecutive atoms, OR
      - the previous atom is a standard AA and the next is not (e.g. protein→ligand), OR
      - the previous atom is non-AA and the next is a standard AA.

    This is essential for tleap so that terminal residues (CGLU, NGLY, …) are
    correctly recognised and OXT / H1 / H2 / H3 get proper force-field types.
    """
    def _is_std(rn: str) -> bool:
        return rn in STANDARD_AA

    def _res_key(a: dict) -> tuple:
        return (a["chainid"], a["resid"], a["icode"], a["resname"])

    res_atom_names: Dict[tuple, Set[str]] = {}
    for a in atoms:
        res_atom_names.setdefault(_res_key(a), set()).add(a["name"])

    serial = 0
    with open(out_file, "w") as fh:
        prev = None
        for a in atoms:
            # Insert TER at chain break before writing the new atom
            if prev is not None:
                prev_key = _res_key(prev)
                curr_key = _res_key(a)
                new_residue = curr_key != prev_key
                chain_change = (a["chainid"] != prev["chainid"])
                type_change = (_is_std(a["resname"]) != _is_std(prev["resname"]))
                terminal_break = (
                    new_residue
                    and (
                        "OXT" in res_atom_names.get(prev_key, set())
                        or bool({"H1", "H2", "H3"} & res_atom_names.get(curr_key, set()))
                    )
                )
                if chain_change or type_change or terminal_break:
                    serial += 1
                    fh.write(
                        f"TER   {serial:5d}      "
                        f"{prev['resname']:>3s} {prev['chainid']}{prev['resid']:4d}\n"
                    )
            serial += 1
            name = a["name"]
            name_field = f" {name:<3s}" if len(name) < 4 else f"{name:<4s}"
            fh.write(
                f"{a['record']:<6s}{serial:5d} {name_field}{a['altloc']}"
                f"{a['resname']:>3s} {a['chainid']}{a['resid']:4d}{a['icode']}   "
                f"{a['x']:8.3f}{a['y']:8.3f}{a['z']:8.3f}"
                f"{a['occ']:6.2f}{a['bfac']:6.2f}          "
                f"{a['elem']:>2s}\n"
            )
            prev = a
        # Closing TER + END
        if prev is not None:
            serial += 1
            fh.write(
                f"TER   {serial:5d}      "
                f"{prev['resname']:>3s} {prev['chainid']}{prev['resid']:4d}\n"
            )
        fh.write("END\n")


def get_last_resid(pdb_file: str) -> int:
    """Get the last residue ID from a PDB file."""
    atoms = parse_pdb(pdb_file)
    return max(a["resid"] for a in atoms) if atoms else 0


def get_terminal_residues(pdb_file: str) -> Tuple[Set[int], Set[int]]:
    """Identify N-terminal (H2 present) and C-terminal (OXT present) residues."""
    n_term: Set[int] = set()
    c_term: Set[int] = set()
    for a in parse_pdb(pdb_file):
        if a["resname"] in STANDARD_AA:
            if a["name"] == "H2":
                n_term.add(a["resid"])
            if a["name"] == "OXT":
                c_term.add(a["resid"])
    return n_term, c_term


# ===========================================================================
# Dielectric Utilities
# ===========================================================================
def read_dielectric_file(path: str) -> Dict[str, float]:
    """Read ResidueDielectric.dat → {ResName: dielectric}."""
    diel: Dict[str, float] = {}
    with open(path) as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 2:
                diel[parts[0]] = float(parts[1])
    return diel


def get_diel_key(resname: str, resid: int, n_term: Set[int], c_term: Set[int]) -> str:
    """
    Map a residue to its dielectric-file key.
    N-terminal residues get 'N' prefix, C-terminal get 'C' prefix.
    """
    if resid in n_term:
        return f"N{resname}"
    if resid in c_term:
        return f"C{resname}"
    return resname


# ===========================================================================
# Core Function 1:  get_near_residues
# Replaces Fortran program  AlaScan_GetNearResidue
# ===========================================================================
def get_near_residues(
    complex_pdb: str,
    rec_start: int,
    rec_stop: int,
    lig_start: int,
    lig_stop: int,
    max_distance: float,
) -> List[Tuple[str, int]]:
    """
    Find receptor residues within *max_distance* Å of any ligand atom.

    Returns sorted list of (resname, resid) excluding GLY/ALA.
    """
    atoms = parse_pdb(complex_pdb)
    lig_coords = np.array(
        [[a["x"], a["y"], a["z"]] for a in atoms if lig_start <= a["resid"] <= lig_stop]
    )

    near: Set[Tuple[str, int]] = set()
    for a in atoms:
        if not (rec_start <= a["resid"] <= rec_stop):
            continue
        coord = np.array([a["x"], a["y"], a["z"]])
        dists = np.linalg.norm(lig_coords - coord, axis=1)
        if dists.min() <= max_distance:
            near.add((a["resname"], a["resid"]))

    # Remove GLY / ALA (can't scan these)
    result = sorted(
        [(n, r) for n, r in near if n not in SKIP_RESIDUES],
        key=lambda x: x[1],
    )
    logger.info(f"Near-ligand residues (≤{max_distance} Å): {len(result)}")
    for n, r in result:
        logger.info(f"  {n}{r}")
    return result


# ===========================================================================
# Core Function 2:  create_mutant_pdb
# Replaces Fortran program  AlaScan_GetMutPDB
# ===========================================================================
def create_mutant_pdb(
    pdb_file: str, mut_res_id: int, output_prefix: str
) -> Tuple[str, str]:
    """
    Create alanine-mutant PDB: strip sidechain beyond CB, rename → ALA.

    Parameters
    ----------
    pdb_file : wildtype PDB
    mut_res_id : residue ID to mutate
    output_prefix : e.g. 'cpx' or 'protein_only'

    Returns
    -------
    (mutant_base_name, original_resname)
    e.g. ('cpx_LEU123ALA', 'LEU')
    """
    atoms = parse_pdb(pdb_file)
    orig_resname = None
    for a in atoms:
        if a["resid"] == mut_res_id and a["resname"] in STANDARD_AA:
            orig_resname = a["resname"]
            break
    if orig_resname is None:
        raise ValueError(f"Residue {mut_res_id} not found or not standard AA")

    mut_name = f"{output_prefix}_{orig_resname}{mut_res_id}ALA"

    # Build mutant atom list
    keep = BACKBONE_ATOMS | {"CB"}  # Keep backbone + CB only (tleap adds HB*)
    new_atoms = []
    for a in atoms:
        if a["resid"] == mut_res_id and a["resname"] == orig_resname:
            if a["name"] in keep:
                cp = dict(a)
                cp["resname"] = "ALA"
                new_atoms.append(cp)
            # else: sidechain atom removed
        else:
            new_atoms.append(a)

    write_pdb(new_atoms, f"{mut_name}.pdb")
    logger.info(f"Mutant PDB: {mut_name}.pdb  ({orig_resname}{mut_res_id} → ALA)")
    return mut_name, orig_resname


# ===========================================================================
# Core Function 3:  mutant coordinates
# Replaces Fortran program  AlaScan_GetMutMDCrd
# ===========================================================================
# Every mutant atom that the wild type also has takes the wild-type
# coordinates of the same frame.  Every hydrogen the mutant has and the wild
# type lacks is put on a bond the mutation deleted, NEW_H_BOND_LENGTH from the
# atom it hangs on, pointing at the removed wild-type atom of that frame:
#
#   HB2/HB3 kept; HB1 on CB->CG (CB->SG for Cys, CB->OG for Ser)
#   ILE / VAL: HB kept as HB2; HB1 on CB->CG2, HB3 on CB->CG1
#   THR:       HB kept as HB2; HB1 on CB->CG2, HB3 on CB->OG1
#   PRO:       the amide H (H1 at an N terminus) on N->CD
#
# The three ALA methyl hydrogens carry identical parameters, so which name
# takes which bond changes no energy.
NEW_H_BOND_LENGTH = 1.09

# Wild-type atom whose bond to CB receives ALA HB1, for residues whose CB
# carries HB2 and HB3.
ALA_HB1_PARTNER: Dict[str, str] = {
    "ARG": "CG", "ASH": "CG", "ASN": "CG", "ASP": "CG", "GLH": "CG",
    "GLN": "CG", "GLU": "CG", "HID": "CG", "HIE": "CG", "HIP": "CG",
    "LEU": "CG", "LYN": "CG", "LYS": "CG", "MET": "CG", "PHE": "CG",
    "PRO": "CG", "TRP": "CG", "TYR": "CG",
    "CYM": "SG", "CYS": "SG", "CYX": "SG",
    "SER": "OG",
}
# Residues whose CB carries a single HB: partners of (HB1, HB3).
ALA_BRANCHED_PARTNERS: Dict[str, Tuple[str, str]] = {
    "ILE": ("CG2", "CG1"),
    "VAL": ("CG2", "CG1"),
    "THR": ("CG2", "OG1"),
}


def mutant_h_rule(
    wt_resname: str,
    wt_names: Set[str],
    mut_names: Set[str],
) -> Tuple[Dict[str, str], Dict[str, Tuple[str, str]]]:
    """Hydrogen rule for one residue mutated to ALA.

    Returns (inherited, generated):
      inherited  mutant atom name -> differently named wild-type atom whose
                 coordinates it takes
      generated  mutant H name -> (wild-type atom it hangs on, wild-type atom
                 at the far end of the deleted bond)
    """
    if wt_resname in ALA_BRANCHED_PARTNERS:
        hb1, hb3 = ALA_BRANCHED_PARTNERS[wt_resname]
        inherited = {"HB2": "HB"}
        generated = {"HB1": ("CB", hb1), "HB3": ("CB", hb3)}
    elif wt_resname in ALA_HB1_PARTNER:
        inherited, generated = {}, {"HB1": ("CB", ALA_HB1_PARTNER[wt_resname])}
    else:
        raise ValueError(f"no mutant hydrogen rule for residue type {wt_resname}")
    if wt_resname == "PRO":
        for name in ("H", "H1"):
            if name in mut_names and name not in wt_names:
                generated[name] = ("N", "CD")
    return inherited, generated


def mutant_coordinate_plan(
    wt_atoms: List[dict],
    mut_atoms: List[dict],
    mut_res_id: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Where every mutant atom takes its coordinates from, frame by frame.

    Returns (mapping, generated):
      mapping    (n_mut,) wild-type atom index each mutant atom copies,
                 -1 for a generated hydrogen
      generated  (k, 3) rows (mutant index, wild-type index of the atom the H
                 hangs on, wild-type index of the deleted bond partner)

    A mutant atom covered by neither is an error, so no atom can be left at a
    coordinate that does not follow the trajectory.
    """
    wt_lookup = {(a["resid"], a["name"]): i for i, a in enumerate(wt_atoms)}
    wt_res = [a for a in wt_atoms if a["resid"] == mut_res_id]
    if not wt_res:
        raise ValueError(f"residue {mut_res_id} is not in the wild-type structure")
    wt_resname = wt_res[0]["resname"]
    inherited, rule = mutant_h_rule(
        wt_resname,
        {a["name"] for a in wt_res},
        {a["name"] for a in mut_atoms if a["resid"] == mut_res_id},
    )

    mapping = np.full(len(mut_atoms), -1, dtype=int)
    generated: List[Tuple[int, int, int]] = []
    missing: List[str] = []
    for mi, ma in enumerate(mut_atoms):
        name = ma["name"]
        in_res = ma["resid"] == mut_res_id
        if in_res and name in rule:
            ends = [wt_lookup.get((mut_res_id, n), -1) for n in rule[name]]
            if min(ends) < 0:
                missing.append(f"{name} (needs wild-type {'/'.join(rule[name])})")
            else:
                generated.append((mi, ends[0], ends[1]))
            continue
        source = inherited.get(name, name) if in_res else name
        wi = wt_lookup.get((ma["resid"], source), -1)
        if wi < 0:
            missing.append(f":{ma['resid']}@{name}")
        else:
            mapping[mi] = wi
    if missing:
        raise ValueError(
            f"mutant of residue {mut_res_id} ({wt_resname}): no wild-type source for "
            + ", ".join(missing)
        )
    return mapping, np.array(generated, dtype=int).reshape(-1, 3)


def build_mutant_coordinates(
    wt_xyz: np.ndarray,
    mapping: np.ndarray,
    generated: np.ndarray,
) -> np.ndarray:
    """Apply a mutant_coordinate_plan to one frame (n_wt, 3) or frames (n, n_wt, 3)."""
    # C order: pytraj.Trajectory(xyz=...) rejects the strided array the fancy
    # index returns ("Buffer not C contiguous").
    mut = np.ascontiguousarray(wt_xyz[..., np.maximum(mapping, 0), :], dtype=np.float64)
    if len(generated):
        origin = wt_xyz[..., generated[:, 1], :]
        bond = wt_xyz[..., generated[:, 2], :] - origin
        mut[..., generated[:, 0], :] = origin + NEW_H_BOND_LENGTH * (
            bond / np.linalg.norm(bond, axis=-1, keepdims=True)
        )
    return mut


_TRAJ_FRAME_COUNT_CACHE = {}


def get_trajectory_frame_count(traj_file: str, top_file: str) -> int:
    """Return the number of frames, cached per trajectory/topology pair."""
    import pytraj as pt

    key = (os.path.abspath(traj_file), os.path.abspath(top_file))
    if key not in _TRAJ_FRAME_COUNT_CACHE:
        _TRAJ_FRAME_COUNT_CACHE[key] = int(pt.iterload(traj_file, top_file).n_frames)
    return _TRAJ_FRAME_COUNT_CACHE[key]


def validate_frame_indices(traj_file: str, top_file: str, frame_indices, context: str) -> None:
    """Fail early if config frame_start/frame_stop exceeds available frames."""
    if not frame_indices:
        raise ValueError(f"{context}: no frames selected; check frame_start/frame_stop/frame_offset")
    min_idx = min(frame_indices)
    max_idx = max(frame_indices)
    if min_idx < 0:
        raise ValueError(f"{context}: frame_start must be >= 1")
    n_frames = get_trajectory_frame_count(traj_file, top_file)
    if max_idx >= n_frames:
        requested = f"{min_idx + 1}-{max_idx + 1}"
        raise ValueError(
            f"{context}: requested 1-based frames {requested} from {traj_file}, "
            f"but this trajectory has only {n_frames} frames."
        )


def create_mutant_trajectory(
    wt_pdb: str,
    wt_mdcrd: str,
    mut_pdb_after_tleap: str,
    mut_top: str,
    mut_res_id: int,
    first_frame: int,
    last_frame: int,
    offset_frame: int,
    output_nc: str,
) -> None:
    """
    Create mutant trajectory matching the tleap-generated mutant topology.

    1. Map every mutant atom onto the wild type (mutant_coordinate_plan).
    2. Load the selected wild-type frames and build the mutant coordinates
       frame by frame (build_mutant_coordinates).
    3. Write output NetCDF using pytraj, or cpptraj as a fallback.
    """
    mapping, generated = mutant_coordinate_plan(
        parse_pdb(wt_pdb), parse_pdb(mut_pdb_after_tleap), mut_res_id
    )

    # --- Determine frame indices (1-based → 0-based for pytraj) ---
    frame_indices = list(range(first_frame - 1, last_frame, offset_frame))
    n_frames = len(frame_indices)

    # The frame-range guard sits inside this try: its ValueError is a
    # configuration error and is re-raised, because the cpptraj fallback does
    # not check the range and would silently use a different number of frames.
    # Any other failure of the pytraj path falls back to cpptraj.
    try:
        import pytraj as pt

        validate_frame_indices(wt_mdcrd, wt_pdb, frame_indices, "Mutant trajectory generation")
        wt_traj = pt.load(wt_mdcrd, wt_pdb, frame_indices=frame_indices)
        mut_xyz = build_mutant_coordinates(wt_traj.xyz, mapping, generated)

        mut_top_obj = pt.load_topology(mut_top)
        mut_traj = pt.Trajectory(xyz=mut_xyz, top=mut_top_obj)
        pt.write_traj(output_nc, mut_traj, overwrite=True)
        logger.info(f"Mutant trajectory (pytraj): {output_nc}  ({n_frames} frames)")
        return

    except ValueError:
        raise
    except Exception as exc:
        logger.warning(f"pytraj mutant-trajectory path failed ({exc}), using cpptraj fallback")

    # --- Fallback: cpptraj frame by frame ---
    _create_mutant_traj_cpptraj(
        wt_pdb, wt_mdcrd, mut_top, mut_res_id, first_frame, last_frame,
        offset_frame, output_nc, mapping, generated,
    )


def _create_mutant_traj_cpptraj(
    wt_pdb, wt_mdcrd, mut_top, mut_res_id, first_frame, last_frame,
    offset_frame, output_nc, mapping, generated,
):
    """
    Fallback: use cpptraj frame-by-frame extraction + Python coordinate assembly.
    Writes individual restart files, merges them.
    """
    tmp_dir = f"_tmp_mutcrd_{mut_res_id}"
    os.makedirs(tmp_dir, exist_ok=True)

    n_wt = len(parse_pdb(wt_pdb))
    frame_indices = list(range(first_frame, last_frame + 1, offset_frame))
    n_frames = len(frame_indices)

    # Extract each WT frame → restart file, read coords, build mut coords
    for fi, frame_num in enumerate(frame_indices):
        rst_file = os.path.join(tmp_dir, f"wt_{fi}.rst7")
        cpptraj_in = (
            f"parm {wt_pdb}\n"
            f"trajin {wt_mdcrd} {frame_num} {frame_num} 1\n"
            f"trajout {rst_file} restart\n"
            f"go\n"
        )
        _run_cpptraj(cpptraj_in, f"{tmp_dir}/_cpptraj_{fi}.in")

        wt_coords = _read_restart_coords(rst_file, n_wt)
        mut_rst = os.path.join(tmp_dir, f"mut_{fi}.rst7")
        _write_restart(build_mutant_coordinates(wt_coords, mapping, generated), mut_rst)

    # Combine all restart files into single NetCDF trajectory
    cpptraj_combine = f"parm {mut_top}\n"
    for fi in range(n_frames):
        cpptraj_combine += f"trajin {tmp_dir}/mut_{fi}.rst7\n"
    cpptraj_combine += f"trajout {output_nc} netcdf\ngo\n"
    _run_cpptraj(cpptraj_combine, f"{tmp_dir}/_combine.in")

    shutil.rmtree(tmp_dir, ignore_errors=True)
    logger.info(f"Mutant trajectory (cpptraj fallback): {output_nc}  ({n_frames} frames)")


def _run_cpptraj(input_text: str, input_file: str = "_cpptraj_tmp.in") -> None:
    """Write cpptraj input and run."""
    with open(input_file, "w") as fh:
        fh.write(input_text)
    result = subprocess.run(
        ["cpptraj", "-i", input_file],
        capture_output=True, text=True,
    )
    os.remove(input_file)
    if result.returncode != 0:
        logger.error(f"cpptraj FAILED:\n{result.stderr}\n{result.stdout}")
        raise RuntimeError("cpptraj failed")


def _read_restart_coords(rst_file: str, n_atoms: int) -> np.ndarray:
    """Read coordinates from Amber restart (.rst7) file."""
    coords = []
    with open(rst_file) as fh:
        lines = fh.readlines()
    # Line 0: title,  Line 1: natom [time]
    # Lines 2+: coordinates (6 values per line, F12.7)
    for line in lines[2:]:
        vals = [line[i:i+12] for i in range(0, len(line.rstrip()), 12)]
        for v in vals:
            v = v.strip()
            if v:
                coords.append(float(v))
            if len(coords) >= n_atoms * 3:
                break
        if len(coords) >= n_atoms * 3:
            break
    return np.array(coords[:n_atoms * 3]).reshape(n_atoms, 3)


def _write_restart(coords: np.ndarray, rst_file: str) -> None:
    """Write Amber restart (.rst7) file from coordinate array (n_atoms, 3)."""
    n_atoms = coords.shape[0]
    with open(rst_file, "w") as fh:
        fh.write("mutant restart\n")
        fh.write(f"{n_atoms:5d}\n")
        flat = coords.flatten()
        for i in range(0, len(flat), 6):
            chunk = flat[i:i+6]
            fh.write("".join(f"{v:12.7f}" for v in chunk) + "\n")


# ===========================================================================
# tleap Helpers
# ===========================================================================
def _tleap_source_lines(cfg: ASGBIEConfig) -> str:
    """Generate tleap source commands for force fields."""
    lines = []
    if cfg.old_ff:
        lines.append(f"source {cfg.old_ff}")
    lines.append(f"source {cfg.protein_ff}")
    lines.append(f"source {cfg.gaff_ff}")
    return "\n".join(lines)


def run_tleap(input_text: str, log_file: str = "tleap.log") -> bool:
    """Run tleap with given input string."""
    in_file = "_tleap_temp.in"
    with open(in_file, "w") as fh:
        fh.write(input_text)
    result = subprocess.run(
        ["tleap", "-s", "-f", in_file],
        capture_output=True, text=True,
    )
    with open(log_file, "w") as fh:
        fh.write(result.stdout or "")
        fh.write(result.stderr or "")
    os.remove(in_file)
    if result.returncode != 0:
        logger.error(f"tleap FAILED – see {log_file}")
        return False
    # Check for FATAL errors in output
    if "FATAL" in (result.stdout or ""):
        logger.error(f"tleap FATAL error – see {log_file}")
        return False
    return True


# ===========================================================================
# MMPBSA Helpers
# ===========================================================================
def create_mmpbsa_input(
    intdiel: float,
    startframe: int,
    endframe: int,
    interval: int,
    cfg: ASGBIEConfig,
) -> str:
    """
    Generate MMPBSA.py input file content.

    NOTE: intdiel is NOT placed here — MMPBSA.py does not recognise it as a
    valid &gb variable.  Instead, we always use the two-pass workaround
    (-make-mdins → inject intdiel into _MMPBSA_gb.mdin → -use-mdins).
    The intdiel parameter is accepted here only so the caller's signature
    stays unchanged; actual injection happens in run_mmpbsa().
    """
    text = f"""MMGBSA control file
&general
    startframe={startframe},
    endframe={endframe},
    interval={interval},
    netcdf=1,
    keep_files=0,
    debug_printlevel=0,
    verbose=1,
    entropy=0,
"""
    # Per-residue intdiel is injected into sander mdins below, so we must
    # force the sander execution path to preserve the legacy ASGB behavior.
    text += "    use_sander=1,\n"
    # NOTE: Only parameters that MMPBSA.py recognises go here.
    # intdiel and extdiel are sander-only &gb variables and are
    # injected later via the -make-mdins / -use-mdins two-pass approach.
    text += """/
&gb
    igb={igb},
    saltcon={saltcon},
    ifqnt=0,
    molsurf=0,
    surften={surften},
    surfoff={surfoff},
/
""".format(
        igb=cfg.igb,
        saltcon=cfg.saltcon,
        surften=cfg.surften,
        surfoff=cfg.surfoff,
    )
    return text


def run_mmpbsa(
    input_file: str,
    output_dat: str,
    output_csv: str,
    solvated_top: str,
    complex_top: str,
    receptor_top: str,
    ligand_top: str,
    mdcrd: str,
    processors: int = 1,
    intdiel: float = 1.0,
    extdiel: float = 80.0,
    use_workaround: bool = False,  # kept for API compat; always uses two-pass now
) -> bool:
    """
    Run MMPBSA.py[.MPI] with the two-pass intdiel injection.

    MMPBSA.py (AmberTools 24) does NOT accept 'intdiel' in its &gb input.
    We always use:
      pass-1: -make-mdins  →  generates _MMPBSA_gb.mdin (sander mdin)
      inject: add 'intdiel=X' into that mdin's &gb namelist
      pass-2: -use-mdins   →  runs sander with the patched mdin
    """
    log_file = output_dat.replace(".dat", ".log")

    base_cmd: List[str] = []
    if processors > 1:
        # --oversubscribe: SLURM --cpus-per-task=N gives 1 task + N CPUs,
        # but mpirun/PRRTE sees only 1 "slot".
        base_cmd = [
            "mpirun",
            "--oversubscribe",
            "-np", str(processors),
            "MMPBSA.py.MPI",
        ]
    else:
        base_cmd = ["MMPBSA.py"]

    common_args = [
        "-O",
        "-i", input_file,
        "-o", output_dat,
        "-eo", output_csv,
        "-sp", solvated_top,
        "-cp", complex_top,
        "-rp", receptor_top,
        "-lp", ligand_top,
        "-y", mdcrd,
    ]

    # === Pass 1: generate sander mdin files ===
    # Serial here avoids PRRTE/MPI hangs; the actual GB run below still uses MPI.
    cmd1 = ["MMPBSA.py"] + common_args + ["-make-mdins"]
    r1 = subprocess.run(cmd1, capture_output=True, text=True)
    with open(log_file, "w") as fh:
        fh.write("=== PASS 1: -make-mdins ===\n")
        fh.write(r1.stdout or "")
        fh.write(r1.stderr or "")

    if r1.returncode != 0:
        logger.error(f"MMPBSA.py -make-mdins FAILED – see {log_file}")
        return False

    # === Inject intdiel AND extdiel into the generated sander mdin ===
    # MMPBSA.py does NOT pass intdiel or extdiel through its input parser.
    # The generated _MMPBSA_gb*.mdin files already contain an &gb namelist
    # with igb, saltcon, etc. set by sander defaults.  We inject our values
    # right after the 'igb=' line.
    mdin_files = ["_MMPBSA_gb.mdin", "_MMPBSA_gb_com.mdin",
                   "_MMPBSA_gb_rec.mdin", "_MMPBSA_gb_lig.mdin"]
    injected = False
    for mdin in mdin_files:
        if not os.path.exists(mdin):
            continue
        with open(mdin) as fh:
            content = fh.read()

        modified = False
        # Inject intdiel if not already present
        if "intdiel" not in content and "igb" in content:
            content = re.sub(
                r"(igb\s*=\s*\d+\s*,)",
                rf"\1\n  intdiel={intdiel},",
                content,
            )
            modified = True
        # Inject extdiel if not already present
        if "extdiel" not in content and "igb" in content:
            content = re.sub(
                r"(igb\s*=\s*\d+\s*,)",
                rf"\1\n  extdiel={extdiel},",
                content,
            )
            modified = True

        if modified:
            with open(mdin, "w") as fh:
                fh.write(content)
            injected = True

    if injected:
        logger.info(f"Injected intdiel={intdiel}, extdiel={extdiel} into sander mdin files")
    else:
        logger.warning("No _MMPBSA_gb*.mdin files found to patch")

    # === Pass 2: run with patched mdin ===
    cmd2 = base_cmd + common_args + ["-use-mdins"]
    r2 = subprocess.run(cmd2, capture_output=True, text=True)
    with open(log_file, "a") as fh:
        fh.write("\n=== PASS 2: -use-mdins ===\n")
        fh.write(r2.stdout or "")
        fh.write(r2.stderr or "")
    ok = r2.returncode == 0

    if not ok:
        logger.error(f"MMPBSA.py FAILED – see {log_file}")
    return ok


def parse_mmpbsa_dat(dat_file: str) -> Dict[str, float]:
    """
    Parse MMPBSA output .dat for average energy components.
    Returns dict with keys: VDWAALS, EEL, EGB, ESURF, DELTA_TOTAL
    """
    results: Dict[str, float] = {}
    with open(dat_file) as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("VDWAALS"):
                results["VDWAALS"] = float(line.split()[1])
            elif line.startswith("EEL") and "EEL" in line.split()[0]:
                results["EEL"] = float(line.split()[1])
            elif line.startswith("EGB"):
                results["EGB"] = float(line.split()[1])
            elif line.startswith("ESURF"):
                results["ESURF"] = float(line.split()[1])
            elif "DELTA TOTAL" in line:
                results["DELTA_TOTAL"] = float(line.split()[2])
    return results


# ===========================================================================
# Step 1: Wildtype MMGBSA
# ===========================================================================
def step1_wildtype(cfg: ASGBIEConfig) -> None:
    """Prepare wildtype topologies and run wildtype MMGBSA with all dielectric values."""
    logger.info("=" * 60)
    logger.info("STEP 1: Wildtype MMGBSA")
    logger.info("=" * 60)

    wt_dir = os.path.join(os.path.dirname(cfg.work_dir), "Wildtype")
    if os.path.exists(wt_dir):
        shutil.rmtree(wt_dir)
    os.makedirs(wt_dir)

    # Symlink input files
    for fname in [cfg.com_pdb, cfg.com_mdcrd, cfg.rec_pdb, cfg.lig_pdb]:
        src = os.path.join(cfg.work_dir, fname)
        dst = os.path.join(wt_dir, fname)
        if os.path.exists(dst):
            os.remove(dst)
        os.symlink(src, dst)

    orig_dir = os.getcwd()
    os.chdir(wt_dir)

    # --- tleap: wildtype topologies ---
    lig_mol2_path = os.path.join(cfg.work_dir, cfg.lig_mol2)
    lig_frcmod_path = os.path.join(cfg.work_dir, cfg.lig_frcmod)

    tleap_in = f"""{_tleap_source_lines(cfg)}
{cfg.lig_name_in_pdb}=loadmol2 {lig_mol2_path}
loadamberparams {lig_frcmod_path}
WidRec=loadpdb {cfg.rec_pdb}
Lig=loadpdb {cfg.lig_pdb}
WidCom=loadpdb {cfg.com_pdb}
set default PBRadii {cfg.pb_radii}
saveamberparm WidRec {cfg.rec_name}.top {cfg.rec_name}.crd
saveamberparm Lig {cfg.lig_name}.top {cfg.lig_name}.crd
saveamberparm WidCom {cfg.com_name}.top {cfg.com_name}.crd
quit
"""
    if not run_tleap(tleap_in, "tleap_wildtype.log"):
        raise RuntimeError("tleap failed for wildtype")

    # --- Get all unique dielectric values ---
    diel_map = read_dielectric_file(os.path.join(cfg.work_dir, cfg.res_diel_file))
    unique_diels = sorted(set(diel_map.values()))
    logger.info(f"Dielectric values: {unique_diels}")

    # --- Run MMGBSA for each dielectric ---
    for diel in unique_diels:
        logger.info(f"Running wildtype MMGBSA with intdiel={diel} ...")
        in_file = f"In_MMGBSA_intdiel={diel}.in"
        out_dat = f"{cfg.com_name}_MMGBSA_intdiel={diel}.dat"
        out_csv = f"{cfg.com_name}_MMGBSA_intdiel={diel}.csv"

        mmpbsa_text = create_mmpbsa_input(
            intdiel=diel,
            startframe=cfg.frame_start,
            endframe=cfg.frame_stop,
            interval=cfg.frame_offset,
            cfg=cfg,
        )
        with open(in_file, "w") as fh:
            fh.write(mmpbsa_text)

        ok = run_mmpbsa(
            input_file=in_file,
            output_dat=out_dat,
            output_csv=out_csv,
            solvated_top=f"{cfg.com_name}.top",
            complex_top=f"{cfg.com_name}.top",
            receptor_top=f"{cfg.rec_name}.top",
            ligand_top=f"{cfg.lig_name}.top",
            mdcrd=cfg.com_mdcrd,
            processors=cfg.processors,
            intdiel=diel,
            extdiel=cfg.extdiel,
            use_workaround=cfg.intdiel_workaround,
        )
        if not ok:
            logger.error(f"Wildtype MMGBSA intdiel={diel} FAILED")

    # --- Cleanup ---
    if cfg.remove_temp:
        for pat in ["*.nc", "*.pdb", "*.top", "*.crd", "In_*.in",
                     "Log_*.log", "_MMPBSA_*"]:
            for f in Path(".").glob(pat):
                # Keep result files
                if "MMGBSA_intdiel" in f.name and f.suffix in (".dat", ".csv"):
                    continue
                f.unlink(missing_ok=True)

    os.chdir(orig_dir)
    logger.info("Step 1 complete.\n")


# ===========================================================================
# Step 2: Prepare mutant directories
# ===========================================================================
def step2_prepare(cfg: ASGBIEConfig) -> List[Tuple[str, int]]:
    """Find near-residues and prepare one directory per mutant."""
    logger.info("=" * 60)
    logger.info("STEP 2: Prepare mutant directories")
    logger.info("=" * 60)

    orig_dir = os.getcwd()
    os.chdir(cfg.work_dir)

    # Auto-detect residue ranges if needed
    if cfg.rec_res_stop < 0:
        cfg.rec_res_stop = get_last_resid(cfg.rec_pdb)
    if cfg.lig_res_start < 0:
        cfg.lig_res_start = cfg.rec_res_stop + 1
    if cfg.lig_res_stop < 0:
        cfg.lig_res_stop = cfg.rec_res_stop + 1

    logger.info(f"Receptor residues: {cfg.rec_res_start}–{cfg.rec_res_stop}")
    logger.info(f"Ligand residues:   {cfg.lig_res_start}–{cfg.lig_res_stop}")

    # --- Find near residues ---
    near = get_near_residues(
        cfg.com_pdb, cfg.rec_res_start, cfg.rec_res_stop,
        cfg.lig_res_start, cfg.lig_res_stop, cfg.max_distance,
    )

    # Save NearResidue.dat (same format as original)
    with open(cfg.near_residue_file, "w") as fh:
        for resname, resid in near:
            fh.write(f"{resname}{resid}\n")

    # --- Prepare directories ---
    n_term, c_term = get_terminal_residues(cfg.com_pdb)
    diel_map = read_dielectric_file(cfg.res_diel_file)

    for resname, resid in near:
        mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
        mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
        if os.path.exists(mut_dir):
            shutil.rmtree(mut_dir)
        os.makedirs(mut_dir)

        # Symlink input files
        for fname in [cfg.com_pdb, cfg.com_mdcrd, cfg.rec_pdb, cfg.lig_pdb]:
            src = os.path.join(cfg.work_dir, fname)
            dst = os.path.join(mut_dir, fname)
            os.symlink(src, dst)

        # Determine dielectric for this residue
        diel_key = get_diel_key(resname, resid, n_term, c_term)
        diel_val = diel_map.get(diel_key, 1.0)

        # Write mutant metadata for Step 3
        meta = configparser.ConfigParser()
        meta["mutant"] = {
            "resname": resname,
            "resid": str(resid),
            "diel_key": diel_key,
            "diel_value": str(diel_val),
        }
        with open(os.path.join(mut_dir, "_mutant_meta.ini"), "w") as fh:
            meta.write(fh)

        logger.info(f"  Prepared {mut_dir_name}  (intdiel={diel_val})")

    os.chdir(orig_dir)
    logger.info(f"Step 2 complete – {len(near)} mutants prepared.\n")
    return near


# ===========================================================================
# Step 3: Calculate (per-mutant worker + parallel dispatch)
# ===========================================================================
def _calculate_single_mutant(
    cfg: ASGBIEConfig,
    resname: str,
    resid: int,
) -> str:
    """
    Run full calculation for a single mutant:
      1. Create mutant PDBs (complex + receptor)
      2. tleap → topologies
      3. Build mutant trajectory
      4. Run MMPBSA
    Returns status string.
    """
    mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
    mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
    os.chdir(mut_dir)

    # Read metadata
    meta = configparser.ConfigParser()
    meta.read("_mutant_meta.ini")
    diel_val = float(meta["mutant"]["diel_value"])

    try:
        # --- 1. Create mutant PDBs ---
        mut_com_name, _ = create_mutant_pdb(cfg.com_pdb, resid, cfg.com_name)
        mut_rec_name, _ = create_mutant_pdb(cfg.rec_pdb, resid, cfg.rec_name)

        # --- 2. tleap → topologies ---
        lig_mol2_path = os.path.join(cfg.work_dir, cfg.lig_mol2)
        lig_frcmod_path = os.path.join(cfg.work_dir, cfg.lig_frcmod)

        tleap_in = f"""{_tleap_source_lines(cfg)}
{cfg.lig_name_in_pdb}=loadmol2 {lig_mol2_path}
loadamberparams {lig_frcmod_path}
MutRec=loadpdb {mut_rec_name}.pdb
WidRec=loadpdb {cfg.rec_pdb}
Lig=loadpdb {cfg.lig_pdb}
MutCom=loadpdb {mut_com_name}.pdb
WidCom=loadpdb {cfg.com_pdb}
set default PBRadii {cfg.pb_radii}
saveamberparm MutRec {mut_rec_name}.top {mut_rec_name}.crd
savepdb MutRec {mut_rec_name}.pdb
saveamberparm WidRec {cfg.rec_name}.top {cfg.rec_name}.crd
saveamberparm Lig {cfg.lig_name}.top {cfg.lig_name}.crd
saveamberparm MutCom {mut_com_name}.top {mut_com_name}.crd
savepdb MutCom {mut_com_name}.pdb
saveamberparm WidCom {cfg.com_name}.top {cfg.com_name}.crd
quit
"""
        if not run_tleap(tleap_in, "tleap_mutant.log"):
            return f"{mut_dir_name}: tleap FAILED"

        # --- 3. Build mutant trajectory ---
        output_nc = f"{mut_com_name}.nc"
        create_mutant_trajectory(
            wt_pdb=cfg.com_pdb,
            wt_mdcrd=cfg.com_mdcrd,
            mut_pdb_after_tleap=f"{mut_com_name}.pdb",  # tleap-overwritten PDB
            mut_top=f"{mut_com_name}.top",
            mut_res_id=resid,
            first_frame=cfg.frame_start,
            last_frame=cfg.frame_stop,
            offset_frame=cfg.frame_offset,
            output_nc=output_nc,
        )

        # --- 4. Run MMPBSA ---
        in_file = f"In_MMGBSA_intdiel={diel_val}.in"
        out_dat = f"{mut_com_name}_MMGBSA_intdiel={diel_val}.dat"
        out_csv = f"{mut_com_name}_MMGBSA_intdiel={diel_val}.csv"

        mmpbsa_text = create_mmpbsa_input(
            intdiel=diel_val,
            startframe=1,
            endframe=cfg.total_frames,
            interval=1,
            cfg=cfg,
        )
        with open(in_file, "w") as fh:
            fh.write(mmpbsa_text)

        ok = run_mmpbsa(
            input_file=in_file,
            output_dat=out_dat,
            output_csv=out_csv,
            solvated_top=f"{mut_com_name}.top",
            complex_top=f"{mut_com_name}.top",
            receptor_top=f"{mut_rec_name}.top",
            ligand_top=f"{cfg.lig_name}.top",
            mdcrd=output_nc,
            processors=cfg.processors,
            intdiel=diel_val,
            extdiel=cfg.extdiel,
            use_workaround=cfg.intdiel_workaround,
        )
        if not ok:
            return f"{mut_dir_name}: MMPBSA FAILED"

        # --- Cleanup ---
        if cfg.remove_temp:
            for pat in ["*.nc", "*.pdb", "*.top", "*.crd", "In_*.in",
                         "Log_*.log", "_MMPBSA_*", "_mutant_meta.ini",
                         "tleap_mutant.log"]:
                for f in Path(".").glob(pat):
                    if "MMGBSA_intdiel" in f.name and f.suffix in (".dat", ".csv"):
                        continue
                    f.unlink(missing_ok=True)

        return f"{mut_dir_name}: OK"

    except Exception as exc:
        return f"{mut_dir_name}: ERROR – {exc}"


def step3_calculate(cfg: ASGBIEConfig, near: List[Tuple[str, int]]) -> None:
    """Run all mutant calculations, optionally in parallel."""
    logger.info("=" * 60)
    logger.info("STEP 3: Calculate mutants")
    logger.info("=" * 60)

    orig_dir = os.getcwd()

    if cfg.parallel_mutants <= 1:
        # Sequential
        for resname, resid in near:
            status = _calculate_single_mutant(cfg, resname, resid)
            logger.info(status)
            os.chdir(orig_dir)
    else:
        # Parallel
        with ProcessPoolExecutor(max_workers=cfg.parallel_mutants) as pool:
            futures = {}
            for resname, resid in near:
                fut = pool.submit(_calculate_single_mutant, cfg, resname, resid)
                futures[fut] = (resname, resid)

            for fut in as_completed(futures):
                status = fut.result()
                logger.info(status)

    os.chdir(orig_dir)
    logger.info("Step 3 complete.\n")


# ===========================================================================
# Step 4: Collect results
# ===========================================================================
def step4_results(cfg: ASGBIEConfig, near: List[Tuple[str, int]]) -> None:
    """Collect ΔΔG results from all mutants."""
    logger.info("=" * 60)
    logger.info("STEP 4: Collect results")
    logger.info("=" * 60)

    orig_dir = os.getcwd()
    os.chdir(cfg.work_dir)

    n_term, c_term = get_terminal_residues(cfg.com_pdb)
    diel_map = read_dielectric_file(cfg.res_diel_file)

    out_file = "AlaScan_GB.dat"
    header = f"{'Mut-Wid':>7s} {'dVDW':>9s} {'dEEL':>9s} {'dGB':>9s} {'dNP':>9s} {'dH':>9s}"

    logger.info(f"{cfg.com_name} Alanine Scanning MMGBSA Result → {out_file}")
    print(header)

    results_lines = [header]
    totals = {"dVDW": 0.0, "dEEL": 0.0, "dGB": 0.0, "dNP": 0.0, "dH": 0.0}

    wt_dir = os.path.join(os.path.dirname(cfg.work_dir), "Wildtype")

    for resname, resid in near:
        diel_key = get_diel_key(resname, resid, n_term, c_term)
        diel_val = diel_map.get(diel_key, 1.0)

        mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
        mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
        mut_com_name = f"{cfg.com_name}_{resname}{resid}ALA"

        # Mutant result
        mut_dat = os.path.join(mut_dir, f"{mut_com_name}_MMGBSA_intdiel={diel_val}.dat")
        # Wildtype result (same dielectric)
        wt_dat = os.path.join(wt_dir, f"{cfg.com_name}_MMGBSA_intdiel={diel_val}.dat")

        try:
            mut_res = parse_mmpbsa_dat(mut_dat)
            wt_res = parse_mmpbsa_dat(wt_dat)

            dVDW = mut_res["VDWAALS"] - wt_res["VDWAALS"]
            dEEL = mut_res["EEL"] - wt_res["EEL"]
            dGB  = mut_res["EGB"] - wt_res["EGB"]
            dNP  = mut_res["ESURF"] - wt_res["ESURF"]
            dH   = mut_res["DELTA_TOTAL"] - wt_res["DELTA_TOTAL"]

            totals["dVDW"] += dVDW
            totals["dEEL"] += dEEL
            totals["dGB"]  += dGB
            totals["dNP"]  += dNP
            totals["dH"]   += dH

            line = f"{resid:>4d}{resname:>3s} {dVDW:9.4f} {dEEL:9.4f} {dGB:9.4f} {dNP:9.4f} {dH:9.4f}"
        except Exception as exc:
            line = f"{resid:>4d}{resname:>3s}  ERROR: {exc}"

        print(line)
        results_lines.append(line)

    total_line = (
        f"{'TOTAL':>7s} {totals['dVDW']:9.4f} {totals['dEEL']:9.4f} "
        f"{totals['dGB']:9.4f} {totals['dNP']:9.4f} {totals['dH']:9.4f}"
    )
    print(total_line)
    results_lines.append(total_line)

    with open(out_file, "w") as fh:
        fh.write("\n".join(results_lines) + "\n")

    os.chdir(orig_dir)
    logger.info(f"Results saved to {os.path.join(cfg.work_dir, out_file)}")
    logger.info("Step 4 complete.\n")


# ===========================================================================
# Main
# ===========================================================================
def main():
    parser = argparse.ArgumentParser(
        description="ASGBIE – Alanine Scanning GB Interaction Entropy (Amber24)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python asgbie.py config.ini                    # Run all steps
  python asgbie.py config.ini --step 1           # Only wildtype
  python asgbie.py config.ini --step 234         # Skip wildtype
  python asgbie.py config.ini --parallel 4       # 4 mutants at once
""",
    )
    parser.add_argument("config", help="Path to config.ini file")
    parser.add_argument(
        "--step", default="1234",
        help="Steps to run, e.g. '1234' (default), '1', '234', '4'",
    )
    parser.add_argument(
        "--parallel", type=int, default=None,
        help="Override parallel_mutants from config",
    )
    args = parser.parse_args()

    # Load config
    cfg = load_config(args.config)
    if not cfg.work_dir:
        cfg.work_dir = os.path.abspath(os.path.dirname(args.config) or ".")
    if args.parallel is not None:
        cfg.parallel_mutants = args.parallel

    logger.info(f"Work directory: {cfg.work_dir}")
    logger.info(f"Steps to run:   {args.step}")

    near = None

    if "1" in args.step:
        step1_wildtype(cfg)

    if "2" in args.step:
        near = step2_prepare(cfg)

    if "3" in args.step:
        if near is None:
            # Re-read NearResidue.dat
            dat_path = os.path.join(cfg.work_dir, cfg.near_residue_file)
            near = []
            with open(dat_path) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        resname = line[:3]
                        resid = int(line[3:])
                        near.append((resname, resid))
        step3_calculate(cfg, near)

    if "4" in args.step:
        if near is None:
            dat_path = os.path.join(cfg.work_dir, cfg.near_residue_file)
            near = []
            with open(dat_path) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        resname = line[:3]
                        resid = int(line[3:])
                        near.append((resname, resid))
        step4_results(cfg, near)

    logger.info("All done.")


if __name__ == "__main__":
    main()
