#!/usr/bin/env python3
"""
ASIE - Alanine Scanning Interaction Entropy
Python implementation for Amber24 (no legacy Fortran required)

Replaces the original bash/Fortran workflow:
  - AlaScan_GetNearResidue   → get_near_residues()       [shared with asgb.py]
  - AlaScan_GetMutPDB        → create_mutant_pdb()        [shared with asgb.py]
  - AlaScan_GetMutMDCrd      → create_mutant_trajectory() [shared with asgb.py]
  - AlaScan_InterEntropy     → compute_ie()               [NEW - pure Python]
  - Step1~Step3 bash scripts → step1_prepare() ~ step3_results()

Usage:
    python asie.py config_ie.ini                 # Run all steps
    python asie.py config_ie.ini --step 1        # Only prepare
    python asie.py config_ie.ini --step 23       # Skip prepare (reuse)
    python asie.py config_ie.ini --parallel 4    # 4 mutants at once

Requirements:
    - Amber24 (AmberTools): tleap, cpptraj
    - Python packages: numpy, pytraj, parmed

Author: Rewritten for Amber24 compatibility

Lessons learned from asgb.py:
  - write_pdb MUST insert TER between protein and ligand (tleap CGLU/NGLY)
  - mpirun needs --oversubscribe under SLURM --cpus-per-task
  - MMPBSA.py &gb does NOT accept intdiel / extdiel (sander-only variables)
  - Conda env: /scratch/wx2237/conda_envs/asgbie_new_env
"""

import os
import sys
import re
import math
import subprocess
import shutil
import configparser
import argparse
import logging
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional, Set

import numpy as np
import pytraj as pt

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("ASIE")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
STANDARD_AA: Set[str] = {
    "GLY", "ALA", "VAL", "LEU", "ILE", "PHE", "TRP", "TYR",
    "ASP", "ASH", "ASN", "GLU", "GLH", "LYS", "LYN", "GLN",
    "MET", "SER", "THR", "CYS", "CYX", "CYM", "HIE", "HID", "HIP",
    "ARG", "PRO",
}
BACKBONE_ATOMS: Set[str] = {"N", "H", "H1", "H2", "H3", "CA", "HA", "C", "O", "OXT"}
SKIP_RESIDUES: Set[str] = {"GLY", "ALA"}

# Coulomb constant:  e^2 / (4*pi*eps0) in kcal·Å/mol  (when q in e, r in Å)
COULOMB_CONST = 332.0522173
# Boltzmann constant in kcal/(mol·K)
KB = 0.001987204


# ===========================================================================
# Configuration
# ===========================================================================
@dataclass
class ASIEConfig:
    """All parameters for an ASIE (Interaction Entropy) calculation."""

    # --- File names (same as asgb.py) ---
    com_name: str = "cpx"
    com_pdb: str = "cpx.pdb"
    com_mdcrd: str = "md.nc"
    rec_name: str = "protein_only"
    rec_pdb: str = "protein_only.pdb"
    lig_name: str = "lig"
    lig_pdb: str = "lig.pdb"
    lig_name_in_pdb: str = "MOL"
    lig_mol2: str = "lig.mol2"
    lig_frcmod: str = "lig.frcmod"
    pb_radii: str = "mbondi2"
    res_diel_file: str = "ResidueDielectric.dat"

    # --- Residue range ---
    rec_res_start: int = 1
    rec_res_stop: int = -1
    lig_res_start: int = -1
    lig_res_stop: int = -1

    # --- Trajectory ---
    max_distance: float = 5.0
    frame_start: int = 2001
    frame_stop: int = 5000
    frame_offset: int = 1           # NOTE: IE uses every frame (offset=1), not 30!

    # --- IE-specific ---
    ie_window_ns: float = 3.0       # IE window length in ns; windows do not overlap
    temperature: float = 300.0      # Temperature in K

    # --- Amber24 / housekeeping ---
    parallel_mutants: int = 1
    remove_temp: bool = True
    work_dir: str = ""
    near_residue_file: str = "NearResidue.dat"

    # --- Force field ---
    protein_ff: str = "leaprc.protein.ff14SB"
    gaff_ff: str = "leaprc.gaff2"
    old_ff: str = ""

    @property
    def total_frames(self) -> int:
        return (self.frame_stop - self.frame_start) // self.frame_offset + 1


def load_config(ini_path: str) -> ASIEConfig:
    """Load configuration from an INI file."""
    cp = configparser.ConfigParser()
    cp.read(ini_path)
    cfg = ASIEConfig()

    type_map = {f.name: f.type for f in cfg.__dataclass_fields__.values()}
    for section in cp.sections():
        for key, val in cp.items(section):
            key = key.strip().lower()
            if key not in type_map:
                raise ValueError(f"{ini_path}: [{section}] {key} is not a setting of this program")
            ftype = type_map[key]
            if ftype is bool or ftype == "bool":
                setattr(cfg, key, cp.getboolean(section, key))
            elif ftype is int or ftype == "int":
                setattr(cfg, key, int(val))
            elif ftype is float or ftype == "float":
                setattr(cfg, key, float(val))
            else:
                setattr(cfg, key, val)
    return cfg


def resolve_residue_ranges(cfg: ASIEConfig) -> None:
    """Resolve automatic receptor/ligand residue ranges before any step runs."""
    if cfg.rec_res_stop >= 0 and cfg.lig_res_start >= 0 and cfg.lig_res_stop >= 0:
        return

    orig_dir = os.getcwd()
    try:
        if cfg.work_dir:
            os.chdir(cfg.work_dir)
        if cfg.rec_res_stop < 0:
            cfg.rec_res_stop = get_last_resid(cfg.rec_pdb)
        if cfg.lig_res_start < 0:
            cfg.lig_res_start = cfg.rec_res_stop + 1
        if cfg.lig_res_stop < 0:
            cfg.lig_res_stop = cfg.rec_res_stop + 1
    finally:
        os.chdir(orig_dir)


# ===========================================================================
# PDB Utilities  (same as asgb.py — keep TER fix!)
# ===========================================================================
def parse_pdb(pdb_file: str) -> List[dict]:
    """Parse PDB file → list of atom dicts."""
    atoms = []
    with open(pdb_file) as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            atom = {
                "record":  line[:6].strip(),
                "serial":  int(line[6:11]),
                "name":    line[12:16].strip(),
                "altloc":  line[16],
                "resname": line[17:20].strip(),
                "chainid": line[21],
                "resid":   int(line[22:26]),
                "icode":   line[26],
                "x": float(line[30:38]),
                "y": float(line[38:46]),
                "z": float(line[46:54]),
                "occ":  float(line[54:60]) if line[54:60].strip() else 1.0,
                "bfac": float(line[60:66]) if line[60:66].strip() else 0.0,
                "elem": line[76:78].strip() if len(line) > 76 else "",
            }
            atoms.append(atom)
    return atoms


def write_pdb(atoms: List[dict], out_file: str) -> None:
    """
    Write atom list to PDB file with proper TER records at chain breaks.

    BUG FIX from asgb.py: TER is inserted whenever chainid changes or
    residue type switches (standard AA ↔ non-AA).  Without this, tleap
    cannot identify terminal residues (CGLU/NGLY) and OXT gets no type.
    """
    def _is_std(rn: str) -> bool:
        return rn in STANDARD_AA

    def _res_key(a: dict) -> tuple:
        return (a["chainid"], a["resid"], a["icode"], a["resname"])

    res_atom_names: Dict[tuple, Set[str]] = {}
    for a in atoms:
        res_atom_names.setdefault(_res_key(a), set()).add(a["name"])

    serial = 0
    with open(out_file, "w") as fh:
        prev = None
        for a in atoms:
            if prev is not None:
                prev_key = _res_key(prev)
                curr_key = _res_key(a)
                new_residue = curr_key != prev_key
                chain_change = (a["chainid"] != prev["chainid"])
                type_change = (_is_std(a["resname"]) != _is_std(prev["resname"]))
                terminal_break = (
                    new_residue
                    and (
                        "OXT" in res_atom_names.get(prev_key, set())
                        or bool({"H1", "H2", "H3"} & res_atom_names.get(curr_key, set()))
                    )
                )
                if chain_change or type_change or terminal_break:
                    serial += 1
                    fh.write(
                        f"TER   {serial:5d}      "
                        f"{prev['resname']:>3s} {prev['chainid']}{prev['resid']:4d}\n"
                    )
            serial += 1
            name = a["name"]
            name_field = f" {name:<3s}" if len(name) < 4 else f"{name:<4s}"
            fh.write(
                f"{a['record']:<6s}{serial:5d} {name_field}{a['altloc']}"
                f"{a['resname']:>3s} {a['chainid']}{a['resid']:4d}{a['icode']}   "
                f"{a['x']:8.3f}{a['y']:8.3f}{a['z']:8.3f}"
                f"{a['occ']:6.2f}{a['bfac']:6.2f}          "
                f"{a['elem']:>2s}\n"
            )
            prev = a
        if prev is not None:
            serial += 1
            fh.write(
                f"TER   {serial:5d}      "
                f"{prev['resname']:>3s} {prev['chainid']}{prev['resid']:4d}\n"
            )
        fh.write("END\n")


def get_last_resid(pdb_file: str) -> int:
    atoms = parse_pdb(pdb_file)
    return max(a["resid"] for a in atoms) if atoms else 0


def get_terminal_residues(pdb_file: str) -> Tuple[Set[int], Set[int]]:
    """Identify N-terminal (H2 present) and C-terminal (OXT present) residues."""
    n_term: Set[int] = set()
    c_term: Set[int] = set()
    for a in parse_pdb(pdb_file):
        if a["resname"] in STANDARD_AA:
            if a["name"] == "H2":
                n_term.add(a["resid"])
            if a["name"] == "OXT":
                c_term.add(a["resid"])
    return n_term, c_term


# ===========================================================================
# Dielectric Utilities
# ===========================================================================
def read_dielectric_file(path: str) -> Dict[str, float]:
    """Read ResidueDielectric.dat → {ResName: dielectric}."""
    diel: Dict[str, float] = {}
    with open(path) as fh:
        for line in fh:
            parts = line.split()
            if len(parts) >= 2:
                diel[parts[0]] = float(parts[1])
    return diel


def get_diel_key(resname: str, resid: int, n_term: Set[int], c_term: Set[int]) -> str:
    if resid in n_term:
        return f"N{resname}"
    if resid in c_term:
        return f"C{resname}"
    return resname


# ===========================================================================
# Core Function 1: get_near_residues  (same as asgb.py)
# ===========================================================================
def get_near_residues(
    complex_pdb: str, rec_start: int, rec_stop: int,
    lig_start: int, lig_stop: int, max_distance: float,
) -> List[Tuple[str, int]]:
    """Find receptor residues within max_distance Å of any ligand atom."""
    atoms = parse_pdb(complex_pdb)
    lig_coords = np.array(
        [[a["x"], a["y"], a["z"]] for a in atoms if lig_start <= a["resid"] <= lig_stop]
    )
    near: Set[Tuple[str, int]] = set()
    for a in atoms:
        if not (rec_start <= a["resid"] <= rec_stop):
            continue
        coord = np.array([a["x"], a["y"], a["z"]])
        dists = np.linalg.norm(lig_coords - coord, axis=1)
        if dists.min() <= max_distance:
            near.add((a["resname"], a["resid"]))

    result = sorted(
        [(n, r) for n, r in near if n not in SKIP_RESIDUES],
        key=lambda x: x[1],
    )
    logger.info(f"Near-ligand residues (≤{max_distance} Å): {len(result)}")
    for n, r in result:
        logger.info(f"  {n}{r}")
    return result


# ===========================================================================
# Core Function 2: create_mutant_pdb  (same as asgb.py)
# ===========================================================================
def create_mutant_pdb(
    pdb_file: str, mut_res_id: int, output_prefix: str
) -> Tuple[str, str]:
    """Create alanine-mutant PDB: strip sidechain beyond CB, rename → ALA."""
    atoms = parse_pdb(pdb_file)
    orig_resname = None
    for a in atoms:
        if a["resid"] == mut_res_id and a["resname"] in STANDARD_AA:
            orig_resname = a["resname"]
            break
    if orig_resname is None:
        raise ValueError(f"Residue {mut_res_id} not found or not standard AA")

    mut_name = f"{output_prefix}_{orig_resname}{mut_res_id}ALA"
    keep = BACKBONE_ATOMS | {"CB"}
    new_atoms = []
    for a in atoms:
        if a["resid"] == mut_res_id and a["resname"] == orig_resname:
            if a["name"] in keep:
                cp = dict(a)
                cp["resname"] = "ALA"
                new_atoms.append(cp)
        else:
            new_atoms.append(a)

    write_pdb(new_atoms, f"{mut_name}.pdb")
    logger.info(f"Mutant PDB: {mut_name}.pdb  ({orig_resname}{mut_res_id} → ALA)")
    return mut_name, orig_resname


# ===========================================================================
# Core Function 3:  mutant coordinates
# Replaces Fortran program  AlaScan_GetMutMDCrd
# ===========================================================================
# Every mutant atom that the wild type also has takes the wild-type
# coordinates of the same frame.  Every hydrogen the mutant has and the wild
# type lacks is put on a bond the mutation deleted, NEW_H_BOND_LENGTH from the
# atom it hangs on, pointing at the removed wild-type atom of that frame:
#
#   HB2/HB3 kept; HB1 on CB->CG (CB->SG for Cys, CB->OG for Ser)
#   ILE / VAL: HB kept as HB2; HB1 on CB->CG2, HB3 on CB->CG1
#   THR:       HB kept as HB2; HB1 on CB->CG2, HB3 on CB->OG1
#   PRO:       the amide H (H1 at an N terminus) on N->CD
#
# The three ALA methyl hydrogens carry identical parameters, so which name
# takes which bond changes no energy.
NEW_H_BOND_LENGTH = 1.09

# Wild-type atom whose bond to CB receives ALA HB1, for residues whose CB
# carries HB2 and HB3.
ALA_HB1_PARTNER: Dict[str, str] = {
    "ARG": "CG", "ASH": "CG", "ASN": "CG", "ASP": "CG", "GLH": "CG",
    "GLN": "CG", "GLU": "CG", "HID": "CG", "HIE": "CG", "HIP": "CG",
    "LEU": "CG", "LYN": "CG", "LYS": "CG", "MET": "CG", "PHE": "CG",
    "PRO": "CG", "TRP": "CG", "TYR": "CG",
    "CYM": "SG", "CYS": "SG", "CYX": "SG",
    "SER": "OG",
}
# Residues whose CB carries a single HB: partners of (HB1, HB3).
ALA_BRANCHED_PARTNERS: Dict[str, Tuple[str, str]] = {
    "ILE": ("CG2", "CG1"),
    "VAL": ("CG2", "CG1"),
    "THR": ("CG2", "OG1"),
}


def mutant_h_rule(
    wt_resname: str,
    wt_names: Set[str],
    mut_names: Set[str],
) -> Tuple[Dict[str, str], Dict[str, Tuple[str, str]]]:
    """Hydrogen rule for one residue mutated to ALA.

    Returns (inherited, generated):
      inherited  mutant atom name -> differently named wild-type atom whose
                 coordinates it takes
      generated  mutant H name -> (wild-type atom it hangs on, wild-type atom
                 at the far end of the deleted bond)
    """
    if wt_resname in ALA_BRANCHED_PARTNERS:
        hb1, hb3 = ALA_BRANCHED_PARTNERS[wt_resname]
        inherited = {"HB2": "HB"}
        generated = {"HB1": ("CB", hb1), "HB3": ("CB", hb3)}
    elif wt_resname in ALA_HB1_PARTNER:
        inherited, generated = {}, {"HB1": ("CB", ALA_HB1_PARTNER[wt_resname])}
    else:
        raise ValueError(f"no mutant hydrogen rule for residue type {wt_resname}")
    if wt_resname == "PRO":
        for name in ("H", "H1"):
            if name in mut_names and name not in wt_names:
                generated[name] = ("N", "CD")
    return inherited, generated


def mutant_coordinate_plan(
    wt_atoms: List[dict],
    mut_atoms: List[dict],
    mut_res_id: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Where every mutant atom takes its coordinates from, frame by frame.

    Returns (mapping, generated):
      mapping    (n_mut,) wild-type atom index each mutant atom copies,
                 -1 for a generated hydrogen
      generated  (k, 3) rows (mutant index, wild-type index of the atom the H
                 hangs on, wild-type index of the deleted bond partner)

    A mutant atom covered by neither is an error, so no atom can be left at a
    coordinate that does not follow the trajectory.
    """
    wt_lookup = {(a["resid"], a["name"]): i for i, a in enumerate(wt_atoms)}
    wt_res = [a for a in wt_atoms if a["resid"] == mut_res_id]
    if not wt_res:
        raise ValueError(f"residue {mut_res_id} is not in the wild-type structure")
    wt_resname = wt_res[0]["resname"]
    inherited, rule = mutant_h_rule(
        wt_resname,
        {a["name"] for a in wt_res},
        {a["name"] for a in mut_atoms if a["resid"] == mut_res_id},
    )

    mapping = np.full(len(mut_atoms), -1, dtype=int)
    generated: List[Tuple[int, int, int]] = []
    missing: List[str] = []
    for mi, ma in enumerate(mut_atoms):
        name = ma["name"]
        in_res = ma["resid"] == mut_res_id
        if in_res and name in rule:
            ends = [wt_lookup.get((mut_res_id, n), -1) for n in rule[name]]
            if min(ends) < 0:
                missing.append(f"{name} (needs wild-type {'/'.join(rule[name])})")
            else:
                generated.append((mi, ends[0], ends[1]))
            continue
        source = inherited.get(name, name) if in_res else name
        wi = wt_lookup.get((ma["resid"], source), -1)
        if wi < 0:
            missing.append(f":{ma['resid']}@{name}")
        else:
            mapping[mi] = wi
    if missing:
        raise ValueError(
            f"mutant of residue {mut_res_id} ({wt_resname}): no wild-type source for "
            + ", ".join(missing)
        )
    return mapping, np.array(generated, dtype=int).reshape(-1, 3)


def build_mutant_coordinates(
    wt_xyz: np.ndarray,
    mapping: np.ndarray,
    generated: np.ndarray,
) -> np.ndarray:
    """Apply a mutant_coordinate_plan to one frame (n_wt, 3) or frames (n, n_wt, 3)."""
    # C order: pytraj.Trajectory(xyz=...) rejects the strided array the fancy
    # index returns ("Buffer not C contiguous").
    mut = np.ascontiguousarray(wt_xyz[..., np.maximum(mapping, 0), :], dtype=np.float64)
    if len(generated):
        origin = wt_xyz[..., generated[:, 1], :]
        bond = wt_xyz[..., generated[:, 2], :] - origin
        mut[..., generated[:, 0], :] = origin + NEW_H_BOND_LENGTH * (
            bond / np.linalg.norm(bond, axis=-1, keepdims=True)
        )
    return mut


_TRAJ_FRAME_COUNT_CACHE = {}


def get_trajectory_frame_count(traj_file: str, top_file: str) -> int:
    """Return the number of frames, cached per trajectory/topology pair."""
    import pytraj as pt

    key = (os.path.abspath(traj_file), os.path.abspath(top_file))
    if key not in _TRAJ_FRAME_COUNT_CACHE:
        _TRAJ_FRAME_COUNT_CACHE[key] = int(pt.iterload(traj_file, top_file).n_frames)
    return _TRAJ_FRAME_COUNT_CACHE[key]


def validate_frame_indices(traj_file: str, top_file: str, frame_indices, context: str) -> None:
    """Fail early if config frame_start/frame_stop exceeds available frames."""
    if not frame_indices:
        raise ValueError(f"{context}: no frames selected; check frame_start/frame_stop/frame_offset")
    min_idx = min(frame_indices)
    max_idx = max(frame_indices)
    if min_idx < 0:
        raise ValueError(f"{context}: frame_start must be >= 1")
    n_frames = get_trajectory_frame_count(traj_file, top_file)
    if max_idx >= n_frames:
        requested = f"{min_idx + 1}-{max_idx + 1}"
        raise ValueError(
            f"{context}: requested 1-based frames {requested} from {traj_file}, "
            f"but this trajectory has only {n_frames} frames."
        )


def create_mutant_trajectory(
    wt_pdb: str,
    wt_mdcrd: str,
    mut_pdb_after_tleap: str,
    mut_top: str,
    mut_res_id: int,
    first_frame: int,
    last_frame: int,
    offset_frame: int,
    output_nc: str,
) -> None:
    """
    Create mutant trajectory matching the tleap-generated mutant topology.

    1. Map every mutant atom onto the wild type (mutant_coordinate_plan).
    2. Load the selected wild-type frames and build the mutant coordinates
       frame by frame (build_mutant_coordinates).
    3. Write output NetCDF using pytraj, or cpptraj as a fallback.
    """
    mapping, generated = mutant_coordinate_plan(
        parse_pdb(wt_pdb), parse_pdb(mut_pdb_after_tleap), mut_res_id
    )

    # --- Determine frame indices (1-based → 0-based for pytraj) ---
    frame_indices = list(range(first_frame - 1, last_frame, offset_frame))
    n_frames = len(frame_indices)

    # The frame-range guard sits inside this try: its ValueError is a
    # configuration error and is re-raised, because the cpptraj fallback does
    # not check the range and would silently use a different number of frames.
    # Any other failure of the pytraj path falls back to cpptraj.
    try:
        import pytraj as pt

        validate_frame_indices(wt_mdcrd, wt_pdb, frame_indices, "Mutant trajectory generation")
        wt_traj = pt.load(wt_mdcrd, wt_pdb, frame_indices=frame_indices)
        mut_xyz = build_mutant_coordinates(wt_traj.xyz, mapping, generated)

        mut_top_obj = pt.load_topology(mut_top)
        mut_traj = pt.Trajectory(xyz=mut_xyz, top=mut_top_obj)
        pt.write_traj(output_nc, mut_traj, overwrite=True)
        logger.info(f"Mutant trajectory (pytraj): {output_nc}  ({n_frames} frames)")
        return

    except ValueError:
        raise
    except Exception as exc:
        logger.warning(f"pytraj mutant-trajectory path failed ({exc}), using cpptraj fallback")

    # --- Fallback: cpptraj frame by frame ---
    _create_mutant_traj_cpptraj(
        wt_pdb, wt_mdcrd, mut_top, mut_res_id, first_frame, last_frame,
        offset_frame, output_nc, mapping, generated,
    )


def _create_mutant_traj_cpptraj(
    wt_pdb, wt_mdcrd, mut_top, mut_res_id, first_frame, last_frame,
    offset_frame, output_nc, mapping, generated,
):
    """
    Fallback: use cpptraj frame-by-frame extraction + Python coordinate assembly.
    Writes individual restart files, merges them.
    """
    tmp_dir = f"_tmp_mutcrd_{mut_res_id}"
    os.makedirs(tmp_dir, exist_ok=True)

    n_wt = len(parse_pdb(wt_pdb))
    frame_indices = list(range(first_frame, last_frame + 1, offset_frame))
    n_frames = len(frame_indices)

    # Extract each WT frame → restart file, read coords, build mut coords
    for fi, frame_num in enumerate(frame_indices):
        rst_file = os.path.join(tmp_dir, f"wt_{fi}.rst7")
        cpptraj_in = (
            f"parm {wt_pdb}\n"
            f"trajin {wt_mdcrd} {frame_num} {frame_num} 1\n"
            f"trajout {rst_file} restart\n"
            f"go\n"
        )
        _run_cpptraj(cpptraj_in, f"{tmp_dir}/_cpptraj_{fi}.in")

        wt_coords = _read_restart_coords(rst_file, n_wt)
        mut_rst = os.path.join(tmp_dir, f"mut_{fi}.rst7")
        _write_restart(build_mutant_coordinates(wt_coords, mapping, generated), mut_rst)

    # Combine all restart files into single NetCDF trajectory
    cpptraj_combine = f"parm {mut_top}\n"
    for fi in range(n_frames):
        cpptraj_combine += f"trajin {tmp_dir}/mut_{fi}.rst7\n"
    cpptraj_combine += f"trajout {output_nc} netcdf\ngo\n"
    _run_cpptraj(cpptraj_combine, f"{tmp_dir}/_combine.in")

    shutil.rmtree(tmp_dir, ignore_errors=True)
    logger.info(f"Mutant trajectory (cpptraj fallback): {output_nc}  ({n_frames} frames)")


def _run_cpptraj(input_text: str, input_file: str = "_cpptraj_tmp.in") -> None:
    with open(input_file, "w") as fh:
        fh.write(input_text)
    result = subprocess.run(["cpptraj", "-i", input_file], capture_output=True, text=True)
    os.remove(input_file)
    if result.returncode != 0:
        logger.error(f"cpptraj FAILED:\n{result.stderr}\n{result.stdout}")
        raise RuntimeError("cpptraj failed")


def _read_restart_coords(rst_file: str, n_atoms: int) -> np.ndarray:
    coords = []
    with open(rst_file) as fh:
        lines = fh.readlines()
    for line in lines[2:]:
        vals = [line[i:i+12] for i in range(0, len(line.rstrip()), 12)]
        for v in vals:
            v = v.strip()
            if v:
                coords.append(float(v))
            if len(coords) >= n_atoms * 3:
                break
        if len(coords) >= n_atoms * 3:
            break
    return np.array(coords[:n_atoms * 3]).reshape(n_atoms, 3)


def _write_restart(coords: np.ndarray, rst_file: str) -> None:
    n_atoms = coords.shape[0]
    with open(rst_file, "w") as fh:
        fh.write("mutant restart\n")
        fh.write(f"{n_atoms:5d}\n")
        flat = coords.flatten()
        for i in range(0, len(flat), 6):
            chunk = flat[i:i+6]
            fh.write("".join(f"{v:12.7f}" for v in chunk) + "\n")


# ===========================================================================
# tleap Helpers (same as asgb.py)
# ===========================================================================
def _tleap_source_lines(cfg: ASIEConfig) -> str:
    lines = []
    if cfg.old_ff:
        lines.append(f"source {cfg.old_ff}")
    lines.append(f"source {cfg.protein_ff}")
    lines.append(f"source {cfg.gaff_ff}")
    return "\n".join(lines)


def run_tleap(input_text: str, log_file: str = "tleap.log") -> bool:
    in_file = "_tleap_temp.in"
    with open(in_file, "w") as fh:
        fh.write(input_text)
    result = subprocess.run(["tleap", "-s", "-f", in_file], capture_output=True, text=True)
    with open(log_file, "w") as fh:
        fh.write(result.stdout or "")
        fh.write(result.stderr or "")
    os.remove(in_file)
    if result.returncode != 0:
        logger.error(f"tleap FAILED – see {log_file}")
        return False
    if "FATAL" in (result.stdout or ""):
        logger.error(f"tleap FATAL error – see {log_file}")
        return False
    return True


# ===========================================================================
# Core Function 4: Interaction Entropy  (replaces AlaScan_InterEntropy)
# ===========================================================================
def _get_atom_params(top_file: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read charges, sigma, epsilon from Amber topology using parmed.

    Returns
    -------
    charges : (N,) array, in electron charge units
    sigma   : (N,) array, in Å  (Rmin, not sigma; Eij = eps*[(Rmin/r)^12 - 2*(Rmin/r)^6])
    epsilon : (N,) array, in kcal/mol
    """
    import parmed
    parm = parmed.load_file(top_file)
    charges = np.array([a.charge for a in parm.atoms])
    sigma = np.array([a.sigma for a in parm.atoms])      # Å (van der Waals sigma)
    epsilon = np.array([a.epsilon for a in parm.atoms])   # kcal/mol
    return charges, sigma, epsilon


def _get_residue_atom_indices(top_file: str, res_start: int, res_stop: int) -> List[int]:
    """Get atom indices (0-based) for residues in [res_start, res_stop]."""
    import parmed
    parm = parmed.load_file(top_file)
    indices = []
    for atom in parm.atoms:
        # parmed residue numbering is 0-based, PDB is 1-based
        resid = atom.residue.idx + 1
        if res_start <= resid <= res_stop:
            indices.append(atom.idx)
    return indices


def compute_interaction_energy_per_frame(
    xyz: np.ndarray,
    rec_idx: np.ndarray,
    lig_idx: np.ndarray,
    charges: np.ndarray,
    sigma: np.ndarray,
    epsilon: np.ndarray,
    intdiel: float,
) -> np.ndarray:
    """
    Compute per-frame interaction energy (VDW + EEL/intdiel) between
    receptor atoms and ligand atoms.

    Parameters
    ----------
    xyz      : (n_frames, n_atoms, 3) coordinate array
    rec_idx  : atom indices of receptor residue(s)
    lig_idx  : atom indices of ligand
    charges  : (n_atoms,) charges in e
    sigma    : (n_atoms,) LJ sigma in Å
    epsilon  : (n_atoms,) LJ epsilon in kcal/mol
    intdiel  : interior dielectric constant

    Returns
    -------
    eint : (n_frames,) interaction energy in kcal/mol
    """
    n_frames = xyz.shape[0]
    eint = np.zeros(n_frames)

    # Pre-compute LJ cross-terms (Lorentz-Berthelot combining rules)
    sig_rec = sigma[rec_idx]               # (n_rec,)
    sig_lig = sigma[lig_idx]               # (n_lig,)
    eps_rec = epsilon[rec_idx]
    eps_lig = epsilon[lig_idx]
    q_rec = charges[rec_idx]
    q_lig = charges[lig_idx]

    # Cross-parameter arrays: (n_rec, n_lig)
    sig_ij = (sig_rec[:, None] + sig_lig[None, :]) / 2.0
    eps_ij = np.sqrt(eps_rec[:, None] * eps_lig[None, :])
    qq_ij = COULOMB_CONST * q_rec[:, None] * q_lig[None, :]

    for fi in range(n_frames):
        rec_xyz = xyz[fi, rec_idx, :]   # (n_rec, 3)
        lig_xyz = xyz[fi, lig_idx, :]   # (n_lig, 3)

        # Pairwise distances: (n_rec, n_lig)
        diff = rec_xyz[:, None, :] - lig_xyz[None, :, :]  # (n_rec, n_lig, 3)
        dist = np.sqrt(np.sum(diff * diff, axis=2))        # (n_rec, n_lig)
        dist = np.maximum(dist, 0.001)  # avoid division by zero

        # LJ: 4*eps*[(sig/r)^12 - (sig/r)^6]
        r6 = (sig_ij / dist) ** 6
        vdw = 4.0 * eps_ij * (r6 * r6 - r6)

        # Coulomb: q1*q2*332.05 / (intdiel * r)
        eel = qq_ij / (intdiel * dist)

        eint[fi] = np.sum(vdw) + np.sum(eel)

    return eint


def ie_window_frames(traj_file: str, frame_offset: int, window_ns: float) -> int:
    """Frames per IE window: window_ns of simulated time, on the trajectory's own clock."""
    from scipy.io import netcdf_file

    with netcdf_file(traj_file, "r", mmap=False) as nc:
        t = np.asarray(nc.variables["time"][:], dtype=float)
    if len(t) < 2:
        raise ValueError(f"{traj_file}: needs at least 2 frames to read the time step")
    steps = np.diff(t)
    dt = float(steps[0])
    if dt <= 0 or np.abs(steps - dt).max() > 1e-3 * dt:
        raise ValueError(
            f"{traj_file}: frames are not evenly spaced in time "
            f"(steps {steps.min():g} to {steps.max():g} ps)"
        )
    exact = window_ns * 1000.0 / (dt * frame_offset)
    frames = int(round(exact))
    if frames < 2 or abs(exact - frames) > 1e-6 * exact:
        raise ValueError(
            f"ie_window_ns = {window_ns:g} is {exact:g} frames at {dt:g} ps/frame and "
            f"frame_offset = {frame_offset}; it must be a whole number of frames"
        )
    return frames


def ie_windows(n_frames: int, window_frames: int) -> List[Tuple[int, int]]:
    """Non-overlapping windows of window_frames; frames left over at the end are logged and left out."""
    if window_frames < 2:
        raise ValueError(f"an IE window of {window_frames} frames is too short")
    n_win = n_frames // window_frames
    if n_win == 0:
        raise ValueError(
            f"{n_frames} frames do not fill one IE window of {window_frames} frames"
        )
    left = n_frames - n_win * window_frames
    if left:
        logger.warning(f"IE: the last {left} of {n_frames} frames do not fill a window and are left out")
    return [(k * window_frames, (k + 1) * window_frames) for k in range(n_win)]


def compute_ie(
    eint: np.ndarray,
    window_frames: int,
    temperature: float = 300.0,
) -> Dict[str, float]:
    """
    Compute Interaction Entropy from an energy time series.

    The trajectory is divided into non-overlapping windows of window_frames
    frames (ie_window_ns of simulated time).  For each window, IE is computed
    using several truncation methods.  The final result is the average over
    all windows.

    Returns dict with keys: IE_Int, IE_3S, IE_4S, IE_5S, IE_7S, IE_Gau
    """
    n_frames = len(eint)
    kT = KB * temperature
    beta = 1.0 / kT

    windows = ie_windows(n_frames, window_frames)

    sigma_names = ["IE_Int", "IE_3S", "IE_4S", "IE_5S", "IE_7S", "IE_Gau"]
    sigma_cutoffs = [None, 3, 4, 5, 7, None]  # None = no truncation / Gaussian

    # Accumulate per-window IE values
    all_ie = {name: [] for name in sigma_names}

    for w_start, w_end in windows:
        e_window = eint[w_start:w_end]
        mean_e = np.mean(e_window)
        delta_e = e_window - mean_e
        std_e = np.std(delta_e)

        for name, cutoff in zip(sigma_names, sigma_cutoffs):
            if name == "IE_Gau":
                # Gaussian approximation to -TΔS.
                ie_val = (std_e ** 2) / (2.0 * kT)
            elif cutoff is None:
                # Integral (no truncation)
                exp_vals = np.exp(beta * delta_e)
                mean_exp = np.mean(exp_vals)
                if mean_exp > 0:
                    ie_val = kT * np.log(mean_exp)
                else:
                    ie_val = 0.0
            else:
                # N-sigma truncation
                mask = np.abs(delta_e) <= cutoff * std_e
                if np.sum(mask) > 0:
                    exp_vals = np.exp(beta * delta_e[mask])
                    mean_exp = np.mean(exp_vals)
                    if mean_exp > 0:
                        ie_val = kT * np.log(mean_exp)
                    else:
                        ie_val = 0.0
                else:
                    ie_val = 0.0
            all_ie[name].append(ie_val)

    # Average over windows
    result = {}
    for name in sigma_names:
        result[name] = np.mean(all_ie[name]) if all_ie[name] else 0.0

    return result


def run_ie_for_system(
    top_file: str,
    traj_file: str,
    rec_res_id: int,
    lig_res_start: int,
    lig_res_stop: int,
    first_frame: int,
    last_frame: int,
    offset_frame: int,
    window_frames: int,
    intdiel: float,
    temperature: float,
    out_file: str,
) -> Dict[str, float]:
    """
    Full IE calculation for one system (wildtype or mutant).

    1. Load topology → charges, LJ params, atom indices
    2. Load trajectory frames
    3. Compute per-frame interaction energy
    4. Compute IE with multiple truncation methods
    5. Write results to .dat file

    Returns IE dict.
    """
    import pytraj as pt

    logger.info(f"IE: {top_file}  traj={traj_file}  res={rec_res_id}  intdiel={intdiel}")

    # Load parameters
    charges, sigma, epsilon = _get_atom_params(top_file)
    rec_idx = np.array(_get_residue_atom_indices(top_file, rec_res_id, rec_res_id))
    lig_idx = np.array(_get_residue_atom_indices(top_file, lig_res_start, lig_res_stop))

    if len(rec_idx) == 0:
        raise ValueError(f"No atoms found for receptor residue {rec_res_id}")
    if len(lig_idx) == 0:
        raise ValueError(f"No atoms found for ligand residues {lig_res_start}-{lig_res_stop}")

    logger.info(f"  Receptor residue {rec_res_id}: {len(rec_idx)} atoms")
    logger.info(f"  Ligand residues {lig_res_start}-{lig_res_stop}: {len(lig_idx)} atoms")

    # Load trajectory
    frame_indices = list(range(first_frame - 1, last_frame, offset_frame))
    traj = pt.load(traj_file, top_file, frame_indices=frame_indices)
    xyz = traj.xyz  # (n_frames, n_atoms, 3)
    logger.info(f"  Loaded {xyz.shape[0]} frames")

    # Compute interaction energy per frame
    eint = compute_interaction_energy_per_frame(
        xyz, rec_idx, lig_idx, charges, sigma, epsilon, intdiel
    )
    logger.info(f"  Eint: mean={np.mean(eint):.4f}  std={np.std(eint):.4f} kcal/mol")

    # Compute IE
    ie = compute_ie(eint, window_frames, temperature)

    # Write output .dat
    n_frames_total = len(eint)
    windows = ie_windows(n_frames_total, window_frames)

    kT = KB * temperature
    beta = 1.0 / kT

    with open(out_file, "w") as fh:
        fh.write(f"# Interaction Entropy: {top_file}\n")
        fh.write(f"# Receptor residue: {rec_res_id}  Ligand: {lig_res_start}-{lig_res_stop}\n")
        fh.write(f"# intdiel={intdiel}  T={temperature}K  kT={kT:.6f} kcal/mol\n")
        fh.write(f"# Frames: {first_frame}-{last_frame} offset={offset_frame} total={n_frames_total}\n")
        fh.write(f"# IE windows: {len(windows)} × {window_frames} frames, non-overlapping\n")
        fh.write(f"#\n")
        fh.write(f"{'#Win':>5s} {'IE_Int':>12s} {'IE_3S':>12s} {'IE_4S':>12s} "
                 f"{'IE_5S':>12s} {'IE_7S':>12s} {'IE_Gau':>12s}\n")

        sigma_names = ["IE_Int", "IE_3S", "IE_4S", "IE_5S", "IE_7S", "IE_Gau"]
        sigma_cutoffs = [None, 3, 4, 5, 7, None]

        for wi, (w_start, w_end) in enumerate(windows, 1):
            e_window = eint[w_start:w_end]
            mean_e = np.mean(e_window)
            delta_e = e_window - mean_e
            std_e = np.std(delta_e)

            vals = []
            for name, cutoff in zip(sigma_names, sigma_cutoffs):
                if name == "IE_Gau":
                    v = (std_e ** 2) / (2.0 * kT)
                elif cutoff is None:
                    exp_vals = np.exp(beta * delta_e)
                    mean_exp = np.mean(exp_vals)
                    v = kT * np.log(mean_exp) if mean_exp > 0 else 0.0
                else:
                    mask = np.abs(delta_e) <= cutoff * std_e
                    if np.sum(mask) > 0:
                        exp_vals = np.exp(beta * delta_e[mask])
                        mean_exp = np.mean(exp_vals)
                        v = kT * np.log(mean_exp) if mean_exp > 0 else 0.0
                    else:
                        v = 0.0
                vals.append(v)
            fh.write(f"{wi:5d} " + " ".join(f"{v:12.6f}" for v in vals) + "\n")

        # Average line
        fh.write(f"{'Avg':>5s} " + " ".join(f"{ie[n]:12.6f}" for n in sigma_names) + "\n")

    logger.info(f"  IE result → {out_file}")
    logger.info(f"    IE_Int={ie['IE_Int']:.4f}  IE_3S={ie['IE_3S']:.4f}  "
                f"IE_5S={ie['IE_5S']:.4f}  IE_Gau={ie['IE_Gau']:.4f}")

    return ie


# ===========================================================================
# Step 1: Prepare mutant directories
# ===========================================================================
def step1_prepare(cfg: ASIEConfig) -> List[Tuple[str, int]]:
    """Find near-residues and prepare one directory per mutant."""
    logger.info("=" * 60)
    logger.info("STEP 1: Prepare mutant directories")
    logger.info("=" * 60)

    orig_dir = os.getcwd()
    os.chdir(cfg.work_dir)

    if cfg.rec_res_stop < 0:
        cfg.rec_res_stop = get_last_resid(cfg.rec_pdb)
    if cfg.lig_res_start < 0:
        cfg.lig_res_start = cfg.rec_res_stop + 1
    if cfg.lig_res_stop < 0:
        cfg.lig_res_stop = cfg.rec_res_stop + 1

    logger.info(f"Receptor residues: {cfg.rec_res_start}–{cfg.rec_res_stop}")
    logger.info(f"Ligand residues:   {cfg.lig_res_start}–{cfg.lig_res_stop}")

    near = get_near_residues(
        cfg.com_pdb, cfg.rec_res_start, cfg.rec_res_stop,
        cfg.lig_res_start, cfg.lig_res_stop, cfg.max_distance,
    )

    with open(cfg.near_residue_file, "w") as fh:
        for resname, resid in near:
            fh.write(f"{resname}{resid}\n")

    n_term, c_term = get_terminal_residues(cfg.com_pdb)
    diel_map = read_dielectric_file(cfg.res_diel_file)

    for resname, resid in near:
        mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
        mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
        if os.path.exists(mut_dir):
            shutil.rmtree(mut_dir)
        os.makedirs(mut_dir)

        for fname in [cfg.com_pdb, cfg.com_mdcrd, cfg.rec_pdb, cfg.lig_pdb]:
            src = os.path.join(cfg.work_dir, fname)
            dst = os.path.join(mut_dir, fname)
            os.symlink(src, dst)

        diel_key = get_diel_key(resname, resid, n_term, c_term)
        diel_val = diel_map.get(diel_key, 1.0)

        meta = configparser.ConfigParser()
        meta["mutant"] = {
            "resname": resname,
            "resid": str(resid),
            "diel_key": diel_key,
            "diel_value": str(diel_val),
        }
        with open(os.path.join(mut_dir, "_mutant_meta.ini"), "w") as fh:
            meta.write(fh)

        logger.info(f"  Prepared {mut_dir_name}  (intdiel={diel_val})")

    os.chdir(orig_dir)
    logger.info(f"Step 1 complete – {len(near)} mutants prepared.\n")
    return near


# ===========================================================================
# Step 2: Calculate IE  (per-mutant worker)
# ===========================================================================
def _calculate_single_mutant_ie(
    cfg: ASIEConfig,
    resname: str,
    resid: int,
) -> str:
    """
    For one mutant:
      1. Create mutant PDB + tleap topology
      2. Build mutant trajectory (all frames, offset=1)
      3. Compute IE for wildtype complex (this residue vs ligand)
      4. Compute IE for mutant complex (ALA vs ligand)
    """
    mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
    mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
    os.chdir(mut_dir)

    meta = configparser.ConfigParser()
    meta.read("_mutant_meta.ini")
    diel_val = float(meta["mutant"]["diel_value"])

    try:
        # --- 1. Create mutant PDBs ---
        mut_com_name, _ = create_mutant_pdb(cfg.com_pdb, resid, cfg.com_name)
        mut_rec_name, _ = create_mutant_pdb(cfg.rec_pdb, resid, cfg.rec_name)

        # --- 2. tleap → topologies ---
        lig_mol2_path = os.path.join(cfg.work_dir, cfg.lig_mol2)
        lig_frcmod_path = os.path.join(cfg.work_dir, cfg.lig_frcmod)

        tleap_in = f"""{_tleap_source_lines(cfg)}
{cfg.lig_name_in_pdb}=loadmol2 {lig_mol2_path}
loadamberparams {lig_frcmod_path}
MutRec=loadpdb {mut_rec_name}.pdb
WidRec=loadpdb {cfg.rec_pdb}
Lig=loadpdb {cfg.lig_pdb}
MutCom=loadpdb {mut_com_name}.pdb
WidCom=loadpdb {cfg.com_pdb}
set default PBRadii {cfg.pb_radii}
saveamberparm MutRec {mut_rec_name}.top {mut_rec_name}.crd
savepdb MutRec {mut_rec_name}.pdb
saveamberparm WidRec {cfg.rec_name}.top {cfg.rec_name}.crd
saveamberparm Lig {cfg.lig_name}.top {cfg.lig_name}.crd
saveamberparm MutCom {mut_com_name}.top {mut_com_name}.crd
savepdb MutCom {mut_com_name}.pdb
saveamberparm WidCom {cfg.com_name}.top {cfg.com_name}.crd
quit
"""
        if not run_tleap(tleap_in, "tleap_mutant.log"):
            return f"{mut_dir_name}: tleap FAILED"

        # --- 3. Build mutant trajectory (ALL frames, offset=1 for IE) ---
        output_nc = f"{mut_com_name}.nc"
        create_mutant_trajectory(
            wt_pdb=cfg.com_pdb,
            wt_mdcrd=cfg.com_mdcrd,
            mut_pdb_after_tleap=f"{mut_com_name}.pdb",
            mut_top=f"{mut_com_name}.top",
            mut_res_id=resid,
            first_frame=cfg.frame_start,
            last_frame=cfg.frame_stop,
            offset_frame=cfg.frame_offset,
            output_nc=output_nc,
        )

        window_frames = ie_window_frames(cfg.com_mdcrd, cfg.frame_offset, cfg.ie_window_ns)

        # --- 4a. Compute IE for wildtype (this residue vs ligand) ---
        wt_ie_file = f"{cfg.com_name}_IE_int={diel_val}.dat"
        run_ie_for_system(
            top_file=f"{cfg.com_name}.top",
            traj_file=cfg.com_mdcrd,
            rec_res_id=resid,
            lig_res_start=cfg.lig_res_start,
            lig_res_stop=cfg.lig_res_stop,
            first_frame=cfg.frame_start,
            last_frame=cfg.frame_stop,
            offset_frame=cfg.frame_offset,
            window_frames=window_frames,
            intdiel=diel_val,
            temperature=cfg.temperature,
            out_file=wt_ie_file,
        )

        # --- 4b. Compute IE for mutant (ALA vs ligand) ---
        mut_ie_file = f"{mut_com_name}_IE_int={diel_val}.dat"
        run_ie_for_system(
            top_file=f"{mut_com_name}.top",
            traj_file=output_nc,
            rec_res_id=resid,
            lig_res_start=cfg.lig_res_start,
            lig_res_stop=cfg.lig_res_stop,
            first_frame=1,
            last_frame=cfg.total_frames,
            offset_frame=1,
            window_frames=window_frames,
            intdiel=diel_val,
            temperature=cfg.temperature,
            out_file=mut_ie_file,
        )

        # --- Cleanup ---
        if cfg.remove_temp:
            for pat in ["*.nc", "*.pdb", "*.top", "*.crd",
                         "_mutant_meta.ini", "tleap_mutant.log", "leap.log"]:
                for f in Path(".").glob(pat):
                    if "_IE_int=" in f.name and f.suffix == ".dat":
                        continue
                    f.unlink(missing_ok=True)

        return f"{mut_dir_name}: OK"

    except Exception as exc:
        return f"{mut_dir_name}: ERROR – {exc}"


def step2_calculate(cfg: ASIEConfig, near: List[Tuple[str, int]]) -> None:
    """Run IE calculations for all mutants."""
    logger.info("=" * 60)
    logger.info("STEP 2: Calculate IE for all mutants")
    logger.info("=" * 60)

    orig_dir = os.getcwd()

    if cfg.parallel_mutants <= 1:
        for resname, resid in near:
            status = _calculate_single_mutant_ie(cfg, resname, resid)
            logger.info(status)
            os.chdir(orig_dir)
    else:
        with ProcessPoolExecutor(max_workers=cfg.parallel_mutants) as pool:
            futures = {}
            for resname, resid in near:
                fut = pool.submit(_calculate_single_mutant_ie, cfg, resname, resid)
                futures[fut] = (resname, resid)
            for fut in as_completed(futures):
                status = fut.result()
                logger.info(status)

    os.chdir(orig_dir)
    logger.info("Step 2 complete.\n")


# ===========================================================================
# Step 3: Collect IE results
# ===========================================================================
def step3_results(cfg: ASIEConfig, near: List[Tuple[str, int]]) -> None:
    """Collect ΔIE results (mutant - wildtype) from all mutants."""
    logger.info("=" * 60)
    logger.info("STEP 3: Collect IE results")
    logger.info("=" * 60)

    orig_dir = os.getcwd()
    os.chdir(cfg.work_dir)

    n_term, c_term = get_terminal_residues(cfg.com_pdb)
    diel_map = read_dielectric_file(cfg.res_diel_file)

    out_file = "AlaScan_IE.dat"
    ie_names = ["dIE_Int", "dIE_3S", "dIE_4S", "dIE_5S", "dIE_7S", "dIE_Gau"]
    header = f"{'Mut-Wid':>7s} " + " ".join(f"{n:>9s}" for n in ie_names)

    logger.info(f"{cfg.com_name} Alanine Scanning IE Result → {out_file}")
    print(header)

    results_lines = [header]
    totals = {n: 0.0 for n in ie_names}

    for resname, resid in near:
        diel_key = get_diel_key(resname, resid, n_term, c_term)
        diel_val = diel_map.get(diel_key, 1.0)

        mut_dir_name = f"{cfg.com_name}_{resid}{resname}"
        mut_dir = os.path.join(os.path.dirname(cfg.work_dir), mut_dir_name)
        mut_com_name = f"{cfg.com_name}_{resname}{resid}ALA"

        # IE result files
        mut_ie_file = os.path.join(mut_dir, f"{mut_com_name}_IE_int={diel_val}.dat")
        wt_ie_file = os.path.join(mut_dir, f"{cfg.com_name}_IE_int={diel_val}.dat")

        try:
            mut_ie = _parse_ie_avg(mut_ie_file)
            wt_ie = _parse_ie_avg(wt_ie_file)

            dIE_Int = mut_ie["IE_Int"] - wt_ie["IE_Int"]
            dIE_3S = mut_ie["IE_3S"] - wt_ie["IE_3S"]
            dIE_4S = mut_ie["IE_4S"] - wt_ie["IE_4S"]
            dIE_5S = mut_ie["IE_5S"] - wt_ie["IE_5S"]
            dIE_7S = mut_ie["IE_7S"] - wt_ie["IE_7S"]
            dIE_Gau = mut_ie["IE_Gau"] - wt_ie["IE_Gau"]

            totals["dIE_Int"] += dIE_Int
            totals["dIE_3S"] += dIE_3S
            totals["dIE_4S"] += dIE_4S
            totals["dIE_5S"] += dIE_5S
            totals["dIE_7S"] += dIE_7S
            totals["dIE_Gau"] += dIE_Gau

            line = (f"{resid:>4d}{resname:>3s} {dIE_Int:9.4f} {dIE_3S:9.4f} "
                    f"{dIE_4S:9.4f} {dIE_5S:9.4f} {dIE_7S:9.4f} {dIE_Gau:9.4f}")
        except Exception as exc:
            line = f"{resid:>4d}{resname:>3s}  ERROR: {exc}"

        print(line)
        results_lines.append(line)

    total_line = (
        f"{'TOTAL':>7s} {totals['dIE_Int']:9.4f} {totals['dIE_3S']:9.4f} "
        f"{totals['dIE_4S']:9.4f} {totals['dIE_5S']:9.4f} "
        f"{totals['dIE_7S']:9.4f} {totals['dIE_Gau']:9.4f}"
    )
    print(total_line)
    results_lines.append(total_line)

    with open(out_file, "w") as fh:
        fh.write("\n".join(results_lines) + "\n")

    os.chdir(orig_dir)
    logger.info(f"Results saved to {os.path.join(cfg.work_dir, out_file)}")
    logger.info("Step 3 complete.\n")


def _parse_ie_avg(dat_file: str) -> Dict[str, float]:
    """Parse IE .dat file for the 'Avg' line → dict of IE values."""
    ie_names = ["IE_Int", "IE_3S", "IE_4S", "IE_5S", "IE_7S", "IE_Gau"]
    with open(dat_file) as fh:
        for line in fh:
            parts = line.split()
            if parts and parts[0] == "Avg":
                vals = [float(v) for v in parts[1:]]
                if len(vals) >= 6:
                    return dict(zip(ie_names, vals))
    raise ValueError(f"No 'Avg' line found in {dat_file}")


# ===========================================================================
# Main
# ===========================================================================
def main():
    parser = argparse.ArgumentParser(
        description="ASIE – Alanine Scanning Interaction Entropy (Amber24)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python asie.py config_ie.ini                  # Run all steps
  python asie.py config_ie.ini --step 1         # Only prepare
  python asie.py config_ie.ini --step 23        # Skip prepare
  python asie.py config_ie.ini --parallel 4     # 4 mutants at once
""",
    )
    parser.add_argument("config", help="Path to config_ie.ini file")
    parser.add_argument(
        "--step", default="123",
        help="Steps to run, e.g. '123' (default), '1', '23', '3'",
    )
    parser.add_argument(
        "--parallel", type=int, default=None,
        help="Override parallel_mutants from config",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)
    if not cfg.work_dir:
        cfg.work_dir = os.path.abspath(os.path.dirname(args.config) or ".")
    else:
        cfg.work_dir = os.path.abspath(cfg.work_dir)
    resolve_residue_ranges(cfg)
    if args.parallel is not None:
        cfg.parallel_mutants = args.parallel

    logger.info(f"Work directory: {cfg.work_dir}")
    if "2" in args.step:
        wf = ie_window_frames(os.path.join(cfg.work_dir, cfg.com_mdcrd), cfg.frame_offset, cfg.ie_window_ns)
        logger.info(f"IE windows: {cfg.ie_window_ns:g} ns = {wf} frames; "
                    f"{cfg.total_frames // wf} windows over frames {cfg.frame_start}-{cfg.frame_stop}")
    logger.info(f"Steps to run:   {args.step}")

    near = None

    if "1" in args.step:
        near = step1_prepare(cfg)

    if "2" in args.step:
        if near is None:
            dat_path = os.path.join(cfg.work_dir, cfg.near_residue_file)
            near = []
            with open(dat_path) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        resname = line[:3]
                        resid = int(line[3:])
                        near.append((resname, resid))
        step2_calculate(cfg, near)

    if "3" in args.step:
        if near is None:
            dat_path = os.path.join(cfg.work_dir, cfg.near_residue_file)
            near = []
            with open(dat_path) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        resname = line[:3]
                        resid = int(line[3:])
                        near.append((resname, resid))
        step3_results(cfg, near)

    logger.info("All done.")


if __name__ == "__main__":
    main()
