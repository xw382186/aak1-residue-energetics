#!/usr/bin/env python3
"""Isolated, SHA-pinned ASGBIE pilot. No sbatch and no scientific-code patches."""
import argparse
import configparser
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def save(path, data):
    p = Path(path)
    t = p.with_suffix(p.suffix + '.tmp')
    t.write_text(json.dumps(data, indent=2) + '\n')
    os.replace(t, p)

def run(cmd, cwd, log, timings):
    start = time.monotonic()
    with open(log, 'w') as out:
        p = subprocess.run(cmd, cwd=cwd, stdout=out, stderr=subprocess.STDOUT)
    timings.append({'command': cmd, 'seconds': time.monotonic() - start,
                    'returncode': p.returncode, 'log': str(log), 'finished_at': now()})
    if p.returncode:
        raise RuntimeError(f'Command exited {p.returncode}; see {log}')

def nc_metadata(path):
    import numpy as np
    from scipy.io import netcdf_file
    with netcdf_file(str(path), 'r', mmap=True) as nc:
        shape = list(nc.variables['coordinates'].shape)
        t = np.array(nc.variables['time'][:], dtype=float, copy=True)
        box = 'cell_lengths' in nc.variables and 'cell_angles' in nc.variables
    return {'shape': shape, 'n_frames': len(t), 'first_ps': float(t[0]), 'last_ps': float(t[-1]),
            'uniform_5ps': bool(np.all(np.isfinite(t)) and np.allclose(np.diff(t), 5.0, rtol=0, atol=1e-3)),
            'has_box': box}

def load_engine(path):
    spec = importlib.util.spec_from_file_location('frozen_asgb', path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod

def execute(root, case_id):
    case = next(c for c in json.loads((root / 'manifest.json').read_text())['cases'] if c['case_id'] == case_id)
    for rel, expected in json.loads((root / 'deployment_sha256.json').read_text()).items():
        if sha(root / rel) != expected:
            raise RuntimeError(f'Deployment SHA mismatch: {rel}')
    if int(os.environ.get('SLURM_NTASKS', '0')) != 1 or int(os.environ.get('SLURM_CPUS_PER_TASK', '0')) != 10 or int(os.environ.get('SLURM_JOB_NUM_NODES', '0')) != 1:
        raise RuntimeError('Requires one Slurm job with 1 node, 1 task x 10 CPUs, no GPU')
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        if os.environ.get(key) != '1':
            raise RuntimeError(f'{key} must be 1')
    work = root / 'cases' / case_id
    work.mkdir(parents=True, exist_ok=True)
    lock = open(work / 'case.lock', 'a+')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (work / 'state.json').exists():
        raise RuntimeError('Case already attempted; reconcile existing state before an independent retry')
    state = {'case_id': case_id, 'job_id': os.environ.get('SLURM_JOB_ID'), 'status': 'RUNNING',
             'started_at': now(), 'timings': [], 'scope': 'pilot', 'residue_threshold': None}
    save(work / 'state.json', state)
    started = time.monotonic()
    try:
        inputs = work / 'inputs'
        inputs.mkdir()
        for name, rec in case['sources'].items():
            actual = sha(rec['path'])
            if actual != rec['sha256']:
                raise RuntimeError(f'Scientific input SHA mismatch: {name}')
            shutil.copyfile(rec['path'], inputs / name)
        trajectory = case['trajectory']
        meta = nc_metadata(trajectory['path'])
        if meta['n_frames'] != 10000 or meta['first_ps'] != 325.0 or meta['last_ps'] != 50320.0 or not meta['uniform_5ps'] or not meta['has_box']:
            raise RuntimeError(f'Full trajectory time/box mismatch: {meta}')
        meta['sha256'] = sha(trajectory['path'])
        if trajectory.get('sha256') and meta['sha256'] != trajectory['sha256']:
            raise RuntimeError('Full trajectory differs from its historical pinned SHA')
        save(work / 'source_snapshot.json', {'case': case, 'trajectory': meta, 'verified_at': now()})
        # The original MD reference PDB defines the unchanged 5 A residue set.
        engine = load_engine(root / 'engine/asgb.py')
        pdb_atoms = engine.parse_pdb(str(inputs / 'cpx.pdb'))
        import parmed
        topology = parmed.load_file(str(inputs / 'cpx_vac.prmtop'))
        if meta['shape'][1] != len(topology.atoms) or len(pdb_atoms) != len(topology.atoms):
            raise RuntimeError('PDB / dry topology / full trajectory atom counts differ')
        for pa, ta in zip(pdb_atoms, topology.atoms):
            if (pa['name'], pa['resname'], pa['resid']) != (ta.name, ta.residue.name, ta.residue.idx + 1):
                raise RuntimeError(f'PDB / MD topology atom order or numbering differs at atom {ta.idx + 1}')
        protein_stop = engine.get_last_resid(str(inputs / 'protein_only.pdb'))
        ligand_atoms = engine.parse_pdb(str(inputs / 'lig.pdb'))
        if not ligand_atoms or {a['resname'] for a in ligand_atoms} != {'MOL'}:
            raise RuntimeError('Unexpected ligand residue name; explicit case configuration required')
        if {a['resid'] for a in pdb_atoms if a['resname'] == 'MOL'} != {protein_stop + 1}:
            raise RuntimeError('Ligand must follow the protein with a unique residue index')
        near = engine.get_near_residues(str(inputs / 'cpx.pdb'), 1, protein_stop, protein_stop + 1, protein_stop + 1, 5.0)
        if not near:
            raise RuntimeError('No scannable residues within 5 A')
        nt, ct = engine.get_terminal_residues(str(inputs / 'cpx.pdb'))
        diel = engine.read_dielectric_file(str(root / 'config/ResidueDielectric.dat'))
        missing = [engine.get_diel_key(name, resid, nt, ct) for name, resid in near
                   if engine.get_diel_key(name, resid, nt, ct) not in diel]
        if missing:
            raise RuntimeError(f'Dielectric table lacks explicit residue keys: {missing}')
        (work / 'expected_NearResidue.dat').write_text(''.join(f'{name}{resid}\n' for name, resid in near))
        state['n_residues'] = len(near)
        # Reproduce the engine's WT tleap preparation, independently compare it with MD.
        chem = work / 'chemistry_check'
        chem.mkdir()
        leap = ['source leaprc.protein.ff14SB', 'source leaprc.gaff2',
                f'MOL=loadmol2 {inputs / "lig.mol2"}', f'loadamberparams {inputs / "lig.frcmod"}',
                f'WidCom=loadpdb {inputs / "cpx.pdb"}', 'set default PBRadii mbondi2',
                'saveamberparm WidCom cpx.top cpx.crd', 'quit']
        (chem / 'tleap.in').write_text('\n'.join(leap) + '\n')
        run(['tleap', '-f', 'tleap.in'], chem, chem / 'tleap.log', state['timings'])
        run([sys.executable, str(root / 'scripts/validate_wt_topology.py'), '--source', str(inputs / 'cpx_vac.prmtop'),
             '--rebuilt', str(chem / 'cpx.top'), '--report', str(chem / 'identity.json')], chem, chem / 'identity.log', state['timings'])
        # cpptraj preserves source times and uses each frame's box. All 6000 frames retained.
        cpp = f'parm {inputs / "cpx_vac.prmtop"}\ntrajin {trajectory["path"]} 4001 10000 1\nautoimage\ntrajout {inputs / "md.nc"} netcdf\nrun\nquit\n'
        (inputs / 'extract.in').write_text(cpp)
        run(['cpptraj', '-i', 'extract.in'], inputs, inputs / 'extract.log', state['timings'])
        cropped = nc_metadata(inputs / 'md.nc')
        if cropped['n_frames'] != 6000 or cropped['first_ps'] != 20325.0 or cropped['last_ps'] != 50320.0 or not cropped['uniform_5ps']:
            raise RuntimeError(f'Extracted trajectory time mismatch: {cropped}')
        cropped['sha256'] = sha(inputs / 'md.nc')
        save(work / 'analysis_trajectory.json', cropped)
        for mode, config in [('ASGB', 'config_gb.ini'), ('ASIE', 'config_ie.ini')]:
            prep = work / mode / 'prepare'
            prep.mkdir(parents=True)
            for name in ('cpx.pdb', 'protein_only.pdb', 'lig.pdb', 'lig.mol2', 'lig.frcmod', 'md.nc'):
                (prep / name).symlink_to(inputs / name)
            shutil.copyfile(root / 'config/ResidueDielectric.dat', prep / 'ResidueDielectric.dat')
            shutil.copyfile(root / 'config' / config, prep / config)
        gb, ie = work / 'ASGB/prepare', work / 'ASIE/prepare'
        # Separate preparation first so missing dielectric/residue mismatches cannot pass silently.
        run([sys.executable, str(root / 'engine/asgb.py'), str(gb / 'config_gb.ini'), '--step', '2'], gb, work / 'gb_prepare.log', state['timings'])
        run([sys.executable, str(root / 'engine/asie.py'), str(ie / 'config_ie.ini'), '--step', '1'], ie, work / 'ie_prepare.log', state['timings'])
        expected = (work / 'expected_NearResidue.dat').read_text()
        if any((p / 'NearResidue.dat').read_text() != expected for p in (gb, ie)):
            raise RuntimeError('GB/IE preparation disagrees with pinned residue set')
        save(work / 'state.json', state)
        run([sys.executable, str(root / 'engine/asgb.py'), str(gb / 'config_gb.ini'), '--step', '134'], gb, work / 'asgb.log', state['timings'])
        run([sys.executable, str(root / 'engine/asie.py'), str(ie / 'config_ie.ini'), '--step', '23'], ie, work / 'asie.log', state['timings'])
        run([sys.executable, str(root / 'scripts/validate_asgbie_outputs.py'), '--case-root', str(work),
             '--expected-near', str(work / 'expected_NearResidue.dat'), '--source-frame-start', '1', '--source-frame-stop', '6000',
             '--report', str(work / 'validation.json')], work, work / 'validation.log', state['timings'])
        verified = json.loads((work / 'validation.json').read_text())
        if verified['status'] != 'PASS':
            raise RuntimeError('Independent acceptance did not PASS')
        result = {'case_id': case_id, 'cohort': case['cohort'], 'pose': case['pose'],
                  'definition': 'sum over every scannable residue within the original 5 A set: dH + dIE_3S',
                  'threshold': None, 'negative_and_small_contributions_included': True,
                  'dH': verified['totals']['GB']['dH'], 'dIE_3S': verified['totals']['IE']['dIE_3S'],
                  'ASGBIE_all': verified['totals']['GB']['dH'] + verified['totals']['IE']['dIE_3S'],
                  'n_residues': len(near), 'production_ns': [20, 50], 'gb_frames': 100,
                  'ie_frames': 6000, 'ie_windows': 10, 'ie_window_ns': 3, 'temperature_K': 298.15,
                  'validation_sha256': sha(work / 'validation.json')}
        save(work / 'result.json', result)
        state['status'] = 'COMPLETE_VALIDATED'
    except Exception as exc:
        state['status'] = 'FAILED'
        state['error'] = repr(exc)
        raise
    finally:
        state['wall_seconds'] = time.monotonic() - started
        state['finished_at'] = now()
        save(work / 'state.json', state)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--case-id')
    p.add_argument('--case-list', type=Path)
    args = p.parse_args()
    case_id = args.case_id
    if args.case_list:
        case_id = json.loads(args.case_list.read_text())[int(os.environ['SLURM_ARRAY_TASK_ID'])]
    if not case_id:
        p.error('Specify --case-id or --case-list')
    execute(args.root.resolve(), case_id)

if __name__ == '__main__':
    main()
