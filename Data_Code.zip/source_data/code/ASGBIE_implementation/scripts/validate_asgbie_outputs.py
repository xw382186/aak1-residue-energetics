#!/usr/bin/env python3
"""Independent, stdlib-only acceptance gate for the 2026-09-18 ASGBIE campaign.

Usage:
  python3 validate_asgbie_outputs.py --case-root CASE \
    --expected-near PINNED_NearResidue.dat --report CASE/validation.json
  python3 validate_asgbie_outputs.py --gb-prepare GB/prepare \
    --ie-prepare ASIE/prepare --expected-near PINNED_NearResidue.dat --report report.json
  python3 validate_asgbie_outputs.py --self-test --report self_test.json

Expected campaign: original frames 4001..10000; GB stride 60 (100 frames),
IE stride 1 (6000 frames), ten non-overlapping 600-frame windows, 298.15 K.
Never imports or executes the calculation engine. Never filters residues by score.
A nonzero exit and a machine-readable FAIL report result from any missing,
nonfinite, malformed, mismatched, duplicated, or incomplete expected output.
This verifies saved results and settings, not the correctness of MD or chemistry.
"""
from __future__ import annotations
import argparse
import configparser
import csv
import hashlib
import io
import json
import math
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

VERSION = "1.0.0"
DIEL_SHA = "19517cb941a9cc1b03f2a6202ef6a9154ccb30b827f265c562826e0b9aabc246"
GB_COLS = ["dVDW", "dEEL", "dGB", "dNP", "dH"]
IE_COLS = ["IE_Int", "IE_3S", "IE_4S", "IE_5S", "IE_7S", "IE_Gau"]
ENERGY_COLS = ["VDWAALS", "EEL", "EGB", "ESURF"]
SECTIONS = ["Complex", "Receptor", "Ligand", "DELTA"]

class Invalid(ValueError):
    pass

def require(ok, message):
    if not ok:
        raise Invalid(message)

def finite_values(tokens, context):
    try:
        vals = [float(x) for x in tokens]
    except ValueError as exc:
        raise Invalid(f"{context}: invalid numeric field: {exc}") from exc
    require(all(math.isfinite(x) for x in vals), f"{context}: nonfinite numeric value")
    return vals

def close(x, y, tolerance):
    return abs(x - y) <= tolerance + 1e-12 * max(1.0, abs(x), abs(y))

def near_list(text):
    result = []
    for line in text.splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([A-Z]{3})([1-9]\d*)", line.strip())
        require(match is not None, f"malformed NearResidue line: {line!r}")
        name, rid = match.group(1), int(match.group(2))
        require(name not in {"ALA", "GLY"}, "ALA/GLY must not be in the scanning list")
        result.append((name, rid))
    require(result, "empty NearResidue list cannot establish complete results")
    require(len(result) == len(set(result)), "duplicate residue in NearResidue list")
    require(len({r for _, r in result}) == len(result), "ambiguous duplicate residue ID")
    return result

def summary_table(text, columns, expected):
    require(not re.search(r"\b(?:ERROR|FATAL)\b", text, re.I), "ERROR/FATAL in summary")
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    require(lines and lines[0].split() == ["Mut-Wid"] + columns, "wrong summary header")
    rows, total = {}, None
    for i, line in enumerate(lines[1:], 1):
        cells = line.split()
        require(len(cells) == len(columns) + 1, f"wrong field count: {line!r}")
        vals = finite_values(cells[1:], f"summary row {cells[0]}")
        if cells[0] == "TOTAL":
            require(total is None and i == len(lines) - 1, "TOTAL must occur exactly once, last")
            total = vals
            continue
        match = re.fullmatch(r"([1-9]\d*)([A-Z]{3})", cells[0])
        require(match is not None, f"malformed residue label: {cells[0]}")
        key = (match.group(2), int(match.group(1)))
        require(key not in rows, f"duplicate summary residue: {key}")
        rows[key] = vals
    require(total is not None, "missing TOTAL")
    require(set(rows) == set(expected),
            f"summary residue mismatch; missing={sorted(set(expected)-set(rows))}; "
            f"extra={sorted(set(rows)-set(expected))}")
    # Individual rows and TOTAL are independently rounded to four decimals.
    tol = (len(rows) + 1) * 0.00005 + 1e-8
    for j, col in enumerate(columns):
        require(close(math.fsum(v[j] for v in rows.values()), total[j], tol),
                f"TOTAL {col} does not equal the sum of all expected residue rows")
    return {"rows": rows, "total": total}

def ie_file(text, *, topology, residue, ligand, dielectric, temperature, mutant, source_frames=(4001,10000)):
    require(not re.search(r"\b(?:ERROR|FATAL)\b", text, re.I), "ERROR/FATAL in IE file")
    lines = [s.strip() for s in text.splitlines() if s.strip()]
    def unique(pattern, label):
        matches = [m for line in lines if (m := re.fullmatch(pattern, line))]
        require(len(matches) == 1, f"expected one {label} metadata line, got {len(matches)}")
        return matches[0]
    top = unique(r"# Interaction Entropy: (.+)", "topology").group(1)
    require(top == topology, f"wrong topology {top!r}; expected {topology!r}")
    m = unique(r"# Receptor residue: (\d+)\s+Ligand: (\d+)-(\d+)", "residue/ligand")
    require(tuple(map(int, m.groups())) == (residue, *ligand), "wrong receptor/ligand identity")
    m = unique(r"# intdiel=(\S+)\s+T=(\S+)K\s+kT=(\S+) kcal/mol", "dielectric/temperature")
    diel, temp, kt = finite_values(m.groups(), "IE metadata")
    require(close(diel, dielectric, 1e-10), "IE dielectric does not match WT residue mapping")
    require(close(temp, temperature, 1e-8), "IE temperature does not match requested temperature")
    require(close(kt, 0.001987204 * temperature, 0.00000051), "IE kT is inconsistent with temperature")
    m = unique(r"# Frames: (\d+)-(\d+) offset=(\d+) total=(\d+)", "frame range")
    wanted = (1, 6000, 1, 6000) if mutant else (*source_frames, 1, 6000)
    require(tuple(map(int, m.groups())) == wanted, f"wrong IE frame selection; expected {wanted}")
    m = unique(r"# IE windows: (\d+) [×x] (\d+) frames, non-overlapping", "window")
    require(tuple(map(int, m.groups())) == (10, 600), "IE must contain ten 600-frame windows")
    headers = [line for line in lines if line.startswith("#Win")]
    require(len(headers) == 1 and headers[0].split() == ["#Win"] + IE_COLS, "wrong IE column header")
    values, averages = [], []
    seen_avg = False
    for line in lines:
        if line.startswith("#"):
            continue
        cells = line.split()
        require(len(cells) == 7, f"wrong IE row field count: {line!r}")
        nums = finite_values(cells[1:], "IE row")
        if cells[0] == "Avg":
            seen_avg = True
            averages.append(nums)
        else:
            require(not seen_avg, "IE window occurs after Avg")
            require(cells[0] == str(len(values) + 1), "IE window IDs are missing, duplicated, or reordered")
            values.append(nums)
    require(len(values) == 10 and len(averages) == 1, "IE requires 10 numeric window rows and one Avg")
    avg = averages[0]
    for j, name in enumerate(IE_COLS):
        require(close(math.fsum(v[j] for v in values)/10, avg[j], 0.00000101),
                f"IE Avg {name} does not match the ten window rows")
    return {"avg": avg, "windows": 10, "frames": 6000, "temperature": temp, "dielectric": diel}

def gb_dat(text, *, mutant, source_frames=(4001,10000), receptor=None, ligand=None, topology=None):
    require(not re.search(r"\b(?:ERROR|FATAL)\b", text, re.I), "ERROR/FATAL in GB dat")
    require(text.count("GENERALIZED BORN:") == 1, "missing/duplicate GENERALIZED BORN section")
    frame_values = {}
    for field in ("startframe", "endframe", "interval"):
        hits = re.findall(r"\b" + field + r"\s*=\s*(\d+)\s*,", text)
        require(len(hits) == 1, f"missing/duplicate GB input {field}")
        frame_values[field] = int(hits[0])
    wanted = {"startframe": 1, "endframe": 100, "interval": 1} if mutant else {
        "startframe": source_frames[0], "endframe": source_frames[1], "interval": 60}
    require(frame_values == wanted, f"wrong GB input frame range: {frame_values}; expected {wanted}")
    for label, wanted_range in (("Receptor", receptor), ("Ligand", ligand)):
        if wanted_range is not None:
            hits = re.findall(r"\|" + label + r' mask:\s+"(:[\d-]+)"', text)
            wanted_mask = ":" + str(wanted_range[0]) + ("-"+str(wanted_range[1]) if wanted_range[1] != wanted_range[0] else "")
            acceptable = {wanted_mask, f":{wanted_range[0]}-{wanted_range[1]}"}
            require(len(hits) == 1 and hits[0] in acceptable, f"wrong/missing GB {label} mask")
    if topology is not None:
        hits = re.findall(r"\|Complex topology file:\s+(\S+)", text)
        require(len(hits) == 1 and Path(hits[0]).name == topology, "wrong/missing GB complex topology")
    sections, active = {}, None
    for line in text.splitlines():
        line = line.strip()
        if line in {"Complex:", "Receptor:", "Ligand:"}:
            active = line[:-1]
            require(active not in sections, f"duplicate GB {active} section")
            sections[active] = {}
        elif line == "Differences (Complex - Receptor - Ligand):":
            active = "DELTA"
            require(active not in sections, "duplicate GB differences section")
            sections[active] = {}
        elif active:
            parts = line.split()
            key, offset = None, 1
            if parts and parts[0] in ENERGY_COLS:
                key = parts[0]
            elif parts[:2] == ["DELTA", "TOTAL"]:
                key, offset = "TOTAL", 2
            elif parts[:3] in (["DELTA", "G", "gas"], ["DELTA", "G", "solv"]):
                key, offset = " ".join(parts[1:3]), 3
            elif parts[:2] in (["G", "gas"], ["G", "solv"]):
                key, offset = " ".join(parts[:2]), 2
            elif parts and parts[0] == "TOTAL":
                key = "TOTAL"
            if key:
                require(key not in sections[active], f"duplicate GB {active}/{key}")
                require(len(parts[offset:]) == 3, f"GB {active}/{key}: expected mean, SD, SEM")
                sections[active][key] = finite_values(parts[offset:], f"GB {active}/{key}")[0]
    require(set(sections) == set(SECTIONS), "GB is missing a complete energy section")
    for name, vals in sections.items():
        require(set(vals) == set(ENERGY_COLS + ["G gas", "G solv", "TOTAL"]), f"missing GB {name} energy terms")
        require(close(vals["G gas"], vals["VDWAALS"]+vals["EEL"], 0.000151), f"GB dat {name}: G gas sum mismatch")
        require(close(vals["G solv"], vals["EGB"]+vals["ESURF"], 0.000151), f"GB dat {name}: G solv sum mismatch")
        require(close(vals["TOTAL"], vals["G gas"]+vals["G solv"], 0.000151), f"GB dat {name}: TOTAL sum mismatch")
    return {"sections": sections, "delta": [sections["DELTA"][k] for k in ENERGY_COLS + ["TOTAL"]]}

def gb_csv(text):
    sections, active, header = {}, None, None
    for raw in csv.reader(io.StringIO(text)):
        row = [x.strip() for x in raw]
        if not row or not any(row):
            continue
        if len(row) == 1 and row[0] == "GENERALIZED BORN:":
            continue
        if len(row) == 1 and row[0].endswith(" Energy Terms"):
            active = row[0][:-len(" Energy Terms")]
            require(active in SECTIONS and active not in sections, f"invalid/duplicate GB CSV section {active}")
            sections[active] = []
            header = None
            continue
        require(active is not None, f"GB CSV data outside a section: {row!r}")
        if row[0] == "Frame #":
            require(header is None, "duplicate GB CSV header")
            expected = ["Frame #"] + ENERGY_COLS + (["DELTA G gas", "DELTA G solv", "DELTA TOTAL"]
                        if active == "DELTA" else ["G gas", "G solv", "TOTAL"])
            require(row == expected, f"wrong GB CSV header in {active}: {row}")
            header = row
            continue
        require(header is not None and len(row) == 8, f"malformed GB CSV row in {active}")
        require(re.fullmatch(r"\d+", row[0]) is not None, "GB CSV noninteger frame ID")
        sections[active].append((int(row[0]), finite_values(row[1:], f"GB CSV {active}")))
    require(set(sections) == set(SECTIONS), "GB CSV missing a section")
    indices = None
    means = {}
    for name, rows in sections.items():
        require(len(rows) == 100, f"GB CSV {name} has {len(rows)} frames, expected 100")
        ids = [r[0] for r in rows]
        require(ids in [list(range(100)), list(range(1, 101))], f"GB CSV {name} frame IDs are incomplete/duplicated")
        require(indices is None or ids == indices, "GB CSV frame IDs do not pair across sections")
        indices = ids
        means[name] = [math.fsum(r[1][j] for r in rows)/100 for j in range(7)]
        for i, (_,v) in enumerate(rows):
            require(close(v[4],v[0]+v[1],1e-6), f"GB CSV {name} frame {i}: gas sum mismatch")
            require(close(v[5],v[2]+v[3],1e-6), f"GB CSV {name} frame {i}: solv sum mismatch")
            require(close(v[6],v[4]+v[5],1e-6), f"GB CSV {name} frame {i}: TOTAL sum mismatch")
    for i in range(100):
        for j in range(7):
            rhs = sections["Complex"][i][1][j] - sections["Receptor"][i][1][j] - sections["Ligand"][i][1][j]
            require(close(sections["DELTA"][i][1][j], rhs, 1e-6),
                    f"GB CSV DELTA does not equal complex-receptor-ligand at row {i}, col {j}")
    return {"means": means, "frames": 100}

def load_ini(text):
    cp = configparser.ConfigParser()
    cp.read_string(text)
    values = {}
    for section in cp.sections():
        for key, value in cp.items(section):
            require(key not in values, f"duplicate config key across sections: {key}")
            values[key] = value.strip()
    return values

def pdb_info(text):
    residues, nterm, cterm = {}, set(), set()
    for line in text.splitlines():
        if not line.startswith(("ATOM  ", "HETATM")):
            continue
        require(len(line) >= 27, "short PDB atom record")
        resid, resname, atom = int(line[22:26]), line[17:20].strip(), line[12:16].strip()
        require(resid not in residues or residues[resid] == resname, "ambiguous PDB residue ID")
        residues[resid] = resname
        if atom == "H2": nterm.add(resid)
        if atom == "OXT": cterm.add(resid)
    require(residues, "PDB has no atoms")
    return residues, nterm, cterm

class Validator:
    def __init__(self):
        self.report = {"validator_version": VERSION, "created_utc": datetime.now(timezone.utc).isoformat(),
                       "status": "FAIL", "errors": [], "files": {}, "residues": [],
                       "acceptance_scope": "saved output completeness, finite values, frame/window metadata and WT-ALA consistency; not a new energy or trajectory calculation"}
        self.cache = {}
    def read(self, path):
        path = Path(path).resolve()
        if path not in self.cache:
            raw = path.read_bytes()
            require(bool(raw), "empty file")
            self.report["files"][str(path)] = {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
            self.cache[path] = raw.decode("utf-8")
        return self.cache[path]
    def check(self, label, path, fn):
        try:
            return fn()
        except (Invalid, ValueError, KeyError, OSError, UnicodeError, configparser.Error) as exc:
            self.report["errors"].append({"check": label, "path": str(path), "message": str(exc)})
            return None
    def require_check(self, ok, label, path, message):
        return self.check(label, path, lambda: require(ok, message))

    def run(self, gb, ie, expected_near, dielectric_sha, temperature=298.15, source_frames=(4001,10000)):
        gb, ie = Path(gb).resolve(), Path(ie).resolve()
        self.report["inputs"] = {"gb_prepare": str(gb), "ie_prepare": str(ie),
                                 "expected_near": str(Path(expected_near).resolve()),
                                 "expected_dielectric_sha256": dielectric_sha, "temperature": temperature,
                                 "source_frames":list(source_frames), "finite_policy":"all GB and all six IE columns must be finite"}
        require(source_frames[0] >= 1 and source_frames[1]-source_frames[0]+1 == 6000,
                "source range must select exactly 6000 consecutive original input frames")
        expected = self.check("expected_near", expected_near, lambda: near_list(self.read(expected_near)))
        if expected is None: return self.report
        self.report["expected_residues"] = [f"{n}{r}" for n, r in expected]
        configs, tables, infos = {}, {}, {}
        for mode, directory, filename in [("GB", gb, "config_gb.ini"), ("IE", ie, "config_ie.ini")]:
            cfgpath = directory/filename
            cfg = self.check(f"{mode}_config", cfgpath, lambda p=cfgpath: load_ini(self.read(p)))
            if cfg is None: continue
            configs[mode] = cfg
            must = {"frame_start": source_frames[0], "frame_stop": source_frames[1], "frame_offset": 60 if mode == "GB" else 1,
                    "parallel_mutants": 1 if mode == "GB" else 10}
            if mode == "GB": must["processors"] = 10
            else: must.update({"ie_window_ns": 3.0, "temperature": temperature})
            for key, val in must.items():
                self.check(f"{mode}_config_{key}", cfgpath,
                           lambda k=key,v=val,c=cfg: require(close(float(c[k]), v, 1e-8), f"expected {k}={v}, got {c.get(k)}"))
            nearpath = directory/cfg.get("near_residue_file", "NearResidue.dat")
            actual = self.check(f"{mode}_near", nearpath, lambda p=nearpath: near_list(self.read(p)))
            if actual is not None:
                self.require_check(set(actual) == set(expected), f"{mode}_near_matches_expected", nearpath,
                                   "NearResidue list does not match independently supplied expected list")
            table = self.check(f"{mode}_summary", directory/("AlaScan_GB.dat" if mode == "GB" else "AlaScan_IE.dat"),
                 lambda d=directory,m=mode: summary_table(self.read(d/("AlaScan_GB.dat" if m == "GB" else "AlaScan_IE.dat")),
                        GB_COLS if m == "GB" else ["d"+x for x in IE_COLS], expected))
            if table: tables[mode] = table
            pdbpath = directory/cfg.get("com_pdb", "cpx.pdb")
            pi = self.check(f"{mode}_PDB", pdbpath, lambda p=pdbpath: pdb_info(self.read(p)))
            dielpath = directory/cfg.get("res_diel_file", "ResidueDielectric.dat")
            def dielectric_map(p=dielpath):
                txt = self.read(p)
                require(hashlib.sha256(txt.encode()).hexdigest() == dielectric_sha, "dielectric table SHA256 differs from pinned legacy table")
                result = {}
                for line in txt.splitlines():
                    if not line.strip(): continue
                    cells = line.split()
                    require(len(cells) == 2 and cells[0] not in result, "malformed/duplicate dielectric-table entry")
                    result[cells[0]] = finite_values([cells[1]], "dielectric table")[0]
                require(set(result.values()) == {1.0, 3.0, 10.0}, "dielectric values must be exactly 1/3/10")
                return result
            dm = self.check(f"{mode}_dielectric", dielpath, dielectric_map)
            if pi is not None and dm is not None:
                infos[mode] = (pi, dm)
        if set(configs) != {"GB", "IE"} or set(infos) != {"GB", "IE"}:
            return self.report
        for filekey, fallback in [("com_pdb", "cpx.pdb"), ("rec_pdb", "protein_only.pdb")]:
            a, b = gb/configs["GB"].get(filekey,fallback), ie/configs["IE"].get(filekey,fallback)
            self.check("paired_"+filekey, a, lambda a=a,b=b: require(self.read(a)==self.read(b), f"GB and IE {filekey} differ"))
        name = configs["GB"].get("com_name", "cpx")
        self.require_check(configs["IE"].get("com_name", "cpx") == name, "complex_name", ie, "GB/IE com_name differ")
        def residue_ranges(mode, directory):
            c = configs[mode]
            recstop = int(c.get("rec_res_stop", -1))
            if recstop < 0:
                recstop = max(pdb_info(self.read(directory/c.get("rec_pdb","protein_only.pdb")))[0])
            a,b = int(c.get("lig_res_start",-1)), int(c.get("lig_res_stop",-1))
            return (int(c.get("rec_res_start",1)),recstop),(recstop+1 if a < 0 else a, recstop+1 if b < 0 else b)
        ierange = self.check("IE_residue_ranges", ie, lambda: residue_ranges("IE",ie))
        gbrange = self.check("GB_residue_ranges", gb, lambda: residue_ranges("GB",gb))
        if ierange is None or gbrange is None: return self.report
        self.require_check(ierange == gbrange, "paired_residue_ranges", gb, "GB/IE receptor/ligand ranges differ")
        receptor, ligand = ierange
        diels = {}
        for resname, resid in expected:
            for mode in ("GB", "IE"):
                pi, dm = infos[mode]
                def lookup(pi=pi,dm=dm,resname=resname,resid=resid):
                    residues, nt, ct = pi
                    require(residues.get(resid) == resname, "NearResidue identity differs from WT PDB")
                    key = ("N" if resid in nt else "C" if resid in ct else "") + resname
                    require(key in dm, f"missing dielectric key {key}; refuse silent fallback to 1")
                    return dm[key]
                value = self.check(f"{mode}_residue_dielectric_{resname}{resid}", gb if mode=="GB" else ie, lookup)
                if value is not None:
                    if (resname,resid) in diels:
                        self.require_check(diels[(resname,resid)] == value, "paired_dielectric", ie, "GB/IE dielectric assignment differs")
                    else: diels[(resname,resid)] = value
        gb_cache = {}
        def gb_system(directory, prefix, diel, mutant):
            key = (str(directory/prefix), diel)
            if key in gb_cache: return gb_cache[key]
            datpath = directory/f"{prefix}_MMGBSA_intdiel={diel}.dat"
            csvpath = datpath.with_suffix(".csv")
            dat = self.check("GB_dat", datpath, lambda: gb_dat(self.read(datpath), mutant=mutant,
                source_frames=source_frames,receptor=receptor,ligand=ligand,topology=prefix+".top"))
            vectors = self.check("GB_csv", csvpath, lambda: gb_csv(self.read(csvpath)))
            if dat is not None and vectors is not None:
                for sec in SECTIONS:
                    for j, col in enumerate(ENERGY_COLS + ["G gas","G solv","TOTAL"]):
                        self.require_check(close(dat["sections"][sec][col], vectors["means"][sec][j], 0.000051),
                            "GB_dat_matches_csv", datpath, f"{sec}/{col} dat mean differs from 100-frame CSV mean")
            gb_cache[key] = dat
            return dat
        # The engine computes WT once for every unique dielectric in the legacy table.
        for diel in (1.0,3.0,10.0): gb_system(gb.parent/"Wildtype", name, diel, False)
        for resname, resid in expected:
            record = {"resname": resname, "resid": resid}
            self.report["residues"].append(record)
            if (resname,resid) not in diels: continue
            diel = diels[(resname,resid)]
            record["dielectric"] = diel
            dirname, mutname = f"{name}_{resid}{resname}", f"{name}_{resname}{resid}ALA"
            wtgb = gb_system(gb.parent/"Wildtype", name, diel, False)
            mutgb = gb_system(gb.parent/dirname, mutname, diel, True)
            if wtgb is not None and mutgb is not None and "GB" in tables:
                computed = [a-b for a,b in zip(mutgb["delta"],wtgb["delta"])]
                for j,col in enumerate(GB_COLS):
                    self.require_check(close(tables["GB"]["rows"][(resname,resid)][j],computed[j],0.000051),
                        "GB_WT_ALA_pair", gb/"AlaScan_GB.dat", f"{resname}{resid}/{col} does not match ALA minus WT")
                record["GB_delta"] = computed
            iev = {}
            for role, prefix, mutant in [("WT",name,False),("ALA",mutname,True)]:
                p = ie.parent/dirname/f"{prefix}_IE_int={diel}.dat"
                result = self.check(f"IE_{role}", p, lambda p=p,prefix=prefix,mutant=mutant,resid=resid,diel=diel:
                    ie_file(self.read(p),topology=prefix+".top",residue=resid,ligand=ligand,dielectric=diel,
                            temperature=temperature,mutant=mutant,source_frames=source_frames))
                if result is not None: iev[role] = result
            if set(iev) == {"WT","ALA"}:
                computed = [a-b for a,b in zip(iev["ALA"]["avg"],iev["WT"]["avg"])]
                if "IE" in tables:
                    for j,col in enumerate(IE_COLS):
                        self.require_check(close(tables["IE"]["rows"][(resname,resid)][j],computed[j],0.000051),
                            "IE_WT_ALA_pair", ie/"AlaScan_IE.dat", f"{resname}{resid}/d{col} does not match ALA minus WT")
                record.update({"IE_delta":computed,"IE_frames_per_system":6000,"IE_windows_per_system":10})
        self.report["counts"] = {"expected_residues":len(expected),"GB_summary_rows":len(tables.get("GB",{}).get("rows",{})),
                                 "IE_summary_rows":len(tables.get("IE",{}).get("rows",{})),"hashed_files":len(self.report["files"])}
        self.report["totals"] = {mode:dict(zip(GB_COLS if mode == "GB" else ["d"+c for c in IE_COLS],table["total"]))
                                for mode,table in tables.items()}
        self.report["status"] = "PASS" if not self.report["errors"] else "FAIL"
        return self.report

def write_report(path, report):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    # Sibling temporary file + replace avoids publishing a partial JSON report.
    with tempfile.NamedTemporaryFile("w",encoding="utf-8",dir=path.parent,prefix=path.name+".",delete=False) as fh:
        json.dump(report,fh,indent=2,ensure_ascii=False,allow_nan=False)
        fh.write("\n")
        temp = Path(fh.name)
    temp.replace(path)


def main():
    ap=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--case-root",type=Path)
    ap.add_argument("--gb-prepare",type=Path)
    ap.add_argument("--ie-prepare",type=Path)
    ap.add_argument("--expected-near",type=Path)
    ap.add_argument("--expected-dielectric-sha256",default=DIEL_SHA)
    ap.add_argument("--temperature",type=float,default=298.15)
    ap.add_argument("--source-frame-start",type=int,default=4001)
    ap.add_argument("--source-frame-stop",type=int,default=10000)
    ap.add_argument("--report",type=Path,required=True)
    ap.add_argument("--self-test",action="store_true")
    args=ap.parse_args()
    if args.self_test:
        report=self_test()
    else:
        if args.case_root:
            args.gb_prepare=args.gb_prepare or args.case_root/"ASGB"/"prepare"
            args.ie_prepare=args.ie_prepare or args.case_root/"ASIE"/"prepare"
        if not (args.gb_prepare and args.ie_prepare and args.expected_near):
            ap.error("provide --case-root (or both prepare paths), and --expected-near")
        validator=Validator()
        try:
            report=validator.run(args.gb_prepare,args.ie_prepare,args.expected_near,args.expected_dielectric_sha256,args.temperature,
                                 (args.source_frame_start,args.source_frame_stop))
        except Exception as exc:
            report=validator.report
            report["status"]="FAIL"
            report["errors"].append({"check":"validator_exception","message":f"{type(exc).__name__}: {exc}"})
    write_report(args.report,report)
    print(json.dumps({"status":report["status"],"errors":len(report.get("errors",[])),"report":str(args.report.resolve())},ensure_ascii=False))
    return 0 if report["status"]=="PASS" else 1

# Self-test is defined below. It builds disposable, source-format fixtures and then
# corrupts one fact at a time; it performs no molecular or energy calculation.
def self_test():
    """Acceptance and actual corruption tests; no engine imports or calculations."""
    results=[]
    def fixture(root, source_frames=(4001,10000)):
        gb,ie=root/"ASGB/prepare",root/"ASIE/prepare"
        gb.mkdir(parents=True);ie.mkdir(parents=True)
        near="LEU20\nGLU22\n"
        (root/"expected_near.dat").write_text(near)
        diel="LEU 1.0\nASN 3.0\nGLU 10.0\n"
        dielsha=hashlib.sha256(diel.encode()).hexdigest()
        def pdb(ligand):
            records=[(20,"LEU"),(22,"GLU")]+([(23,"MOL")] if ligand else [])
            return "".join(f"ATOM  {i:5d}  CA  {name:3s} A{rid:4d}    {0.:8.3f}{0.:8.3f}{0.:8.3f}{1.:6.2f}{0.:6.2f}           C\n"
                           for i,(rid,name) in enumerate(records,1))+"END\n"
        for mode,directory in [("GB",gb),("IE",ie)]:
            (directory/"NearResidue.dat").write_text(near)
            (directory/"ResidueDielectric.dat").write_text(diel)
            (directory/"cpx.pdb").write_text(pdb(True))
            (directory/"protein_only.pdb").write_text(pdb(False))
            cfg=("[files]\ncom_name=cpx\ncom_pdb=cpx.pdb\nrec_pdb=protein_only.pdb\nres_diel_file=ResidueDielectric.dat\nnear_residue_file=NearResidue.dat\n"
                 "[residues]\nrec_res_start=1\nrec_res_stop=22\nlig_res_start=23\nlig_res_stop=23\n"
                 f"[trajectory]\nframe_start={source_frames[0]}\nframe_stop={source_frames[1]}\nframe_offset={60 if mode=='GB' else 1}\n"
                 f"[run]\nparallel_mutants={1 if mode=='GB' else 10}\n")
            cfg += "processors=10\n" if mode=="GB" else "[ie]\nie_window_ns=3.0\ntemperature=298.15\n"
            (directory/("config_gb.ini" if mode=="GB" else "config_ie.ini")).write_text(cfg)
        def terms(v):return v+[v[0]+v[1],v[2]+v[3],sum(v)]
        def gb_output(directory,prefix,diel,mutant,shift):
            directory.mkdir(parents=True,exist_ok=True)
            delta=[-3.+shift[0],-2./diel+shift[1],1./diel+shift[2],-.1+shift[3]]
            rec=[-80.,-180.,40.,.8];lig=[-17.,-18.,9.,.3]
            sections={"Complex":terms([a+b+c for a,b,c in zip(rec,lig,delta)]),"Receptor":terms(rec),"Ligand":terms(lig),"DELTA":terms(delta)}
            start,stop,stride=(1,100,1) if mutant else (*source_frames,60)
            dat=f"|&general\n| startframe={start},\n| endframe={stop},\n| interval={stride},\n|/\n"
            dat+=f'|Complex topology file: {prefix}.top\n|Receptor mask: ":1-22"\n|Ligand mask: ":23"\nGENERALIZED BORN:\n'
            csvtext="GENERALIZED BORN:\n"
            for section,vals in sections.items():
                dat+=("Differences (Complex - Receptor - Ligand):" if section=="DELTA" else section+":")+"\n"
                for col,val in zip(ENERGY_COLS+["G gas","G solv","TOTAL"],vals):
                    label="DELTA "+col if section=="DELTA" and col in {"G gas","G solv","TOTAL"} else col
                    dat+=f"{label} {val:.4f} 0.0000 0.0000\n"
                csvtext+=section+" Energy Terms\n"
                labels=ENERGY_COLS+(["DELTA G gas","DELTA G solv","DELTA TOTAL"] if section=="DELTA" else ["G gas","G solv","TOTAL"])
                csvtext+="Frame #,"+",".join(labels)+"\n"
                csvtext+="".join(str(i)+","+",".join(f"{x:.10f}" for x in vals)+"\n" for i in range(100))
            path=directory/f"{prefix}_MMGBSA_intdiel={diel}.dat"
            path.write_text(dat);path.with_suffix(".csv").write_text(csvtext)
        for d in (1.,3.,10.):gb_output(gb.parent/"Wildtype","cpx",d,False,[0.]*4)
        gbrows,ierows={},{}
        for ri,(name,rid,d) in enumerate([("LEU",20,1.),("GLU",22,10.)]):
            dirname=f"cpx_{rid}{name}";mut=f"cpx_{name}{rid}ALA"
            shift=[.1,-.2,.07,-.01] if ri==0 else [.3,.2,-.1,.05]
            gb_output(gb.parent/dirname,mut,d,True,shift)
            gbrows[(name,rid)]=shift+[sum(shift)]
            ieshift=[x*(ri+1) for x in [.01,-.02,.03,-.04,.05,-.06]]
            ierows[(name,rid)]=ieshift
            for mutant,prefix in [(False,"cpx"),(True,mut)]:
                directory=ie.parent/dirname;directory.mkdir(parents=True,exist_ok=True)
                first,last=(1,6000) if mutant else source_frames
                text=(f"# Interaction Entropy: {prefix}.top\n# Receptor residue: {rid}  Ligand: 23-23\n"
                      f"# intdiel={d}  T=298.15K  kT={0.001987204*298.15:.6f} kcal/mol\n"
                      f"# Frames: {first}-{last} offset=1 total=6000\n# IE windows: 10 × 600 frames, non-overlapping\n#\n"
                      "#Win "+" ".join(IE_COLS)+"\n")
                values=[[1.+.1*j+.01*w+(ieshift[j] if mutant else 0.) for j in range(6)] for w in range(10)]
                text+="".join(str(i)+" "+" ".join(f"{x:.6f}" for x in vals)+"\n" for i,vals in enumerate(values,1))
                text+="Avg "+" ".join(f"{sum(v[j] for v in values)/10:.6f}" for j in range(6))+"\n"
                (directory/f"{prefix}_IE_int={d}.dat").write_text(text)
        for path,cols,rows in [(gb/"AlaScan_GB.dat",GB_COLS,gbrows),(ie/"AlaScan_IE.dat",["d"+x for x in IE_COLS],ierows)]:
            text="Mut-Wid "+" ".join(cols)+"\n"
            text+="".join(f"{rid}{name} "+" ".join(f"{x:.4f}" for x in vals)+"\n" for (name,rid),vals in rows.items())
            text+="TOTAL "+" ".join(f"{sum(v[j] for v in rows.values()):.4f}" for j in range(len(cols)))+"\n"
            path.write_text(text)
        return gb,ie,root/"expected_near.dat",dielsha
    def modify(path,fn):path.write_text(fn(path.read_text()))
    with tempfile.TemporaryDirectory(prefix="asgbie_validator_selftest_") as td:
        for bounds in [(4001,10000),(1,6000)]:
            root=Path(td)/f"good_{bounds[0]}"
            args=fixture(root,bounds)
            report=Validator().run(*args,source_frames=bounds)
            results.append({"name":f"complete_case_{bounds[0]}_{bounds[1]}_including_small_negative_values",
                            "pass":report["status"]=="PASS","observed_status":report["status"],"errors":report["errors"]})
        corruptions={
            "missing_GB_residue":("ASGB/prepare/AlaScan_GB.dat",lambda s:"\n".join(x for x in s.splitlines() if not x.startswith("20LEU"))+"\n"),
            "missing_IE_residue":("ASIE/prepare/AlaScan_IE.dat",lambda s:"\n".join(x for x in s.splitlines() if not x.startswith("20LEU"))+"\n"),
            "ERROR_with_total":("ASGB/prepare/AlaScan_GB.dat",lambda s:re.sub(r"20LEU[^\n]+","20LEU ERROR: missing result",s)),
            "nan_IE_window":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("1.000000","nan",1)),
            "inf_nonprimary_IE_Int":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("1.000000","inf",1)),
            "nan_GB_gas":("ASGB/Wildtype/cpx_MMGBSA_intdiel=1.0.dat",lambda s:re.sub(r"(G gas )\S+",r"\g<1>nan",s,count=1)),
            "inf_GB_CSV":("ASGB/Wildtype/cpx_MMGBSA_intdiel=1.0.csv",lambda s:s.replace("-100.0000000000","inf",1)),
            "missing_TOTAL":("ASGB/prepare/AlaScan_GB.dat",lambda s:"\n".join(x for x in s.splitlines() if not x.startswith("TOTAL"))+"\n"),
            "forged_TOTAL":("ASIE/prepare/AlaScan_IE.dat",lambda s:re.sub(r"TOTAL \S+","TOTAL 999.0",s)),
            "duplicate_summary_residue":("ASGB/prepare/AlaScan_GB.dat",lambda s:s.replace("TOTAL",s.splitlines()[1]+"\nTOTAL")),
            "wrong_IE_frame_count":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("total=6000","total=3000")),
            "wrong_IE_window_count":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("10 × 600","1 × 6000")),
            "missing_IE_window":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:re.sub(r"(?m)^5 [^\n]*\n","",s)),
            "wrong_IE_residue":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("residue: 20","residue: 22")),
            "wrong_IE_dielectric":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:s.replace("intdiel=1.0","intdiel=3.0")),
            "wrong_IE_avg":("ASIE/cpx_20LEU/cpx_IE_int=1.0.dat",lambda s:re.sub(r"Avg \S+","Avg 0.123456",s)),
            "wrong_WT_ALA_pair":("ASIE/prepare/AlaScan_IE.dat",lambda s:s.replace("20LEU 0.0100","20LEU 0.0200").replace("TOTAL 0.0300","TOTAL 0.0400")),
            "wrong_GB_mask":("ASGB/Wildtype/cpx_MMGBSA_intdiel=1.0.dat",lambda s:s.replace('Ligand mask: ":23"','Ligand mask: ":999"')),
            "missing_GB_frame":("ASGB/Wildtype/cpx_MMGBSA_intdiel=1.0.csv",lambda s:re.sub(r"(?m)^99,[^\n]*\n","",s,count=1)),
            "GB_different_residue_scope":("ASGB/prepare/config_gb.ini",lambda s:s.replace("lig_res_start=23","lig_res_start=24")),
            "wrong_temperature":("ASIE/prepare/config_ie.ini",lambda s:s.replace("temperature=298.15","temperature=300.0")),
            "wrong_expected_near":("expected_near.dat",lambda s:s+"ASN24\n"),
            "wrong_dielectric_table":("ASIE/prepare/ResidueDielectric.dat",lambda s:s.replace("GLU 10.0","GLU 3.0")),
        }
        for index,(name,(rel,fn)) in enumerate(corruptions.items()):
            root=Path(td)/f"bad_{index}"
            args=fixture(root)
            original=(root/rel).read_text();new=fn(original)
            require(new != original,f"self-test mutation did not alter fixture: {name}")
            (root/rel).write_text(new)
            report=Validator().run(*args)
            results.append({"name":name,"pass":report["status"]=="FAIL" and bool(report["errors"]),
                            "observed_status":report["status"],"first_error":report["errors"][:1]})
        root=Path(td)/"missing_IE_ALA";args=fixture(root)
        (root/"ASIE/cpx_20LEU/cpx_LEU20ALA_IE_int=1.0.dat").unlink()
        report=Validator().run(*args)
        results.append({"name":"missing_IE_ALA_file","pass":report["status"]=="FAIL","first_error":report["errors"][:1]})
    failures=[x for x in results if not x["pass"]]
    return {"validator_version":VERSION,"status":"FAIL" if failures else "PASS","self_test":True,
            "tests":results,"counts":{"passed":len(results)-len(failures),"total":len(results)},
            "errors":[{"check":r["name"],"message":"self-test unexpected acceptance result"} for r in failures]}

if __name__=="__main__":
    sys.exit(main())
