# Frozen ASGBIE implementation and configuration

These seven files provide the calculation implementation inspected for the manuscript's ASGBIE Methods. They are byte-for-byte copies of the archived September 21, 2026 deployment (`bulk11q9_activeguard_recovery_queue_all_20260921_01`, batch `wave_003_cpu_short`). Content SHA256 identifiers, rather than an invented software release number, define this version. Every file was matched to its original deployment and the audited evidence copy before packaging. No code changes or new calculations were made.

| File | Role |
| --- | --- |
| `engine/asgb.py` | Alanine-scan topology/trajectory construction and GB endpoint energy component |
| `engine/asie.py` | Interaction-energy fluctuation calculation, 3σ filtering and IE window calculations |
| `scripts/run_case.py` | Case input/SHA/time/atom-order guards, production-window extraction and execution wrapper |
| `scripts/validate_asgbie_outputs.py` | Independent scientific output validation |
| `config/config_gb.ini` | GB frame sampling, solvent/dielectric/force-field settings |
| `config/config_ie.ini` | IE frame sampling, temperature and window settings |
| `config/ResidueDielectric.dat` | Original residue-class internal dielectric assignments |

## Scope and dependencies

This directory is implementation evidence, not a self-contained simulator or a portable one-command deployment. The frozen engines require Amber/AmberTools 24 executables (including `tleap`, `cpptraj`, `sander` and `MMPBSA.py` as applicable), the corresponding force-field resources, and Python packages used by the code (including NumPy, SciPy, ParmEd and pytraj). Amber binaries, force-field distributions, model weights and third-party environments are not included.

The historical wrapper additionally expects the original deployment layout, a case manifest, a deployment SHA map, matching molecular input files and trajectories, and Slurm resource/environment guards. Its historical `pilot` wording is retained because the source bytes are unchanged; it does not describe new pilot calculations in this package. Site-specific paths and example commands in source comments are historical context. The manuscript protocol and accepted source-data records specify the scientific analysis; executing a script against unmatched or incomplete inputs is not a reproduction of that analysis.

## Scientific interpretation

The frozen production analysis extracts 6000 frames from (20, 50] ns, samples 100 frames for the GB endpoint term, and uses all 6000 for IE in ten 3 ns windows at 298.15 K. `dIE_3S` denotes the 3σ fluctuation filter, independently of the 3 ns window length. `dH` and `dIE_3S` are alanine-minus-WT contributions. Pair and Triad sums retain all signed member contributions. The separate 16-residue hotspot score restricts the sum to single-residue contributions greater than 1 kcal/mol. These are model-based residue scores and should not be relabelled as exact experimental mutation free energies.

`IMPLEMENTATION_SHA256.csv` maps each delivered file to its version, source and SHA. `IMPLEMENTATION_PROVENANCE.json` records the copy verification. The original scientific inputs and large trajectories are documented separately in the project publication-data index; they are not silently replaced by these code files.
