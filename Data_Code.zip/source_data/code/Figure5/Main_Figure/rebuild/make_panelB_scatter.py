#!/usr/bin/env python3
"""Figure 5 panel B, right facet replaced with an ECFP4 PCA chemical-space map.

PCA of 2048-bit Morgan (r=2) fingerprints over all 47 MD candidates; the 15 the
campaign bought are highlighted (teal = report-positive, grey = report-negative)
against the 32 it did not (pale).  Left facet, shared feature labels, the
filled/open note and the bottom Pair/Triad/Boltz-2 key are untouched.
"""
from __future__ import annotations
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import numpy as np, pandas as pd
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox
from matplotlib.lines import Line2D

import sys
sys.path.insert(0, str(Path.home()/"mnt/AAK1/draft/Figure/5/rebuild"))
import figure2_style as st
from figure2_style import EDGE, FS_TICK, FS_NOTE, FS_ANNOT, LW_EDGE

HERE = Path.home()/"fig5v2"
OUT  = HERE/"panelB"; OUT.mkdir(exist_ok=True)

TEAL="#137A6E"; GREY="#9AA3B0"; POOL="#D9DCE5"
EV1, EV2 = 7.4, 7.1
SLOT = (180.0, 243.0, 253.0, 423.0)
AX   = (190.0, 271.0, 250.0, 339.0)          # square-ish scatter box, page pts
TITLE_XC = (186.8+251.7)/2


def build():
    st.apply_style()
    d = pd.read_csv(HERE/"panelB_coords.csv")
    pool = d[~d.purchased]; pneg = d[d.purchased & ~d.positive]; ppos = d[d.purchased & d.positive]

    x0,y0,x1,y1 = SLOT; w,h = x1-x0, y1-y0
    def fx(X): return (X-x0)/w
    def fy(Y): return (y1-Y)/h
    fig = plt.figure(figsize=(w/72, h/72))
    ax = fig.add_axes([fx(AX[0]), fy(AX[3]), (AX[2]-AX[0])/w, (AX[3]-AX[1])/h])

    ax.set_xlim(-7.2, 2.2); ax.set_ylim(-4.95, 3.75)
    ax.scatter(pool.PC1, pool.PC2, s=8,  c=POOL, linewidths=0, zorder=2)
    ax.scatter(pneg.PC1, pneg.PC2, s=18, c=GREY, edgecolors=EDGE, linewidths=LW_EDGE, zorder=3)
    ax.scatter(ppos.PC1, ppos.PC2, s=21, c=TEAL, edgecolors=EDGE, linewidths=LW_EDGE, zorder=4)

    for s in ("top","right"): ax.spines[s].set_visible(False)
    ax.spines["left"].set_bounds(-4.28, 3.33)
    ax.spines["bottom"].set_bounds(-7.0, 1.8)
    ax.set_xticks([]); ax.set_yticks([])

    cx = (AX[0]+AX[2])/2
    fig.text(fx(cx), fy(347.0), f"PC1 ({EV1:.1f}%)", ha="center", va="baseline", fontsize=FS_TICK)
    fig.text(fx(186.0), fy((AX[1]+AX[3])/2), f"PC2 ({EV2:.1f}%)",
             ha="center", va="center", rotation=90, fontsize=FS_TICK)

    fig.text(fx(TITLE_XC), fy(251.5), "ECFP4 chemical", ha="center", va="baseline",
             fontsize=FS_ANNOT, fontweight="bold")
    fig.text(fx(TITLE_XC), fy(259.2), "space of the 47", ha="center", va="baseline",
             fontsize=FS_ANNOT)

    handles = [
        Line2D([0],[0], marker="o", ls="none", markerfacecolor=TEAL,
               markeredgecolor=EDGE, markeredgewidth=LW_EDGE, markersize=4.6, label="active (9)"),
        Line2D([0],[0], marker="o", ls="none", markerfacecolor=GREY,
               markeredgecolor=EDGE, markeredgewidth=LW_EDGE, markersize=4.3, label="inactive (6)"),
        Line2D([0],[0], marker="o", ls="none", markerfacecolor=POOL,
               markeredgecolor="none", markersize=3.2, label="pool (32)"),
    ]
    leg = ax.legend(handles=handles, loc="upper left", bbox_to_anchor=(-0.01, 1.03),
                    fontsize=FS_NOTE, handletextpad=0.35, labelspacing=0.3,
                    borderpad=0.0, borderaxespad=0.1)
    leg.set_zorder(6)

    box = Bbox.from_bounds(0,0,w/72,h/72)
    for ext in ("pdf","png"):
        fig.savefig(OUT/f"Figure5_panelB.{ext}", dpi=st.DPI, bbox_inches=box, transparent=True)
    plt.close(fig)
    print("pool",len(pool),"pneg",len(pneg),"ppos",len(ppos))

if __name__ == "__main__":
    build()
