#!/usr/bin/env python3
"""Figure 5 panel C, 2026-09-30 (v3): the heat map, and two bar charts.

The residue-panel strength plot is removed at the author's request.  In its
place, two readouts of the same question on the 15 compounds the prospective
campaign bought and assayed -- would ranking them by the residue panel have
put the report-defined positives first?

  left   the matched budget: each score takes its own top 9, 9 being the number
         of positives, and the bar is the hit rate of those nine;
  right  no budget at all: the AUC of each score over all 15.

These are the two readouts Figures 3 and 4 already pair (a fixed-depth hit rate
and a threshold-free AUC), so the panel speaks the paper's own vocabulary.  The
residue scores were recomputed after the assay, so this is a re-ranking of
prospectively assayed compounds, not a prospective test of the panel, and the
caption says so.

The heat map keeps the frozen page's own objects; only the rectangle right of
it is cleared and redrawn.  Filled bars are the residue panels in their own
colours; the Boltz-2 reference is an open blue bar, the page's existing
convention for "Boltz-2 ranking, same n".
"""
from __future__ import annotations

from itertools import combinations
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox
from scipy.stats import rankdata

import figure2_style as st
from figure2_style import (ANNOT_GREY, EDGE, FS_ANNOT, FS_NOTE, GRID_GREY,
                           LW_EDGE, LW_GRID, LW_REF, REF_GREY)

HERE = Path(__file__).resolve().parent
F5 = Path.home() / "mnt/AAK1/draft/Figure/5"
PSD = F5 / "panel_source_data"
OUT = HERE / "panelC_v3"
OUT.mkdir(exist_ok=True)

SLOT = (400.00, 242.00, 629.83, 425.00)   # cleared and restamped
BAND = (262.00, 397.00)                   # both charts' axes top and bottom;
                                          # 242-262 holds each chart's two-line header
LEFT_X = (433.00, 509.00)                 # top-9 hit rate
RIGHT_X = (551.00, 623.90)                # AUC over all 15

METHODS = ["Pair", "Triad", "Boltz-2"]
# the two residue panels side by side, the Boltz-2 reference set a little
# apart: it reads as "ours against the reference", and it leaves the gap
# arrow and its label room between the groups
XPOS = {"Pair": 0.0, "Triad": 1.0, "Boltz-2": 2.30}
INK = {"Pair": "#956CB4", "Triad": "#D65F5F", "Boltz-2": "#4878D0"}


def auc(score, lab):
    r = rankdata(score)
    na = int(lab.sum())
    return (r[lab].sum() - na * (na + 1) / 2) / (na * (len(score) - na))


def load():
    d = pd.read_csv(PSD / "Figure5_panelC_plotted_values.csv")
    pos = d["report_screen_positive"].to_numpy(bool)
    n, K = len(d), int(pos.sum())
    score = {"Pair": d["boltz_pair"].to_numpy(float),
             "Triad": d["boltz_triad"].to_numpy(float),
             "Boltz-2": -d["historical_boltz_pred_ic50_nM"].to_numpy(float)}
    top = {m: np.argsort(-s, kind="mergesort")[:K] for m, s in score.items()}
    hits = {m: int(pos[t].sum()) for m, t in top.items()}
    aucs = {m: auc(s, pos) for m, s in score.items()}

    # exact conditional randomization over every placement of the K positive
    # labels among the n compounds, for both readouts at once
    ge_hit = {m: 0 for m in ("Pair", "Triad")}
    ge_auc = {m: 0 for m in ("Pair", "Triad")}
    ge_hit_max = ge_auc_max = 0
    obs_h = {m: hits[m] - hits["Boltz-2"] for m in ge_hit}
    obs_a = {m: aucs[m] - aucs["Boltz-2"] for m in ge_auc}
    for a in combinations(range(n), K):
        lab = np.zeros(n, bool); lab[list(a)] = True
        hb = int(lab[top["Boltz-2"]].sum()); ab = auc(score["Boltz-2"], lab)
        dh = {m: int(lab[top[m]].sum()) - hb for m in ge_hit}
        da = {m: auc(score[m], lab) - ab for m in ge_auc}
        for m in ge_hit:
            ge_hit[m] += dh[m] >= obs_h[m]
            ge_auc[m] += da[m] >= obs_a[m] - 1e-12
        ge_hit_max += max(dh.values()) >= max(obs_h.values())
        ge_auc_max += max(da.values()) >= max(obs_a.values()) - 1e-12
    total = len(list(combinations(range(n), K)))
    ids = d["experiment_id"].to_numpy()
    return {"n": n, "K": K, "hits": hits, "auc": aucs, "total": total,
            "p_hit": {m: v / total for m, v in ge_hit.items()},
            "p_auc": {m: v / total for m, v in ge_auc.items()},
            "p_hit_max": ge_hit_max / total, "p_auc_max": ge_auc_max / total,
            "same_top": set(top["Pair"]) == set(top["Triad"]),
            "top_ids": {m: sorted(int(i) for i in ids[t]) for m, t in top.items()},
            "chance_hit": K / n, "missed": sorted(set(ids[pos]) - set(ids[top["Pair"]])),
            "kept_negative": sorted(set(ids[top["Pair"]]) - set(ids[pos]))}


def _bars(ax, values, fmt):
    for m in METHODS:
        i = XPOS[m]
        open_bar = m == "Boltz-2"
        ax.bar(i, values[m], 0.68,
               color="white" if open_bar else INK[m],
               edgecolor=INK[m] if open_bar else EDGE,
               linewidth=1.1 if open_bar else LW_EDGE, zorder=3)
        top = ax.get_ylim()[1]
        if open_bar:
            ax.text(i, values[m] - 0.025 * top, fmt(m), ha="center", va="top",
                    fontsize=FS_ANNOT, color=INK[m], zorder=5)
        else:
            ax.text(i, values[m] + 0.018 * top, fmt(m), ha="center",
                    va="bottom", fontsize=FS_ANNOT, color=INK[m], zorder=5)
    ax.set_xlim(-0.62, 2.92)
    ax.set_xticks([XPOS[m] for m in METHODS])
    ax.set_xticklabels(METHODS)
    for t, m in zip(ax.get_xticklabels(), METHODS):
        t.set_color(INK[m])
    ax.tick_params(axis="x", length=0, pad=3)
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)


def _gap(ax, lo, hi, label):
    """The residue panels' level carried across to the Boltz-2 bar, and the gap."""
    xb = XPOS["Boltz-2"]
    ax.plot([0.34, xb], [hi, hi], color=ANNOT_GREY, lw=0.6, ls=":", zorder=4)
    ax.annotate("", xy=(xb, hi), xytext=(xb, lo),
                arrowprops=dict(arrowstyle="<->", color=ANNOT_GREY, lw=0.9,
                                shrinkA=0, shrinkB=0), zorder=6)
    ax.text(xb - 0.08, (lo + hi) / 2, label, ha="right", va="center",
            fontsize=FS_ANNOT, color=ANNOT_GREY, fontweight="bold", zorder=6)


def chart_top9(ax, D):
    """Hit rate among each score's own top 9 of the 15 assayed."""
    K = D["K"]
    rate = {m: D["hits"][m] / K * 100 for m in METHODS}
    ax.set_ylim(0, 112)
    ax.axhline(D["chance_hit"] * 100, color=REF_GREY, lw=LW_REF, ls="--", zorder=2)
    _bars(ax, rate, lambda m: f"{D['hits'][m]}/{K}")
    gap = D["hits"]["Pair"] - D["hits"]["Boltz-2"]
    _gap(ax, rate["Boltz-2"], rate["Pair"], f"+{gap}")
    ax.set_ylim(0, 100)
    ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_ylabel(f"Hit rate in top {K}  (%)")


def chart_auc(ax, D):
    """Discrimination over all 15, with no budget and no threshold."""
    ax.set_ylim(0, 1.12)
    ax.axhline(0.5, color=REF_GREY, lw=LW_REF, ls="--", zorder=2)
    _bars(ax, D["auc"], lambda m: f"{D['auc'][m]:.2f}")
    _gap(ax, D["auc"]["Boltz-2"], D["auc"]["Pair"],
         f"+{D['auc']['Pair'] - D['auc']['Boltz-2']:.2f}")
    ax.set_ylim(0, 1.0)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0", "", "0.5", "", "1.0"])
    ax.set_ylabel(f"ROC AUC, all {D['n']}")


def build():
    st.apply_style()
    D = load()
    x0, y0, x1, y1 = SLOT
    w, h = x1 - x0, y1 - y0
    fig_w, fig_h = w / 72, h / 72
    fig = plt.figure(figsize=(fig_w, fig_h))

    def place(xa, xb):
        return ((xa - x0) / w, (y1 - BAND[1]) / h, (xb - xa) / w,
                (BAND[1] - BAND[0]) / h)

    chart_top9(fig.add_axes(place(*LEFT_X)), D)
    chart_auc(fig.add_axes(place(*RIGHT_X)), D)

    def header(xa, lines):
        for i, (text, bold) in enumerate(lines):
            fig.text((xa - x0) / w, (y1 - (250.0 + i * 7.6)) / h, text,
                     ha="left", va="baseline", fontsize=FS_NOTE,
                     color="black" if bold else ANNOT_GREY,
                     fontweight="bold" if bold else "normal")
    header(LEFT_X[0] - 1.0, [(f"Same budget: top {D['K']} of {D['n']}", True),
                             ("Pair and Triad pick the same 9" if D["same_top"]
                              else "", False)])
    header(RIGHT_X[0] - 1.0, [(f"All {D['n']}, no threshold", True),
                              ("dashed: random ranking", False)])

    box = Bbox.from_bounds(0, 0, fig_w, fig_h)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"Figure5_panelC_right.{ext}", dpi=st.DPI, bbox_inches=box)
    plt.close(fig)

    rows = []
    for m in METHODS:
        rows.append({
            "method": m, "n_assayed": D["n"], "report_positive": D["K"],
            "budget_K": D["K"], "positives_in_topK": D["hits"][m],
            "negatives_in_topK": D["K"] - D["hits"][m],
            "hit_rate_topK": D["hits"][m] / D["K"],
            "chance_hit_rate": D["chance_hit"],
            "auc_all": D["auc"][m], "chance_auc": 0.5,
            "topK_experiment_ids": ";".join(map(str, D["top_ids"][m])),
            "exact_p_hits_vs_Boltz2": D["p_hit"].get(m, np.nan),
            "exact_p_auc_vs_Boltz2": D["p_auc"].get(m, np.nan)})
    t = pd.DataFrame(rows)
    t.to_csv(OUT / "Figure5_panelC_prospective_rerank_values.csv", index=False)
    print(t.drop(columns=["topK_experiment_ids"]).round(4).to_string(index=False))
    print(f"\nexact conditional randomization over {D['total']} label placements")
    print(f"  top-9 hits, max over Pair/Triad: P = {D['p_hit_max']:.4f}")
    print(f"  AUC,        max over Pair/Triad: P = {D['p_auc_max']:.4f}")
    print(f"  Pair/Triad pick the same nine: {D['same_top']}; "
          f"missed positive {D['missed']}, kept negative {D['kept_negative']}")


if __name__ == "__main__":
    build()
