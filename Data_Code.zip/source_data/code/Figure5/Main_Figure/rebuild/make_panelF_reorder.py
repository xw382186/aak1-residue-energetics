#!/usr/bin/env python3
"""Figure 5 panel F, re-ordered by 50 uM inhibition (most active at top).

Same lollipop, same x-axis (nearest kinase-reference ECFP4 Tanimoto), same
teal/grey = report-positive/negative, same #14 ring and its note.  Only the row
order changes: rows now run from the most active compound at the top to the
least active at the bottom, so the eye reads activity down the column while the
dot's x still reads chemical similarity.  The point the ordering makes is that
the single most-similar compound (#14, the exact kinase-reference match, far
right) sits in the middle of the activity ranking, not at its head.
"""
from __future__ import annotations
from pathlib import Path
import sys
import matplotlib
matplotlib.use("Agg")
import numpy as np, pandas as pd
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox

sys.path.insert(0, str(Path.home()/"mnt/AAK1/draft/Figure/5/rebuild"))
import figure2_style as st
from figure2_style import (EDGE, FS_LABEL, FS_TICK, FS_ANNOT, FS_NOTE,
                           GRID_GREY, LW_EDGE, LW_GRID, TICK_LEN)

F5   = Path.home()/"mnt/AAK1/draft/Figure/5"
PSD  = F5/"panel_source_data"
HERE = Path.home()/"fig5v2"
OUT  = HERE/"panelF"; OUT.mkdir(exist_ok=True)

TEAL = (0.07450980693, 0.47843137383, 0.43137255311)   # #137A6E, report-positive
GREY_DOT = (0.8509804, 0.8627451, 0.8980392)            # report-negative dot fill
TEAL_LAB = "#137A6E"
GREY_LAB = "#9AA3B0"

# ---- page geometry of the frozen panel F (top-left origin, PDF points) -------
SLOT = (440.0, 462.0, 629.83, 621.0)                 # cleared + restamped
PLOT = (461.4, 466.1, 623.9, 587.2)                  # white rect = axes box
ROW_Y = np.array([471.1 + i*7.8143 for i in range(15)])   # 15 row centres
XMAP0, XMAP_SLOPE = 0.4, 262.0                       # 0.4 -> x479.7, +262/Tanimoto
XLIM = (0.3302, 0.9499)                              # so 0.4->479.7, 0.9->610.8
XTICKS = [0.4,0.5,0.6,0.7,0.8,0.9]


def load():
    f = pd.read_csv(PSD/"Figure5_panelF_plotted_values.csv")
    b = pd.read_csv(HERE/"panelB_coords.csv")
    inh = {int(r.experiment_id): r.inhibition_50uM_pct
           for _,r in b.dropna(subset=["experiment_id"]).iterrows()}
    f["inh"] = f["experiment_id"].map(inh)
    f = f.sort_values("inh", ascending=False).reset_index(drop=True)   # most active top
    return f


def build():
    st.apply_style()
    f = load()
    x0,y0,x1,y1 = SLOT; w,h = x1-x0, y1-y0
    def fx(X): return (X-x0)/w
    def fy(Y): return (y1-Y)/h
    fig = plt.figure(figsize=(w/72, h/72))
    ax = fig.add_axes([fx(PLOT[0]), fy(PLOT[3]),
                       (PLOT[2]-PLOT[0])/w, (PLOT[3]-PLOT[1])/h])
    ax.set_xlim(*XLIM); ax.set_ylim(587.2, 466.1)        # page-y, inverted
    # vertical gridlines at each tick
    for xt in XTICKS:
        ax.plot([xt,xt],[587.2,466.1], color=GRID_GREY, lw=LW_GRID, zorder=0)
    # rows: stem + dot
    for i,(_,r) in enumerate(f.iterrows()):
        py = ROW_Y[i]; T = r.nearest_nonself_tanimoto_ECFP4_2048
        pos = bool(r.report_screen_positive)
        ax.plot([XLIM[0], T],[py,py], color="#CFCFCF", lw=0.8, zorder=1)
        ax.plot([T],[py], marker="o", markersize=4.7,
                markerfacecolor=TEAL if pos else GREY_DOT,
                markeredgecolor=EDGE, markeredgewidth=LW_EDGE, zorder=4)
        # #N row label, coloured like its dot
        fig.text(fx(459.4), fy(py), f"#{int(r.experiment_id)}",
                 ha="right", va="center", fontsize=FS_NOTE,
                 color=TEAL_LAB if pos else GREY_LAB)
        if int(r.experiment_id) == 14:
            ax.plot([T],[py], marker="o", markersize=9.8, markerfacecolor="none",
                    markeredgecolor=EDGE, markeredgewidth=0.9, zorder=5)
            ax.annotate("#14  exact canonical-SMILES match",
                        xy=(T, py), xytext=(T-0.012, py), ha="right", va="center",
                        fontsize=FS_ANNOT, color="black", zorder=6,
                        bbox=dict(boxstyle="square,pad=0.15", fc="white", ec="none"))
    # x-axis
    ax.set_xticks(XTICKS); ax.set_xticklabels([f"{t:.1f}" for t in XTICKS])
    ax.tick_params(axis="x", length=TICK_LEN, labelsize=FS_TICK)
    ax.spines["left"].set_visible(False)
    ax.set_yticks([])
    for s in ("top","right"): ax.spines[s].set_visible(False)
    # 2-line x label (redrawn identically)
    cx = (PLOT[0]+PLOT[2])/2
    fig.text(fx(cx), fy(609.5), "Nearest kinase-reference neighbour",
             ha="center", va="baseline", fontsize=FS_LABEL)
    fig.text(fx(cx), fy(618.4), "ECFP4 Tanimoto",
             ha="center", va="baseline", fontsize=FS_LABEL)
    # rotated y label: order cue (reads bottom->top, low at bottom / high at top)
    fig.text(fx(444.8), fy((471.1+580.5)/2), "50 µM inhibition  (low → high)",
             ha="center", va="center", rotation=90, fontsize=FS_NOTE, color="black")

    box = Bbox.from_bounds(0,0,w/72,h/72)
    for ext in ("pdf","png"):
        fig.savefig(OUT/f"Figure5_panelF.{ext}", dpi=st.DPI, bbox_inches=box, transparent=True)
    plt.close(fig)
    print("order (most active -> least):",
          [f"#{int(r.experiment_id)}({r.inh:.0f}%,T{r.nearest_nonself_tanimoto_ECFP4_2048:.2f})"
           for _,r in f.iterrows()])


if __name__ == "__main__":
    build()
