#!/usr/bin/env python3
"""Restyle the Figure 5 supplements onto the frozen series style.

The build script hardcodes absolute roots that no longer exist and creates its
output tree at import time, so its path literals are rewritten before the
module is executed -- otherwise importing it would recreate the deleted
workspace inside the project.  The raw roots are reconstituted from the
published Table_S* files using the script's own export mapping.
"""
from __future__ import annotations

import os
import shutil
import sys
import traceback
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent             # FigureN/Supplementary_Figures/rebuild
FS = HERE.parents[2]                               # release root (FigureandSI)
STYLE_DIR = FS / "Shared/style"                    # figure2_style.py, si_style.py, si_paths.py
sys.path.insert(0, str(STYLE_DIR))
sys.dont_write_bytecode = True                     # no __pycache__ inside the release
import si_paths as P                               # noqa: E402

OUTDIR = Path(os.environ.get("SI_RESTYLE_OUT", P.STAGE_ROOT / "out")) / "Figure5"
TABLES = P.stage_published_tables(5, P.STAGE_ROOT / "Figure5/published")
MAIN5 = P.stage_tree(P.main_rebuild(5), P.STAGE_ROOT / "Figure5/main_rebuild")
STAGE = P.STAGE_ROOT / "Figure5/src"
PKGSTAGE = P.STAGE_ROOT / "Figure5/pkg"
# the two build inputs recovered on 2026-10-07 (byte-identical to the 2026-09-24
# Codex originals): per-source procurement accounting (Suppl. Fig. 16F) and the
# threshold-audit QA whose exact_conditional_randomization block Suppl. Fig. 18F plots
PROCUREMENT = P.si_folder(16) / "source_data" / "47_15_procurement_summary.csv"
THRESHOLD_QA = P.raw_data(18) / "threshold_audit_QA.json"

# published table -> its path under the raw roots, from the script's export map
MAP = {
    "Table_S1_stage_counts.csv": ("F5", "01_MAIN/00_traceable_stage_counts.csv"),
    "Table_S2_all45_assay_wells.csv": ("F5", "01_MAIN/A_15x3_inhibition_from_primary_plate.csv"),
    "Table_S3_all15_scores_and_labels.csv": ("F5", "01_MAIN/D_15_assay_current_Boltz_pair_triad.csv"),
    "Table_S4_full_threshold_scan.csv": ("THR", "preset_half_kcal_thresholds.csv"),
    "Table_S5_continuous_score_diagnostics.csv": ("THR", "continuous_score_diagnostics.csv"),
    "Table_S6_top200_to_47_feature_audit.csv": ("RET47", "source_stratified_feature_permutation.csv"),
    "Table_S7_top200_to_47_diversity_null.csv": ("RET47", "diversity_vs_source_stratified_random.csv"),
    "Table_S8_47_to_15_feature_audit.csv": ("RET15", "47_15_within_source_permutation_pq.csv"),
    "Table_S9_47_to_15_diversity_null.csv": ("RET15", "47_15_diversity_against_source_quota_random.csv"),
    "Table_S10_all15_kinase_reference_neighbors.csv": ("F5", "01_MAIN/F_15_kinase_reference_novelty.csv"),
    "Table_S11_selection_assay_identity.csv": ("F5", "02_SI/current_energy/15_selection_vs_assay_smiles_identity.csv"),
    "Table_S12_assay_transcription_discrepancies.csv": ("DISCREP", ""),
}
ROOTS = {
    "F5": "outputs/AAK1_FIGURE5_SOURCE_PACKAGE_20260924/Figure5_raw_data_20260924",
    "RET47": "outputs/AAK1_FIGURE5_RETROSPECTIVE_TOP200_47_20260924",
    "RET15": "outputs/AAK1_FIGURE5_RETROSPECTIVE_47_15_20260924",
    "THR": "outputs/AAK1_FIGURE5_TRIAD_THRESHOLD_AUDIT_20260924",
}


def stage() -> None:
    STAGE.mkdir(parents=True, exist_ok=True)
    n = 0
    for pub, (root, rel) in MAP.items():
        src = TABLES / pub
        if not src.exists():
            print(f"    [miss] {pub}")
            continue
        dst = (STAGE / "discrep.csv") if root == "DISCREP" else (STAGE / ROOTS[root] / rel)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists():
            shutil.copyfile(src, dst)
        n += 1
    # any remaining published table, mirrored flat so stray reads still resolve
    for p in TABLES.glob("*.csv"):
        d = STAGE / p.name
        if not d.exists():
            shutil.copyfile(p, d)
    # the two experimental originals supplement 1 shows are kept with it as raw data
    EXP = P.raw_data(17) / "experimental_originals"
    orig = STAGE / ROOTS["F5"] / "02_SI/experimental_originals"
    orig.mkdir(parents=True, exist_ok=True)
    for nm in ("\u86cb\u767d\u8003\u67d3\u56fe2-\u542bMarker\u4fe1\u606f.png", "WB-\u542bMarker\u4fe1\u606f.tif"):
        s = EXP / nm
        d = orig / nm
        if s.exists() and not d.exists():
            shutil.copyfile(s, d)
            print(f"    staged image {nm}")
    print(f"    staged {n} mapped tables -> {STAGE}")


def load_patched():
    src = (HERE / "build_figure5_si.py").read_text()
    src = src.replace('ROOT = Path("/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2")',
                      f'ROOT = Path("{STAGE}")')
    src = src.replace('PKG = Path("/Users/wxmacbookpro/Desktop/project/AAK1/draft/Figure/5/SI/current_20260927")',
                      f'PKG = Path("{PKGSTAGE}")')
    src = src.replace('DISCREP = Path("/Users/wxmacbookpro/Desktop/project/AAK1/Analysis/Figure5_prospective_sensitivity_review_20260909_R1/tables/assay_transcription_discrepancies.csv")',
                      f'DISCREP = Path("{STAGE}/discrep.csv")')

    # Three module-level inputs were never published.  Two have exact published
    # equivalents and are substituted; the third (procurement accounting) has
    # none, so it is left empty and the figure that needs it is not emitted.
    MAIN5SRC = P.main_source_data(5)
    SUP5 = TABLES
    src = src.replace(
        'candidate47 = pd.read_csv(F5 / "01_MAIN/C_47_chemical_space_properties.csv")',
        'candidate47 = __import__("pandas").read_csv(r"%s/Figure5_panelB_chemspace47.csv").rename('
        'columns={"group":"source_group","positive":"report_screen_positive_posthoc",'
        '"PC1":"pc1_on_47_ecfp4","PC2":"pc2_on_47_ecfp4"})' % MAIN5SRC)
    # The two inputs never published: when the author's original file is placed
    # in the figure's source_data/, it is used and that figure is drawn.
    if PROCUREMENT.exists():
        src = src.replace('procure = pd.read_csv(RET15 / "47_15_procurement_summary.csv")',
                          f'procure = pd.read_csv(r"{PROCUREMENT}")')
    else:
        src = src.replace(
            'procure = pd.read_csv(RET15 / "47_15_procurement_summary.csv")',
            'procure = __import__("pandas").DataFrame(columns=["source_group","in_quote_table_N","selection","N"])')
    if THRESHOLD_QA.exists():
        src = src.replace('qa_thr = json.loads((THR / "QA.json").read_text())',
                          f'qa_thr = json.loads(Path(r"{THRESHOLD_QA}").read_text())')
    else:
        src = src.replace(
            'qa_thr = json.loads((THR / "QA.json").read_text())',
            'qa_thr = {"exact_conditional_randomization": '
            '__import__("pandas").read_csv(r"%s/Table_S14_same_budget_exact_randomization_summary.csv")'
            '.set_index("statistic").to_dict("index")}' % SUP5)
    mod = types.ModuleType("build_fig5_si")
    mod.__file__ = str(HERE / "build_figure5_si.py")
    sys.modules["build_fig5_si"] = mod
    exec(compile(src, mod.__file__, "exec"), mod.__dict__)
    return mod


def main() -> None:
    sys.path.insert(0, str(STYLE_DIR))
    sys.path.insert(0, str(MAIN5))
    import si_style as S
    import matplotlib.figure as mfig

    OUTDIR.mkdir(parents=True, exist_ok=True)
    PKGSTAGE.mkdir(parents=True, exist_ok=True)
    stage()

    mod = load_patched()
    mod.FIG = OUTDIR
    mod.INK = "black"
    mod.GREY = S.ANNOT_GREY
    mod.LIGHT = S.GRID_GREY
    mod.panel = lambda ax, letter: S.panel_letter(ax, letter)
    mod.clean = lambda ax, grid="y": S.clean(ax, grid)

    orig_suptitle = mfig.Figure.suptitle
    mfig.Figure.suptitle = lambda self, *a, **k: None
    done = []

    real_save = mod.save

    def save(fig, stem, *, wspace=0.38, hspace=0.48, left=0.065, pad=0.04):
        # the builder's own save() spaced the grid before writing; keep that step
        fig.subplots_adjust(left=left, right=0.99, bottom=0.09, top=0.95,
                            wspace=wspace, hspace=hspace)
        S.strip_legacy_titles(fig)
        n = S.PUBLIC_NUMBER[stem]
        S.stamp_heading(fig, n)
        S.save_si(fig, OUTDIR, stem)
        done.append(stem)
        print(f"  rendered {S.public_stem(stem)}")

    mod.save = save
    S.apply_si_style()

    # S2 panel F is "procurement accounting by source", whose table was never
    # published and is not recoverable; it is not rebuilt rather than drawn
    # from invented numbers.
    fns = ["fig_s1_assay", "fig_s4_counterexamples"]
    if PROCUREMENT.exists():
        fns.insert(0, "fig_s2_selection")
    if THRESHOLD_QA.exists():
        fns.append("fig_s3_thresholds")
    held = [f for f, ok in (("fig_s2_selection", PROCUREMENT.exists()),
                            ("fig_s3_thresholds", THRESHOLD_QA.exists())) if not ok]
    print("    figure builders:", fns, f"(withheld, input not yet in source_data/: {held})" if held else "")
    for fn in fns:
        try:
            getattr(mod, fn)()
        except Exception as e:
            print(f"  [FAIL] {fn}: {type(e).__name__}: {e}")
            traceback.print_exc(limit=3)

    print(f"\n{len(done)} of 4 Figure 5 supplements restyled -> {OUTDIR}")


if __name__ == "__main__":
    main()
