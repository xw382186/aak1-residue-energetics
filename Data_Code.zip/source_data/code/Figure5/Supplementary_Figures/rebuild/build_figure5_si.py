#!/usr/bin/env python3
"""Build the current, source-backed Figure 5 supplementary package.

This script intentionally keeps assay labels descriptive.  The experiment has one
confirmed sample well per compound/concentration and the nine positives are the
laboratory report's qualitative preliminary calls.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from PIL import Image


ROOT = Path("/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2")
PKG = Path("/Users/wxmacbookpro/Desktop/project/AAK1/draft/Figure/5/SI/current_20260927")
FIG = PKG / "figures"
TAB = PKG / "tables"
ASSET = PKG / "assets"
QA = PKG / "qa"
SCRIPT = PKG / "scripts"
for d in (FIG, TAB, ASSET, QA, SCRIPT):
    d.mkdir(parents=True, exist_ok=True)

F5 = ROOT / "outputs/AAK1_FIGURE5_SOURCE_PACKAGE_20260924/Figure5_raw_data_20260924"
RET47 = ROOT / "outputs/AAK1_FIGURE5_RETROSPECTIVE_TOP200_47_20260924"
RET15 = ROOT / "outputs/AAK1_FIGURE5_RETROSPECTIVE_47_15_20260924"
THR = ROOT / "outputs/AAK1_FIGURE5_TRIAD_THRESHOLD_AUDIT_20260924"
DISCREP = Path("/Users/wxmacbookpro/Desktop/project/AAK1/Analysis/Figure5_prospective_sensitivity_review_20260909_R1/tables/assay_transcription_discrepancies.csv")

INK = "#222222"
GREY = "#9AA0A8"
LIGHT = "#E8EAF0"
BLUE = "#4878D0"
ORANGE = "#EE854A"
GREEN = "#6ACC64"
RED = "#D65F5F"
PURPLE = "#956CB4"
TEAL = "#137A6E"
SOURCE_COLORS = {"TS1": "#4A5568", "TS2": "#7B8799", "EnamineSim": "#AAB2C0", "Kinase_Library": "#D5DAE4"}

mpl.rcParams.update({
    "font.family": "Arial",
    "font.sans-serif": ["Arial"],
    "font.size": 7.2,
    "axes.labelsize": 7.5,
    "axes.titlesize": 8.2,
    "xtick.labelsize": 6.7,
    "ytick.labelsize": 6.7,
    "legend.fontsize": 6.5,
    "axes.linewidth": 0.65,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "savefig.facecolor": "white",
})


def read(rel: str) -> pd.DataFrame:
    return pd.read_csv(ROOT / rel)


assay = pd.read_csv(F5 / "01_MAIN/A_15x3_inhibition_from_primary_plate.csv")
candidate47 = pd.read_csv(F5 / "01_MAIN/C_47_chemical_space_properties.csv")
scores15 = pd.read_csv(F5 / "01_MAIN/D_15_assay_current_Boltz_pair_triad.csv")
nn15 = pd.read_csv(F5 / "01_MAIN/F_15_kinase_reference_novelty.csv")
thresholds = pd.read_csv(THR / "preset_half_kcal_thresholds.csv")
continuous = pd.read_csv(THR / "continuous_score_diagnostics.csv")
top_features = pd.read_csv(RET47 / "source_stratified_feature_permutation.csv")
top_div = pd.read_csv(RET47 / "diversity_vs_source_stratified_random.csv")
buy_features = pd.read_csv(RET15 / "47_15_within_source_permutation_pq.csv")
buy_div = pd.read_csv(RET15 / "47_15_diversity_against_source_quota_random.csv")
procure = pd.read_csv(RET15 / "47_15_procurement_summary.csv")
qa_thr = json.loads((THR / "QA.json").read_text())


def panel(ax, letter: str) -> None:
    ax.text(-0.13, 1.08, letter, transform=ax.transAxes, fontsize=11, fontweight="bold", va="top")


def clean(ax, grid: str = "y") -> None:
    ax.spines[["top", "right"]].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=LIGHT, linewidth=0.55, zorder=0)
    ax.tick_params(width=0.65, length=2.5)


def save(fig: plt.Figure, stem: str, *, wspace: float = 0.38, hspace: float = 0.48,
         left: float = 0.065, pad: float = 0.04) -> None:
    fig.subplots_adjust(left=left, right=0.99, bottom=0.09, top=0.95, wspace=wspace, hspace=hspace)
    for ext in ("pdf", "svg", "png", "tif"):
        kw = {"bbox_inches": "tight", "pad_inches": pad}
        if ext in {"png", "tif"}:
            kw["dpi"] = 600
        if ext == "tif":
            kw["pil_kwargs"] = {"compression": "tiff_lzw"}
        fig.savefig(FIG / f"{stem}.{ext}", **kw)
    plt.close(fig)


def fig_s1_assay() -> None:
    fig = plt.figure(figsize=(8.55, 5.65))
    gs = fig.add_gridspec(2, 2, width_ratios=(0.86, 1.35), height_ratios=(1.0, 1.0))
    axA = fig.add_subplot(gs[0, 0]); axB = fig.add_subplot(gs[1, 0])
    axC = fig.add_subplot(gs[0, 1]); axD = fig.add_subplot(gs[1, 1])

    imgs = [
        F5 / "02_SI/experimental_originals/蛋白考染图2-含Marker信息.png",
        F5 / "02_SI/experimental_originals/WB-含Marker信息.tif",
    ]
    for ax, p, title, letter in zip((axA, axB), imgs, ("Coomassie-stained protein", "Western blot"), ("A", "B")):
        im = Image.open(p)
        ax.imshow(im, cmap="gray" if p.suffix.lower() == ".tif" else None)
        ax.set_title(title, loc="left", fontweight="bold")
        ax.axis("off"); panel(ax, letter)

    concs = [1, 10, 50]
    jitter = {1: -0.06, 10: 0, 50: 0.06}
    for c, color in zip(concs, (BLUE, ORANGE, RED)):
        d = assay[assay.concentration_uM == c]
        x = np.where(d.report_screen_positive, 1, 0) + jitter[c]
        axC.scatter(x, d.inhibition_pct, s=21, c=color, edgecolor="white", linewidth=0.45, label=f"{c} µM", zorder=3)
    axC.axhline(0, color=GREY, lw=0.7)
    axC.set_xticks([0, 1], ["Report negative\n(n=6)", "Report preliminary\npositive (n=9)"])
    axC.set_ylabel("Observed inhibition (%)")
    axC.set_title("All 45 sample wells; one well per condition", loc="left", fontweight="bold")
    axC.legend(frameon=False, ncol=3, loc="upper left")
    clean(axC); panel(axC, "C")

    mat = assay.pivot(index="experiment_id", columns="concentration_uM", values="inhibition_pct").loc[range(1, 16), concs]
    cmap = LinearSegmentedColormap.from_list("inh", ["#F5F5F5", "#B7DED6", "#15806D"])
    im = axD.imshow(mat.values, aspect="auto", cmap=cmap, vmin=0, vmax=100)
    axD.set_xticks(range(3), ["1", "10", "50"]); axD.set_xlabel("Concentration (µM)")
    axD.set_yticks(range(15), [f"#{i}" for i in range(1, 16)])
    pos = set(scores15.loc[scores15.report_screen_positive, "experiment_id"].astype(int))
    for tick, i in zip(axD.get_yticklabels(), range(1, 16)):
        tick.set_color(TEAL if i in pos else GREY)
        tick.set_fontweight("bold" if i in pos else "normal")
    for i in range(15):
        for j in range(3):
            axD.text(j, i, f"{mat.iloc[i,j]:.0f}", ha="center", va="center", fontsize=5.6,
                     color="white" if mat.iloc[i,j] > 55 else INK)
    cb = fig.colorbar(im, ax=axD, fraction=0.035, pad=0.02); cb.set_label("Inhibition (%)")
    axD.set_title("Primary plate values used in the analysis", loc="left", fontweight="bold")
    panel(axD, "D")
    save(fig, "Figure5_S1_assay_and_protein_provenance", pad=.12)


def _nice_metric(s: str) -> str:
    repl = {
        "binding_probability": "Binding probability", "boltz_ic50_nM": "Boltz IC50",
        "third_batch_boltz_pred_IC50_nM": "Later Boltz IC50", "source_top200_rank": "Top-200 rank",
        "top200_affinity_pred_IC50_nM": "Top-200 Boltz IC50", "top200_binding_probability": "Binding probability",
        "MW": "Molecular weight", "MW_rdkit": "Molecular weight", "cLogP": "cLogP", "cLogP_rdkit": "cLogP",
        "TPSA": "TPSA", "TPSA_rdkit": "TPSA", "RotB": "Rotatable bonds", "RotB_rdkit": "Rotatable bonds",
        "QED": "QED", "QED_rdkit": "QED", "rank": "Top-200 rank",
    }
    return repl.get(s, s.replace("_", " "))


def _normalized_null(obs, med, lo, hi):
    span = (hi - lo) / 2
    return (obs - med) / span if span else 0


def fig_s2_selection() -> None:
    fig, axs = plt.subplots(2, 3, figsize=(8.55, 5.35))
    axA, axB, axC, axD, axE, axF = axs.ravel()

    feat_order = ["binding_probability", "MW", "RotB", "QED", "cLogP", "boltz_ic50_nM", "rank", "TPSA"]
    d = top_features.set_index("feature").loc[[x for x in feat_order if x in set(top_features.feature)]].iloc[::-1]
    y = np.arange(len(d)); z = d.source_adjusted_z_mean_selected.to_numpy()
    axA.barh(y, z, color=[TEAL if p < 0.05 else "#CBD0DA" for p in d.stratified_permutation_two_sided_p], height=.68)
    axA.axvline(0, color=INK, lw=.8); axA.set_yticks(y, [_nice_metric(x) for x in d.index])
    axA.set_xlabel("Source-adjusted selected-set z")
    axA.set_title("800 rank positions → 47 MD candidates", loc="left", fontweight="bold", fontsize=7.8)
    clean(axA); panel(axA, "A")

    feat2 = ["top200_binding_probability", "third_batch_boltz_pred_IC50_nM", "MW_rdkit", "QED_rdkit", "RotB_rdkit", "cLogP_rdkit", "source_top200_rank"]
    d = buy_features.set_index("metric").loc[[x for x in feat2 if x in set(buy_features.metric)]].iloc[::-1]
    y = np.arange(len(d)); auc = d.source_stratified_auc_purchased_higher.to_numpy()
    axB.barh(y, auc-.5, left=.5, color=[TEAL if q < .1 else "#CBD0DA" for q in d.BH_q_across_14_reported_metrics], height=.68)
    axB.axvline(.5, color=INK, lw=.8); axB.set_yticks(y, [_nice_metric(x) for x in d.index])
    axB.set_xlim(0, 1); axB.set_xlabel("Within-source AUC (purchased higher)")
    axB.set_title("47 MD candidates → 15 purchased", loc="left", fontweight="bold", fontsize=7.8)
    clean(axB); panel(axB, "B")

    keep = ["unique_murcko", "mean_pairwise_tanimoto", "mean_nearest_other_tanimoto", "clusters_represented_tan_0.6", "clusters_represented_tan_0.7"]
    d = top_div[top_div.metric.isin(keep)].copy().iloc[::-1]
    d["z95"] = [_normalized_null(r.observed_MD47, r.null_median, r.null_2p5, r.null_97p5) for _, r in d.iterrows()]
    y = np.arange(len(d)); axC.axvspan(-1, 1, color="#EEF0F4", zorder=0)
    axC.scatter(d.z95, y, s=30, color=PURPLE, edgecolor=INK, lw=.4, zorder=3)
    short_top={"unique_murcko":"Murcko scaffolds","mean_pairwise_tanimoto":"Mean pairwise Tanimoto","mean_nearest_other_tanimoto":"Mean nearest-neighbour","clusters_represented_tan_0.6":"Clusters at T=0.6","clusters_represented_tan_0.7":"Clusters at T=0.7"}
    axC.axvline(0, color=GREY, lw=.7); axC.set_yticks(y, [short_top.get(x,x) for x in d.metric])
    axC.set_xlabel("Source-matched 95% interval units")
    axC.set_title("Top-200 → 47 diversity audit", loc="left", fontweight="bold")
    clean(axC); panel(axC, "C")

    d = buy_div.iloc[::-1].copy()
    d["z90"] = [_normalized_null(r.actual_purchased15, r.source_quota_random_median, r.source_quota_random_q05, r.source_quota_random_q95) for _, r in d.iterrows()]
    y = np.arange(len(d)); axD.axvspan(-1, 1, color="#EEF0F4", zorder=0)
    axD.scatter(d.z90, y, s=30, color=ORANGE, edgecolor=INK, lw=.4, zorder=3)
    short_buy={"murcko_count":"Murcko scaffolds","mean_pairwise_tanimoto":"Mean pairwise Tanimoto","median_pairwise_tanimoto":"Median pairwise Tanimoto","max_pairwise_tanimoto":"Max pairwise Tanimoto","pairs_ge_0p6":"Pairs ≥0.6","pairs_ge_0p7":"Pairs ≥0.7","distinct_clusters_at_T0.6":"Clusters at T=0.6","distinct_clusters_at_T0.7":"Clusters at T=0.7"}
    axD.axvline(0, color=GREY, lw=.7); axD.set_yticks(y, [short_buy.get(x,x) for x in d.metric])
    axD.set_xlabel("Source-matched 5–95% interval units")
    axD.set_title("47 → 15 diversity audit", loc="left", fontweight="bold")
    clean(axD); panel(axD, "D")

    for src, dd in candidate47.groupby("source_group"):
        axE.scatter(dd.pc1_on_47_ecfp4, dd.pc2_on_47_ecfp4, s=18, color=SOURCE_COLORS.get(src, GREY), label=src,
                    alpha=.85, edgecolor="white", lw=.3)
    pur = candidate47[candidate47.purchased]
    axE.scatter(pur.pc1_on_47_ecfp4, pur.pc2_on_47_ecfp4, s=40, facecolors="none", edgecolors=INK, lw=.8, label="Purchased")
    pos = candidate47[candidate47.report_screen_positive_posthoc.fillna(False).astype(bool)]
    axE.scatter(pos.pc1_on_47_ecfp4, pos.pc2_on_47_ecfp4, s=18, color=TEAL, edgecolor=INK, lw=.3, label="Report positive")
    axE.set_xlabel("ECFP4 PC1 (7.44%)"); axE.set_ylabel("ECFP4 PC2 (7.15%)")
    axE.set_title("Low-variance 2D projection", loc="left", fontweight="bold")
    clean(axE); panel(axE, "E")
    axE.legend(frameon=False, ncol=1, loc="upper left", fontsize=5.0, handletextpad=.3, labelspacing=.28)

    groups = ["TS1", "TS2", "EnamineSim", "Kinase_Library"]
    cand_counts = candidate47.source_group.value_counts().reindex(groups).fillna(0)
    quoted = []
    purchased = []
    for g in groups:
        rows = procure[(procure.source_group == g)]
        quoted.append(rows.in_quote_table_N.sum())
        purchased.append(rows.loc[rows.selection == "purchased", "N"].sum())
    x = np.arange(4); w=.23
    axF.bar(x-w, cand_counts, width=w, color="#AAB2C0", label="MD candidates")
    axF.bar(x, quoted, width=w, color=BLUE, label="Quote recorded")
    axF.bar(x+w, purchased, width=w, color=TEAL, label="Purchased")
    axF.set_xticks(x, ["TS1", "TS2", "Enamine", "Kinase"], rotation=25, ha="right")
    axF.set_ylabel("Compounds (n)"); axF.set_title("Procurement accounting by source", loc="left", fontweight="bold")
    axF.legend(frameon=False, fontsize=5.6); clean(axF); panel(axF, "F")
    save(fig, "Figure5_S2_selection_and_chemical_space_audit", wspace=.70, hspace=.58, left=.143)


def fig_s3_thresholds() -> None:
    fig, axs = plt.subplots(2, 3, figsize=(8.55, 5.15))
    axA, axB, axC, axD, axE, axF = axs.ravel()
    for ax, name, color, letter in [(axA, "pair", PURPLE, "A"), (axB, "triad", RED, "B")]:
        d = thresholds[(thresholds.pose == "Boltz2") & (thresholds.panel == name)].sort_values("strict_gt_threshold_kcal_mol")
        x = d.strict_gt_threshold_kcal_mol
        ax.plot(x, d.ppv_pct, "o-", color=color, lw=1.25, ms=3.4, label="Observed PPV")
        ax.plot(x, d.recall_pct, "s--", color=TEAL, lw=1.0, ms=3.0, label="Positive recall")
        ax.plot(x, d.same_k_boltz_ppv_pct, "o--", color=BLUE, lw=1.0, ms=3.0, label="same-K Boltz PPV")
        ax.axhline(60, color=GREY, lw=.8, ls=":", label="9/15 baseline")
        ax.set_ylim(-3, 104); ax.set_xlabel(f"{name.title()} strength > threshold (kcal/mol)"); ax.set_ylabel("Percent (%)")
        ax.set_title(f"{name.title()} gate: purity and recall", loc="left", fontweight="bold")
        clean(ax); panel(ax, letter)
    axA.legend(frameon=False, fontsize=5.6, loc="lower left")

    dparts=[]
    for name, color in [("pair", PURPLE), ("triad", RED)]:
        d=thresholds[(thresholds.pose=="Boltz2")&(thresholds.panel==name)].sort_values("strict_gt_threshold_kcal_mol")
        axC.plot(d.strict_gt_threshold_kcal_mol, d.retained_n, "o-", color=color, ms=3.2, lw=1.2, label=name.title())
    axC.axhline(15, color=GREY, lw=.7, ls=":"); axC.set_ylim(-.5,15.8)
    axC.set_xlabel("Energy threshold (kcal/mol)"); axC.set_ylabel("Retained compounds (n)")
    axC.set_title("Stricter gates rapidly reduce K", loc="left", fontweight="bold"); axC.legend(frameon=False); clean(axC); panel(axC,"C")

    names={"Boltz2_Pair_strength":"Pair","Boltz2_Triad_strength":"Triad","historical_Boltz_predicted_affinity_negative_IC50":"Historical Boltz"}
    d=continuous.copy(); y=np.arange(len(d)); vals=d.ROC_AUC_report_screen_positive.to_numpy()
    lo=vals-d.ROC_AUC_stratified_bootstrap95_low_descriptive.to_numpy(); hi=d.ROC_AUC_stratified_bootstrap95_high_descriptive.to_numpy()-vals
    colors=[PURPLE,RED,BLUE]
    axD.errorbar(vals,y,xerr=[lo,hi],fmt="none",ecolor=GREY,lw=1,capsize=2,zorder=1)
    axD.scatter(vals,y,s=34,c=colors,edgecolor=INK,lw=.4,zorder=2)
    axD.axvline(.5,color=GREY,ls=":",lw=.8); axD.set_xlim(0,1.04)
    axD.set_yticks(y,[names[x] for x in d.method]); axD.set_xlabel("ROC AUC for report label")
    axD.set_title("ROC AUC for report label (N=15)",loc="left",fontweight="bold"); clean(axD); panel(axD,"D")

    rhos=d[["spearman_rho_inhibition_1uM","spearman_rho_inhibition_10uM","spearman_rho_inhibition_50uM"]].to_numpy()
    xx=np.arange(3); labels=["1 µM","10 µM","50 µM"]
    for i,(lab,color) in enumerate(zip([names[x] for x in d.method],colors)):
        axE.plot(xx,rhos[i],"o-",color=color,lw=1.1,ms=3.2,label=lab)
    axE.axhline(0,color=GREY,lw=.8); axE.set_xticks(xx,labels); axE.set_ylabel("Spearman rho")
    axE.set_title("Scores vs continuous inhibition",loc="left",fontweight="bold"); axE.legend(frameon=False,fontsize=5.5); clean(axE); panel(axE,"E")

    rnd=qa_thr["exact_conditional_randomization"]
    rows=[("Pair",rnd["pair_preset_0p5"]), ("Triad",rnd["triad_preset_0p5"]), ("Combined",rnd["pair_plus_triad_preset_0p5"])]
    yy=np.arange(3); p_en=[r[1]["exact_scan_adjusted_p_for_min_hypergeom_p"] for r in rows]
    p_adv=[r[1]["exact_scan_adjusted_p_for_max_advantage"] for r in rows]
    axF.scatter(p_en,yy-.12,s=34,color=TEAL,label="enrichment vs 9/15")
    axF.scatter(p_adv,yy+.12,s=34,color=ORANGE,label="advantage vs same-K Boltz")
    axF.axvline(.05,color=GREY,ls=":",lw=.8); axF.set_xscale("log"); axF.set_xlim(.015,.4)
    axF.set_yticks(yy,[r[0] for r in rows]); axF.set_xlabel("Exact scan-adjusted p (preset 0.5 grid)")
    axF.set_title("Threshold-scan adjustment",loc="left",fontweight="bold"); axF.legend(frameon=False,fontsize=5.3); clean(axF); panel(axF,"F")
    save(fig, "Figure5_S3_full_threshold_and_uncertainty", wspace=.52, hspace=.58)


def fig_s4_counterexamples() -> None:
    fig, axs = plt.subplots(2, 3, figsize=(8.55, 5.05))
    axA, axB, axC, axD, axE, axF = axs.ravel()
    piv=assay.pivot(index="experiment_id",columns="concentration_uM",values="inhibition_pct").loc[range(1,16),[1,10,50]]
    positive=set(scores15.loc[scores15.report_screen_positive,"experiment_id"].astype(int))
    for i in range(1,16):
        axA.plot([1,10,50],piv.loc[i],"o-",lw=1.05,ms=2.8,color=TEAL if i in positive else GREY,alpha=.9)
    axA.set_xscale("log"); axA.set_xticks([1,10,50],["1","10","50"]); axA.set_xlabel("Concentration (µM)"); axA.set_ylabel("Inhibition (%)")
    axA.set_title("Observed three-point profiles",loc="left",fontweight="bold"); clean(axA); panel(axA,"A")

    def scatter_score(ax,col,color,title,letter):
        ax.scatter(scores15[col],scores15.inhibition_50uM_pct,c=[TEAL if x else "#D8DAE0" for x in scores15.report_screen_positive],s=28,edgecolor=INK,lw=.4)
        for idx in [1,15]:
            r=scores15[scores15.experiment_id==idx].iloc[0]
            ax.annotate(f"#{idx}",(r[col],r.inhibition_50uM_pct),xytext=(3,4),textcoords="offset points",fontsize=6)
        ax.set_xlabel(title); ax.set_ylabel("Inhibition at 50 µM (%)"); ax.set_title(title,loc="left",fontweight="bold"); clean(ax); panel(ax,letter)
    scatter_score(axB,"boltz_pair",PURPLE,"Pair strength (kcal/mol)","B")
    scatter_score(axC,"boltz_triad",RED,"Triad strength (kcal/mol)","C")

    x=-np.log10(scores15.historical_boltz_pred_ic50_nM.astype(float))
    axD.scatter(x,scores15.inhibition_50uM_pct,c=[TEAL if z else "#D8DAE0" for z in scores15.report_screen_positive],s=28,edgecolor=INK,lw=.4)
    axD.set_xlabel("Historical Boltz score (−log10 IC50 nM)"); axD.set_ylabel("Inhibition at 50 µM (%)")
    axD.set_title("Historical Boltz ranking",loc="left",fontweight="bold"); clean(axD); panel(axD,"D")

    axE.scatter(nn15.nearest_nonself_tanimoto_ECFP4_2048,scores15.inhibition_50uM_pct,c=[TEAL if z else "#D8DAE0" for z in scores15.report_screen_positive],s=28,edgecolor=INK,lw=.4)
    for _,r in nn15.iterrows():
        if r.exact_smiles_in_kinase_reference:
            axE.annotate(f"#{int(r.experiment_id)} exact",(r.nearest_nonself_tanimoto_ECFP4_2048,scores15.loc[scores15.experiment_id==r.experiment_id,"inhibition_50uM_pct"].iloc[0]),fontsize=5.8)
    axE.set_xlabel("Nearest kinase-reference ECFP4 Tanimoto"); axE.set_ylabel("Inhibition at 50 µM (%)")
    axE.set_title("Reference proximity is not selectivity",loc="left",fontweight="bold"); clean(axE); panel(axE,"E")

    rows=[]
    for idx,label in [(1,"Highest Triad; report negative"),(15,"Strongest 50 µM response; Pair gate−")]:
        r=scores15[scores15.experiment_id==idx].iloc[0]
        rows.append([f"#{idx}",label,r.inhibition_1uM_pct,r.inhibition_10uM_pct,r.inhibition_50uM_pct,r.boltz_pair,r.boltz_triad])
    axF.axis("off"); panel(axF,"F"); axF.set_title("Illustrative discordant cases",loc="left",fontweight="bold")
    y=.78
    for row in rows:
        axF.text(.02,y,row[0],fontsize=10,fontweight="bold",color=TEAL if row[0]=="#15" else GREY,transform=axF.transAxes)
        axF.text(.17,y,row[1],fontsize=6.5,transform=axF.transAxes)
        axF.text(.17,y-.13,f"Inhibition 1/10/50 µM: {row[2]:.0f} / {row[3]:.0f} / {row[4]:.0f}%",fontsize=6.2,transform=axF.transAxes)
        axF.text(.17,y-.23,f"Pair {row[5]:.2f}; Triad {row[6]:.2f} kcal/mol",fontsize=6.2,transform=axF.transAxes)
        y-=.46
    axF.text(.02,.02,"Illustrative only: three single wells; no fitted IC50 or error bars.",fontsize=6.2,color="#555",transform=axF.transAxes)
    save(fig, "Figure5_S4_all_compounds_and_counterexamples", wspace=.47, hspace=.55)


def write_tables_and_docs() -> None:
    sources = {
        "Table_S1_stage_counts.csv": F5 / "01_MAIN/00_traceable_stage_counts.csv",
        "Table_S2_all45_assay_wells.csv": F5 / "01_MAIN/A_15x3_inhibition_from_primary_plate.csv",
        "Table_S3_all15_scores_and_labels.csv": F5 / "01_MAIN/D_15_assay_current_Boltz_pair_triad.csv",
        "Table_S4_full_threshold_scan.csv": THR / "preset_half_kcal_thresholds.csv",
        "Table_S5_continuous_score_diagnostics.csv": THR / "continuous_score_diagnostics.csv",
        "Table_S6_top200_to_47_feature_audit.csv": RET47 / "source_stratified_feature_permutation.csv",
        "Table_S7_top200_to_47_diversity_null.csv": RET47 / "diversity_vs_source_stratified_random.csv",
        "Table_S8_47_to_15_feature_audit.csv": RET15 / "47_15_within_source_permutation_pq.csv",
        "Table_S9_47_to_15_diversity_null.csv": RET15 / "47_15_diversity_against_source_quota_random.csv",
        "Table_S10_all15_kinase_reference_neighbors.csv": F5 / "01_MAIN/F_15_kinase_reference_novelty.csv",
        "Table_S11_selection_assay_identity.csv": F5 / "02_SI/current_energy/15_selection_vs_assay_smiles_identity.csv",
        "Table_S12_assay_transcription_discrepancies.csv": DISCREP,
    }
    provenance=[]
    for name,src in sources.items():
        dst=TAB/name; shutil.copy2(src,dst)
        provenance.append({"package_file":str(dst.relative_to(PKG)),"source_path":str(src),"transformation":"byte copy"})

    # One reviewer-friendly workbook; all source CSVs remain authoritative.
    xlsx=TAB/"Figure5_SI_tables_current_20260927.xlsx"
    with pd.ExcelWriter(xlsx,engine="openpyxl") as w:
        index=[]
        for i,(name,_) in enumerate(sources.items(),start=1):
            sheet=f"S{i}_{Path(name).stem.replace('Table_S'+str(i)+'_','')[:22]}"[:31]
            pd.read_csv(TAB/name).to_excel(w,sheet_name=sheet,index=False)
            index.append({"sheet":sheet,"source_csv":name})
        pd.DataFrame(index).to_excel(w,sheet_name="INDEX",index=False)

    scope=pd.DataFrame([
        ["Figure5_S1","assay plate","15 compounds / 45 wells",9,"one well per compound/concentration"],
        ["Figure5_S2","selection audit","800 rank positions → 47 → 26 quoted → 15",9,"retrospective; source-matched nulls"],
        ["Figure5_S3","post-assay gate re-analysis","N=15",9,"strict >; same-K Boltz; full tails"],
        ["Figure5_S4","all purchased compounds","N=15",9,"descriptive counterexamples"],
    ],columns=["item","cohort","N","report_preliminary_positive_N","scope_note"])
    scope.to_csv(PKG/"SCOPE_ASSERTIONS.csv",index=False)

    source_map=pd.DataFrame([
        ["S1A-B","Protein characterization images",str(F5/"02_SI/experimental_originals")],
        ["S1C-D","All 45 primary wells",str(F5/"01_MAIN/A_15x3_inhibition_from_primary_plate.csv")],
        ["S2A,C","Top-200→47 retrospective audit",str(RET47)],
        ["S2B,D,F","47→15 procurement/space audit",str(RET15)],
        ["S2E","47-candidate ECFP4 PCA",str(F5/"01_MAIN/C_47_chemical_space_properties.csv")],
        ["S3A-F","Full threshold and continuous-score audit",str(THR)],
        ["S4A-D,F","15-compound assay and scores",str(F5/"01_MAIN/D_15_assay_current_Boltz_pair_triad.csv")],
        ["S4E","Kinase-reference nearest neighbours",str(F5/"01_MAIN/F_15_kinase_reference_novelty.csv")],
    ],columns=["panel","content","source"])
    source_map.to_csv(PKG/"SOURCE_MAP.csv",index=False)

    caption = "# Figure 5 supplementary captions (current 2026-09-27)\n\n"
    caption += "## Figure 5—figure supplement 1 | Protein and assay provenance\n"
    caption += "(A) Coomassie-stained preparation and (B) Western blot supplied with the laboratory report; the reported >90% purity was not independently densitometrically quantified. (C,D) All 45 sample wells (15 compounds × 1, 10 and 50 µM), one confirmed sample well per compound/concentration. Blank mean was 1,500 RLU and vehicle mean was 89,500 RLU; inhibition was calculated as 100×(89,500−sample)/(89,500−1,500). The report identifies Promega ADP-Glo V6930, whereas the raw UTF-16 export is labelled PlateA_Firefly/PlateB_Renilla and its footer says Dual-GLO. These metadata labels disagree and should be clarified with the laboratory. The nine highlighted compounds are report-defined qualitative preliminary positives, not confirmed inhibitors.\n\n"
    caption += "## Figure 5—figure supplement 2 | Retrospective selection and chemical-space audit\n"
    caption += "All comparisons describe the selected sets retrospectively and were not applied historical selection rules. The 800 inputs are rank positions, not 800 unique molecules. Source-stratified comparisons show which recorded properties differ for the 47 traceable MD candidates and 15 purchased compounds. The ECFP4 projection explains only 14.59% in PC1+PC2. Both selection stages span multiple scaffolds in absolute terms, but neither is more diverse than source-matched random sampling; selected sets are modestly more similar by mean pairwise Tanimoto. Procurement and supplier quote availability contribute to the 47→26→15 transition.\n\n"
    caption += "## Figure 5—figure supplement 3 | Full post-assay threshold sensitivity\n"
    caption += "Pair and Triad strengths use strict > thresholds. PPV, positive recall, same-K historical Boltz performance and retained K are shown across the full preset 0.5-kcal/mol grid. More stringent gates are not monotonically better: Pair >4.5 retains only 2/15, Pair >5 retains none; Triad >5.5 retains 4/15 and Triad >6 retains 2/15. Exact conditional randomization over all 5,005 allocations of nine positive labels gives a preset-grid scan-adjusted p=0.0563 for the maximum +3-TP advantage over same-K Boltz (combined Pair/Triad). Continuous AUC and Spearman results are descriptive for N=15; the score labels do not imply biological replication.\n\n"
    caption += "## Figure 5—figure supplement 4 | All-compound profiles and discordant examples\n"
    caption += "Observed three-point single-well profiles and their relation to Pair, Triad, historical Boltz and kinase-reference proximity. #1 has the highest Triad strength yet is report negative; #15 has the strongest 50-µM response but lies below the fixed Pair gate. These examples prevent a monotonic or universal-gate interpretation. Kinase-reference similarity is chemical proximity only and does not establish novelty or selectivity. No IC50 was fitted and no SD/SEM is available.\n"
    (PKG/"CAPTIONS.md").write_text(caption)

    readme = "# Figure 5 SI — current package (2026-09-27)\n\n"
    readme += "This directory supplements the current Figure 5 with source-backed analyses that are too detailed for the main figure. It is the release candidate; older Figure 5 scratch outputs are not imported.\n\n"
    readme += "## Contents\n\n- S1: protein and assay provenance, including all 45 wells.\n- S2: source-adjusted selection, procurement and chemical-space audit.\n- S3: complete threshold tails, retention/recall, same-K baseline, continuous diagnostics and scan correction.\n- S4: all-compound profiles, counterexamples and kinase-reference proximity.\n- Tables S1–S12: exact machine-readable sources and identity/transcription audits.\n\n"
    readme += "## Interpretation boundaries\n\n- The analysis is a **post-assay re-analysis**, not prospective validation.\n- The nine positives are the report's qualitative preliminary calls. Each concentration has one confirmed sample well, so the package contains no SD/SEM, fitted IC50, repeatability or confirmed-hit claim.\n- The 47→26→15 path includes supplier quote and purchase constraints.\n- Chemical-reference similarity is proximity, not evidence of selectivity.\n- Compound #4 uses the instrument/primary-workbook values; three conflicting secondary transcriptions are preserved in Table S12.\n"
    (PKG/"README.md").write_text(readme)
    pd.DataFrame(provenance).to_csv(PKG/"SOURCE_PROVENANCE.csv",index=False)


def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()


def verify() -> None:
    checks={}
    checks["assay_rows_45"] = len(assay)==45
    checks["assay_15_compounds"] = assay.experiment_id.nunique()==15
    checks["one_well_each"] = bool((assay.groupby(["experiment_id","concentration_uM"]).size()==1).all())
    checks["positives_9"] = int(scores15.report_screen_positive.sum())==9
    checks["threshold_denominators"] = bool(((thresholds.tp+thresholds.fn)==9).all() and ((thresholds.tp+thresholds.fp)==thresholds.retained_n).all() and ((thresholds.tp+thresholds.fp+thresholds.fn+thresholds.tn)==15).all())
    checks["current_identity_15"] = scores15.experiment_id.nunique()==15
    figures=list(FIG.glob("Figure5_S*.*"))
    for stem in sorted({p.stem for p in figures}):
        exts={p.suffix for p in figures if p.stem==stem}
        checks[f"formats_{stem}"]={".pdf",".svg",".png",".tif"}.issubset(exts)
    checks["all_hard_checks_pass"] = all(v is True for v in checks.values())
    (QA/"QA_REPORT.json").write_text(json.dumps(checks,indent=2))
    if not checks["all_hard_checks_pass"]:
        raise RuntimeError(checks)
    rows=[]
    for p in sorted(PKG.rglob("*")):
        if p.is_file() and p.name != "FILE_MANIFEST_SHA256.csv":
            rows.append({"relative_path":str(p.relative_to(PKG)),"size_bytes":p.stat().st_size,"sha256":sha256(p)})
    pd.DataFrame(rows).to_csv(PKG/"FILE_MANIFEST_SHA256.csv",index=False)


def main() -> None:
    fig_s1_assay(); fig_s2_selection(); fig_s3_thresholds(); fig_s4_counterexamples()
    write_tables_and_docs()
    shutil.copy2(Path(__file__), SCRIPT/Path(__file__).name)
    verify()
    print(PKG)


if __name__ == "__main__":
    main()
