#!/usr/bin/env python3
"""Restyle the Figure 3 supplements onto the frozen series style.

The original build script recomputes every derived quantity from raw inputs
that are no longer on disk (including an N=143 energy-matrix .npz).  Those
derived quantities were, however, written out as the published S01-S17 tables,
so the plot functions are called directly with those tables instead.  No value
is recomputed and no panel logic is rewritten; only the presentation layer is
replaced.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent             # FigureN/Supplementary_Figures/rebuild
FS = HERE.parents[2]                               # release root (FigureandSI)
STYLE_DIR = FS / "Shared/style"                    # figure2_style.py, si_style.py, si_paths.py
sys.path.insert(0, str(STYLE_DIR))
sys.dont_write_bytecode = True                     # no __pycache__ inside the release
import si_paths as P                               # noqa: E402

OUTDIR = Path(os.environ.get("SI_RESTYLE_OUT", P.STAGE_ROOT / "out")) / "Figure3"
TABLES = P.stage_published_tables(3, P.STAGE_ROOT / "Figure3/published")
MAIN3 = P.stage_tree(P.main_rebuild(3), P.STAGE_ROOT / "Figure3/main_rebuild")


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main() -> None:
    sys.path.insert(0, str(STYLE_DIR))
    sys.path.insert(0, str(MAIN3))
    import si_style as S

    OUTDIR.mkdir(parents=True, exist_ok=True)
    t = lambda n: pd.read_csv(TABLES / n)
    # the two weighted-Jaccard matrices carry methods in the first column;
    # the plot code indexes them by method name
    tm = lambda n: pd.read_csv(TABLES / n, index_col=0)

    mod = load(HERE / "build_figure3_si.py", "build_fig3_si")
    mod.FIG_DIR = OUTDIR
    # the two tables plot_s1 reads from raw paths are published as S03 / S04
    mod.SRC_N213_GAINS = TABLES / "S03_N213_paired_gain_intervals.csv"
    mod.SRC_N213_CUTOFF = TABLES / "S04_N213_cutoff_sensitivity.csv"

    mod.configure_style = S.apply_si_style
    mod.panel_label = lambda ax, label: S.panel_letter(ax, label)
    mod.tidy_axis = lambda ax, grid_axis="y": S.clean(ax, grid_axis)
    mod.INK = "black"
    mod.MID = S.ANNOT_GREY
    mod.GRID = S.GRID_GREY

    import matplotlib.figure as mfig
    orig_suptitle = mfig.Figure.suptitle
    mfig.Figure.suptitle = lambda self, *a, **k: None

    done = []

    def export_figure(fig, stem):
        S.strip_legacy_titles(fig)
        n = S.PUBLIC_NUMBER[stem]
        S.stamp_heading(fig, n)
        S.save_si(fig, OUTDIR, stem)
        done.append(stem)
        print(f"  rendered {S.public_stem(stem)}")

    mod.export_figure = export_figure
    S.apply_si_style()

    jobs = [
        ("plot_s1", lambda: mod.plot_s1(tm("S06_N213_topK_weighted_jaccard.csv"),
                                        t("S07_N213_leave_one_series_out.csv"))),
        ("plot_s2", lambda: mod.plot_s2(t("S10_N143_all120_pairs.csv"),
                                        t("S11_N143_pair_plus14_residues.csv"),
                                        t("S12_N143_all560_triads.csv"),
                                        t("S13_N143_fixed_pair_triad_rank_context.csv"))),
        ("plot_s3", lambda: mod.plot_s3(t("S08_N143_complete_case_transition.csv"),
                                        t("S09_N143_missing_terms_all214.csv"),
                                        tm("S15_N143_fixed_methods_weighted_jaccard.csv"))),
    ]
    for name, fn in jobs:
        try:
            fn()
        except Exception as e:
            print(f"  [FAIL] {name}: {type(e).__name__}: {e}")
            traceback.print_exc(limit=4)

    # supplement 1 is drawn by the main figure's own module
    try:
        import matplotlib.pyplot as plt
        disp = load(HERE / "make_figure3_si_displaced.py", "fig3_displaced")
        disp.OUT = OUTDIR
        disp.TABLES = P.STAGE_ROOT / "Figure3/displaced_tables"   # keep the run out of the release
        grabbed = {}
        real = plt.Figure.savefig
        plt.Figure.savefig = lambda self, *a, **k: grabbed.setdefault("fig", self) and None
        try:
            disp.build()
        finally:
            plt.Figure.savefig = real
        fig = grabbed.get("fig")
        if fig is None:
            print("  [FAIL] displaced supplement produced no figure")
        else:
            export_figure(fig, "Figure3_S1_N213_primary_ranking_readouts")
    except Exception as e:
        print(f"  [FAIL] displaced S1: {type(e).__name__}: {e}")
        traceback.print_exc(limit=4)

    print(f"\n{len(done)} of 4 Figure 3 supplements restyled -> {OUTDIR}")


if __name__ == "__main__":
    main()
