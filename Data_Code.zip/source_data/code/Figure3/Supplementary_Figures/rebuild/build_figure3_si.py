#!/usr/bin/env python3
"""Build supplements 2-4 of the current Figure 3 supplementary package.

Supplement 1 (the two readouts the ten-panel main figure moved here) is
built by make_figure3_si_displaced.py and is not produced by this script;
the numbering below is the 2026-09-30 numbering.

Scientific scope is intentionally split:
  * N=213 (98 active at IC50 <= 100 nM; K=64) for Figure 3 F--I
    benchmarking and robustness. Compound 1-7-6 is excluded.
  * N=143 complete cases (70 active; K=43) for Figure 3 J/K and all
    exhaustive 16-residue combinatorial analyses.

The script only writes inside Figure/3/SI/current_20260930.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from PIL import Image
from scipy.stats import rankdata


ROOT = Path("/Users/wxmacbookpro/Desktop/project/AAK1/draft/Figure/3/SI/current_20260930")
FIG_DIR = ROOT / "figures"
TAB_DIR = ROOT / "tables"
SCRIPT_DIR = ROOT / "scripts"
QA_DIR = ROOT / "qa"

FIG3 = Path("/Users/wxmacbookpro/Desktop/project/AAK1/draft/Figure/3")
WORK = Path("/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2")

SRC_N213 = FIG3 / "raw_data_N213/N213_analysis_source/stress_compound_scores_N213_excluding_1-7-6.csv"
SRC_N213_METRICS = FIG3 / "raw_data_N213/derived_plotter_inputs_N213/Figure3_stress_metrics_N213.csv"
SRC_N213_GAINS = FIG3 / "raw_data_N213/derived_plotter_inputs_N213/Figure3_paired_gain_intervals_N213.csv"
SRC_N213_CUTOFF = FIG3 / "raw_data_N213/derived_plotter_inputs_N213/Figure3_cutoff_sensitivity_N213.csv"

SRC_PAIR120 = FIG3 / "panel_source_data/Figure3_panelJ_plotted_values.csv"
SRC_THIRD14 = FIG3 / "panel_source_data/Figure3_panelK_plotted_values.csv"
SRC_N143_NPZ = WORK / "outputs/AAK1_FIGURE4_R2_MECHANISM_20260924/method_sensitivity/N143_complete_energy_matrix.npz"
SRC_N143_META = WORK / "outputs/AAK1_FIGURE4_R2_MECHANISM_20260924/method_sensitivity/N143_eval_metadata.csv"
SRC_N143_METHODS = WORK / "outputs/AAK1_FIGURE4_R2_MECHANISM_20260924/method_sensitivity/N143_all_methods_K43_paired_metrics.csv"
SRC_TRANSITION = WORK / "outputs/AAK1_FIGURE_MD_REFRESH_20260924/figure3_stage/N143_candidate_NOT_FOR_FROZEN_FIGURE/complete_case_inclusion_oldN172_newN143.csv"
SRC_MISSING = WORK / "outputs/AAK1_FIGURE3_JK_AUDIT_20260924/missing_terms_all214.csv"
SRC_AUDIT = WORK / "outputs/AAK1_FIGURE3_JK_AUDIT_20260924/cohort_audit.json"

SOURCES = [
    SRC_N213, SRC_N213_METRICS, SRC_N213_GAINS, SRC_N213_CUTOFF,
    SRC_PAIR120, SRC_THIRD14, SRC_N143_NPZ, SRC_N143_META,
    SRC_N143_METHODS, SRC_TRANSITION, SRC_MISSING, SRC_AUDIT,
]

BLUE = "#4878D0"
ORANGE = "#EE854A"
GREEN = "#6ACC64"
RED = "#D65F5F"
PURPLE = "#956CB4"
INK = "#222222"
MID = "#6D7480"
LIGHT = "#DDE2EA"
GRID = "#D9DDE3"
METHOD_COLORS = {"Boltz-2": BLUE, "Leu26": ORANGE, "Pair": PURPLE, "Triad": RED}
METHOD_MARKERS = {"Boltz-2": "o", "Leu26": "s", "Pair": "D", "Triad": "^"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def configure_style() -> None:
    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 7.0,
        "axes.labelsize": 7.5,
        "axes.titlesize": 8.0,
        "xtick.labelsize": 6.7,
        "ytick.labelsize": 6.7,
        "legend.fontsize": 6.4,
        "axes.linewidth": 0.75,
        "xtick.major.width": 0.65,
        "ytick.major.width": 0.65,
        "xtick.major.size": 3.0,
        "ytick.major.size": 3.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    })


def tidy_axis(ax, grid_axis: str | None = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if grid_axis:
        ax.grid(axis=grid_axis, color=GRID, linewidth=0.55, alpha=0.75, zorder=0)
    ax.set_axisbelow(True)


def panel_label(ax, label: str) -> None:
    ax.text(-0.13, 1.08, label, transform=ax.transAxes, fontsize=11, fontweight="bold",
            ha="left", va="top", color=INK)


def export_figure(fig, stem: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    # Preserve the fixed journal width (8.75 in = 222.25 mm). Constrained
    # layout already keeps labels inside; a tight bbox would silently widen it.
    fig.savefig(FIG_DIR / f"{stem}.pdf")
    fig.savefig(FIG_DIR / f"{stem}.svg")
    fig.savefig(FIG_DIR / f"{stem}.png", dpi=600)
    fig.savefig(FIG_DIR / f"{stem}.tif", dpi=600,
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


def tie_aware_membership(scores: np.ndarray, k: int) -> np.ndarray:
    """Return top-k membership weights, splitting a boundary tie fractionally."""
    scores = np.asarray(scores, dtype=float)
    assert 0 < k <= len(scores) and np.isfinite(scores).all()
    boundary = np.sort(scores)[::-1][k - 1]
    above = scores > boundary
    tied = scores == boundary
    w = above.astype(float)
    w[tied] = (k - int(above.sum())) / int(tied.sum())
    assert np.isclose(w.sum(), k)
    return w


def weighted_recovery(scores: np.ndarray, active: np.ndarray, k: int) -> float:
    return float(np.dot(tie_aware_membership(scores, k), np.asarray(active, dtype=float)) / k)


def rank_average(x: np.ndarray) -> np.ndarray:
    return rankdata(np.asarray(x), method="average")


def pearson(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    dx, dy = x - x.mean(), y - y.mean()
    return float(np.dot(dx, dy) / math.sqrt(np.dot(dx, dx) * np.dot(dy, dy)))


def score_metrics(scores: np.ndarray, ic50: np.ndarray) -> dict[str, float]:
    """Six metrics used by the current N=143 exhaustive analysis."""
    scores = np.asarray(scores, dtype=float)
    ic50 = np.asarray(ic50, dtype=float)
    n = len(scores)
    active100 = ic50 <= 100
    k30 = math.ceil(0.30 * n)
    ranks = rank_average(scores)
    na = int(active100.sum())
    auc = (ranks[active100].sum() - na * (na + 1) / 2) / (na * (n - na))
    out = {
        "N": n,
        "n_active_100": na,
        "top30_K": k30,
        "top30_active_fraction": weighted_recovery(scores, active100, k30),
        "auc_100nM": float(auc),
        "spearman_rho": pearson(ranks, rank_average(-ic50)),
    }
    for cutoff in (25, 50, 100):
        active = ic50 <= cutoff
        out[f"matchedK_{cutoff}nM"] = weighted_recovery(scores, active, int(active.sum()))
    return out


def soft_jaccard(weights: dict[str, np.ndarray]) -> pd.DataFrame:
    methods = list(weights)
    out = pd.DataFrame(index=methods, columns=methods, dtype=float)
    for a in methods:
        for b in methods:
            num = np.minimum(weights[a], weights[b]).sum()
            den = np.maximum(weights[a], weights[b]).sum()
            out.loc[a, b] = num / den
    return out


def wilson(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = k / n
    den = 1 + z*z/n
    center = (p + z*z/(2*n))/den
    half = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return center-half, center+half


def load_and_assert_sources():
    for p in SOURCES:
        assert p.exists(), f"Missing source: {p}"

    n213 = pd.read_csv(SRC_N213)
    assert len(n213) == 213
    assert "1-7-6" not in set(n213.compound_id)
    assert int((n213.IC50_nM <= 100).sum()) == 98
    assert math.ceil(0.3 * len(n213)) == 64
    assert n213.compound_id.nunique() == 213

    metrics213 = pd.read_csv(SRC_N213_METRICS)
    assert set(metrics213.method) == {"Boltz-2", "Leu26", "Pair", "Triad"}
    assert set(metrics213.N) == {213}
    assert set(metrics213.n_active_100nM) == {98}
    assert set(metrics213.top30_K) == {64}

    pair120 = pd.read_csv(SRC_PAIR120)
    third14 = pd.read_csv(SRC_THIRD14)
    assert len(pair120) == 120 and len(third14) == 14
    assert set(pair120.N) == {143} and set(third14.N) == {143}
    assert set(pair120.top30_K) == {43} and set(third14.top30_K) == {43}

    meta143 = pd.read_csv(SRC_N143_META)
    z = np.load(SRC_N143_NPZ, allow_pickle=False)
    ids = z["compound_ids"].astype(str)
    residues = z["residues"].astype(str)
    matrix = z["contribution_1e4"].astype(np.int64)
    assert matrix.shape == (143, 16)
    assert len(ids) == len(set(ids)) == len(meta143) == 143
    assert list(ids) == list(meta143.compound_id.astype(str))
    assert len(set(residues)) == 16
    assert "1-7-6" not in set(ids)
    assert int((meta143.IC50_nM <= 100).sum()) == 70
    assert math.ceil(0.3 * len(meta143)) == 43

    transition = pd.read_csv(SRC_TRANSITION)
    assert len(transition) == 214
    assert int(transition.new_null_complete.sum()) == 143
    assert int(transition.old_null_complete.sum()) == 172

    missing = pd.read_csv(SRC_MISSING)
    assert len(missing) == 76
    return n213, metrics213, pair120, third14, meta143, ids, residues, matrix, transition, missing


def derive_n213(n213: pd.DataFrame):
    active = (n213.IC50_nM.to_numpy() <= 100)
    scores = {
        "Boltz-2": n213.Boltz_direction_normalized_score.to_numpy(float),
        "Leu26": -n213.Boltz_L26_E.to_numpy(float),
        "Pair": -n213.Boltz_Pair_E.to_numpy(float),
        "Triad": -n213.Boltz_Triad_E.to_numpy(float),
    }
    k = 64
    weights = {m: tie_aware_membership(v, k) for m, v in scores.items()}
    membership = n213[["compound_id", "group_id", "IC50_nM"]].copy()
    membership["active_100nM"] = active
    for m, w in weights.items():
        membership[f"{m}_topK_weight"] = w
    overlap = soft_jaccard(weights)

    # Leave-one-series-out sensitivity. This is re-evaluation after removal,
    # not model fitting and not held-out validation.
    rows = []
    for group in sorted(n213.group_id.unique()):
        keep = n213.group_id.ne(group).to_numpy()
        n = int(keep.sum())
        kk = math.ceil(0.30 * n)
        act = active[keep]
        values = {m: weighted_recovery(v[keep], act, kk) for m, v in scores.items()}
        for m, val in values.items():
            rows.append({
                "excluded_group": group,
                "excluded_n": int((~keep).sum()),
                "remaining_N": n,
                "remaining_active_100nM": int(act.sum()),
                "remaining_top30_K": kk,
                "method": m,
                "top30_active_fraction": val,
                "gain_vs_Boltz_pp": 100 * (val - values["Boltz-2"]),
                "analysis_type": "leave-one-series-out sensitivity; scores not refit",
            })
    logo = pd.DataFrame(rows)
    return scores, membership, overlap, logo


def derive_n143(meta, ids, residues, matrix, pair120, third14):
    idx = {r: i for i, r in enumerate(residues)}
    ic50 = meta.IC50_nM.to_numpy(float)
    triads = []
    for a, b, c in itertools.combinations(residues, 3):
        score = matrix[:, [idx[a], idx[b], idx[c]]].sum(axis=1)
        row = {"residue_1": a, "residue_2": b, "residue_3": c}
        row.update(score_metrics(score, ic50))
        row["contains_Leu26"] = "26LEU" in (a, b, c)
        row["contains_Phe102"] = "102PHE" in (a, b, c)
        row["contains_fixed_pair"] = {"26LEU", "102PHE"}.issubset({a, b, c})
        row["is_fixed_triad"] = set((a, b, c)) == {"26LEU", "102PHE", "107GLN"}
        triads.append(row)
    triad560 = pd.DataFrame(triads)
    assert len(triad560) == 560

    metric_cols = ["top30_active_fraction", "auc_100nM", "spearman_rho",
                   "matchedK_25nM", "matchedK_50nM", "matchedK_100nM"]
    for metric in metric_cols:
        triad560[f"rank_{metric}"] = triad560[metric].rank(method="min", ascending=False).astype(int)
        triad560[f"percentile_{metric}"] = 100 * (len(triad560) - triad560[f"rank_{metric}"] + 1) / len(triad560)

    # Independent verification of published Pair/Triad metrics.
    pair_score = matrix[:, [idx["26LEU"], idx["102PHE"]]].sum(axis=1)
    triad_score = pair_score + matrix[:, idx["107GLN"]]
    pair_stats = score_metrics(pair_score, ic50)
    triad_stats = score_metrics(triad_score, ic50)
    pair_ref = pair120[(pair120.residue_1.eq("26LEU") & pair120.residue_2.eq("102PHE")) |
                       (pair120.residue_1.eq("102PHE") & pair120.residue_2.eq("26LEU"))]
    third_ref = third14[third14.X_residue.eq("107GLN")]
    assert len(pair_ref) == len(third_ref) == 1
    for metric in metric_cols:
        assert np.isclose(pair_stats[metric], float(pair_ref.iloc[0][metric]), atol=1e-12)
        assert np.isclose(triad_stats[metric], float(third_ref.iloc[0][metric]), atol=1e-12)
        fixed = triad560[triad560.is_fixed_triad].iloc[0]
        assert np.isclose(triad_stats[metric], fixed[metric], atol=1e-12)

    # Rank and at-least-as-good counts make ties explicit.
    rank_rows = []
    for method, universe, observed in [("Fixed Pair", pair120, pair_stats),
                                       ("Fixed Triad", triad560, triad_stats)]:
        for metric in metric_cols:
            values = universe[metric].to_numpy(float)
            obs = observed[metric]
            rank_min = int(pd.Series(values).rank(method="min", ascending=False)[np.flatnonzero(np.isclose(values, obs, atol=1e-12))[0]]) if False else int(1 + np.sum(values > obs + 1e-12))
            at_least = int(np.sum(values >= obs - 1e-12))
            rank_rows.append({
                "method": method, "metric": metric, "observed": obs,
                "universe_n": len(values), "rank_min": rank_min,
                "n_at_least_as_good": at_least,
                "empirical_fraction_at_least_as_good": at_least / len(values),
                "percentile_rank_min": 100 * (len(values) - rank_min + 1) / len(values),
            })
    rank_context = pd.DataFrame(rank_rows)

    fixed_scores = {
        "Boltz-2": -meta.Boltz_raw_lower_is_stronger.to_numpy(float),
        "Leu26": matrix[:, idx["26LEU"]].astype(float),
        "Pair": pair_score.astype(float),
        "Triad": triad_score.astype(float),
    }
    weights = {m: tie_aware_membership(v, 43) for m, v in fixed_scores.items()}
    membership = meta[["compound_id", "group_id", "IC50_nM"]].copy()
    membership["active_100nM"] = membership.IC50_nM <= 100
    for m, w in weights.items():
        membership[f"{m}_topK_weight"] = w
    overlap = soft_jaccard(weights)
    return triad560, rank_context, membership, overlap


def write_tables(n213, metrics213, pair120, third14, transition, missing,
                 membership213, overlap213, logo213, triad560, rank_context,
                 membership143, overlap143):
    TAB_DIR.mkdir(parents=True, exist_ok=True)
    tables = {
        "S01_N213_compound_scores.csv": n213,
        "S02_N213_method_summary.csv": metrics213,
        "S03_N213_paired_gain_intervals.csv": pd.read_csv(SRC_N213_GAINS),
        "S04_N213_cutoff_sensitivity.csv": pd.read_csv(SRC_N213_CUTOFF),
        "S05_N213_topK_membership.csv": membership213,
        "S06_N213_topK_weighted_jaccard.csv": overlap213.reset_index(names="method"),
        "S07_N213_leave_one_series_out.csv": logo213,
        "S08_N143_complete_case_transition.csv": transition,
        "S09_N143_missing_terms_all214.csv": missing,
        "S10_N143_all120_pairs.csv": pair120,
        "S11_N143_pair_plus14_residues.csv": third14,
        "S12_N143_all560_triads.csv": triad560,
        "S13_N143_fixed_pair_triad_rank_context.csv": rank_context,
        "S14_N143_fixed_methods_topK_membership.csv": membership143,
        "S15_N143_fixed_methods_weighted_jaccard.csv": overlap143.reset_index(names="method"),
    }
    for name, df in tables.items():
        df.to_csv(TAB_DIR / name, index=False)

    # Human-readable workbook; CSV files remain the canonical machine-readable copies.
    workbook = TAB_DIR / "Figure3_SI_tables_current_20260930.xlsx"
    with pd.ExcelWriter(workbook, engine="openpyxl") as xw:
        index_rows = []
        for i, (name, df) in enumerate(tables.items(), 1):
            sheet = f"S{i:02d}_{Path(name).stem.split('_', 1)[1]}"[:31]
            df.to_excel(xw, sheet_name=sheet, index=False)
            index_rows.append({"sheet": sheet, "csv": name, "rows": len(df), "columns": len(df.columns)})
        pd.DataFrame(index_rows).to_excel(xw, sheet_name="INDEX", index=False)
    return tables


def plot_s1(overlap213, logo213):
    gains = pd.read_csv(SRC_N213_GAINS)
    cutoff = pd.read_csv(SRC_N213_CUTOFF)
    fig, axs = plt.subplots(2, 2, figsize=(8.75, 6.9), constrained_layout=True)

    # A: paired group-bootstrap differences across six endpoints.
    ax = axs[0, 0]
    order = ["top30_active_fraction", "auc_100nM", "spearman_rho",
             "matchedK_25nM", "matchedK_50nM", "matchedK_100nM"]
    labels = ["Top-30% active fraction", "ROC AUC (100 nM)", "Spearman rho",
              "Recovery at 25 nM", "Recovery at 50 nM", "Recovery at 100 nM"]
    comparisons = ["Leu26 minus Boltz-2", "Pair minus Boltz-2", "Triad minus Boltz-2"]
    comp_names = {c: c.split(" minus")[0] for c in comparisons}
    ybase = np.arange(len(order))[::-1]
    offs = {comparisons[0]: 0.18, comparisons[1]: 0.0, comparisons[2]: -0.18}
    for comp in comparisons:
        d = gains[gains.comparison.eq(comp)].set_index("metric").loc[order]
        med = 100 * d.bootstrap_median.to_numpy()
        lo = 100 * d.ci_low.to_numpy()
        hi = 100 * d.ci_high.to_numpy()
        y = ybase + offs[comp]
        m = comp_names[comp]
        ax.errorbar(med, y, xerr=[med-lo, hi-med], fmt=METHOD_MARKERS[m], ms=4.0,
                    color=METHOD_COLORS[m], ecolor=METHOD_COLORS[m], elinewidth=0.9,
                    capsize=1.8, label=m, zorder=3)
    ax.axvline(0, color=MID, linewidth=0.8, linestyle="--")
    ax.set_yticks(ybase, labels)
    ax.set_xlabel("Difference vs Boltz-2 × 100\n(pp for proportions; 100 × delta rho)")
    ax.set_title("Paired group-bootstrap sensitivity (95% descriptive intervals)", loc="left")
    ax.legend(frameon=False, ncol=3, loc="lower right")
    tidy_axis(ax, "x")
    panel_label(ax, "A")

    # B: cutoff sensitivity.
    ax = axs[0, 1]
    for method in ["Boltz-2", "Leu26", "Pair", "Triad"]:
        d = cutoff[cutoff.method.eq(method)].sort_values("ic50_cutoff_nm")
        ax.plot(d.ic50_cutoff_nm, 100*d.matchedK_recovery, marker=METHOD_MARKERS[method],
                color=METHOD_COLORS[method], linewidth=1.2, ms=3.8, label=method)
    ax.set_xlabel("Experimental activity cutoff (nM)")
    ax.set_ylabel("Recovery at matched K (%)")
    ax.set_title("Performance across activity definitions", loc="left")
    ax.legend(frameon=False, ncol=2, loc="lower right")
    tidy_axis(ax, "y")
    panel_label(ax, "B")

    # C: tie-aware overlap.
    ax = axs[1, 0]
    arr = overlap213.loc[["Boltz-2", "Leu26", "Pair", "Triad"],
                         ["Boltz-2", "Leu26", "Pair", "Triad"]].to_numpy()
    im = ax.imshow(arr, vmin=0, vmax=1, cmap="Blues")
    ax.set_xticks(range(4), ["Boltz-2", "Leu26", "Pair", "Triad"], rotation=28, ha="right")
    ax.set_yticks(range(4), ["Boltz-2", "Leu26", "Pair", "Triad"])
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{arr[i,j]:.2f}", ha="center", va="center",
                    color="white" if arr[i,j] > .62 else INK, fontsize=6.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
    cb.set_label("Tie-aware weighted Jaccard")
    ax.set_title("Top-64 compound overlap", loc="left")
    panel_label(ax, "C")

    # D: leave-one-series-out sensitivity.
    ax = axs[1, 1]
    methods = ["Leu26", "Pair", "Triad"]
    rng = np.random.default_rng(20260927)
    for x, method in enumerate(methods):
        vals = logo213[logo213.method.eq(method)].gain_vs_Boltz_pp.to_numpy()
        jitter = rng.normal(0, 0.035, len(vals))
        ax.scatter(np.full(len(vals), x)+jitter, vals, s=13, alpha=.62,
                   color=METHOD_COLORS[method], edgecolor="white", linewidth=.25, zorder=2)
        q1, med, q3 = np.percentile(vals, [25, 50, 75])
        ax.vlines(x, q1, q3, color=INK, linewidth=3.3, zorder=3)
        ax.scatter([x], [med], marker="_", s=85, color="white", linewidth=1.2, zorder=4)
    ax.axhline(0, color=MID, linewidth=0.8, linestyle="--")
    ax.set_xticks(range(3), methods)
    ax.set_ylabel("Top-30% gain vs Boltz-2 (pp)")
    ax.set_title("Leave-one-series-out sensitivity (no refitting)", loc="left")
    ax.text(.99, .02, f"{logo213.excluded_group.nunique()} omitted series",
            transform=ax.transAxes, ha="right", va="bottom", color=MID, fontsize=6.2)
    tidy_axis(ax, "y")
    panel_label(ax, "D")

    export_figure(fig, "Figure3_S2_N213_benchmark_robustness")


def plot_s2(pair120, third14, triad560, rank_context):
    fig, axs = plt.subplots(2, 2, figsize=(8.75, 6.8), constrained_layout=True)
    fixed_pair = pair120[(pair120.residue_1.eq("26LEU") & pair120.residue_2.eq("102PHE")) |
                         (pair120.residue_1.eq("102PHE") & pair120.residue_2.eq("26LEU"))].iloc[0]
    fixed_triad = triad560[triad560.is_fixed_triad].iloc[0]

    # A: all pairs, correct bins that include all 120 combinations.
    ax = axs[0, 0]
    vals = 100*pair120.top30_active_fraction.to_numpy()
    lo = math.floor(vals.min()/2.5)*2.5
    hi = math.ceil(vals.max()/2.5)*2.5 + 2.5
    bins = np.arange(lo, hi+1e-9, 2.5)
    without = 100*pair120.loc[~pair120.contains_leu26, "top30_active_fraction"].to_numpy()
    with_l = 100*pair120.loc[pair120.contains_leu26, "top30_active_fraction"].to_numpy()
    counts, _ = np.histogram(vals, bins=bins)
    assert counts.sum() == 120
    ax.hist([without, with_l], bins=bins, stacked=True, color=[LIGHT, ORANGE],
            edgecolor=INK, linewidth=.45, label=["Without Leu26 (105)", "With Leu26 (15)"])
    ax.axvline(100*fixed_pair.top30_active_fraction, color=PURPLE, linewidth=1.4, linestyle="--",
               label="Fixed Pair 76.7%")
    ax.axvline(100*70/143, color=MID, linewidth=.9, linestyle=":", label="Random 49.0%")
    ax.set_xlabel("Active fraction in top 30% (%)")
    ax.set_ylabel("Number of pairs")
    ax.set_title("All 120 two-residue combinations", loc="left")
    ax.legend(frameon=False, loc="upper left")
    tidy_axis(ax, "y")
    panel_label(ax, "A")

    # B: all 560 triads.
    ax = axs[0, 1]
    vals = 100*triad560.top30_active_fraction.to_numpy()
    lo = math.floor(vals.min()/2.5)*2.5
    hi = math.ceil(vals.max()/2.5)*2.5 + 2.5
    bins = np.arange(lo, hi+1e-9, 2.5)
    all_counts, _ = np.histogram(vals, bins=bins)
    assert all_counts.sum() == 560
    ax.hist(vals, bins=bins, color=LIGHT, edgecolor=INK, linewidth=.45, label="All triads (560)")
    cond = triad560.contains_fixed_pair
    ax.hist(vals[cond], bins=bins, histtype="step", color=RED, linewidth=1.25,
            label="Fixed Pair + X (14)")
    ax.axvline(100*fixed_triad.top30_active_fraction, color=RED, linewidth=1.4, linestyle="--",
               label="Fixed Triad 76.7%")
    ax.axvline(100*70/143, color=MID, linewidth=.9, linestyle=":")
    ax.set_xlabel("Active fraction in top 30% (%)")
    ax.set_ylabel("Number of triads")
    ax.set_title("All 560 three-residue combinations", loc="left")
    ax.legend(frameon=False, loc="upper left")
    tidy_axis(ax, "y")
    panel_label(ax, "B")

    # C: every conditional third residue.
    ax = axs[1, 0]
    d = third14.sort_values(["delta_top30_vs_pair_pp", "auc_100nM"], ascending=[True, True]).reset_index(drop=True)
    y = np.arange(len(d))
    colors = [RED if r == "107GLN" else PURPLE for r in d.X_residue]
    ax.hlines(y, 0, d.delta_top30_vs_pair_pp, color=["#C7CBD3"]*len(d), linewidth=1.1)
    ax.scatter(d.delta_top30_vs_pair_pp, y, c=colors, s=25, edgecolor=INK, linewidth=.45, zorder=3)
    ax.axvline(0, color=MID, linewidth=.8, linestyle="--")
    ax.set_yticks(y, d.X_residue)
    ax.set_xlabel("Change vs fixed Pair (pp, top-30% active fraction)")
    ax.set_title("Fixed Pair plus each eligible third residue", loc="left")
    qrow = d[d.X_residue.eq("107GLN")].iloc[0]
    ax.text(.98, .03, f"Gln107: {qrow.delta_top30_vs_pair_pp:+.1f} pp; AUC rank 1/14",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=6.2, color=RED)
    tidy_axis(ax, "x")
    panel_label(ax, "C")

    # D: percentile context across all six metrics.
    ax = axs[1, 1]
    metrics = ["top30_active_fraction", "auc_100nM", "spearman_rho",
               "matchedK_25nM", "matchedK_50nM", "matchedK_100nM"]
    labels = ["Top 30%", "AUC", "rho", "Rec. 25", "Rec. 50", "Rec. 100"]
    x = np.arange(len(metrics))
    for method, off, col, marker in [("Fixed Pair", -.10, PURPLE, "D"), ("Fixed Triad", .10, RED, "^")]:
        dd = rank_context[rank_context.method.eq(method)].set_index("metric").loc[metrics]
        ax.plot(x+off, dd.percentile_rank_min, marker=marker, color=col, linewidth=1.0,
                ms=4.2, label=method)
        for xx, (_, r) in zip(x+off, dd.iterrows()):
            ax.text(xx, r.percentile_rank_min+2.2, f"{int(r.rank_min)}/{int(r.universe_n)}",
                    ha="center", va="bottom", fontsize=5.6, color=col, rotation=28)
    ax.axhline(50, color=MID, linewidth=.8, linestyle=":")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 108)
    ax.set_ylabel("Percentile (higher = better)")
    ax.set_title("Fixed-panel position in exhaustive universes", loc="left")
    ax.legend(frameon=False, loc="lower left")
    tidy_axis(ax, "y")
    panel_label(ax, "D")

    export_figure(fig, "Figure3_S3_N143_exhaustive_combinatorial_context")


def plot_s3(transition, missing, overlap143):
    fig, axs = plt.subplots(2, 2, figsize=(8.75, 6.35), constrained_layout=True)

    # A: membership transition counts.
    ax = axs[0, 0]
    cats = [
        (True, True, "Old complete / new complete", GREEN),
        (True, False, "Old complete / new incomplete", RED),
        (False, True, "Old incomplete / new complete", BLUE),
        (False, False, "Old incomplete / new incomplete", LIGHT),
    ]
    counts = []
    labels = []
    cols = []
    for old, new, lab, col in cats:
        counts.append(int((transition.old_null_complete.eq(old) & transition.new_null_complete.eq(new)).sum()))
        labels.append(lab)
        cols.append(col)
    y = np.arange(4)
    ax.barh(y, counts, color=cols, edgecolor=INK, linewidth=.55)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    for yy, v in zip(y, counts):
        ax.text(v+.8, yy, str(v), va="center", fontsize=6.5)
    ax.set_xlabel("Compounds")
    ax.set_title("Old N=172 to current complete-case N=143", loc="left")
    tidy_axis(ax, "x")
    panel_label(ax, "A")

    # B: missing-term counts.
    ax = axs[0, 1]
    c = missing.residue.value_counts().sort_values()
    y = np.arange(len(c))
    ax.barh(y, c.values, color=ORANGE, edgecolor=INK, linewidth=.55)
    ax.set_yticks(y, c.index)
    for yy, v in zip(y, c.values):
        ax.text(v+.7, yy, str(v), va="center", fontsize=6.5)
    ax.set_xlabel("Missing compound-residue terms")
    ax.set_title("Why 71 of 214 cases are incomplete", loc="left")
    ax.text(.99, .03, "76 terms; absent values are not zero",
            transform=ax.transAxes, ha="right", color=MID, fontsize=6.2)
    tidy_axis(ax, "x")
    panel_label(ax, "B")

    # C: activity composition of current complete vs excluded.
    ax = axs[1, 0]
    groups = [("Complete N=143", transition.new_null_complete),
              ("Excluded N=71", ~transition.new_null_complete)]
    vals, lows, highs, ns, ks = [], [], [], [], []
    for _, mask in groups:
        n = int(mask.sum())
        k = int((transition.loc[mask, "experimental_ic50_nm"] <= 100).sum())
        lo, hi = wilson(k, n)
        vals.append(100*k/n); lows.append(100*lo); highs.append(100*hi); ns.append(n); ks.append(k)
    x = np.arange(2)
    ax.bar(x, vals, color=[GREEN, LIGHT], edgecolor=INK, linewidth=.6, width=.58)
    ax.errorbar(x, vals, yerr=[np.array(vals)-np.array(lows), np.array(highs)-np.array(vals)],
                fmt="none", ecolor=INK, elinewidth=.8, capsize=2.2)
    for xx, v, k, n in zip(x, vals, ks, ns):
        ax.text(xx, v+4.8, f"{k}/{n}", ha="center", fontsize=6.4)
    ax.set_xticks(x, [g[0] for g in groups])
    ax.set_ylim(0, max(highs)+12)
    ax.set_ylabel("IC50 <= 100 nM (%)")
    ax.set_title("Activity composition after completeness filtering", loc="left")
    tidy_axis(ax, "y")
    panel_label(ax, "C")

    # D: N143 fixed-method selected-set overlap.
    ax = axs[1, 1]
    methods = ["Boltz-2", "Leu26", "Pair", "Triad"]
    arr = overlap143.loc[methods, methods].to_numpy()
    im = ax.imshow(arr, vmin=0, vmax=1, cmap="Purples")
    ax.set_xticks(range(4), methods, rotation=28, ha="right")
    ax.set_yticks(range(4), methods)
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{arr[i,j]:.2f}", ha="center", va="center",
                    color="white" if arr[i,j] > .62 else INK, fontsize=6.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=.03)
    cb.set_label("Tie-aware weighted Jaccard")
    ax.set_title("Top-43 overlap in the N=143 universe", loc="left")
    panel_label(ax, "D")

    export_figure(fig, "Figure3_S4_N143_scope_missingness_and_overlap")


def write_documents(tables, triad560, rank_context, transition, missing):
    now = datetime.now(timezone.utc).isoformat()
    source_rows = []
    mapping = {
        "Figure3_S2_N213_benchmark_robustness": [SRC_N213, SRC_N213_GAINS, SRC_N213_CUTOFF],
        "Figure3_S3_N143_exhaustive_combinatorial_context": [SRC_N143_NPZ, SRC_N143_META, SRC_PAIR120, SRC_THIRD14],
        "Figure3_S4_N143_scope_missingness_and_overlap": [SRC_TRANSITION, SRC_MISSING, SRC_N143_NPZ, SRC_N143_META],
    }
    for output, sources in mapping.items():
        for source in sources:
            source_rows.append({"output": output, "source": str(source), "source_sha256": sha256(source)})
    pd.DataFrame(source_rows).to_csv(ROOT / "SOURCE_MAP.csv", index=False)

    scope = {
        "status": "PASS",
        "built_utc": now,
        "figure3_F_to_I": {
            "N": 213, "active_IC50_le_100nM": 98, "top30_K": 64,
            "identity_exclusion": "1-7-6 excluded because the simulated structure is mismatched to the registered 940 nM endpoint",
        },
        "figure3_J_K_and_exhaustive_combinatorics": {
            "N": 143, "active_IC50_le_100nM": 70, "top30_K": 43,
            "complete_case_rule": "all 16 prespecified residue contributions present",
            "all_pairs": 120, "all_triads": 560, "conditional_third_residues": 14,
            "identity_exclusion_effect": "1-7-6 is not in the N143 complete-case set; membership is unchanged by the separate N213 identity exclusion",
        },
        "forbidden_mixing": [
            "No N172 energy values are used.",
            "N213 benchmark results are not relabeled as N143 combinatorial results.",
            "Missing residue contributions are not imputed as zero.",
        ],
    }
    (ROOT / "SCOPE_ASSERTIONS.json").write_text(json.dumps(scope, indent=2) + "\n")

    fixed_pair = rank_context[(rank_context.method == "Fixed Pair") & (rank_context.metric == "top30_active_fraction")].iloc[0]
    fixed_triad = rank_context[(rank_context.method == "Fixed Triad") & (rank_context.metric == "top30_active_fraction")].iloc[0]
    captions = f"""# Figure 3 supplementary captions (current 2026-09-27 release)

## Figure S1. N=213 benchmark robustness for Figure 3F-I

**A**, Paired group-bootstrap differences between each residue-panel ranking and Boltz-2 across six endpoints. Intervals are descriptive 95% bootstrap intervals; they are not preregistered superiority tests. Proportion differences are shown in percentage points; Spearman differences are multiplied by 100. **B**, recovery at a matched selection budget over experimental IC50 cutoffs. **C**, tie-aware weighted Jaccard overlap among the top 64 compounds; fractional weights are used only when a score tie crosses the K boundary. **D**, leave-one-series-out sensitivity after re-evaluating all rankings on the remaining compounds; scores are not refit and this is not held-out validation. All panels use N=213, 98 compounds with IC50 <=100 nM, K=64, and exclude identity-conflicted compound 1-7-6.

## Figure S2. Exhaustive N=143 residue-panel context for Figure 3J/K

**A**, distribution of top-30% active fraction across all 120 two-residue combinations; all 120 observations are counted, including the two 81.4% pairs previously outside a fixed histogram boundary. **B**, corresponding distribution across all 560 three-residue combinations derived directly from the current 16-residue integer matrix. **C**, fixed Leu26+Phe102 plus each of the other 14 eligible residues. Gln107 changes the top-30% active fraction by 0 pp, although its AUC is rank 1/14; these are distinct endpoints. **D**, percentile positions of the fixed Pair and fixed Triad across their complete exhaustive universes and six prespecified metrics. For top-30% active fraction, the fixed Pair has minimum rank {int(fixed_pair.rank_min)}/120 with {int(fixed_pair.n_at_least_as_good)}/120 combinations at least as good; the fixed Triad has minimum rank {int(fixed_triad.rank_min)}/560 with {int(fixed_triad.n_at_least_as_good)}/560 at least as good. This analysis is an internal exhaustive sensitivity analysis, not an independent prospective validation.

## Figure S3. Complete-case scope, missingness, and selected-set overlap for Figure 3J/K

**A**, transition from the former N=172 complete-case membership to the current N=143 membership: 138 remain complete, 34 become incomplete, 5 become complete, and 37 remain incomplete. **B**, the 76 absent compound-residue terms among all 214 stress compounds. Absence means that the residue was outside that case's accepted scan output and must not be interpreted as zero energy. **C**, observed activity composition in the current complete and excluded subsets with Wilson 95% intervals; completeness is based only on residue availability. **D**, tie-aware weighted Jaccard overlap among fixed-method top-43 sets in the N=143 universe.

## Scope note

Figure 3F-I and Figure S1 use the corrected N=213 benchmark. Figure 3J/K and Figures S2-S3 use the independent N=143 complete-case universe. The two denominators answer different questions and are never pooled.
"""
    (ROOT / "CAPTIONS.md").write_text(captions)

    readme = """# Figure 3 supplementary package — current 2026-09-27 release

This directory is the current SI companion for Figure 3. It replaces the older withheld SI figures and keeps two required analysis universes explicit:

- **Benchmark robustness (Figure 3F-I):** N=213, 98 active at IC50 <=100 nM, top-30% K=64, compound `1-7-6` excluded.
- **Residue combinatorics (Figure 3J/K):** N=143 complete cases, 70 active, K=43, 16 prespecified residues, 120 pairs, 560 triads, and 14 additions to the fixed Pair.

## Contents

- `figures/`: three SI figures in PDF, SVG, 600 dpi PNG, and 600 dpi LZW-compressed TIFF.
- `tables/`: canonical CSV tables plus an indexed Excel workbook.
- `scripts/build_figure3_si.py`: complete rebuild script.
- `scripts/verify_figure3_si.py`: independent release checks.
- `CAPTIONS.md`: manuscript-ready captions.
- `SOURCE_MAP.csv`, `SCOPE_ASSERTIONS.json`, `PROVENANCE.json`: source and scope records.
- `qa/QA_REPORT.json` and `qa/QA_SUMMARY.md`: release validation.
- `MANIFEST_SHA256.csv`: hashes of every released artifact except the manifest itself.

## Interpretation boundary

The exhaustive combination analyses demonstrate where the fixed Pair and Triad sit among all allowed panels on the same N=143 data. They do not constitute an independent validation set or evidence that Q107 uniquely improves the top-30% endpoint. Gln107 has 0 pp top-30% gain over Pair but rank 1/14 AUC among conditional third residues.

## Rebuild

Run with the Python recorded in `PROVENANCE.json`:

```bash
/opt/anaconda3/bin/python scripts/build_figure3_si.py
/opt/anaconda3/bin/python scripts/verify_figure3_si.py
```
"""
    (ROOT / "README.md").write_text(readme)

    provenance = {
        "built_utc": now,
        "script": str(SCRIPT_DIR / "build_figure3_si.py"),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "note_on_runtime": "The Codex bundled Python lacked matplotlib; the installed Anaconda Python was used for rendering and is recorded here.",
        "packages": {
            "numpy": np.__version__, "pandas": pd.__version__, "matplotlib": mpl.__version__,
        },
        "sources": [{"path": str(p), "sha256": sha256(p)} for p in SOURCES],
        "derived_counts": {
            "N213": 213, "N213_active": 98, "N213_K": 64,
            "N143": 143, "N143_active": 70, "N143_K": 43,
            "pairs": 120, "conditional_thirds": 14, "triads": len(triad560),
            "transition_rows": len(transition), "missing_terms": len(missing),
        },
    }
    (ROOT / "PROVENANCE.json").write_text(json.dumps(provenance, indent=2) + "\n")


def write_qa_and_manifest(tables):
    checks = {}
    checks["all_sources_exist"] = all(p.exists() for p in SOURCES)
    checks["expected_csv_count"] = len(list(TAB_DIR.glob("*.csv"))) >= 15
    checks["three_figure_stems"] = len(list(FIG_DIR.glob("*.pdf"))) >= 3
    checks["all_four_formats"] = all(len(list(FIG_DIR.glob(f"{stem}.*"))) == 4 for stem in [
        "Figure3_S2_N213_benchmark_robustness",
        "Figure3_S3_N143_exhaustive_combinatorial_context",
        "Figure3_S4_N143_scope_missingness_and_overlap",
    ])
    checks["no_missing_summary_cells"] = all(not df.isna().any().any() for name, df in tables.items()
                                                    if name not in {"S01_N213_compound_scores.csv", "S08_N143_complete_case_transition.csv"})
    checks["all_560_triads"] = len(tables["S12_N143_all560_triads.csv"]) == 560
    checks["all_120_pairs"] = len(tables["S10_N143_all120_pairs.csv"]) == 120
    checks["all_14_additions"] = len(tables["S11_N143_pair_plus14_residues.csv"]) == 14
    checks["N213_membership"] = len(tables["S05_N213_topK_membership.csv"]) == 213
    checks["N143_membership"] = len(tables["S14_N143_fixed_methods_topK_membership.csv"]) == 143
    checks["weight_sums_N213"] = all(np.isclose(tables["S05_N213_topK_membership.csv"][f"{m}_topK_weight"].sum(), 64)
                                             for m in ["Boltz-2", "Leu26", "Pair", "Triad"])
    checks["weight_sums_N143"] = all(np.isclose(tables["S14_N143_fixed_methods_topK_membership.csv"][f"{m}_topK_weight"].sum(), 43)
                                             for m in ["Boltz-2", "Leu26", "Pair", "Triad"])
    checks["scope_files_present"] = all((ROOT / p).exists() for p in [
        "README.md", "CAPTIONS.md", "SOURCE_MAP.csv", "SCOPE_ASSERTIONS.json", "PROVENANCE.json"
    ])

    image_qa = []
    for p in sorted(list(FIG_DIR.glob("*.png")) + list(FIG_DIR.glob("*.tif"))):
        with Image.open(p) as im:
            dpi = im.info.get("dpi", (None, None))
            image_qa.append({"file": p.name, "width_px": im.width, "height_px": im.height,
                             "dpi_x": None if dpi[0] is None else float(dpi[0]),
                             "dpi_y": None if dpi[1] is None else float(dpi[1]),
                             "mode": im.mode})
            checks[f"raster_size_{p.name}"] = im.width >= 3000 and im.height >= 2000
            if p.suffix == ".tif":
                checks[f"tiff_compression_{p.name}"] = str(im.info.get("compression", "")).lower() in {"tiff_lzw", "5"}

    status = "PASS" if all(checks.values()) else "FAIL"
    qa = {"status": status, "checked_utc": datetime.now(timezone.utc).isoformat(),
          "checks": checks, "images": image_qa}
    (QA_DIR / "QA_REPORT.json").write_text(json.dumps(qa, indent=2) + "\n")
    failed = [k for k, v in checks.items() if not v]
    summary = f"# Figure 3 SI QA\n\n**Status: {status}**\n\n"
    summary += f"- Checks: {len(checks)}\n- Failed: {len(failed)}\n"
    if failed:
        summary += "- Failures: " + ", ".join(failed) + "\n"
    summary += "- Scope: N213 benchmark and N143 complete-case combinatorics kept separate.\n"
    summary += "- Exhaustive coverage: 120/120 pairs, 560/560 triads, 14/14 conditional additions.\n"
    summary += "- Raster outputs: 600 dpi request, minimum 3000 x 2000 pixels verified.\n"
    (QA_DIR / "QA_SUMMARY.md").write_text(summary)
    assert status == "PASS", failed

    rows = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and p.name != "MANIFEST_SHA256.csv":
            rows.append({"relative_path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": sha256(p)})
    pd.DataFrame(rows).to_csv(ROOT / "MANIFEST_SHA256.csv", index=False)


def main():
    for d in (FIG_DIR, TAB_DIR, SCRIPT_DIR, QA_DIR):
        d.mkdir(parents=True, exist_ok=True)
    configure_style()
    (n213, metrics213, pair120, third14, meta143, ids, residues, matrix,
     transition, missing) = load_and_assert_sources()
    _, membership213, overlap213, logo213 = derive_n213(n213)
    triad560, rank_context, membership143, overlap143 = derive_n143(
        meta143, ids, residues, matrix, pair120, third14)
    tables = write_tables(n213, metrics213, pair120, third14, transition, missing,
                          membership213, overlap213, logo213, triad560, rank_context,
                          membership143, overlap143)
    plot_s1(overlap213, logo213)
    plot_s2(pair120, third14, triad560, rank_context)
    plot_s3(transition, missing, overlap143)
    write_documents(tables, triad560, rank_context, transition, missing)
    write_qa_and_manifest(tables)
    print(json.dumps({"status": "PASS", "root": str(ROOT), "figures": 3,
                      "csv_tables": 15, "triads": len(triad560)}, indent=2))


if __name__ == "__main__":
    main()
