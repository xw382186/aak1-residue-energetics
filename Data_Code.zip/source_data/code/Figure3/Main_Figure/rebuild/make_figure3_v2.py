#!/usr/bin/env python3
"""
Figure 3 for the AAK1 residue-panel study.  N = 214.

Layout follows the agreed reference: a full-height "Analysis outline" rail on
the left, a hairline divider, and nine data panels plus one reserved slot on the
right.  Panel titles are a left-aligned block -- letter, bold title, grey
sub-line -- so no title is centred over an axes and no width is wasted on a
letter gutter.  Every panel that carries a number a reader has to judge also
carries its baseline.

    A  Analysis outline          the whole derivation as a picture
    B  Binding-site context      reserved for the pocket render
    C  Residue association       point-range, strong cohort n = 139
    D  Hotspot prevalence        bars + Wilson CI, top-potency subset n = 15
    E  Crystal-start MD/ASGBIE   heatmap, 11 co-crystal structures
    F  Top-30% active fraction   point-range, stress cohort n = 214
    G  Activity-cutoff sensitivity  matched-K recovery vs a random curve
    H  Paired gain over Boltz-2  point-range on the paired bootstrap
    I  ROC discrimination        curves, AUC printed in the series colour
    J  Could other pairs work?   120 enumerated pairs, split by Leu26
    K  Which third residue helps?  14 candidates, as change from the Pair

Typography and rule weights are Figure 2's, imported verbatim from
figure2_style; the two figures also render at exactly the same page width, so
they take the same production scale.

Running prose lives in FIGURE3_ANNOTATIONS.md, ready for the caption.
Data: Figure3_derived_data/, produced by build_figure3_data.py, which reproduces
every published value in the N=214 R1 audit before deriving anything new.
"""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Arc, Ellipse, FancyBboxPatch, Polygon, Rectangle
from matplotlib.transforms import Bbox
from scipy.stats import gaussian_kde

import figure2_style as st
import figure_layout as fl
from figure2_style import (ANNOT_GREY, EDGE, ERR_KW, FS_ANNOT, FS_LEGEND_DENSE,
                           FS_LETTER, FS_NOTE, FS_TICK_DENSE, FS_TITLE, GRID_GREY,
                           LW_CURVE, LW_EDGE, LW_GRID, LW_REF, LW_REF_THIN, LW_ZERO,
                           REF_GREY)

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
# R2, 2026-09-07. Built by build_figure3_data_R2.py from the audited
# package; Figure3_derived_data/ is kept beside it as the R1 snapshot.
DATA = HERE / "Figure3_derived_data_R2"
OUT = HERE / "figure3_output_v2"
PANELS = OUT / "panels"
PLOTTED = OUT / "panel_source_data"
for d in (OUT, PANELS, PLOTTED):
    d.mkdir(parents=True, exist_ok=True)


def clear_generated():
    """Rebuilt from scratch on every run, so a file from an earlier layout can
    never survive into a shipped package.  Called from main, never on import --
    the verifier imports this module and must not delete what it is checking."""
    for d in (PANELS, PLOTTED):
        for f in d.iterdir():
            f.unlink()


# ==========================================================================
# Page
# ==========================================================================
# The printed page is a fixed budget, so Figure 3 renders at exactly the width
# of the frozen Figure 2 (222.19 mm).  Same width means the same production
# scale factor, which is the only way frozen type sizes stay frozen on paper.
PAGE_H_MM = 168.00
RAIL = (0.008, 0.135)            # the analysis outline

# Three rows, one per step of the analysis, so the outline on the left and the
# panels on the right say the same thing at the same height.  Each entry is
# (title baseline, axes top, axes bottom); all three rows are the same height.
# Only the panel letters sit above the axes now -- every title and sub-line
# moved into the caption -- so the header band is a letter tall, not a letter
# plus two lines, and the page is 18 mm shorter for it.
ROWS = [(0.9568, 0.9416, 0.7494),     # step 1, derive:  B C D E
        (0.6482, 0.6329, 0.4407),     # step 2, compare: F G H I
        (0.3182, 0.3030, 0.1108)]     # step 3, others:  J K
LEGEND_Y = 0.3721                # shared method key, in the gap below row 2
SUBTITLE_DY = 0.0158             # grey sub-line, below the title baseline

RAIL_BOTTOM = 0.0110
RAIL_TOP = ROWS[0][1]
RAIL_STEP = [r[1] for r in ROWS]      # each step level with the row it explains

METHODS = ["Boltz-2", "Leu26", "Pair", "Triad"]
METHOD_COLORS = {"Boltz-2": "#4878D0", "Leu26": "#EE854A",
                 "Pair": "#956CB4", "Triad": "#D65F5F"}
METHOD_MARKERS = {"Boltz-2": "o", "Leu26": "s", "Pair": "D", "Triad": "^"}
METHOD_LEGEND = {"Boltz-2": "Boltz-2", "Leu26": "Leu26", "Pair": "Pair",
                 "Triad": "Triad"}

RESIDUES = ["26LEU", "102PHE", "107GLN"]
RESIDUE_COLORS = {"26LEU": "#EE854A", "102PHE": "#956CB4", "107GLN": "#D65F5F"}
RESIDUE_SHORT = {"26LEU": "L26", "102PHE": "F102", "107GLN": "Q107"}
REMAINDER_GREY = "#E7EAF0"
RANDOM_GREY = "#9AA1AC"          # every random-selection baseline in the figure
RULE_GREY = "#C8CCD2"

# Diverging, blue through neutral to red, because this readout has a real
# midpoint: 1 kcal/mol is the hotspot criterion the panel is about.  Cool cells
# fall short of it, warm cells clear it, and the neutral band is the threshold
# itself -- so the colour says what the bold type says, twice over.
HEAT_CENTER = 1.0
HEAT_CMAP = LinearSegmentedColormap.from_list("house_diverging", [
    "#2C4F8E", "#4878D0", "#9DBAE4", "#DCE7F6", "#F4F4F2",
    "#F8DEDE", "#E29391", "#D65F5F", "#A63C3B"])


def pretty_residue(code: str) -> str:
    """'107GLN' -> 'Q107': one residue-naming convention across the whole figure."""
    num = "".join(c for c in code if c.isdigit())
    aa = "".join(c for c in code if c.isalpha())
    one = {"ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C", "GLN": "Q",
           "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I", "LEU": "L", "LYS": "K",
           "MET": "M", "PHE": "F", "PRO": "P", "SER": "S", "THR": "T", "TRP": "W",
           "TYR": "Y", "VAL": "V"}
    return f"{one.get(aa.upper(), aa.capitalize())}{num}"


def asym_err(point, lo, hi):
    point, lo, hi = (np.asarray(v, float) for v in (point, lo, hi))
    return np.vstack([np.clip(point - lo, 0, None), np.clip(hi - point, 0, None)])


def load():
    rd = lambda n: pd.read_csv(DATA / n, encoding="utf-8-sig")
    return dict(evidence=rd("Figure3_convergent_evidence.csv"),
                stress=rd("Figure3_stress_metrics_N214.csv"),
                cutoff=rd("Figure3_cutoff_sensitivity_N214.csv"),
                crystal=rd("Figure3_crystal_heatmap.csv"),
                roc=rd("Figure3_roc_curves_N214.csv"),
                pair_null=rd("Figure3_pair_null_N172.csv"),
                triad_null=rd("Figure3_conditional_triad_null_N172.csv"),
                pair_pct=rd("Figure3_pair_percentile_summary.csv"),
                gln_pct=rd("Figure3_gln107_percentile_summary.csv"),
                gain=rd("Figure3_paired_gain_top30.csv"),
                gains=rd("Figure3_paired_gain_intervals.csv"),
                sweep=rd("Figure3_residue_threshold_sweep_N213.csv"),
                scope=json.loads((DATA / "Figure3_panelA_scope.json").read_text()))


def evidence_frame(D):
    e = D["evidence"].set_index("residue").loc[RESIDUES].reset_index()
    e["row_y"] = np.arange(len(e))[::-1]
    return e


def stress_frame(D, value):
    s = D["stress"].set_index("method").loc[METHODS].reset_index()
    s["row_y"] = np.arange(len(s))[::-1]
    return s.rename(columns={value: "value", f"{value}_ci_low": "ci_low",
                             f"{value}_ci_high": "ci_high"})


bare = fl.bare


# ==========================================================================
# A -- analysis outline                              (schematic, Fig 1A)
# ==========================================================================
def _dots(ax, cx, cy, w, h, n, color, seed, r=0.030, zorder=3):
    """A pile of compounds.  Deterministic, so the cartoon never reshuffles."""
    rng = np.random.default_rng(seed)
    for _ in range(n):
        ax.add_patch(Ellipse((cx + (rng.random() - 0.5) * w,
                              cy + (rng.random() - 0.5) * h),
                             r, r * RAIL_ASPECT, facecolor=color, edgecolor="none",
                             zorder=zorder))


# What the outline would say with no data behind it. Every one of these is
# overwritten from Figure3_panelA_scope.json, which is panel A's designated
# plotting source in the R2 panel map; they exist only so the rail still draws
# when a panel is exported on its own without the figure's data.
SCOPE_DEFAULT = {"strong_N": 139, "crystal_N": 11, "fixed_stress_N": 214,
                 "top30_K": 65, "n_eligible_residues": 16, "n_pairs": 120,
                 "n_conditional_thirds": 14, "null_N": 172}


def stage_rail(ax, D=None):
    """The analysis as a picture: build the panels, compare four rankings, then
    ask whether other residues would have done as well.

    Every number printed here is read from the scope file, so the outline cannot
    drift away from the denominators the data panels are drawn on.
    """
    sc = dict(SCOPE_DEFAULT)
    if D is not None and "scope" in D:
        sc.update(D["scope"])
    ax.set_xlim(0, 1)
    ax.set_ylim(RAIL_BOTTOM, RAIL_TOP)
    bare(ax)

    def step(y, n, text):
        ax.add_patch(Ellipse((0.062, y), 0.105, 0.105 * RAIL_ASPECT,
                             facecolor="#22262C", edgecolor="none", zorder=5,
                             clip_on=False))
        ax.text(0.062, y, str(n), ha="center", va="center", fontsize=FS_NOTE,
                color="white", fontweight="bold", zorder=6, clip_on=False)
        ax.text(0.140, y, text, ha="left", va="center", fontsize=FS_ANNOT,
                fontweight="bold", color="#22262C", zorder=5, clip_on=False)

    def note(y, text, weight="normal", color=ANNOT_GREY, size=FS_NOTE):
        ax.text(0.50, y, text, ha="center", va="top", fontsize=size, color=color,
                linespacing=1.45, fontweight=weight, zorder=5)

    def arrow(y0, y1, x=0.50):
        ax.annotate("", xy=(x, y1), xytext=(x, y0), zorder=4,
                    arrowprops=dict(arrowstyle="-|>", color="#B4BAC4", lw=1.0,
                                    shrinkA=0, shrinkB=0))

    def node(x, y, color, r=0.105):
        ax.add_patch(Ellipse((x, y), r, r * RAIL_ASPECT, facecolor=color,
                             edgecolor=EDGE, linewidth=LW_EDGE, zorder=5))

    # ---- 1. build the residue panels --------------------------------------
    # Every step is level with the row of panels it explains, and each section
    # is spaced to fill that row rather than to sit as close as it can.
    step(RAIL_STEP[0], 1, "Build residue panels")
    hy = 0.9010

    def ring(cx, cy, r, inner=False, stub=0.0):
        """One cartoon ring, a regular hexagon once it reaches paper.

        x and y are on different scales in this rail, so the vertices are
        generated round and then squashed by RAIL_ASPECT -- the same trick the
        node() helper uses to keep its circles circular.
        """
        pts = [(cx + r * np.cos(a), cy + r * RAIL_ASPECT * np.sin(a))
               for a in np.deg2rad(np.arange(30, 390, 60))]
        ax.add_patch(Polygon(pts, closed=True, facecolor="white",
                             edgecolor="#B4BAC4", linewidth=LW_EDGE, zorder=3))
        if inner:
            ax.add_patch(Ellipse((cx, cy), r * 0.92, r * 0.92 * RAIL_ASPECT,
                                 facecolor="none", edgecolor="#CBD2DC",
                                 linewidth=LW_EDGE, zorder=4))
        if stub:
            ax.plot([cx + r * 0.87, cx + r * 0.87 + stub], [cy, cy],
                    color="#B4BAC4", lw=LW_EDGE, zorder=3,
                    solid_capstyle="round")
            ax.add_patch(Ellipse((cx + r * 0.87 + stub, cy), 0.020,
                                 0.020 * RAIL_ASPECT, facecolor="#B4BAC4",
                                 edgecolor="none", zorder=4))

    # four cartoon compounds where the single hexagon used to sit, one of them
    # a fused pair, so the glyph reads as a set rather than as one molecule
    # the middle two share an edge, so their centres sit r*sqrt(3) apart --
    # any closer and the pair reads as two rings that happen to overlap
    ring(0.048, hy, 0.032, inner=True)
    ring(0.138, hy, 0.032)
    ring(0.193, hy, 0.032, inner=True)
    ring(0.285, hy, 0.032, stub=0.022)

    # the crystal starts: the supplied surface, as a small stack
    if CRYSTAL_ICON.exists():
        icon = plt.imread(CRYSTAL_ICON)
        ih, iw = icon.shape[0], icon.shape[1]
        w = 0.160
        h = w * (ih / iw) * RAIL_ASPECT
        for dx, dy, alpha, z in ((-0.030, -0.0060, 0.30, 3),
                                 (-0.015, -0.0030, 0.55, 4),
                                 (0.0, 0.0, 1.00, 5)):
            ax.imshow(icon, extent=(0.645 - w / 2 + dx, 0.645 + w / 2 + dx,
                                    hy - h / 2 + dy, hy + h / 2 + dy),
                      aspect="auto", interpolation="antialiased",
                      alpha=alpha, zorder=z)
    ax.text(0.180, 0.8790, f"{sc['strong_N']}\ncompounds", ha="center", va="top",
            fontsize=FS_NOTE,
            color=ANNOT_GREY, linespacing=1.40, zorder=5)
    ax.text(0.645, 0.8790, f"{sc['crystal_N']} crystal\nstarts", ha="center", va="top",
            fontsize=FS_NOTE, color=ANNOT_GREY, linespacing=1.40, zorder=5)

    arrow(0.8440, 0.8260)
    node(0.250, 0.8060, RESIDUE_COLORS["26LEU"])
    node(0.470, 0.8060, RESIDUE_COLORS["102PHE"])
    ax.plot([0.250, 0.470], [0.8060, 0.8060], color=RULE_GREY, lw=1.1, zorder=4)
    ax.text(0.640, 0.8060, "Pair", ha="left", va="center", fontsize=FS_NOTE,
            fontweight="bold", zorder=5)

    node(0.170, 0.7590, RESIDUE_COLORS["26LEU"])
    node(0.360, 0.7590, RESIDUE_COLORS["102PHE"])
    node(0.550, 0.7590, RESIDUE_COLORS["107GLN"])
    ax.plot([0.170, 0.550], [0.7590, 0.7590], color=RULE_GREY, lw=1.1, zorder=4)
    ax.text(0.700, 0.7590, "Triad", ha="left", va="center", fontsize=FS_NOTE,
            fontweight="bold", zorder=5)
    note(0.7350, "L26 + F102 (+ Q107)")

    # ---- 2. compare four rankings -----------------------------------------
    arrow(0.7080, 0.6440)
    step(RAIL_STEP[1], 2, "Compare four rankings")
    for r in range(2):
        for c in range(9):
            ax.add_patch(Rectangle((0.075 + c * 0.098, 0.5940 - r * 0.0210),
                                   0.070, 0.0140, facecolor="#DCE6F5",
                                   edgecolor="none", zorder=3))
    note(0.5520, f"Same {sc['fixed_stress_N']} compounds", weight="bold",
         color="#22262C")

    for i, m in enumerate(METHODS):
        y = 0.5140 - i * 0.0290
        ax.plot([0.090], [y], marker=METHOD_MARKERS[m], ms=4.0,
                color=METHOD_COLORS[m], mec="white", mew=0.6, zorder=5)
        ax.text(0.175, y, m, ha="left", va="center", fontsize=FS_NOTE, zorder=5)
        ax.annotate("", xy=(0.640, y), xytext=(0.520, y), zorder=4,
                    arrowprops=dict(arrowstyle="-|>", color=METHOD_COLORS[m],
                                    lw=0.9, shrinkA=0, shrinkB=0))
        ax.add_patch(FancyBboxPatch((0.680, y - 0.0108), 0.180, 0.0216,
                                    boxstyle="round,pad=0.002,rounding_size=0.008",
                                    facecolor="white", edgecolor=METHOD_COLORS[m],
                                    linewidth=LW_EDGE, zorder=4))
        ax.text(0.770, y, str(sc["top30_K"]), ha="center", va="center", fontsize=FS_NOTE,
                color=METHOD_COLORS[m], zorder=5)
    note(0.4010, "Enrichment over random\nacross activity cutoffs")

    # ---- 3. try other residues --------------------------------------------
    arrow(0.3600, 0.3150)
    step(RAIL_STEP[2], 3, "Try other residues")
    side = int(round(sc["n_eligible_residues"] ** 0.5))
    assert side * side == sc["n_eligible_residues"], sc["n_eligible_residues"]
    for r in range(side):
        for c in range(side):
            k = r * side + c
            col = (RESIDUE_COLORS["26LEU"] if k == 0 else
                   RESIDUE_COLORS["102PHE"] if k == 1 else "#DDE0E6")
            node(0.185 + c * 0.210, 0.2620 - r * 0.0270, col, r=0.090)
    note(0.1560, f"{sc['n_eligible_residues']} candidate residues")
    note(0.1290, f"Choose any 2  →  {sc['n_pairs']} pairs")
    note(0.1020, f"Fixed Pair + 1  →  {sc['n_conditional_thirds']} choices")
    note(0.0700, f"{sc['null_N']} of the {sc['fixed_stress_N']} compounds",
         weight="bold", color="#22262C")
    note(0.0430, f"with all {sc['n_eligible_residues']} scores available")


# ==========================================================================
# B -- reserved pocket slot
# ==========================================================================
POCKET_IMAGE = HERE / "assets" / "panelB_pocket_4WSQ.png"
# The outline's step-1 icons: a molecular surface standing for the crystal
# starts, drawn small enough to read as a glyph rather than as a structure
# figure, and cartoon rings standing for the compound set.
CRYSTAL_ICON = HERE / "assets" / "railA_crystal_surface.png"


def panel_pocket(ax, D=None):
    """The supplied 4WSQ render, fitted to the panel without distortion.

    The image keeps its own aspect ratio: it is placed inside the panel box at
    whichever of the two dimensions binds, and the leftover stays white, so the
    structure is never stretched to fill a slot.
    """
    bare(ax)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    if POCKET_IMAGE.exists():
        # The render gets the whole panel: the colour key sits below the axes,
        # in the band where the other panels of this row put their x labels.
        img = plt.imread(POCKET_IMAGE)
        ih, iw = img.shape[0], img.shape[1]
        pos = ax.get_position()
        box_w = pos.width * ax.figure.get_figwidth()
        box_h = pos.height * ax.figure.get_figheight()
        scale = min(box_w / iw, box_h / ih)
        w, h = iw * scale / box_w, ih * scale / box_h
        ax.imshow(img, extent=(0.5 - w / 2, 0.5 + w / 2, 0.5 - h / 2, 0.5 + h / 2),
                  aspect="auto", interpolation="antialiased", zorder=2)
    else:
        ax.add_patch(Rectangle((0.01, 0.01), 0.98, 0.98, facecolor="#FAFAFA",
                               edgecolor="#B8BCC4", linewidth=0.8,
                               linestyle=(0, (4, 3)), zorder=1))
        ax.text(0.5, 0.5, "Pocket view reserved", ha="center", va="center",
                fontsize=FS_ANNOT, color=ANNOT_GREY)
    for i, res in enumerate(RESIDUES):
        x = 0.10 + i * 0.32
        ax.plot([x], [-0.085], marker="o", ms=4.6, color=RESIDUE_COLORS[res],
                mec=EDGE, mew=LW_EDGE, zorder=3, clip_on=False)
        ax.text(x + 0.055, -0.085, RESIDUE_SHORT[res], ha="left", va="center",
                fontsize=FS_NOTE, color=ANNOT_GREY, clip_on=False)


# ==========================================================================
# C -- single-residue association                  (point-range, Fig 6A/3A)
# ==========================================================================
def panel_rho(ax, D):
    e = evidence_frame(D)
    ax.errorbar(e["strong_rho"], e["row_y"],
                xerr=asym_err(e["strong_rho"], e["strong_ci_low"], e["strong_ci_high"]),
                fmt="none", zorder=2, **ERR_KW)
    ax.scatter(e["strong_rho"], e["row_y"], s=30,
               c=[RESIDUE_COLORS[r] for r in e["residue"]], marker="o",
               edgecolors=EDGE, linewidths=LW_EDGE, zorder=3)
    ax.set_xlim(0, 0.88)
    ax.set_xticks(np.arange(0, 0.81, 0.4))
    ax.set_ylim(-0.60, len(e) - 0.40)
    ax.set_yticks(e["row_y"])
    ax.set_yticklabels([RESIDUE_SHORT[r] for r in e["residue"]])
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("Spearman $\\rho$")


# ==========================================================================
# D -- top-potency hotspot prevalence        (bars + Wilson, Fig 5D/E, 6E/F)
# ==========================================================================
def panel_prevalence(ax, D):
    e = evidence_frame(D)
    n = int(e["top15_valid"].iloc[0])
    for r in e.itertuples():
        hits = int(r.top15_hits)
        ax.barh(r.row_y, n, height=0.52, color=REMAINDER_GREY, edgecolor="none",
                zorder=2)
        ax.barh(r.row_y, hits, height=0.52, color=RESIDUE_COLORS[r.residue],
                edgecolor=EDGE, linewidth=LW_EDGE, zorder=3)
        ax.errorbar([hits], [r.row_y],
                    xerr=asym_err([hits], [r.top15_wilson_low * n],
                                  [r.top15_wilson_high * n]),
                    fmt="none", zorder=4, **ERR_KW)
        ax.text(0, r.row_y + 0.42, f"{hits}/{n}", ha="left", va="bottom",
                fontsize=FS_NOTE, zorder=4)
    ax.set_xlim(0, n + 1.4)
    ax.set_xticks([0, 5, 10, 15])
    ax.set_ylim(-0.60, len(e) - 0.20)
    ax.set_yticks(e["row_y"])
    ax.set_yticklabels([RESIDUE_SHORT[r] for r in e["residue"]])
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("Compounds\n>1 kcal mol$^{-1}$", linespacing=1.35)


# ==========================================================================
# E -- crystal-derived ASGBIE per structure               (heatmap, Fig 5F)
# ==========================================================================
def panel_crystal(ax, D):
    m = D["crystal"].set_index("residue").loc[RESIDUES]
    vals = m.to_numpy(float)
    nrow, ncol = vals.shape
    # pcolormesh, not imshow: the cells stay vector in the PDF, so the whole
    # figure is resolution-independent at press.
    im = ax.pcolormesh(np.arange(ncol + 1) - 0.5, np.arange(nrow + 1) - 0.5, vals,
                       cmap=HEAT_CMAP,
                       norm=TwoSlopeNorm(vcenter=HEAT_CENTER, vmin=0.0, vmax=3.2),
                       edgecolors="white", linewidth=0.5)
    ax.set_xlim(-0.5, ncol - 0.5)
    ax.set_ylim(nrow - 0.5, -0.5)
    for i in range(nrow):
        for j in range(ncol):
            v = vals[i, j]
            ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=FS_NOTE,
                    color="white" if (v > 2.35 or v < 0.35) else "black",
                    fontweight="bold" if v > 1.0 else "normal")
    ax.set_xticks(range(ncol))
    ax.set_xticklabels(m.columns, fontsize=FS_NOTE, rotation=90, ha="center",
                       va="top")
    ax.set_yticks(range(nrow))
    ax.set_yticklabels([RESIDUE_SHORT[r] for r in RESIDUES])
    ax.tick_params(length=0)
    for sp in ax.spines.values():
        sp.set_visible(False)

    # The bar is carved out of E's own slot instead of being appended to it, so
    # the panel cannot grow past the right edge of the page.
    fig = ax.figure
    pos = ax.get_position()
    fw = fig.get_figwidth()
    cb_w, cb_gap, cb_lab = 0.063 / fw, 0.074 / fw, 0.143 / fw
    ax.set_position([pos.x0, pos.y0, pos.width - cb_w - cb_gap - cb_lab, pos.height])
    cax = fig.add_axes([pos.x1 - cb_w - cb_lab, pos.y0 + 0.06 * pos.height,
                        cb_w, 0.88 * pos.height])
    cb = fig.colorbar(im, cax=cax, ticks=[0, 1, 2, 3])
    cb.solids.set_rasterized(False)   # matplotlib rasterises >50 levels by default
    cb.ax.axhline(HEAT_CENTER, color=ANNOT_GREY, lw=0.7)
    cb.ax.tick_params(labelsize=FS_NOTE, length=2, width=0.7)
    cb.outline.set_linewidth(0.7)


# ==========================================================================
# F -- Top-30% active fraction                        (point-range, Fig 6A)
# ==========================================================================
def panel_top30(ax, D):
    f = stress_frame(D, "top30_active_fraction")
    n = int(f["N"].iloc[0])
    prev = f["n_active_100nM"].iloc[0] / n * 100
    ax.axvline(prev, color=RANDOM_GREY, lw=LW_REF, ls="--", zorder=1)
    for r in f.itertuples():
        ax.errorbar([r.value * 100], [r.row_y],
                    xerr=asym_err([r.value * 100], [r.ci_low * 100],
                                  [r.ci_high * 100]),
                    fmt="none", zorder=2, **ERR_KW)
        ax.scatter([r.value * 100], [r.row_y], s=30, c=METHOD_COLORS[r.method],
                   marker=METHOD_MARKERS[r.method], edgecolors=EDGE,
                   linewidths=LW_EDGE, zorder=3)
        ax.text(1.03, r.row_y, f"{r.value * 100:.1f}", transform=
                ax.get_yaxis_transform(), ha="left", va="center", fontsize=FS_NOTE,
                clip_on=False, zorder=4)
    ax.set_ylim(-0.60, len(f) - 0.40)
    ax.set_yticks(f["row_y"]); ax.set_yticklabels(f["method"])
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(40, 90)
    ax.set_xticks([40, 60, 80])
    ax.set_xlabel("Active fraction (%)")
    ax.text(prev, -0.56, " random", ha="left", va="bottom", fontsize=FS_NOTE,
            color=ANNOT_GREY)


# ==========================================================================
# G -- matched-K recovery across cutoffs               (lines, Fig 3F / 5B)
# ==========================================================================
def panel_matchedk_enrichment(ax, D):
    """Matched-K recovery as enrichment over what random selection would give.

    The raw recovery curve rises from 25 to 250 nM mostly because K rises with
    the cutoff: at 250 nM a random pick already recovers 68% of the actives, so
    four curves between 70 and 80% look alike whatever they are doing.  Dividing
    by that same K/N expectation removes the base rate and leaves the part that
    is selection: at 25 nM the residue panels sit at 2.15x while Boltz-2 is at
    0.39x -- below random -- and by 125 nM every curve has collapsed onto 1.3x.

    Same numbers as the recovery panel, same table; only the base rate is
    divided out.  1.0x is random, and it is drawn as the reference line.
    """
    c = D["cutoff"].sort_values(["method", "ic50_cutoff_nm"])
    # Selecting K at random recovers K/N of the actives, and K moves with the
    # cutoff -- so the baseline is a curve, not a horizontal line.  Without it
    # the rise from 25 to 250 nM reads as skill when most of it is base rate.
    c = c.assign(enrichment=c["matchedK_recovery"] / (c["K"] / c["N"]))
    ax.axhline(1.0, color=RANDOM_GREY, lw=LW_REF, ls="--", zorder=2)
    # below the rule, not above it: every curve but Boltz-2's first point is
    # above 1.0, so the whole strip under the reference at the right is empty
    ax.text(251, 0.96, "random", ha="right", va="top", fontsize=FS_NOTE,
            color=ANNOT_GREY)
    for m in METHODS:
        s = c[c["method"] == m]
        ax.plot(s["ic50_cutoff_nm"], s["enrichment"],
                color=METHOD_COLORS[m], lw=LW_CURVE, marker=METHOD_MARKERS[m],
                ms=3.4, mec="white", mew=0.6, zorder=3)
    ax.set_ylim(0.2, 2.45)
    ax.set_yticks([0.5, 1.0, 1.5, 2.0])
    ax.set_yticklabels(["0.5", "1.0", "1.5", "2.0"])
    ax.spines["left"].set_bounds(0.5, 2.0)
    ax.set_ylabel("Enrichment over random ($\\times$)")
    ax.set_xlim(15, 262)
    ax.set_xticks([25, 100, 175, 250])
    ax.set_xlabel("$IC_{50}$ cutoff (nM)")
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# H -- how strict does the hotspot threshold have to be?   (threshold sweep)
# ==========================================================================
# Thin evidence is drawn thin: below this many retained compounds one molecule
# moves the point by more than five percentage points, so the curve is dashed
# and its markers hollow rather than left to look like the rest of the line.
SWEEP_MIN_N = 20


def panel_threshold(ax, D):
    """Enrichment against the per-residue hotspot threshold, 1 to 2 kcal/mol.

    The gates are nested -- Leu26, then the Pair, then the Triad -- and each is
    drawn against a Boltz-2 that is allowed to keep the same number of
    compounds at that threshold.  That reference is the point of the panel: a
    gate that keeps fewer, better compounds is not thereby better than a ranking
    given the same budget, and here the three gates sit above the reference at
    every threshold while the reference itself stays flat.

    The threshold is not tuned here; 1 kcal/mol is the hotspot criterion panels
    D and E already use, and the sweep is an exploratory sensitivity with no
    multiplicity adjustment.
    """
    s = D["sweep"]
    ax.axhline(1.0, color=RANDOM_GREY, lw=LW_REF, ls="--", zorder=2)
    ax.text(1.005, 1.006, "random", ha="left", va="bottom", fontsize=FS_NOTE,
            color=ANNOT_GREY)

    ref = s[s["gate"] == "Pair"].sort_values("threshold_kcal_mol")
    ax.plot(ref["threshold_kcal_mol"], ref["same_budget_boltz_enrichment"],
            color=METHOD_COLORS["Boltz-2"], lw=LW_CURVE,
            marker=METHOD_MARKERS["Boltz-2"], ms=3.4, mec="white", mew=0.6,
            zorder=3)

    for gate in ("Leu26", "Pair", "Triad"):
        g = s[s["gate"] == gate].sort_values("threshold_kcal_mol")
        thin = g["n_retained"] < SWEEP_MIN_N
        ax.plot(g["threshold_kcal_mol"], g["enrichment"], color=METHOD_COLORS[gate],
                lw=LW_CURVE, zorder=4, alpha=0.95)
        if thin.any():   # redraw the thin tail dashed, over the solid line
            t = g[thin | thin.shift(1, fill_value=False)]
            ax.plot(t["threshold_kcal_mol"], t["enrichment"],
                    color="white", lw=LW_CURVE + 0.5, zorder=5)
            ax.plot(t["threshold_kcal_mol"], t["enrichment"],
                    color=METHOD_COLORS[gate], lw=LW_CURVE, ls=":", zorder=6)
        ax.plot(g.loc[~thin, "threshold_kcal_mol"], g.loc[~thin, "enrichment"],
                lw=0, marker=METHOD_MARKERS[gate], ms=3.4,
                color=METHOD_COLORS[gate], mec="white", mew=0.6, zorder=7)
        ax.plot(g.loc[thin, "threshold_kcal_mol"], g.loc[thin, "enrichment"],
                lw=0, marker=METHOD_MARKERS[gate], ms=3.4, mfc="white",
                mec=METHOD_COLORS[gate], mew=0.9, zorder=7)

    ax.text(1.985, 1.012, f"open, dotted: n < {SWEEP_MIN_N} retained",
            ha="right", va="bottom", fontsize=FS_NOTE, color=ANNOT_GREY)
    ax.text(1.02, 1.775, "Boltz-2 at the Pair gate's own budget",
            ha="left", va="top", fontsize=FS_NOTE, color=ANNOT_GREY)
    ax.set_ylim(0.985, 1.79)
    ax.set_yticks([1.0, 1.2, 1.4, 1.6])
    ax.set_yticklabels(["1.0", "1.2", "1.4", "1.6"])
    ax.spines["left"].set_bounds(1.0, 1.6)
    ax.set_ylabel("Enrichment over random ($\\times$)")
    ax.set_xlim(0.96, 2.04)
    ax.set_xticks([1.0, 1.25, 1.5, 1.75, 2.0])
    ax.set_xlabel("Per-residue threshold (kcal mol$^{-1}$)")
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# G -- paired gain over Boltz-2                       (point-range, Fig 6A)
# ==========================================================================
def gain_frame(D):
    g = D["gain"].set_index("method").loc[["Leu26", "Pair", "Triad"]].reset_index()
    g["row_y"] = np.arange(len(g))[::-1]
    return g


def panel_gain(ax, D):
    g = gain_frame(D)
    ax.axvline(0, color=REF_GREY, lw=LW_ZERO, ls="--", zorder=1)
    ax.errorbar(g["observed_gain_pp"], g["row_y"],
                xerr=asym_err(g["observed_gain_pp"], g["ci_low_pp"], g["ci_high_pp"]),
                fmt="none", zorder=2, **ERR_KW)
    for r in g.itertuples():
        ax.scatter([r.observed_gain_pp], [r.row_y], s=32,
                   c=METHOD_COLORS[r.method], marker=METHOD_MARKERS[r.method],
                   edgecolors=EDGE, linewidths=LW_EDGE, zorder=4)
    ax.set_ylim(-0.60, len(g) - 0.40)
    ax.set_yticks(g["row_y"]); ax.set_yticklabels(g["method"])
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(-11, 31)
    ax.set_xticks([-10, 0, 10, 20, 30])
    ax.set_xlabel("Gain (pp)")


# ==========================================================================
# I -- ROC curves                        (cumulative curves, Fig 3G/4B/5A)
# ==========================================================================
def panel_roc(ax, D):
    roc = D["roc"]
    auc = D["stress"].set_index("method")["auc_100nM"]
    ax.plot([0, 1], [0, 1], color=RANDOM_GREY, lw=LW_REF_THIN, ls="--", zorder=1)
    ax.text(0.62, 0.555, "random", ha="left", va="top", fontsize=FS_NOTE,
            color=ANNOT_GREY, rotation=39, rotation_mode="anchor")
    for m in METHODS:
        d = roc[roc["method"] == m]
        ax.plot(d["fpr"], d["tpr"], color=METHOD_COLORS[m], lw=LW_CURVE, zorder=3)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xticks([0, 0.5, 1.0]); ax.set_yticks([0, 0.5, 1.0])
    ax.set_xlabel("False-positive rate")
    ax.set_ylabel("True-positive rate")
    # The AUC sits in the series' own colour instead of a legend box: four
    # numbers, four curves, no key to look up.
    ax.text(0.985, 0.315, "AUC", ha="right", va="bottom", fontsize=FS_NOTE,
            color=ANNOT_GREY)
    for i, m in enumerate(METHODS):
        ax.text(0.985, 0.250 - i * 0.068, f"{auc[m]:.3f}", ha="right", va="bottom",
                fontsize=FS_NOTE, color=METHOD_COLORS[m])
    ax.set_axisbelow(True)
    ax.grid(True, color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# J -- 120 eligible pairs, split by Leu26     (stacked histogram, Fig 2E)
# ==========================================================================
def pair_null_frame(D):
    """The 120 enumerated pairs, flagged for Leu26 membership.

    Splitting the null this way is the point of the panel: it turns "the chosen
    Pair is unremarkable" into "the chosen Pair is unremarkable among the pairs
    that contain Leu26, and Leu26 membership is what moves the distribution".
    """
    n = D["pair_null"].copy()
    n["contains_leu26"] = (n["residue_1"] == "26LEU") | (n["residue_2"] == "26LEU")
    return n


def panel_pairnull(ax, D):
    n = pair_null_frame(D)
    pct = D["pair_pct"].set_index("metric").loc["top30_active_fraction"]
    actual = float(pct["actual_value"]) * 100
    prev = float(D["stress"]["n_active_100nM"].iloc[0]) / float(D["stress"]["N"].iloc[0]) * 100
    bins = np.arange(36, 82.1, 2.5)

    with_l = n.loc[n["contains_leu26"], "top30_active_fraction"].to_numpy() * 100
    without = n.loc[~n["contains_leu26"], "top30_active_fraction"].to_numpy() * 100
    ax.hist([without, with_l], bins=bins, stacked=True,
            color=[REMAINDER_GREY, RESIDUE_COLORS["26LEU"]], edgecolor=EDGE,
            linewidth=LW_EDGE, zorder=2,
            label=[f"Without Leu26   {len(without)} pairs, median "
                   f"{np.median(without):.1f}%",
                   f"With Leu26   {len(with_l)} pairs, median "
                   f"{np.median(with_l):.1f}%"])
    ax.axvline(prev, color=RANDOM_GREY, lw=LW_REF, ls="--", zorder=3)
    ax.axvline(actual, color=METHOD_COLORS["Pair"], lw=1.4, ls="--", zorder=4)

    ax.set_xlim(bins[0], bins[-1])
    ax.set_xticks(np.arange(40, 81, 10))
    ax.set_xlabel("Active fraction in top 30% (%)")
    ax.set_ylabel("Number of pairs")
    top = ax.get_ylim()[1]
    ax.set_ylim(0, top * 1.30)
    ax.set_yticks(np.arange(0, top * 1.05, 10))
    ax.text(prev - 0.6, top * 0.42, "random", ha="right", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY, rotation=90)
    ax.text(actual + 1.2, top * 1.20,
            f"Fixed Pair {actual:.1f}%\nrank {int(pct['rank_competition'])}"
            f"/{int(pct['total_null_panels']) + 1}\np = {float(pct['empirical_p']):.3f}",
            ha="left", va="top", fontsize=FS_NOTE, color=METHOD_COLORS["Pair"],
            linespacing=1.40)
    ax.legend(loc="upper left", fontsize=FS_LEGEND_DENSE, handlelength=1.1,
              labelspacing=0.24, borderaxespad=0.30, handletextpad=0.45)
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# K -- 14 conditional third residues            (deviation bars, Fig 5D)
# ==========================================================================
def triad_null_frame(D):
    """Each candidate third residue as a change from the Pair alone.

    Plotted as a change, not as a level: bars need a meaningful zero, and the
    honest zero here is the Pair without any third residue, measured on the
    same N = 172.  A bar chart of the levels themselves would either start at
    0.60 -- a truncated baseline -- or flatten every difference at 0.
    """
    base = float(D["pair_pct"].set_index("metric")
                 .loc["top30_active_fraction", "actual_value"])
    t = D["triad_null"].copy()
    t["pair_alone"] = base
    t["delta_pp"] = (t["top30_active_fraction"] - base) * 100
    t = t.sort_values(["delta_pp", "X_residue"], ascending=[False, True])
    return t.reset_index(drop=True)


def panel_triadnull(ax, D):
    t = triad_null_frame(D)
    pct = D["gln_pct"].set_index("metric").loc["top30_active_fraction"]
    x = np.arange(len(t))
    is_gln = (t["X_residue"] == "107GLN").to_numpy()

    ax.bar(x[~is_gln], t.loc[~is_gln, "delta_pp"], width=0.66, color=REMAINDER_GREY,
           edgecolor=EDGE, linewidth=LW_EDGE, zorder=2)
    ax.bar(x[is_gln], t.loc[is_gln, "delta_pp"], width=0.66,
           color=METHOD_COLORS["Triad"], edgecolor=EDGE, linewidth=LW_EDGE, zorder=3)
    ax.axhline(0, color=ANNOT_GREY, lw=LW_ZERO, zorder=4)
    ax.set_xticks(x)
    ax.set_xticklabels([pretty_residue(r) for r in t["X_residue"]], rotation=45,
                       ha="right", rotation_mode="anchor", fontsize=FS_NOTE)
    ax.set_xlim(-0.72, len(t) - 0.28)
    ax.set_ylim(-5.6, 5.6)
    ax.set_yticks([-4, 0, 4])
    ax.set_ylabel("Gain (pp)")
    ax.text(len(t) - 0.40, 0.35, "0 = fixed Pair alone", ha="right", va="bottom",
            fontsize=FS_NOTE, color=ANNOT_GREY, zorder=5)
    ax.set_axisbelow(True)
    ax.grid(True, axis="y", color=GRID_GREY, lw=LW_GRID, zorder=0)


# ==========================================================================
# Assembly
# ==========================================================================
# Only the outline keeps a heading; every data panel is identified by its letter
# alone and described in the caption.  The wording that used to sit here is kept
# verbatim in FIGURE3_ANNOTATIONS.md, and the verifier asserts it is still there.
TITLES = {"A": ("Analysis outline", None),
          **{k: (None, None) for k in "BCDEFGHIJ"}}
CAPTION_HEADINGS = {
    "B": ("Binding-site context", "4WSQ · ATP site"),
    "C": ("Residue association", "strong cohort, n = 139"),
    "D": ("Hotspot prevalence", "top-potency subset, n = 15"),
    "E": ("Crystal-start MD/ASGBIE", "contribution (kcal mol⁻¹); bold >1"),
    "F": ("Paired gain over Boltz-2", "top-30% fraction; 95% CI"),
    "G": ("Activity-cutoff sensitivity", "matched-K enrichment over random"),
    "H": ("Hotspot-threshold sensitivity", "1-2 kcal/mol; same-budget Boltz-2"),
    "I": ("Could other pairs work as well?", "120 pairs; same n = 143; top30 K = 43"),
    "J": ("Which third residue helps?", "add one residue to the fixed Pair"),
}
# The two panels this revision moved to the supplement keep their wording here,
# so the supplement and the old page say the same thing about the same mark.
MOVED_TO_SI_HEADINGS = {
    "top30": ("Top-30% active fraction", "stress n = 213; K = 64"),
    "roc": ("ROC discrimination", "active: IC50 ≤ 100 nM"),
}

# letter, draw fn, block weight.  One entry per row.
LAYOUT = [
    # step 1 -- the binding site and the three derivation streams
    [("B", panel_pocket, 0.62), ("C", panel_rho, 0.72), ("D", panel_prevalence, 0.70),
     ("E", panel_crystal, 1.36)],
    # step 2 -- the four rankings compared on the stress cohort.  The top-30%
    # forest and the ROC are in the supplement; what stays is the part that
    # moves with the question being asked: how strict is the activity
    # definition (F), and how strict is the hotspot threshold (H).
    [("F", panel_gain, 0.86), ("G", panel_matchedk_enrichment, 1.10),
     ("H", panel_threshold, 1.14)],
    # step 3 -- every panel that could have been chosen instead
    [("I", panel_pairnull, 1.06), ("J", panel_triadnull, 1.00)],
]
GRID = fl.Grid(page_h_mm=PAGE_H_MM, rows=LAYOUT, bands=ROWS, titles=TITLES,
               rail=RAIL, rail_fn=stage_rail, legend_y=LEGEND_Y)
RAIL_ASPECT = GRID.rail_aspect(RAIL_BOTTOM)
FIG_W, FIG_H = GRID.fig_w, GRID.fig_h
LEFT, RIGHT, DIVIDER_X = GRID.left, GRID.right, GRID.divider_x
COL_GAP = GRID.col_gap
COMPOSITE_LETTER_POSITIONS = GRID.letters


def band_legend(fig, y):
    """One shared key for the four scores, so no panel repeats it."""
    handles = [Line2D([], [], color=METHOD_COLORS[m], lw=LW_CURVE,
                      marker=METHOD_MARKERS[m], ms=4.2, mec="white", mew=0.6,
                      label=METHOD_LEGEND[m]) for m in METHODS]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.58, y),
               ncol=4, frameon=False, fontsize=FS_LEGEND_DENSE, handlelength=1.6,
               columnspacing=2.2, handletextpad=0.45, borderpad=0.0)


def export_plotted_values(D):
    """One file per panel letter, holding exactly what that panel draws."""
    ev = evidence_frame(D)
    ev[["residue", "row_y", "strong_rho", "strong_ci_low", "strong_ci_high"]].to_csv(
        PLOTTED / "Figure3_panelC_plotted_values.csv", index=False)
    ev[["residue", "row_y", "top15_hits", "top15_valid", "top15_fraction",
        "top15_wilson_low", "top15_wilson_high"]].to_csv(
        PLOTTED / "Figure3_panelD_plotted_values.csv", index=False)
    D["crystal"].to_csv(PLOTTED / "Figure3_panelE_plotted_values.csv", index=False)
    gain_frame(D).to_csv(PLOTTED / "Figure3_panelF_plotted_values.csv", index=False)
    D["cutoff"].to_csv(PLOTTED / "Figure3_panelG_plotted_values.csv", index=False)
    D["sweep"].to_csv(PLOTTED / "Figure3_panelH_plotted_values.csv", index=False)
    pair_null_frame(D).to_csv(PLOTTED / "Figure3_panelI_plotted_values.csv", index=False)
    triad_null_frame(D).to_csv(PLOTTED / "Figure3_panelJ_plotted_values.csv", index=False)
    D["pair_pct"].to_csv(PLOTTED / "Figure3_panelI_annotation_values.csv", index=False)
    D["gln_pct"].to_csv(PLOTTED / "Figure3_panelJ_annotation_values.csv", index=False)
    # Tables whose panel is in the supplement, under a name that says so.
    stress_frame(D, "top30_active_fraction").to_csv(
        PLOTTED / "Figure3_moved_to_SI_top30_active_fraction.csv", index=False)
    D["roc"].to_csv(PLOTTED / "Figure3_moved_to_SI_roc_curves.csv", index=False)
    D["gains"].to_csv(PLOTTED / "Figure3_paired_gain_all_metrics.csv", index=False)


def main():
    st.apply_style()
    clear_generated()
    D = load()
    GRID.legend_fn = band_legend
    pads = GRID.measure_all(D)
    rects = GRID.build(D, pads, RAIL_BOTTOM, OUT, "Figure3")
    GRID.build_panels(D, pads, rects, PANELS, "Figure3")
    export_plotted_values(D)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
