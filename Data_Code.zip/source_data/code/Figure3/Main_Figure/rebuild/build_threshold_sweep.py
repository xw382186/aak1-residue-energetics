#!/usr/bin/env python3
"""The per-residue hotspot-threshold sweep behind Figure 3's sensitivity panel.

For each threshold t from 1.0 to 2.0 kcal/mol, three nested gates are applied to
the same 213 endpoint-linked stress compounds:

    Leu26   |L26|  > t
    Pair    |L26|  > t  and  |F102| > t
    Triad   |L26|  > t  and  |F102| > t  and  |Q107| > t

and the active fraction among the compounds each gate retains is compared with
what Boltz-2 achieves when it is allowed to keep the SAME number of compounds.
Without that same-budget reference a gate could look good simply by keeping
fewer, better compounds, which is the failure mode this panel exists to expose.

The 1 kcal/mol threshold is not tuned here: it is the hotspot criterion panels
D and E already use.  The sweep is exploratory -- eleven thresholds, no
multiplicity adjustment -- and the caption must say so.

Enrichment is the active fraction divided by the cohort prevalence, 98/213.
"""
from math import sqrt
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
RAW = Path.home() / "mnt/AAK1/draft/Figure/3/raw_data_N213/N213_analysis_source"
OUT = HERE / "Figure3_derived_data_R2" / "Figure3_residue_threshold_sweep_N213.csv"

RESIDUES = {"Leu26": ["Boltz_L26_E"],
            "Pair":  ["Boltz_L26_E", "Boltz_F102_E"],
            "Triad": ["Boltz_L26_E", "Boltz_F102_E", "Boltz_Q107_E"]}
THRESHOLDS = np.round(np.arange(1.0, 2.001, 0.1), 2)


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    den = 1 + z * z / n
    centre = p + z * z / (2 * n)
    half = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((centre - half) / den, (centre + half) / den)


def main():
    d = pd.read_csv(RAW / "stress_compound_scores_N213_excluding_1-7-6.csv")
    n_total = len(d)
    active = (d["IC50_nM"] <= 100).to_numpy()
    n_active = int(active.sum())
    prevalence = n_active / n_total
    boltz = d["Boltz_direction_normalized_score"].to_numpy()

    def boltz_top(k):
        """Boltz-2's own top k, ties at the boundary shared fractionally."""
        order = np.argsort(-boltz, kind="mergesort")
        s, a = boltz[order], active[order]
        cut = s[k - 1]
        strict = s > cut
        tied = s == cut
        w = np.where(strict, 1.0,
                     np.where(tied, (k - strict.sum()) / tied.sum(), 0.0))
        return float((w * a).sum()) / k

    rows = []
    for name, cols in RESIDUES.items():
        E = d[cols].to_numpy()
        for t in THRESHOLDS:
            keep = (E < -t).all(axis=1)
            n = int(keep.sum())
            k = int(active[keep].sum())
            lo, hi = wilson(k, n)
            ref = boltz_top(n) if n else np.nan
            rows.append({
                "gate": name, "threshold_kcal_mol": float(t),
                "n_residues": len(cols), "N": n_total, "n_active_cohort": n_active,
                "prevalence": prevalence,
                "n_retained": n, "n_active_retained": k,
                "active_fraction": k / n if n else np.nan,
                "enrichment": (k / n) / prevalence if n else np.nan,
                "recall": k / n_active,
                "wilson_low": lo, "wilson_high": hi,
                "enrichment_wilson_low": lo / prevalence,
                "enrichment_wilson_high": hi / prevalence,
                "same_budget_boltz_fraction": ref,
                "same_budget_boltz_enrichment": ref / prevalence if n else np.nan,
                "gain_vs_same_budget_boltz_pp": (k / n - ref) * 100 if n else np.nan,
            })
    out = pd.DataFrame(rows)
    out.to_csv(OUT, index=False)
    print(f"wrote {OUT.name}: {len(out)} rows, "
          f"{out.gate.nunique()} gates x {len(THRESHOLDS)} thresholds")
    print(out.pivot(index="threshold_kcal_mol", columns="gate",
                    values="enrichment").round(2).to_string())


if __name__ == "__main__":
    main()
