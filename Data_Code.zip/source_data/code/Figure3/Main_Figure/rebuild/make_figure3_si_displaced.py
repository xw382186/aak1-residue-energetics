#!/usr/bin/env python3
"""Figure 3 supplement -- the two N = 213 readouts that left the main page.

The ten-panel revision keeps, of step 2, the part that moves with the question
being asked: the paired gain (F), the activity-cutoff sensitivity as enrichment
(G) and the hotspot-threshold sensitivity (H).  The two fixed-setting readouts
-- the top-30% active fraction at the single 100 nM definition, and the ROC for
that same definition -- are here.

Both panels are drawn by the main figure's own functions, unchanged, from the
same tables, so a reader following the caption from the main page to this one
meets the same marks in the same colours and the same type.  The page is the
main figure's width to the millimetre; only the axes are taller.

    python3 make_figure3_si_displaced.py
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox

import figure2_style as st
import figure_layout as fl
import make_figure3_v2 as mf

HERE = Path(__file__).resolve().parent
# Module attributes so the release assembler can point them at its own folders.
OUT = HERE / "figure3_si_output"
TABLES = OUT

STEM = "Figure3_S1_N213_primary_ranking_readouts"
SUPTITLE = ("Figure 3—figure supplement 1 | Primary N = 213 ranking readouts: "
            "top-30% active fraction and ROC discrimination")

# The page, in millimetres.  Width is the main figure's, so the two scale by the
# same factor and the frozen type sizes stay frozen on paper.
SUP_MM      = 7.20     # canvas top to the supplement title's baseline
HEAD_MM     = 8.60     # title baseline to the panel letter's baseline
LETTER_MM   = 6.20     # letter baseline to the axes top: the heading sits
                       # here as well as the letter, so the sub-line below it
                       # needs its own clearance before the axes begin
SUB_MM      = 3.90     # heading baseline down to its sub-line
AXES_MM     = 52.00    # taller than the main page's rows: one row, more room
KEY_DROP_MM = 15.40    # axes bottom to the score key, clear of the x labels
FOOT_MM     = 7.60

PANELS = [("A", mf.panel_top30, 1.16), ("B", mf.panel_roc, 0.96)]
LEFT, RIGHT, COL_GAP = 0.0080, 0.9940, 0.030


def score_key(fig, y):
    """The main figure's own key, centred on a page that has no rail."""
    handles = [Line2D([], [], color=mf.METHOD_COLORS[m], lw=mf.LW_CURVE,
                      marker=mf.METHOD_MARKERS[m], ms=4.2, mec="white", mew=0.6,
                      label=mf.METHOD_LEGEND[m]) for m in mf.METHODS]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, y),
               ncol=4, frameon=False, fontsize=mf.FS_LEGEND_DENSE,
               handlelength=1.6, columnspacing=2.2, handletextpad=0.45,
               borderpad=0.0)


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    st.apply_style()
    D = mf.load()

    fig_w = fl.PAGE_W_MM / 25.4 - 2 * st.SAVEFIG_PAD_IN
    fig_h_mm = SUP_MM + HEAD_MM + LETTER_MM + AXES_MM + KEY_DROP_MM + FOOT_MM
    fig_h = fig_h_mm / 25.4

    span = (RIGHT - LEFT) - COL_GAP * (len(PANELS) - 1)
    total = sum(w for _, _, w in PANELS)
    widths = [span * w / total for _, _, w in PANELS]

    # the room each panel's own labels need, measured at its real size
    pads = {l: fl.measure_panel(fn, D, bw * fig_w, AXES_MM / 25.4)
            for (l, fn, _), bw in zip(PANELS, widths)}

    top_f = 1 - (SUP_MM + HEAD_MM + LETTER_MM) / fig_h_mm
    bottom_f = top_f - AXES_MM / fig_h_mm
    letter_f = 1 - (SUP_MM + HEAD_MM) / fig_h_mm
    key_f = bottom_f - KEY_DROP_MM / fig_h_mm

    fig = plt.figure(figsize=(fig_w, fig_h))
    fig.text(0.008, 1 - SUP_MM / fig_h_mm, SUPTITLE, ha="left", va="baseline",
             fontsize=10.0, fontweight="bold")
    x = LEFT
    for (letter, fn, _), bw in zip(PANELS, widths):
        pl, pr, _, _ = pads[letter]
        fn(fig.add_axes((x + pl / fig_w, bottom_f,
                         bw - (pl + pr) / fig_w, top_f - bottom_f)), D)
        fig.text(x, letter_f, letter, ha="left", va="baseline",
                 fontsize=st.FS_LETTER, fontweight="bold")
        # the heading the main page carried above this panel, kept verbatim
        head, sub = mf.MOVED_TO_SI_HEADINGS["top30" if letter == "A" else "roc"]
        fig.text(x + 0.0190, letter_f, head, ha="left", va="baseline",
                 fontsize=mf.FS_TITLE, fontweight="bold")
        fig.text(x + 0.0190, letter_f - SUB_MM / fig_h_mm, sub, ha="left",
                 va="baseline", fontsize=mf.FS_NOTE, color=mf.ANNOT_GREY)
        x += bw + COL_GAP
    score_key(fig, key_f)

    pad = st.SAVEFIG_PAD_IN
    box = Bbox.from_bounds(-pad, -pad, fig_w + 2 * pad, fig_h + 2 * pad)
    for ext in ("pdf", "svg"):
        fig.savefig(OUT / f"{STEM}.{ext}", bbox_inches=box)
    fig.savefig(OUT / f"{STEM}.png", dpi=st.DPI, bbox_inches=box)
    fig.savefig(OUT / f"{STEM}.tif", dpi=st.DPI, bbox_inches=box,
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    # the values behind every mark, beside the figure
    mf.stress_frame(D, "top30_active_fraction").to_csv(
        TABLES / f"{STEM}_panelA_plotted_values.csv", index=False)
    D["roc"].to_csv(TABLES / f"{STEM}_panelB_curves.csv", index=False)
    D["stress"].to_csv(TABLES / f"{STEM}_panelB_auc.csv", index=False)
    print("wrote", OUT,
          f"({fl.PAGE_W_MM:.2f} x {fig_h_mm + 2 * st.SAVEFIG_PAD_IN * 25.4:.2f} mm)")


if __name__ == "__main__":
    build()
