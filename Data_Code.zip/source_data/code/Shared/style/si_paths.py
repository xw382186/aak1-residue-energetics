"""Locations inside the five-part FigureandSI release.

Every rebuild script finds the release root from its own position, so the tree
can be moved or copied as a whole.  Nothing here reads or writes data; it only
answers "where does X live".

    FigureN/Main_Figure/                 main figure, source_data/, annotations/, rebuild/
    FigureN/Supplementary_Figures/       one folder per public supplementary figure
        Supplementary_Figure_NN_<slug>/  figure exports, source_data/, raw_data/
        docs/  qa/  rebuild/
    FigureN/Supplementary_Table/         Supplementary Table workbook
    Shared/                              style, cross-figure docs and QA, workbook builder
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

FS = Path(os.environ.get("AAK1_FIGUREANDSI", Path(__file__).resolve().parents[2]))
STAGE_ROOT = Path(os.environ.get("SI_RESTYLE_STAGE", Path.home() / "si_restyle"))

# public number -> (figure part, slug); the slug is the provenance stem without
# its local "FigureN_SK_" prefix, so the public name and the label agree.
SI_FOLDERS = {
    1: (2, "cohort_calibration"), 2: (2, "chemical_space_context"),
    3: (2, "global_and_LOGO_robustness"), 4: (2, "perturbation_response"),
    5: (2, "geometry_design_audit"), 6: (2, "secondary_seed_sensitivity"),
    7: (3, "N213_primary_ranking_readouts"), 8: (3, "N213_benchmark_robustness"),
    9: (3, "N143_scope_missingness_and_overlap"), 10: (3, "N143_exhaustive_combinatorial_context"),
    11: (4, "full_threshold_tradeoff_N213"), 12: (4, "full_IC50_energy_grid_N213"),
    13: (4, "gate_separation_crossroute_N213"), 14: (4, "residue_panel_context_N143_K43"),
    15: (4, "case_robustness_109_vs_103"),
    16: (5, "selection_and_chemical_space_audit"), 17: (5, "assay_and_protein_provenance"),
    18: (5, "full_threshold_and_uncertainty"), 19: (5, "all_compounds_and_counterexamples"),
}


def part(fig: int) -> Path:
    return FS / f"Figure{fig}"


def main_rebuild(fig: int) -> Path:
    return part(fig) / "Main_Figure/rebuild"


def main_source_data(fig: int) -> Path:
    return part(fig) / "Main_Figure/source_data"


def si_root(fig: int) -> Path:
    return part(fig) / "Supplementary_Figures"


def si_rebuild(fig: int) -> Path:
    return si_root(fig) / "rebuild"


def si_name(n: int) -> str:
    return f"Supplementary_Figure_{n:02d}_{SI_FOLDERS[n][1]}"


def si_folder(n: int) -> Path:
    return si_root(SI_FOLDERS[n][0]) / si_name(n)


def raw_data(n: int) -> Path:
    return si_folder(n) / "raw_data"


def stage_published_tables(fig: int, dest: Path) -> Path:
    """Copy every SI source_data file of one figure part into one flat folder.

    The legacy build scripts expect all of a figure's supplementary tables in a
    single directory; in the release they sit with the supplementary figure that
    plots them.  Sub-paths below source_data/ (e.g. case_geometry/<id>/) are kept.
    """
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    for sd in sorted(si_root(fig).glob("Supplementary_Figure_*/source_data")):
        for p in sorted(sd.rglob("*")):
            if p.is_file() and p.name != ".DS_Store":
                d = dest / p.relative_to(sd)
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(p, d)
                n += 1
    print(f"    staged {n} published SI tables of Figure {fig} -> {dest}")
    return dest


def stage_tree(src: Path, dest: Path) -> Path:
    """Copy a rebuild folder into the stage and return the copy.

    Several legacy modules create output folders next to themselves when they
    are imported; importing them from a staged copy keeps every run, and every
    byte it writes, outside the release.
    """
    shutil.copytree(src, dest, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
    return dest
