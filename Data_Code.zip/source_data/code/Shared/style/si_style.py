#!/usr/bin/env python3
"""Unified Supplementary-Information style for the AAK1 series.

The main figures are built on the frozen `figure2_style.py`, whose every value
is measured from the style reference the author supplied:

    Xu S, et al. "Benchmarking all-atom biomolecular structure prediction with
    FoldBench." Nature Communications (2026) 17:442.

The SI figures drifted away from it: three different title conventions, local
palettes restated inline, type sizes 7.2/8.2/7.6/6.7/6.5 instead of the frozen
8.0/7.5/7.0/7.0/6.5, 0.7 pt spines instead of 0.9 pt, a seaborn whitegrid on
every panel, and two different bold Arial faces embedded across the set.

This module re-imposes the frozen style on the SI so the supplements read as
the same document as the main figures, and fixes the public numbering into the
figure itself.  It adds nothing the frozen module does not already define
except the supplementary-title convention, which the main figures do not need.
"""
from __future__ import annotations

import matplotlib as mpl
import matplotlib.pyplot as plt

import figure2_style as st
from figure2_style import (ANNOT_GREY, COHORT_COLORS, EDGE, FS_ANNOT, FS_LABEL,
                           FS_LEGEND, FS_LETTER, FS_NOTE, FS_TICK, FS_TITLE,
                           GRID_GREY, LW_AXIS, LW_EDGE, LW_GRID, LW_REF,
                           METHOD_COLORS, REF_GREY)

# ----------------------------------------------------------- public numbering
# Public supplementary numbers follow first citation in the Results.  The file
# stems are provenance identities and do NOT match the public number, which is
# exactly the inconsistency this pass removes.
PUBLIC_NUMBER = {
    "Figure2_S1_current_cohort_calibration": 1,
    "Figure2_S6_current_chemical_space_context": 2,
    "Figure2_S2_current_global_and_LOGO_robustness": 3,
    "Figure2_S4_current_perturbation_response": 4,
    "Figure2_S5_current_geometry_design_audit": 5,
    "Figure2_S3_current_secondary_seed_sensitivity": 6,
    "Figure3_S1_N213_primary_ranking_readouts": 7,
    "Figure3_S2_N213_benchmark_robustness": 8,
    "Figure3_S4_N143_scope_missingness_and_overlap": 9,
    "Figure3_S3_N143_exhaustive_combinatorial_context": 10,
    "Figure4_S1_full_threshold_tradeoff_N213": 11,
    "Figure4_S2_full_IC50_energy_grid_N213": 12,
    "Figure4_S3_gate_separation_crossroute_N213": 13,
    "Figure4_S4_residue_panel_context_N143_K43": 14,
    "Figure4_S5_case_robustness_109_vs_103": 15,
    "Figure5_S2_selection_and_chemical_space_audit": 16,
    "Figure5_S1_assay_and_protein_provenance": 17,
    "Figure5_S3_full_threshold_and_uncertainty": 18,
    "Figure5_S4_all_compounds_and_counterexamples": 19,
}

# Short public titles, used after the "Supplementary Figure N |" lead-in.
PUBLIC_TITLE = {
    1:  "Cohort composition and historical calibration",
    2:  "Chemical-space context of the 353 source records",
    3:  "Global and within-source association and leave-one-group-out robustness",
    4:  "Alanine-perturbation response: rank retention and coordinate coupling",
    5:  "Geometry and perturbation-design audit",
    6:  "Ten-compound secondary-seed sensitivity",
    7:  "Primary N = 213 ranking readouts: top-30% active fraction and ROC discrimination",
    8:  "N = 213 benchmark robustness, uncertainty and overlap",
    9:  "N = 143 scope, missingness and top-K overlap",
    10: "Exhaustive combinatorial context in N = 143",
    11: "Selection-level trade-off: residue gates versus same-size Boltz-2",
    12: "Complete IC$_{50}$ \u00d7 energy sensitivity grid",
    13: "Fixed-gate separation and cross-route dependence",
    14: "Complete residue-panel context at fixed K = 43",
    15: "Retrospective case robustness and explicit mechanism limits",
    16: "Selection, procurement and source-matched chemical-space audit",
    17: "Assay and protein provenance",
    18: "Full threshold tails, uncertainty and scan correction",
    19: "All-compound profiles, discordant cases and reference proximity",
}

# ------------------------------------------------------------ title geometry
FS_SUPTITLE = 9.5          # bold supplementary title
SUPTITLE_X = 0.01
SUPTITLE_Y = 0.995
DPI = 600
PAGE_W_PT = 629.83        # main-figure page width; every supplement matches it


def apply_si_style() -> None:
    """Install the frozen style, then the SI-only additions."""
    st.apply_style()
    mpl.rcParams.update({
        # the frozen series carries no background grid; the reference article
        # uses one only on cumulative-curve panels, which set it per-axes.
        "axes.grid": False,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        # SI pages keep their declared canvas so every supplement matches the
        # main-figure page width (629.83 pt); a tight box would retrim each
        # figure to its own ink and break that match.
        "savefig.bbox": "tight",
        "savefig.pad_inches": st.SAVEFIG_PAD_IN,
        # keep text as text in every vector export
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })
    # seaborn, if present, must not reinstate its own theme
    try:
        import seaborn as sns
        sns.set_style("ticks", {
            "axes.edgecolor": EDGE,
            "axes.linewidth": LW_AXIS,
            "xtick.direction": "out",
            "ytick.direction": "out",
        })
    except Exception:
        pass


def panel_letter(ax, letter: str, dx: float = -0.16, dy: float = 1.08) -> None:
    """Frozen panel letter: bold, 11 pt, black, top-left of the axes."""
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=FS_LETTER,
            fontweight="bold", va="top", ha="left", color="black")


def clean(ax, grid: str | None = None) -> None:
    """Left+bottom spines, outward ticks; optional single-axis faint grid."""
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_linewidth(LW_AXIS)
        ax.spines[side].set_color(EDGE)
    ax.tick_params(width=st.LW_TICK, length=st.TICK_LEN, direction="out")
    if grid:
        ax.grid(axis=grid, color=GRID_GREY, linewidth=LW_GRID)
        ax.set_axisbelow(True)


def strip_legacy_titles(fig) -> int:
    """Remove any title a delegated module drew itself.

    Some supplements are drawn by the main figure's own module, which stamps
    its local "Figure N-figure supplement M | ..." heading directly as a text
    artist.  That heading is replaced by the unified public title, so it must
    come off first or the figure carries two.
    """
    marks = ("figure supplement", "\u2014figure supplement", "Supplementary Figure")
    removed = 0
    for art in list(getattr(fig, "texts", [])):
        s = (art.get_text() or "").strip()
        if any(m in s for m in marks):
            art.remove()
            removed += 1
    return removed


HEADING_GAP_IN = 0.10      # clear space between the heading and the top-most ink

# ------------------------------------------------------------ layout repairs
# The frozen type is larger than the type several builders were spaced for, and
# a few builders had collisions of their own.  Each repair moves text only --
# never a data mark -- and is applied only to the supplements that need it.
LAYOUT_FIXES = {
    2: ("tick_labels",),
    13: ("tick_labels",),
    14: ("footnotes_below",),
    15: ("footnotes_below",),
}


def _renderer(fig):
    fig.canvas.draw()
    return fig.canvas.get_renderer()


def footnotes_below(fig, gap_pt: float = 3.0) -> None:
    """Move figure-level footnotes clear of the lowest axis labels."""
    r = _renderer(fig)
    axes = [ax for ax in fig.axes if ax.get_visible()]
    frame_bottom = min(ax.get_window_extent(r).y0 for ax in axes)
    notes = [t for t in fig.texts if t.get_visible() and t.get_text().strip()
             and t.get_window_extent(r).y1 < frame_bottom]
    if not notes:
        return
    ink_bottom = min(ax.get_tightbbox(r).y0 for ax in axes)
    top = max(t.get_window_extent(r).y1 for t in notes)
    shift = ink_bottom - gap_pt * fig.dpi / 72.0 - top          # display px; < 0 means overlap
    if shift < 0:
        for t in notes:
            x, y = t.get_position()
            t.set_y(y + shift / fig.bbox.height)


def tick_labels(fig) -> None:
    """Rotated category labels: lay them flat (wrapped onto two or three lines)
    when they fit between ticks, else anchor each by its end at its tick so
    neighbours run parallel instead of crossing."""
    import textwrap
    r = _renderer(fig)
    for ax in fig.axes:
        labs = [l for l in ax.get_xticklabels() if l.get_visible() and l.get_text().strip()]
        if len(labs) < 2 or all(abs(l.get_rotation()) % 180 < 1 for l in labs):
            continue
        xs = sorted(ax.transData.transform((t, 0))[0] for t in ax.get_xticks()
                    if ax.get_xlim()[0] <= t <= ax.get_xlim()[1])
        spacing = min(b - a for a, b in zip(xs, xs[1:])) if len(xs) > 1 else ax.bbox.width
        texts = [l.get_text() for l in labs]
        for width in (40, 16, 12, 10):
            wrapped = ["\n".join(textwrap.wrap(t.replace("\n", " "), width)) if "\n" not in t else t for t in texts]
            for l, t in zip(labs, wrapped):
                l.set_text(t); l.set_rotation(0); l.set_ha("center"); l.set_rotation_mode("default")
            ax.set_xticks(ax.get_xticks()); ax.set_xticklabels(wrapped)
            r = _renderer(fig)
            labs = [l for l in ax.get_xticklabels() if l.get_visible() and l.get_text().strip()]
            if max(l.get_window_extent(r).width for l in labs) < 0.92 * spacing:
                break
        else:
            for l in labs:
                l.set_rotation(30); l.set_ha("right"); l.set_rotation_mode("anchor")


def repel_labels(fig, pad_pt: float = 1.5, passes: int = 20) -> None:
    """Separate in-axes text labels that overlap each other or a tick label.

    Only free-standing labels move (panel letters and titles do not), and only
    vertically, by the overlap plus pad_pt; the leader point stays where it is.
    """
    from matplotlib.text import Annotation
    pad = pad_pt * fig.dpi / 72.0
    for ax in fig.axes:
        texts = [t for t in ax.texts if t.get_visible() and t.get_text().strip()
                 and not (len(t.get_text().strip()) == 1 and t.get_fontweight() in ("bold", 700))]
        if not texts:
            continue
        for _ in range(passes):
            r = _renderer(fig)
            fixed = [l.get_window_extent(r) for l in ax.get_xticklabels() + ax.get_yticklabels()
                     if l.get_visible() and l.get_text().strip()]
            moved = False
            boxes = {id(t): t.get_window_extent(r) for t in texts}
            for i, t in enumerate(texts):
                bt = boxes[id(t)]
                others = [boxes[id(u)] for u in texts[:i]] + fixed
                for bo in others:
                    if not bt.overlaps(bo.padded(pad)):      # closer than pad counts as touching
                        continue
                    up = (bt.y0 + bt.y1) >= (bo.y0 + bo.y1)
                    dy = (bo.y1 - bt.y0 + 2 * pad) if up else -(bt.y1 - bo.y0 + 2 * pad)
                    if isinstance(t, Annotation):
                        tr = t._get_xy_transform(r, t.anncoords)
                        px, py = tr.transform(t.xyann)
                        t.xyann = tuple(tr.inverted().transform((px, py + dy)))
                    else:
                        tr = t.get_transform()
                        px, py = tr.transform(t.get_position())
                        t.set_position(tr.inverted().transform((px, py + dy)))
                    moved = True
                    break
                if moved:
                    break
            if not moved:
                break


def tidy_layout(fig, n: int) -> None:
    """Per-figure text repairs (si_polish), then the generic ones above."""
    import si_polish
    si_polish.polish(fig, n)
    for fix in LAYOUT_FIXES.get(n, ()):
        globals()[fix](fig)


def stamp_heading(fig, n: int) -> str:
    """Put "Supplementary Figure N | title" above everything the figure draws.

    The heading is placed from the figure's own ink: left-aligned with the
    left-most element and HEADING_GAP_IN above the top-most one, so it can never
    sit on a panel letter or panel title, whatever layout the original builder
    used.  It may land above the canvas; the tight save grows to include it.
    """
    text = f"Supplementary Figure {n} | {PUBLIC_TITLE[n]}"
    tidy_layout(fig, n)
    fig.canvas.draw()
    bb = fig.get_tightbbox(fig.canvas.get_renderer())      # inches
    w, h = fig.get_size_inches()
    fig.text(bb.x0 / w, (bb.y1 + HEADING_GAP_IN) / h, text, ha="left", va="bottom",
             fontsize=FS_SUPTITLE, fontweight="bold", color="black")
    return text


def supplementary_title(fig, stem: str) -> str:
    """Stamp the unified public heading for a provenance stem."""
    return stamp_heading(fig, PUBLIC_NUMBER[stem])


def public_stem(stem: str) -> str:
    """Public filename: number-first, without the local "FigureN_SK_" tag.

    Supplementary_Figure_NN_<slug>, where the slug is the provenance stem minus
    its local prefix, so the public number is the only number in the name and
    it agrees with the label printed on the figure.
    """
    import re
    n = PUBLIC_NUMBER[stem]
    slug = re.sub(r"^Figure\d_S\d_(current_)?", "", stem)
    return f"Supplementary_Figure_{n:02d}_{slug}"


def save_si(fig, outdir, stem: str) -> list:
    """Write the four published formats under the public stem.

    Saved with a tight box so no long tick label is ever clipped, then the
    page box is normalised to the main-figure width (629.83 pt) by centring
    the artwork -- never by cropping it.  The rasters are rendered from that
    normalised page, so every supplement lands on the same page width as the
    main figures and scales with them by one factor.
    """
    from pathlib import Path
    import pymupdf
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = None

    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    name = public_stem(stem)
    pad = st.SAVEFIG_PAD_IN

    tight = outdir / f".{name}_tight.pdf"
    fig.savefig(tight, bbox_inches="tight", pad_inches=pad)
    svg = outdir / f"{name}.svg"
    fig.savefig(svg, bbox_inches="tight", pad_inches=pad)
    plt.close(fig)

    src = pymupdf.open(tight)
    sp = src[0]
    w, h = sp.rect.width, sp.rect.height
    scale = PAGE_W_PT / w if w > PAGE_W_PT else 1.0
    nw, nh = PAGE_W_PT, h * scale
    doc = pymupdf.open()
    page = doc.new_page(width=nw, height=nh)
    x0 = (nw - w * scale) / 2.0
    page.show_pdf_page(pymupdf.Rect(x0, 0, x0 + w * scale, nh), src, 0)
    pdf = outdir / f"{name}.pdf"
    doc.save(pdf, garbage=4, deflate=True)
    doc.close(); src.close()
    tight.unlink(missing_ok=True)

    page = pymupdf.open(pdf)[0]
    pm = page.get_pixmap(dpi=DPI)
    png = outdir / f"{name}.png"
    pm.save(png)
    with Image.open(png) as im:
        im.save(outdir / f"{name}.tif", format="TIFF",
                compression="tiff_lzw", dpi=(DPI, DPI))
    _normalise_svg(svg)
    return [pdf, svg, png, outdir / f"{name}.tif"]


def _normalise_svg(path) -> None:
    """Give the SVG the same page box as the PDF (629.83 pt wide).

    matplotlib writes width/height in pt and a viewBox in the same units.  A
    narrower drawing is centred by widening the viewBox; a wider one keeps its
    viewBox and is scaled by the declared width -- exactly what the PDF does.
    """
    import re
    from pathlib import Path
    path = Path(path)
    txt = path.read_text()
    m = re.search(r'<svg[^>]*?width="([0-9.]+)pt" height="([0-9.]+)pt" viewBox="([^"]+)"', txt)
    if not m:
        return
    w, h = float(m.group(1)), float(m.group(2))
    x0, y0, vw, vh = (float(v) for v in m.group(3).split())
    if abs(w - PAGE_W_PT) < 1e-3:
        return
    if w < PAGE_W_PT:
        pad = (PAGE_W_PT - w) / 2.0
        box = f"{x0 - pad:.4f} {y0:.4f} {vw + 2 * pad:.4f} {vh:.4f}"
        new = f'width="{PAGE_W_PT:.2f}pt" height="{h:.2f}pt" viewBox="{box}"'
    else:
        s = PAGE_W_PT / w
        new = f'width="{PAGE_W_PT:.2f}pt" height="{h * s:.2f}pt" viewBox="{m.group(3)}"'
    old = f'width="{m.group(1)}pt" height="{m.group(2)}pt" viewBox="{m.group(3)}"'
    path.write_text(txt.replace(old, new, 1))
