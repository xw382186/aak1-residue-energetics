"""Presentation repairs for individual supplementary figures.

The supplements are drawn by their original builders; this module only moves,
resizes or re-weights TEXT and legends after the drawing, so that nothing
collides once the frozen series type sizes are in place.  No data mark, axis
value range of plotted data, or number is changed (one y-limit is extended
downward to make a legend band; the bars it frames are untouched).

Every repair names the artist it acts on and fails loudly if that artist is
missing, so a change in a builder cannot silently skip a repair.
"""
from __future__ import annotations

import math
import re

import numpy as np
from matplotlib.collections import LineCollection, PathCollection
from matplotlib.colors import to_rgba
from matplotlib.text import Annotation

import figure2_style as st

FS_ANNOT = st.FS_ANNOT
FS_TITLE = st.FS_TITLE


# ------------------------------------------------------------------ helpers
def _r(fig):
    fig.canvas.draw()
    return fig.canvas.get_renderer()


def _titles(ax):
    return [t for t in (ax.title, ax._left_title, ax._right_title) if t.get_text().strip()]


def axes_titled(fig, needle):
    hits = [ax for ax in fig.axes if any(needle in t.get_text() for t in _titles(ax))]
    assert hits, f"no axes titled {needle!r}"
    return hits[0]


def axes_ylabel(fig, needle):
    hits = [ax for ax in fig.axes if needle in ax.get_ylabel()]
    assert hits, f"no axes with y label {needle!r}"
    return hits[0]


def text_in(ax, pattern):
    rx = re.compile(pattern)
    hits = [t for t in ax.texts if rx.search(t.get_text())]
    assert hits, f"no text matching {pattern!r}"
    return hits


def shift_px(t, dx=0.0, dy=0.0):
    """Move a Text or Annotation by (dx, dy) display pixels."""
    fig = t.figure
    r = _r(fig)
    if isinstance(t, Annotation):
        tr = t._get_xy_transform(r, t.anncoords)
        p = tr.transform(t.xyann)
        t.xyann = tuple(tr.inverted().transform((p[0] + dx, p[1] + dy)))
    else:
        tr = t.get_transform()
        p = tr.transform(t.get_position())
        t.set_position(tuple(tr.inverted().transform((p[0] + dx, p[1] + dy))))


def remake_legend(ax, **kw):
    """Re-draw an axes legend at a new place, keeping its entries and type size."""
    old = ax.get_legend()
    assert old is not None, "axes has no legend"
    fs = old.get_texts()[0].get_fontsize() if old.get_texts() else st.FS_LEGEND
    h, l = ax.get_legend_handles_labels()
    if l != [t.get_text() for t in old.get_texts()]:      # legend built from proxy handles
        h, l = list(old.legend_handles), [t.get_text() for t in old.get_texts()]
    opts = dict(frameon=False, fontsize=fs, handlelength=old.handlelength,
                handletextpad=old.handletextpad, borderaxespad=0.3)
    opts.update(kw)
    old.remove()
    return ax.legend(h, l, **opts)


def legend_below(ax, gap_pt=2.0, ncol=None):
    """Move an axes legend under the axes' own labels, one row if it fits."""
    leg = ax.get_legend()
    leg.set_visible(False)
    r = _r(ax.figure)
    bottom = ax.get_tightbbox(r).y0
    leg.set_visible(True)
    y = ax.transAxes.inverted().transform((0, bottom - gap_pt * ax.figure.dpi / 72))[1]
    n = len(leg.get_texts())
    return remake_legend(ax, loc="upper center", bbox_to_anchor=(0.5, y), ncol=ncol or n)


def white_legend(ax):
    leg = ax.get_legend()
    leg.set_frame_on(True)
    fr = leg.get_frame()
    fr.set_facecolor("white"); fr.set_edgecolor("none"); fr.set_alpha(1.0)
    leg.set_zorder(10)


# ------------------------------------------------------- generic, all supplements
def bold_panel_titles(fig):
    """Panel titles in the supplements are bold at the frozen title size."""
    for ax in fig.axes:
        for t in _titles(ax):
            if abs(t.get_fontsize() - FS_TITLE) < 0.3:
                t.set_fontweight("bold")


def typography(fig):
    """ASCII stand-ins for relation signs become the signs themselves."""
    rep = (("<=", "≤"), (">=", "≥"))
    arts = list(fig.texts)
    for ax in fig.axes:
        arts += list(ax.texts) + _titles(ax) + [ax.xaxis.label, ax.yaxis.label]
        leg = ax.get_legend()
        if leg:
            arts += leg.get_texts()
    for t in arts:
        s = t.get_text()
        if "$" in s:
            continue
        s2 = s
        for a, b in rep:
            s2 = s2.replace(a, b)
        if s2 != s:
            t.set_text(s2)


# ------------------------------------------------------------- point labels
def line_samples(ax, step_px=2.0):
    """Points every step_px along every line drawn in the axes (display coords)."""
    out = []
    for l in ax.lines:
        if l.get_linestyle() in ("None", "", " ", "none"):
            continue
        xy = l.get_transform().transform(np.column_stack([l.get_xdata(), l.get_ydata()]).astype(float))
        for a, b in zip(xy[:-1], xy[1:]):
            if not (np.isfinite(a).all() and np.isfinite(b).all()):
                continue
            n = max(2, int(np.hypot(*(b - a)) / step_px))
            out += list(a + (b - a) * np.linspace(0, 1, n)[:, None])
    return np.array(out) if out else np.zeros((0, 2))


def place_point_labels(ax, labels, anchors, radii_px, pad_px=2.0, lines=False, prefer_vertical=False):
    """Greedy placement of short labels around their points.

    Each label tries eight positions around its own point (right first, as the
    builder drew it) and takes the first that touches no other label, no other
    point and stays inside the axes; failing that, the least-overlapping one.
    """
    fig = ax.figure
    r = _r(fig)
    pts = np.array([ax.transData.transform(a) for a in anchors])
    ab = ax.get_window_extent(r)
    sizes = [(t.get_window_extent(r).width, t.get_window_extent(r).height) for t in labels]
    order = np.argsort([-np.sum(np.hypot(*(pts - p).T) < 40) for p in pts], kind="stable")
    placed = []
    dirs = [(1, 0), (1, 1), (1, -1), (0, 1), (0, -1), (-1, 0), (-1, 1), (-1, -1)]
    if prefer_vertical:
        dirs = [(0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1), (1, 0), (-1, 0)]
    obst = line_samples(ax) if lines else np.zeros((0, 2))

    def box(cx, cy, w, h, dx, dy, rad):
        g = rad + pad_px
        x0 = cx + g if dx > 0 else (cx - g - w if dx < 0 else cx - w / 2)
        y0 = cy + g * 0.7 if dy > 0 else (cy - g * 0.7 - h if dy < 0 else cy - h / 2)
        return np.array([x0, y0, x0 + w, y0 + h])

    def inter(a, b):
        return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))

    for i in order:
        cx, cy = pts[i]; w, h = sizes[i]; best = None
        for k, (dx, dy) in enumerate(dirs):
            b = box(cx, cy, w, h, dx, dy, radii_px[i])
            score = sum(inter(b, p) for p in placed)
            score += sum(inter(b, [x - rr, y - rr, x + rr, y + rr]) for j, ((x, y), rr) in enumerate(zip(pts, radii_px)) if j != i)
            out = max(0, ab.x0 - b[0]) + max(0, b[2] - ab.x1) + max(0, ab.y0 - b[1]) + max(0, b[3] - ab.y1)
            if len(obst):
                inside = ((obst[:, 0] > b[0] - 1) & (obst[:, 0] < b[2] + 1) &
                          (obst[:, 1] > b[1] - 1) & (obst[:, 1] < b[3] + 1)).sum()
                score += 30.0 * inside
            score += out * 50 + k * 1e-3
            if best is None or score < best[0]:
                best = (score, b)
        b = best[1]; placed.append(b)
        t = labels[i]
        t.set_ha("left"); t.set_va("bottom")
        t.set_transform(ax.transData)
        t.set_position(tuple(ax.transData.inverted().transform((b[0], b[1]))))


# ------------------------------------------------------- per-figure repairs
def si01(fig):
    ax = axes_ylabel(fig, "Within-group Spearman")
    # the builder's y-window (-0.15, 1.02) left source group 1-4 (rho = -0.38)
    # outside the axes: its marker was clipped and its label floated under the
    # figure.  Widen the window so every source group is drawn.
    ys = [o[1] for c in ax.collections if isinstance(c, PathCollection) for o in c.get_offsets()]
    lo, hi = ax.get_ylim()
    if min(ys) < lo:
        ax.set_ylim(math.floor((min(ys) - 0.08) * 10) / 10, hi)
    labels = text_in(ax, r"^\d+-\d+$")
    pts, rad = [], []
    for c in ax.collections:
        if isinstance(c, PathCollection):
            off, s = c.get_offsets(), c.get_sizes()
            s = np.broadcast_to(s, (len(off),)) if len(s) == 1 else s
            for o, ss in zip(off, s):
                pts.append(tuple(o)); rad.append(math.sqrt(ss) / 2 * fig.dpi / 72)
    pts = np.array(pts)
    anchors, radii = [], []
    for t in labels:
        x, y = t.get_position()
        j = int(np.argmin(np.hypot(pts[:, 0] - (x - 1.8), pts[:, 1] - y)))
        anchors.append(pts[j]); radii.append(rad[j])
    place_point_labels(ax, labels, anchors, radii)
    # panel B: the 100 nM reference label sat on the "other" violin; it moves
    # just outside the plot, level with its line
    axb = axes_ylabel(fig, "Experimental pIC")
    t = text_in(axb, r"^100 nM$")[0]
    y = t.get_position()[1]
    t.set_transform(axb.get_yaxis_transform())
    t.set_position((1.01, 7.0)); t.set_ha("left"); t.set_va("center")


def si08(fig):
    ax = axes_titled(fig, "Paired group-bootstrap")
    remake_legend(ax, loc="upper right", ncol=1)
    t = text_in(axes_titled(fig, "Leave-one-series-out"), r"omitted series")[0]
    t.set_position((t.get_position()[0], 0.06))


def si09(fig):
    ax = axes_titled(fig, "Activity composition")
    segs = [s for c in ax.collections if isinstance(c, LineCollection) for s in c.get_segments()]
    span = ax.get_ylim()[1] - ax.get_ylim()[0]
    for t in text_in(ax, r"^\d+/\d+$"):
        x = t.get_position()[0]
        top = max(s[:, 1].max() for s in segs if abs(s[:, 0].mean() - x) < 0.05)
        t.set_position((x, top + 0.012 * span)); t.set_va("bottom")


def si10(fig):
    ax = axes_titled(fig, "Fixed-panel position")
    lines = [l for l in ax.lines if l.get_marker() not in (None, "", "None") and len(l.get_xdata()) > 1]
    labels, anchors, radii = [], [], []
    for t in text_in(ax, r"^\d+/\d+$"):
        x, _ = t.get_position()
        own = [l for l in lines if np.allclose(to_rgba(l.get_color()), to_rgba(t.get_color()))][0]
        i = int(np.argmin(np.abs(np.asarray(own.get_xdata()) - x)))
        anchors.append((float(np.asarray(own.get_xdata())[i]), float(np.asarray(own.get_ydata())[i])))
        radii.append(own.get_markersize() / 2 * fig.dpi / 72)
        t.set_rotation(0)
        labels.append(t)
    place_point_labels(ax, labels, anchors, radii, pad_px=1.5, lines=True, prefer_vertical=True)
    for title in ("All 120 two-residue", "All 560 three-residue"):
        white_legend(axes_titled(fig, title))


def si11(fig):
    for ax in fig.axes:
        for t in [t for t in ax.texts if re.match(r"^random = [\d.]+%$", t.get_text())]:
            v = float(re.findall(r"[\d.]+", t.get_text())[0])
            t.set_transform(ax.get_yaxis_transform())
            t.set_position((0.99, v + 0.6)); t.set_ha("right"); t.set_va("bottom")
            t.set_fontsize(FS_ANNOT)
        for t in [t for t in ax.texts if t.get_text().startswith("Boltz-2 alone")]:
            t.set_position((0.985, t.get_position()[1])); t.set_ha("right")


def si14(fig):
    legend_below(axes_titled(fig, "Triad additions"))


def si15(fig):
    ax_b = axes_ylabel(fig, "Single-residue display energy")
    lo, hi = ax_b.get_ylim()
    ax_b.set_ylim(min(lo, hi) - 0.45, max(lo, hi))          # a band under the bars for the key
    ax_c = [ax for ax in fig.axes if any(t.get_text() == "positive = correct potency direction" for t in ax.texts)][0]
    t = text_in(ax_c, r"^positive = correct potency direction$")[0]
    t.set_position((0.98, 0.075)); t.set_ha("right"); t.set_va("bottom")   # clear of the zero line
    ax_e = [ax for ax in fig.axes if any(t.get_text() == "energy < 0 favors weak 103" for t in ax.texts)][0]
    t = text_in(ax_e, r"^energy < 0 favors weak 103$")[0]
    t.set_position((0.97, 0.97)); t.set_ha("right"); t.set_va("top")


def si16(fig):
    # counts of compounds: whole-number ticks
    from matplotlib.ticker import MultipleLocator
    axes_titled(fig, "Procurement accounting").yaxis.set_major_locator(MultipleLocator(5))


def si18(fig):
    from matplotlib.ticker import FixedFormatter, FixedLocator, MultipleLocator, NullFormatter
    axes_titled(fig, "Stricter gates").yaxis.set_major_locator(MultipleLocator(5))
    # E: the key sat on the zero line; F: the key sat on the Combined points
    legend_below(axes_titled(fig, "Scores vs continuous inhibition"), ncol=3)
    ax = axes_titled(fig, "Threshold-scan adjustment")
    legend_below(ax, ncol=1)
    # readable p values on the log axis (the reference line is at 0.05)
    ax.xaxis.set_major_locator(FixedLocator([0.02, 0.05, 0.1, 0.2]))
    ax.xaxis.set_major_formatter(FixedFormatter(["0.02", "0.05", "0.1", "0.2"]))
    ax.xaxis.set_minor_formatter(NullFormatter())


def si17(fig):
    r = _r(fig)
    letters = [(ax, t) for ax in fig.axes for t in ax.texts
               if re.fullmatch(r"[A-D]", t.get_text()) and t.get_fontweight() in ("bold", 700)]
    assert len(letters) == 4, letters
    xs = {t.get_text(): t.get_window_extent(r).x0 for _, t in letters}
    left = min(xs["A"], xs["B"]); right = min(xs["C"], xs["D"])
    for ax, t in letters:
        target = left if t.get_text() in "AB" else right
        shift_px(t, dx=target - xs[t.get_text()])
    for ax in fig.axes:
        for t in ax.texts:
            if t.get_text() in ("-0", "−0"):
                t.set_text("0")


def si19(fig):
    ax = axes_titled(fig, "Reference proximity")
    for t in text_in(ax, r"exact$"):
        t.anncoords = "offset points"; t.xyann = (-5, 0)
        t.set_ha("right"); t.set_va("center")


SPECIFIC = {1: si01, 8: si08, 9: si09, 10: si10, 11: si11, 14: si14, 15: si15, 16: si16, 17: si17,
            18: si18, 19: si19}


def hidden_data(fig):
    """Data markers that fall outside their axes' view limits (reported, not changed)."""
    out = []
    for k, ax in enumerate(fig.axes):
        x0, x1 = sorted(ax.get_xlim()); y0, y1 = sorted(ax.get_ylim())
        pts = []
        for c in ax.collections:
            if isinstance(c, PathCollection) and c.get_transform() == ax.transData:
                pts += [tuple(o) for o in c.get_offsets()]
        for l in ax.lines:
            if l.get_marker() not in (None, "", "None", " ") and l.get_transform() == ax.transData:
                pts += list(zip(np.asarray(l.get_xdata(), float), np.asarray(l.get_ydata(), float)))
        bad = [(x, y) for x, y in pts if np.isfinite(x) and np.isfinite(y)
               and not (x0 - 1e-9 <= x <= x1 + 1e-9 and y0 - 1e-9 <= y <= y1 + 1e-9)]
        if bad:
            out.append({"axes": k, "title": " ".join(t.get_text() for t in _titles(ax))[:50],
                        "ylabel": ax.get_ylabel()[:40], "outside": len(bad), "of": len(pts),
                        "examples": [tuple(round(v, 3) for v in b) for b in bad[:4]]})
    return out


def align_letters(fig, tol_pt=45.0):
    """Panel letters of one column share one x (within tol_pt they are one column)."""
    r = _r(fig)
    lets = [t for ax in fig.axes for t in ax.texts
            if re.fullmatch(r"[A-Z]", t.get_text()) and t.get_fontweight() in ("bold", 700)
            and abs(t.get_fontsize() - st.FS_LETTER) < 0.5]
    xs = sorted(((t.get_window_extent(r).x0, t) for t in lets), key=lambda z: z[0])
    tol = tol_pt * fig.dpi / 72
    group = []
    for x, t in xs + [(float("inf"), None)]:
        if group and x - group[0][0] > tol:
            x0 = group[0][0]
            for gx, gt in group:
                if gx - x0 > 0.5:
                    shift_px(gt, dx=x0 - gx)
            group = []
        group.append((x, t))


def polish(fig, n: int) -> list:
    done = []
    bold_panel_titles(fig); typography(fig)
    if n in SPECIFIC:
        SPECIFIC[n](fig); done.append(SPECIFIC[n].__name__)
    align_letters(fig)
    hid = hidden_data(fig)
    if hid:
        print(f"    [hidden data] Supplementary Figure {n}: {hid}")
    return done
