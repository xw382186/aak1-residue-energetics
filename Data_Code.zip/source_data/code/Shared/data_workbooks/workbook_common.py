"""Shared conversions for the numbered data workbooks.

matrix(), typed_cell() and sheet_name() are the 2026-09-30 builder's own rules
(rebuild_20260930/prepare_numbered_data.py), unchanged, so a sheet rebuilt here
holds exactly the cells the first build wrote.
"""
import csv, hashlib, json, math, re
from pathlib import PurePosixPath as PP


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def container_for(data_id):
    """Release path of a numbered workbook."""
    kind, num = data_id.rsplit(" ", 1); num = int(num)
    if kind == "Source Data":
        return f"Figure{num}/Main_Figure/source_data/Source_Data_{num}_Figure{num}.xlsx"
    fig = num + 1
    return f"Figure{fig}/Supplementary_Table/Supplementary_Table_{num}_Figure{fig}.xlsx"


def typed_cell(value, header):
    if value == '': return None
    if value in ('True', 'False', 'true', 'false'): return value.lower() == 'true'
    if re.search(r'(^|_)(id|ids|code|codes|identifier|smiles|source|sources|name|label|sha256|path|file|filename|members)(_|$)', header, re.I): return value
    if re.fullmatch(r'[+-]?0\d+', value): return value
    if re.fullmatch(r'[+-]?\d+', value) and abs(int(value)) >= 2**53: return value
    if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', value):
        out = float(value)
        if math.isfinite(out): return int(out) if out.is_integer() and abs(out) < 2**53 else out
    return value


def matrix(p):
    p = PP(str(p)) if not hasattr(p, "open") else p
    if str(p).lower().endswith('.csv'):
        with open(p, encoding='utf-8-sig', newline='') as fh: rows = list(csv.reader(fh))
        assert rows and all(len(r) == len(rows[0]) for r in rows), p
        return [rows[0]] + [[typed_cell(v, h) for v, h in zip(r, rows[0])] for r in rows[1:]], 'flat CSV table'
    with open(p, encoding='utf-8-sig') as fh: obj = json.load(fh)
    leaves = []
    def visit(o, loc='$'):
        if isinstance(o, dict):
            if not o: leaves.append([loc, 'object', '{}'])
            for k, v in o.items(): visit(v, loc + '.' + str(k))
        elif isinstance(o, list):
            if not o: leaves.append([loc, 'array', '[]'])
            for i, v in enumerate(o): visit(v, f'{loc}[{i}]')
        else:
            typ = 'null' if o is None else 'boolean' if isinstance(o, bool) else 'number' if isinstance(o, (int, float)) else 'string'
            if isinstance(o, int) and not isinstance(o, bool) and abs(o) >= 2**53: o = str(o)
            leaves.append([loc, typ, o])
    visit(obj)
    return [['json_path', 'json_type', 'value']] + leaves, 'JSON leaf table; paths/scalar types preserved; integers above 2^53 stored as exact decimal text'


def sheet_name(path, used):
    """Stable sheet ID; `path` is the source's pre-reorganization release path."""
    path = PP(str(path))
    name = path.stem
    name = re.sub(r'^Figure\d+_', '', name)
    name = name.replace('plotted_values', 'values').replace('annotation_values', 'annotations').replace('current_', '').replace('all_', '').replace('complete_', '').replace('compound_', 'cmpd_').replace('Supplementary_', 'SI_')
    name = re.sub(r'[\[\]:*?/\\]', '_', name)
    if 'case_geometry' in str(path): name = path.parent.name + '_' + name
    name = name[:25] + '_' + hashlib.sha1(str(path).encode()).hexdigest()[:5]
    assert name not in used
    used.add(name)
    return name
