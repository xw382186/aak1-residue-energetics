#!/usr/bin/env python3
"""Build the nine numbered data workbooks from Shared/docs/DATA_NUMBERING_INDEX.csv.

Source Data 1-5 -> FigureN/Main_Figure/source_data/Source_Data_N_FigureN.xlsx
Supplementary Tables 1-4 -> FigureN/Supplementary_Table/Supplementary_Table_K_FigureN.xlsx

The index is the specification: one INDEX sheet listing every source with its
release path and SHA-256, then one sheet per CSV/JSON source under its stable
sheet ID, then an ASSETS sheet for indexed images.  Cell values follow the
original 2026-09-30 rules (workbook_common.typed_cell); nothing is recomputed.
Verification re-reads every cell and compares it with the source file, and
compares each sheet with the 2026-09-30 build where that sheet already existed.

Usage:  python3 build_numbered_workbooks.py            # build + verify all nine
        python3 build_numbered_workbooks.py --verify   # verify only
"""
import csv, json, sys, time
from collections import OrderedDict
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.utils.indexed_list import IndexedList

HERE = Path(__file__).resolve().parent
FS = HERE.parents[1]
sys.path.insert(0, str(HERE))
from workbook_common import matrix, sha256   # noqa: E402

# openpyxl writes floats as "%.16g", which drops the 17th significant digit
# some values need to round-trip; the 2026-09-30 build kept full precision, so
# write the shortest exact representation (repr) instead.
import openpyxl.cell._writer as _cell_writer           # noqa: E402
from openpyxl.compat import safe_string as _safe_string  # noqa: E402


def _exact_string(value):
    if isinstance(value, float) and value == value and value not in (float("inf"), float("-inf")):
        return repr(value)
    return _safe_string(value)


_cell_writer.safe_string = _exact_string

INDEX = FS / "Shared/docs/DATA_NUMBERING_INDEX.csv"
OLD_BOOKS = FS / "Archive/_pre_reorg_20261007/workbooks_built_20260930"
QA_OUT = FS / "Shared/qa/DATA_WORKBOOK_QA_20261007.json"
HEAD_FILL = PatternFill("solid", fgColor="FF3F4652")
HEAD_FONT = Font(name="Arial", sz=10, bold=True, color="FFFFFFFF")
HEAD_ALIGN = Alignment(wrap_text=True, horizontal="center", vertical="center")
WRAP = Alignment(wrap_text=True, vertical="center")
INDEX_WIDTHS = [20, 9, 24, 24, 22, 65, 65, 31, 45, 66, 14, 12, 12, 42, 65]
INT_COLS = ("figure", "bytes", "data_rows", "columns")
ASSET_COLS = ["canonical_relative_path", "sha256", "bytes", "main_panel", "content_role"]


def books():
    rows = list(csv.DictReader(INDEX.open(encoding="utf-8")))
    out = OrderedDict()
    for r in rows:
        out.setdefault(r["public_container_relative_path"], []).append(r)
    return list(rows[0].keys()), out


def index_value(k, v):
    if v == "":
        return None
    return int(v) if k in INT_COLS else v


def cell(ws, v, font=None, fill=None, align=None):
    c = WriteOnlyCell(ws, value=v)
    if isinstance(v, str) and v.startswith("="):
        c.data_type = "s"              # literal text, never a formula
    if font: c.font = font
    if fill: c.fill = fill
    if align: c.alignment = align
    return c


def head(ws, values):
    return [cell(ws, v, HEAD_FONT, HEAD_FILL, HEAD_ALIGN) for v in values]


def frame(ws, ncols, widths):
    for j, w in enumerate(widths[:ncols]):
        ws.column_dimensions[get_column_letter(j + 1)].width = w
    ws.freeze_panes = "B2" if ncols > 5 else "A2"
    ws.sheet_view.showGridLines = False


def data_widths(values):
    out = []
    for j in range(len(values[0])):
        sample = [r[j] for r in values[1:25]]
        texts = [len(str(values[0][j]))] + [len(v) for v in sample if isinstance(v, str)]
        out.append(min(60, max(16, round(max(texts) * 0.75))))
    return out


def build(path, cols, rows):
    wb = Workbook(write_only=True)
    wb._fonts = IndexedList([Font(name="Arial", sz=10, family=2, color="FF222222")])
    ix = wb.create_sheet("INDEX")
    ix.sheet_properties.tabColor = "3F4652"
    frame(ix, len(cols), INDEX_WIDTHS)
    ix.append(head(ix, cols))
    for r in rows:
        ix.append([cell(ix, index_value(k, r[k]), align=WRAP) for k in cols])
    for r in rows:
        if r["sheet_name"] == "ASSETS":
            continue
        values, _ = matrix(FS / r["canonical_relative_path"])
        ws = wb.create_sheet(r["sheet_name"])
        frame(ws, len(values[0]), data_widths(values))
        ws.append(head(ws, values[0]))
        for row in values[1:]:
            ws.append([cell(ws, v) if isinstance(v, str) and v.startswith("=") else v for v in row])
    assets = [r for r in rows if r["sheet_name"] == "ASSETS"]
    if assets:
        ws = wb.create_sheet("ASSETS")
        frame(ws, len(ASSET_COLS), [65, 66, 14, 12, 42])
        ws.append(head(ws, ASSET_COLS))
        for r in assets:
            ws.append([index_value(k, r[k]) for k in ASSET_COLS])
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def verify(path, cols, rows):
    w = load_workbook(path, read_only=True)
    tabs = [r for r in rows if r["sheet_name"] != "ASSETS"]
    expect = ["INDEX"] + [r["sheet_name"] for r in tabs] + (["ASSETS"] if len(tabs) < len(rows) else [])
    assert w.sheetnames == expect, (path.name, w.sheetnames, expect)
    got = list(w["INDEX"].iter_rows(values_only=True))
    assert list(got[0]) == cols
    for r, g in zip(rows, got[1:]):
        assert [index_value(k, r[k]) for k in cols] == list(g), (path.name, r["sheet_name"])
    cells = 0
    for r in tabs:
        assert sha256(FS / r["canonical_relative_path"]) == r["sha256"], r["canonical_relative_path"]
        values, _ = matrix(FS / r["canonical_relative_path"])
        n = 0
        rows_iter = w[r["sheet_name"]].iter_rows(max_row=len(values), max_col=len(values[0]),
                                                 values_only=True)
        for i, row in enumerate(rows_iter):
            exp = values[i]
            assert len(row) == len(exp) and all(
                (a is None and e is None) or (a == e and type(a) is type(e)) or
                (isinstance(a, (int, float)) and isinstance(e, (int, float)) and not isinstance(a, bool)
                 and not isinstance(e, bool) and a == e)
                for a, e in zip(row, exp)), (path.name, r["sheet_name"], i)
            n += 1
        assert n == len(values), (path.name, r["sheet_name"], n, len(values))
        cells += n * len(values[0])
    w.close()
    return cells


def compare_old(path, rows):
    """Sheet-by-sheet comparison with the 2026-09-30 build of the same workbook."""
    old = OLD_BOOKS / path.name
    if not old.exists():
        return {"previous_build": None}
    a = load_workbook(old, read_only=True); b = load_workbook(path, read_only=True)
    same, differ, added = [], [], []
    for r in rows:
        s = r["sheet_name"]
        if s == "ASSETS":
            continue
        if s not in a.sheetnames:
            added.append(s); continue
        pad = lambda row, n: tuple(row) + (None,) * (n - len(row))
        la = [tuple(x) for x in a[s].iter_rows(values_only=True)]
        lb = [tuple(x) for x in b[s].iter_rows(values_only=True)]
        n = max([len(x) for x in la + lb] or [0])
        while la and not any(v is not None for v in la[-1]): la.pop()
        while lb and not any(v is not None for v in lb[-1]): lb.pop()
        equal = len(la) == len(lb) and all(pad(x, n) == pad(y, n) for x, y in zip(la, lb))
        (same if equal else differ).append(s)
    removed = [s for s in a.sheetnames if s not in ("INDEX", "ASSETS") and s not in {r["sheet_name"] for r in rows}]
    a.close(); b.close()
    return {"previous_build": str(old.relative_to(FS)), "sheets_identical": len(same),
            "sheets_changed": differ, "sheets_added": added, "sheets_removed": removed}


def main():
    verify_only = "--verify" in sys.argv
    cols, spec = books()
    report = []
    for container, rows in spec.items():
        path = FS / container
        t0 = time.time()
        if not verify_only:
            build(path, cols, rows)
        cells = verify(path, cols, rows)
        cmp = compare_old(path, rows)
        rec = {"workbook": container, "data_id": rows[0]["data_id"],
               "source_sheets": sum(r["sheet_name"] != "ASSETS" for r in rows),
               "assets": sum(r["sheet_name"] == "ASSETS" for r in rows),
               "cells_verified": cells, "bytes": path.stat().st_size, "sha256": sha256(path),
               "seconds": round(time.time() - t0, 1), "status": "PASS"} | cmp
        report.append(rec)
        print(json.dumps({k: rec[k] for k in ("data_id", "source_sheets", "cells_verified", "seconds")}
                         | {k: rec.get(k) for k in ("sheets_changed", "sheets_added")}), flush=True)
    QA_OUT.write_text(json.dumps({
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "builder": "Shared/data_workbooks/build_numbered_workbooks.py (openpyxl, write-only)",
        "specification": "Shared/docs/DATA_NUMBERING_INDEX.csv",
        "status": "PASS", "workbooks": report,
        "cells_verified_total": sum(r["cells_verified"] for r in report)}, indent=2))
    print("QA ->", QA_OUT.relative_to(FS))


if __name__ == "__main__":
    main()
