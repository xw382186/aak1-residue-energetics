# Figure 1 source-data and supplementary-material decision (2026-09-30)

Figure 1 is a graphical overview and has no standalone Supplementary Figure. Source Data 1 indexes its R11 workflow provenance and the shared Figure 5A count table. Detailed evidence appears in Supplementary Figs. 1–6 / Supplementary Table 1 (Figure 2), 7–10 / Supplementary Table 2 (Figure 3), 11–15 / Supplementary Table 3 (Figure 4), and 16–19 / Supplementary Table 4 (Figure 5).

Current overview assets are in `Figure1/Main_Figure/`. Source data are in `Figure1/Main_Figure/source_data/Source_Data_1_Figure1.xlsx`; the exact dependencies are listed in `SOURCE_MAP.csv` and the cross-figure data index.
