# Existing N143 analysis inputs

These two files are unchanged copies of retained analysis inputs, not a newly computed score matrix. The 143 compounds and 16 eligible residues are the complete-case set used in the current supplementary analysis. Matrix rows follow `compound_ids`; columns follow `residues`. `contribution_1e4` stores integer residue contributions at a scale of 10,000 units per kcal/mol. The metadata CSV supplies identities, experimental values, score direction and source references.

Before packaging, all 2,288 matrix values matched the frozen SI14 wide CSV exactly after applying the recorded scale, and all 143 metadata rows matched its corresponding fields. No ranking, gate, threshold or statistical result was recalculated. Missing residue terms in the larger cohort are not zero contributions.
