# Raw data — threshold-audit record behind Supplementary Figure 18F

`threshold_audit_QA.json` is a byte-identical copy (SHA-256 `7b44e765…8a85`) of
`AAK1_FIGURE5_TRIAD_THRESHOLD_AUDIT_20260924/QA.json` from the 2026-09-24 Codex workspace, recovered on
2026-10-07. It is kept whole; its historical source paths and hashes are not rewritten.

Panel F plots the `exact_conditional_randomization` → `pair_preset_0p5`, `triad_preset_0p5` and
`pair_plus_triad_preset_0p5` branches: the exact scan-adjusted p for the minimum hypergeometric p
(enrichment against the 9/15 baseline) and for the maximum true-positive advantage over the same-K
Boltz-2 selection. The `*_all_unique_and_preset` and `*_observed_unique` branches belong to other scan
families and are not plotted. The six values, with their counts out of the 5,005 = C(15,9) label
placements, are tabulated verbatim in `../source_data/Table_S16_threshold_scan_exact_adjustment.csv`
(also a sheet of Supplementary Table 4).

Grid of the original audit: Pair strength > 1 to 6 and Triad strength > 3 to 7 kcal/mol in 0.5 steps
(strict >); K = 0 and K = 15 selections excluded and identical selection sets counted once (4, 6 and 9
distinct sets for Pair, Triad and Pair+Triad). These are post-hoc conditional-randomization results
within the 15 assayed compounds.
