# Raw data — protein production and the primary enzyme screen

Experimental originals behind main Figure 5D–F and Supplementary Figure 17. Copied unchanged from `AAK1/exp_result/`.

## `experimental_originals/`

| File | Used by |
|---|---|
| `蛋白考染图2-含Marker信息.png` | Supplementary Fig. 17A (Coomassie-stained protein, marker annotated) |
| `WB-含Marker信息.tif` | Supplementary Fig. 17B (Western blot, marker annotated) |
| `蛋白考染图1-原图.png` | unannotated original of the Coomassie gel |
| `WB-原图.tif` | unannotated original of the Western blot |

## `assay_source/`

Primary records for the 15 purchased compounds: raw luminescence with derived inhibition (`purchased_raw_luminescence_and_inhibition_long.csv`), the inhibition / gate table, the merge audit, the true-hit summary and the contract laboratory's final report (`结题报告：…TS-20260402-02.pdf`). The 45 single-well observations plotted in Supplementary Fig. 17 are `../source_data/Table_S2_all45_assay_wells.csv`.
