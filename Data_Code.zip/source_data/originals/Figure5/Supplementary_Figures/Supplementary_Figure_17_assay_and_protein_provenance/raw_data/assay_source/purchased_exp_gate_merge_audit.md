# Purchased compound experiment/gate merge audit

## Sources
- Base summary table: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/first_final_merged.csv`
- Backup before patch: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/first_final_merged.backup_before_exp_gate_patch_20260605_135344.csv`
- Experimental workbook: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/附件2-2：FN20260122001 陶术-实验数据处理.xlsx`
- Gate/source rows used by previous slide summary: `/Users/wxmacbookpro/Desktop/project/AAK1/Analysis/60_experimental_rule_validation_two_slides/analysis_data/experimental_rule_validation_source_rows.csv`
- Third-batch ASGB/ASIE/ASGBIE source: `/Users/wxmacbookpro/Desktop/project/AAK1/Analysis/69_third_batch_original_id_summary/third_batch_original_id_asgb_asie_asgbie_properties_summary.csv`

## Experimental calculation
- Blank control raw luminescence values: [1490.0, 1510.0]; mean = 1500.0
- NC control raw luminescence values: [89420.0, 89580.0]; mean = 89500.0
- Inhibition formula: `(NC_mean - sample_raw) / (NC_mean - Blank_mean) * 100`
- Hit label used for this validation: `50 μM inhibition > 40%`

## Gate definition
- Final gate wording: raw residue-panel ASGBIE sum > 3 kcal/mol.
- Pair gate: 26LEU + 102PHE ASGBIE sum > 3 kcal/mol.
- Triad gate: 26LEU + 102PHE + 107GLN ASGBIE sum > 3 kcal/mol.
- Top3/top4/top5 gates are retained as slide-rule enrichment summaries; Top5 is the coverage gate shown in the screenshot.

## Validation against slide summary
- All purchased: observed 9/15; expected 9/15; PASS
- Boltz good/mid: observed 8/11; expected 8/11; PASS
- Boltz bad: observed 1/4; expected 1/4; PASS
- Pair + Boltz good/mid: observed 5/5; expected 5/5; PASS
- Top5 + Boltz good/mid: observed 8/10; expected 8/10; PASS

Overall validation: PASS

## Output files
- Augmented in-place summary: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/first_final_merged.csv`
- Augmented copy: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/first_final_merged_with_exp_inhibition_and_gates.csv`
- Compact 2D inhibition/gate table: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/purchased_compounds_2d_inhibition_gate_table.csv`
- Hit-only compact table: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/purchased_compounds_2d_hit.csv`
- No-hit compact table: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/purchased_compounds_2d_nohit.csv`
- Raw long experimental table: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/purchased_raw_luminescence_and_inhibition_long.csv`
- Rule summary recomputed from raw experiment: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/purchased_rule_summary_recomputed_from_raw.csv`

## Notes
- Pair and triad ASGBIE sums were cross-checked against third-batch original-ID raw metrics; maximum absolute difference was below 0.0005 kcal/mol.
- The recomputed rule summary matches the slide screenshot for 9/15 all purchased, 8/11 Boltz good/mid, 1/4 Boltz bad, 5/5 pair + Boltz good/mid, and 8/10 Top5 + Boltz good/mid.
