# Purchased 15 true-hit summaries

Source: `/Users/wxmacbookpro/Desktop/project/AAK1/exp_result/first_final_merged.csv`

True experimental hit label: `experimental_hit_50uM_gt40`; baseline = 9/15 = 60.0%.

## Gate/rule summary

| selection                      |   N |   hits | hits_over_N   |   hit_rate_pct |   enrichment_vs_all_purchased |   median_10uM_inhibition_pct |   median_50uM_inhibition_pct | note                                                |
|:-------------------------------|----:|-------:|:--------------|---------------:|------------------------------:|-----------------------------:|-----------------------------:|:----------------------------------------------------|
| All purchased                  |  15 |      9 | 9/15          |           60   |                          1    |                         25.7 |                         46   | baseline true experimental hits                     |
| Boltz good/mid                 |  11 |      8 | 8/11          |           72.7 |                          1.21 |                         32.7 |                         51.9 | frozen Boltz tier in {good, mid}                    |
| Boltz bad                      |   4 |      1 | 1/4           |           25   |                          0.42 |                          2.6 |                          5.2 | frozen Boltz tier = bad                             |
| Pair gate >3                   |   6 |      5 | 5/6           |           83.3 |                          1.39 |                         37.3 |                         52.6 | 26LEU + 102PHE raw ASGBIE sum > 3 kcal/mol          |
| Pair gate >3 ∩ Boltz good/mid  |   5 |      5 | 5/5           |          100   |                          1.67 |                         41.9 |                         53.4 | both filters                                        |
| Triad gate >3                  |   9 |      6 | 6/9           |           66.7 |                          1.11 |                         32.7 |                         51.9 | 26LEU + 102PHE + 107GLN raw ASGBIE sum > 3 kcal/mol |
| Triad gate >3 ∩ Boltz good/mid |   8 |      6 | 6/8           |           75   |                          1.25 |                         35.4 |                         52.6 | both filters                                        |
| Top3 gate >3 ∩ Boltz good/mid  |   9 |      7 | 7/9           |           77.8 |                          1.3  |                         38.1 |                         53.4 | Top3 raw ASGBIE sum > 3 kcal/mol and Boltz good/mid |
| Top4 gate >3 ∩ Boltz good/mid  |   9 |      7 | 7/9           |           77.8 |                          1.3  |                         38.1 |                         53.4 | Top4 raw ASGBIE sum > 3 kcal/mol and Boltz good/mid |
| Top5 gate >3 ∩ Boltz good/mid  |  10 |      8 | 8/10          |           80   |                          1.33 |                         35.4 |                         52.6 | Top5 raw ASGBIE sum > 3 kcal/mol and Boltz good/mid |


## Fixed-K / Top30% rank consensus summary

| K_label                         | selection                          |   N |   hits | hits_over_N   |   hit_rate_pct |   enrichment_vs_all_purchased |   median_10uM_inhibition_pct |   median_50uM_inhibition_pct | source_note                                    |
|:--------------------------------|:-----------------------------------|----:|-------:|:--------------|---------------:|------------------------------:|-----------------------------:|-----------------------------:|:-----------------------------------------------|
| TopK using true-hit count (K=9) | Boltz-2 Top9                       |   9 |      5 | 5/9           |           55.6 |                          0.93 |                         13.1 |                         45.2 | lower predicted IC50 ranks stronger            |
| TopK using true-hit count (K=9) | Pair 26+102 Top9                   |   9 |      6 | 6/9           |           66.7 |                          1.11 |                         32.7 |                         51.9 | higher residue-panel ASGBIE sum ranks stronger |
| TopK using true-hit count (K=9) | Boltz Top9 ∩ Pair 26+102 Top9      |   5 |      3 | 3/5           |           60   |                          1    |                         25.7 |                         46   | intersection after applying both rank filters  |
| TopK using true-hit count (K=9) | Boltz-2 Top5 size-matched control  |   5 |      3 | 3/5           |           60   |                          1    |                         13.1 |                         45.2 | Boltz-only top N matched to intersection size  |
| TopK using true-hit count (K=9) | Triad 26+102+107 Top9              |   9 |      6 | 6/9           |           66.7 |                          1.11 |                         32.7 |                         51.9 | higher residue-panel ASGBIE sum ranks stronger |
| TopK using true-hit count (K=9) | Boltz Top9 ∩ Triad 26+102+107 Top9 |   5 |      3 | 3/5           |           60   |                          1    |                         25.7 |                         46   | intersection after applying both rank filters  |
| TopK using true-hit count (K=9) | Boltz-2 Top5 size-matched control  |   5 |      3 | 3/5           |           60   |                          1    |                         13.1 |                         45.2 | Boltz-only top N matched to intersection size  |
| TopK using true-hit count (K=9) | Top5 panel Top9                    |   9 |      7 | 7/9           |           77.8 |                          1.3  |                         38.1 |                         53.4 | higher residue-panel ASGBIE sum ranks stronger |
| TopK using true-hit count (K=9) | Boltz Top9 ∩ Top5 panel Top9       |   5 |      3 | 3/5           |           60   |                          1    |                         25.7 |                         46   | intersection after applying both rank filters  |
| TopK using true-hit count (K=9) | Boltz-2 Top5 size-matched control  |   5 |      3 | 3/5           |           60   |                          1    |                         13.1 |                         45.2 | Boltz-only top N matched to intersection size  |
| Top30% of purchased set (K=5)   | Boltz-2 Top5                       |   5 |      3 | 3/5           |           60   |                          1    |                         13.1 |                         45.2 | lower predicted IC50 ranks stronger            |
| Top30% of purchased set (K=5)   | Pair 26+102 Top5                   |   5 |      4 | 4/5           |           80   |                          1.33 |                         41.9 |                         51.9 | higher residue-panel ASGBIE sum ranks stronger |
| Top30% of purchased set (K=5)   | Boltz Top5 ∩ Pair 26+102 Top5      |   2 |      2 | 2/2           |          100   |                          1.67 |                         33.8 |                         48.9 | intersection after applying both rank filters  |
| Top30% of purchased set (K=5)   | Boltz-2 Top2 size-matched control  |   2 |      1 | 1/2           |           50   |                          0.83 |                         13.6 |                         29.2 | Boltz-only top N matched to intersection size  |
| Top30% of purchased set (K=5)   | Triad 26+102+107 Top5              |   5 |      4 | 4/5           |           80   |                          1.33 |                         41.9 |                         51.9 | higher residue-panel ASGBIE sum ranks stronger |
| Top30% of purchased set (K=5)   | Boltz Top5 ∩ Triad 26+102+107 Top5 |   2 |      2 | 2/2           |          100   |                          1.67 |                         33.8 |                         48.9 | intersection after applying both rank filters  |
| Top30% of purchased set (K=5)   | Boltz-2 Top2 size-matched control  |   2 |      1 | 1/2           |           50   |                          0.83 |                         13.6 |                         29.2 | Boltz-only top N matched to intersection size  |
| Top30% of purchased set (K=5)   | Top5 panel Top5                    |   5 |      3 | 3/5           |           60   |                          1    |                         25.7 |                         46   | higher residue-panel ASGBIE sum ranks stronger |
| Top30% of purchased set (K=5)   | Boltz Top5 ∩ Top5 panel Top5       |   3 |      2 | 2/3           |           66.7 |                          1.11 |                         25.7 |                         46   | intersection after applying both rank filters  |
| Top30% of purchased set (K=5)   | Boltz-2 Top3 size-matched control  |   3 |      2 | 2/3           |           66.7 |                          1.11 |                         25.7 |                         46   | Boltz-only top N matched to intersection size  |


## AUC / Spearman metrics

| method           | score_column       | score_direction    |   auc_vs_true_experimental_hit |   spearman_rho_vs_true_hit_binary |   spearman_p_vs_true_hit_binary |   spearman_rho_vs_50uM_inhibition |   spearman_p_vs_50uM_inhibition |
|:-----------------|:-------------------|:-------------------|-------------------------------:|----------------------------------:|--------------------------------:|----------------------------------:|--------------------------------:|
| Boltz-2          | pred_value_IC50_nM | lower is stronger  |                          0.444 |                            -0.094 |                          0.7377 |                            -0.314 |                          0.2539 |
| Pair 26+102      | pair_sum           | higher is stronger |                          0.667 |                             0.283 |                          0.3059 |                             0.236 |                          0.3977 |
| Triad 26+102+107 | triad_sum          | higher is stronger |                          0.667 |                             0.283 |                          0.3059 |                             0.164 |                          0.5585 |
| Top3 panel       | top3_sum           | higher is stronger |                          0.556 |                             0.094 |                          0.7377 |                            -0.05  |                          0.8595 |
| Top4 panel       | top4_sum           | higher is stronger |                          0.593 |                             0.157 |                          0.5751 |                             0     |                          1      |
| Top5 panel       | top5_sum           | higher is stronger |                          0.574 |                             0.126 |                          0.6546 |                             0.004 |                          0.9899 |

