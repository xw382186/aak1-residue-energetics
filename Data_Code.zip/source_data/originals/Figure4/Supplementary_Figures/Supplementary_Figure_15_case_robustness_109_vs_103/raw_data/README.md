# Raw data — retrospective case 2-2-109 vs 2-2-103

Primary structural material behind the case shown in main Figure 4E–G and in Supplementary Figure 15.

| File | What it is |
|---|---|
| `2-2-109/`, `2-2-103/` `representative_complex_heavy.pdb` | representative (medoid) protein–ligand complex, heavy atoms, Boltz-start route |
| `2-2-109/`, `2-2-103/` `representative_ligand.sdf` | the ligand of that complex |
| `medoid_interaction_geometry.json` | Gln107 donor–acceptor geometry in each medoid frame (distance, angle, occupancy) |
| `case_trajectory_export_6000frames.zip` | trajectory export, 6,000 frames per case |
| `validated_medoid_render.png` | the validated two-medoid render drawn in Supplementary Fig. 15A |
| `validated_medoid_render_source_manifest.json`, `validated_medoid_render_crop_QA.json` | provenance and crop check of that render |

The tables plotted in Supplementary Fig. 15 (windows, contacts, hydrogen bonds, residue terms, selection denominator) are in `../source_data/`; those plotted in main Figure 4E–G are in `Figure4/Main_Figure/source_data/`.
