# Figure 3 supplementary captions — synchronized 2026-09-30

Public numbers follow first appearance in the synchronized manuscript. Local filename stems and legacy CSV/sheet identifiers are preserved for provenance. Numerical sources are supplied in Supplementary Table 2; the exact file-to-sheet map is `Shared/docs/DATA_NUMBERING_INDEX.csv`.

## Supplementary Fig. 7 | Primary N=213 ranking readouts for Figure 3F-H

**A**, active fraction among each method's top 64 of the 213 endpoint-linked stress-cohort records at the single 100 nM activity definition; points are observed estimates, bars are 95% source-group-stratified compound bootstrap intervals from 2,000 resamples, and the dashed rule is the random expectation, which equals the cohort prevalence, 98/213 (46.0%). Hits among the 64: Boltz-2 37, Leu26 47, Pair 47, Triad 44; Leu26 and the Pair tie. **B**, ROC curves and AUCs for that same 100 nM definition; the dashed diagonal is random ranking. Both panels are drawn by the main figure's own panel functions from the same tables, so the colours, markers and type are the main figure's. They report the two fixed-setting readouts; the main figure keeps what varies with the evaluation setting (paired gain, activity cutoff and hotspot threshold), and a higher point estimate here is not a superiority test.

## Supplementary Fig. 8 | N=213 benchmark robustness for Figure 3F-H

**A**, Paired group-bootstrap differences between each residue-panel ranking and Boltz-2 across six endpoints. Intervals are descriptive 95% bootstrap intervals; they are not preregistered superiority tests. Proportion differences are shown in percentage points; Spearman differences are multiplied by 100. **B**, recovery at a matched selection budget over experimental IC50 cutoffs. **C**, tie-aware weighted Jaccard overlap among the top 64 compounds; fractional weights are used only when a score tie crosses the K boundary. **D**, leave-one-series-out sensitivity after re-evaluating all rankings on the remaining compounds; scores are not refit and this is not held-out validation. All panels use N=213, 98 compounds with IC50 <=100 nM, K=64, and exclude identity-conflicted compound 1-7-6.

## Supplementary Fig. 9 | Complete-case scope, missingness, and selected-set overlap for Figure 3I/J

**A**, transition from the former N=172 complete-case membership to the current N=143 membership: 138 remain complete, 34 become incomplete, 5 become complete, and 37 remain incomplete. **B**, the 76 absent compound-residue terms among all 214 stress compounds. Absence means that the residue was outside that case's accepted scan output and must not be interpreted as zero energy. **C**, observed activity composition in the current complete and excluded subsets with Wilson 95% intervals; completeness is based only on residue availability. **D**, tie-aware weighted Jaccard overlap among fixed-method top-43 sets in the N=143 universe.

## Supplementary Fig. 10 | Exhaustive N=143 residue-panel context for Figure 3I/J

**A**, distribution of top-30% active fraction across all 120 two-residue combinations; all 120 observations are counted, including the two 81.4% pairs previously outside a fixed histogram boundary. **B**, corresponding distribution across all 560 three-residue combinations derived directly from the current 16-residue integer matrix. **C**, fixed Leu26+Phe102 plus each of the other 14 eligible residues. Gln107 changes the top-30% active fraction by 0 pp, although its AUC is rank 1/14; these are distinct endpoints. **D**, percentile positions of the fixed Pair and fixed Triad across their complete exhaustive universes and six prespecified metrics. For top-30% active fraction, the fixed Pair has minimum rank 6/120 with 15/120 combinations at least as good; the fixed Triad has minimum rank 45/560 with 78/560 at least as good. This analysis is an internal exhaustive sensitivity analysis, not an independent prospective validation.

## Scope note

Figure 3F–H and Supplementary Figs. 7–8 use the endpoint-linked N=213 benchmark. Figure 3I/J and Supplementary Figs. 9–10 use the nested N=143 complete-case universe. The two denominators are not pooled. In Figure 3H, the blue Boltz-2 curve is matched to the Pair gate’s retained number only; all gate-specific global same-K comparisons are retained in Source Data 3.

