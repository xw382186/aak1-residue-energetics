# Figure 3 supplementary material — synchronized 2026-09-30

Public Supplementary Figure numbers follow first appearance in the synchronized manuscript. The local filename stems remain unchanged so older provenance and reconstruction records are traceable.

| Public number | Stable local source | Content |
|---|---|---|
| Supplementary Fig. 7 | `Figure3_S1_N213_primary_ranking_readouts` | the two fixed-setting N=213 readouts the ten-panel main figure moved here: top-30% active fraction and ROC discrimination, drawn by the main figure's own panel functions |
| Supplementary Fig. 8 | `Figure3_S2_N213_benchmark_robustness` | N=213 ranking sensitivity, uncertainty, overlap and leave-one-series-out analysis |
| Supplementary Fig. 9 | `Figure3_S4_N143_scope_missingness_and_overlap` | N=172->143 membership, missingness and top-K overlap |
| Supplementary Fig. 10 | `Figure3_S3_N143_exhaustive_combinatorial_context` | all 120 pairs, 560 triads and 14 fixed-Pair additions in N=143 |

The current figure exports are in `Figure3/Supplementary_Figures/`; exact numerical files are in `Figure3/Supplementary_Figures/`. All these files are indexed in Supplementary Table 2 (`Figure3/Supplementary_Table/Supplementary_Table_2_Figure3.xlsx`). Main-panel sources are in Source Data 3 (`Figure3/Main_Figure/source_data/Source_Data_3_Figure3.xlsx`). `Shared/docs/DATA_NUMBERING_INDEX.csv` gives the exact CSV-to-sheet correspondence, scientific scope and source SHA.

Legacy identifiers such as `S01_*`, `Table_S3_*` or `Figure4_S4_*` identify source files/sheets only. They are not additional public Supplementary Table or Figure numbers.

## Interpretation boundary

The frozen current main figure has ten panels A–J. F is paired top-30% gain, G is cutoff-dependent enrichment, H is conjunctive per-residue hotspot sensitivity, and I/J are complete-case enumerations. The blue curve in H uses the Pair gate’s retained number only. All three gates have their own global same-K comparator in Source Data 3. N=213 for F–H; N=143 for I/J. Top-30% fractions and ROC readouts moved to Supplementary Fig. 7. Coverage/missingness is Supplementary Fig. 9 and exhaustive combinatorics Supplementary Fig. 10.
