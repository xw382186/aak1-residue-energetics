# AAK1 supplementary figure captions (2026-09-30)


# Main Figure 2

# Figure 2 Supporting Information captions — current release 2026-09-29

## Figure 2—figure supplement 1. Cohort composition and historical calibration

**A,** Compound counts and 100 nM active fractions for all 19 literature source groups (1,434 measurements). Colours mark the prespecified strong, stress and other cohorts. **B,** Experimental pIC50 distributions. The 100 nM boundary is pIC50=7. **C,** Historical Boltz-2 calibration over all 1,434 literature measurements; the diagonal is identity and hexbin colour reports density. **D,** Source-level Spearman association versus source-group sample size. Point area scales with group size. Source heterogeneity and sample-size association are descriptive and are not evidence of causation.

## Figure 2—figure supplement 2. Current global estimates and source-group robustness

**A–B,** Pooled and within-source Spearman correlations for the strong cohort (N=139) and the identity-corrected stress cohort (N=213). Horizontal intervals are source-stratified compound-bootstrap 95% intervals. **C,** Every leave-one-source-group-out pooled estimate versus its full-cohort estimate. **D,** Change in pooled correlation after each source exclusion. LOGO values are sensitivity estimates, not confidence intervals. Glide is included as a comparator; score orientation follows the accepted source tables.

## Figure 2—figure supplement 3. Ten-compound secondary-seed sensitivity

**A,** Affinity output for the first and second structure-prediction seeds, shown for WT and three perturbation variants. **B,** Case-level seed-2 minus seed-1 changes. **C,** Median absolute and signed changes. This is a prediction-only pilot of ten stress compounds per variant and does not represent all 213 endpoint-linked or 214 structure-only stress records. Probability-head outputs are not interpreted as 100 nM activity probabilities.

## Figure 2—figure supplement 4. Alanine-perturbation response

The two readouts of the alanine ladder that the six-panel main figure does not carry, drawn from the same tables and in the same style as the panels that remain there. **A,** Spearman ρ between each perturbed prediction and the same-batch WT prediction, drawn as the fall from 1, for the strong (N=139) and structure-only stress (N=214) cohorts; the dashed line at 1 is a reference, not an observation, because a ranking compared with itself is 1 by construction, so no marker is drawn on it. This is prediction against prediction and no experimental label enters, so a high value means the order was retained and **not** that the model failed to respond to the sequence — main panel E shows that it did. Intervals are 5,000 source-stratified paired draws with indices shared across arms and compounds. **B,** Pocket Cα RMSD against ligand-centroid displacement, both after a global Cα fit to the same compound's WT prediction, for all 1,059 compound–arm pairs of the structure-only cohorts (strong 139, stress 214); the cross is each arm's median with its interval on both axes, and the ligand axis is logarithmic from 0.005 Å, below the smallest value in the data. Read across the arms the two metrics look tightly coupled (ρ=+0.80); within any single arm they are much weaker (+0.19 to +0.50), so most of the apparent coupling is arm identity. Centroid displacement is not a ligand heavy-atom RMSD and neither axis measures agreement with a crystal pose; coordinate fits are inherited from the validated remote collection and no local refit was performed.

## Figure 2—figure supplement 5. Geometry and perturbation-design audit

**A–C,** Protein Cα RMSD, pocket Cα RMSD after global fitting, and ligand-centroid displacement for the strong (N=139) and structure-only stress (N=214) cohorts. **D,** Joint protein and ligand displacement across all 1,059 WT–variant coordinate pairs. Values are the validated remote-collector fits; no independent local coordinate refit was performed. These coordinate diagnostics do not establish experimental effects and should not be read as a protein superposition.

## Figure 2—figure supplement 6. Chemical-space context

**A,** Morgan-fingerprint PCA for 353 source records (139 strong, 214 structure-only stress). **B,** Standardized descriptor mean differences; positive values indicate larger strong-cohort means. **C,** Cross-cohort overlap under exact-identity and scaffold definitions. **D,** Nearest opposite-cohort similarity under exact-overlap exclusion scenarios. The 353 entries are source records rather than 353 unique chemicals. Descriptor comparisons and exact source-level permutation p values are exploratory; none of the source-permutation descriptor tests remains below 0.05 after BH adjustment.


# Main Figure 3

# Figure 3 supplementary captions (current 2026-09-30 release)

## Figure S1. Primary N=213 ranking readouts for Figure 3F-H

**A**, active fraction among each method's top 64 of the 213 endpoint-linked stress-cohort records at the single 100 nM activity definition; points are observed estimates, bars are 95% source-group-stratified compound bootstrap intervals from 2,000 resamples, and the dashed rule is the random expectation, which equals the cohort prevalence, 98/213 (46.0%). Hits among the 64: Boltz-2 37, Leu26 47, Pair 47, Triad 44; Leu26 and the Pair tie. **B**, ROC curves and AUCs for that same 100 nM definition; the dashed diagonal is random ranking. Both panels are drawn by the main figure's own panel functions from the same tables, so the colours, markers and type are the main figure's. They report the two fixed-setting readouts; the main figure keeps what varies with the evaluation setting (paired gain, activity cutoff and hotspot threshold), and a higher point estimate here is not a superiority test.

## Figure S2. N=213 benchmark robustness for Figure 3F-H

**A**, Paired group-bootstrap differences between each residue-panel ranking and Boltz-2 across six endpoints. Intervals are descriptive 95% bootstrap intervals; they are not preregistered superiority tests. Proportion differences are shown in percentage points; Spearman differences are multiplied by 100. **B**, recovery at a matched selection budget over experimental IC50 cutoffs. **C**, tie-aware weighted Jaccard overlap among the top 64 compounds; fractional weights are used only when a score tie crosses the K boundary. **D**, leave-one-series-out sensitivity after re-evaluating all rankings on the remaining compounds; scores are not refit and this is not held-out validation. All panels use N=213, 98 compounds with IC50 <=100 nM, K=64, and exclude identity-conflicted compound 1-7-6.

## Figure S3. Exhaustive N=143 residue-panel context for Figure 3I/J

**A**, distribution of top-30% active fraction across all 120 two-residue combinations; all 120 observations are counted, including the two 81.4% pairs previously outside a fixed histogram boundary. **B**, corresponding distribution across all 560 three-residue combinations derived directly from the current 16-residue integer matrix. **C**, fixed Leu26+Phe102 plus each of the other 14 eligible residues. Gln107 changes the top-30% active fraction by 0 pp, although its AUC is rank 1/14; these are distinct endpoints. **D**, percentile positions of the fixed Pair and fixed Triad across their complete exhaustive universes and six prespecified metrics. For top-30% active fraction, the fixed Pair has minimum rank 6/120 with 15/120 combinations at least as good; the fixed Triad has minimum rank 45/560 with 78/560 at least as good. This analysis is an internal exhaustive sensitivity analysis, not an independent prospective validation.

## Figure S4. Complete-case scope, missingness, and selected-set overlap for Figure 3I/J

**A**, transition from the former N=172 complete-case membership to the current N=143 membership: 138 remain complete, 34 become incomplete, 5 become complete, and 37 remain incomplete. **B**, the 76 absent compound-residue terms among all 214 stress compounds. Absence means that the residue was outside that case's accepted scan output and must not be interpreted as zero energy. **C**, observed activity composition in the current complete and excluded subsets with Wilson 95% intervals; completeness is based only on residue availability. **D**, tie-aware weighted Jaccard overlap among fixed-method top-43 sets in the N=143 universe.

## Scope note

Figure 3F-H and Figures S1-S2 use the corrected N=213 benchmark. Figure 3I/J and Figures S3-S4 use the independent N=143 complete-case universe. The two denominators answer different questions and are never pooled.


# Main Figure 4

# Figure 4 supplementary captions (current 2026-10-05 release)

## Figure 4—figure supplement 1. Full energy-threshold trade-off in the corrected stress cohort.
All 44 evaluated route × panel × threshold rows are shown for N=213 compounds (98 active at IC50≤100 nM). Precision, number retained, active-compound recall and precision-point gain over same-K Boltz-2 are plotted together. The vertical guides mark the historical strict gates Pair E<−2 and Triad E<−3 kcal mol−1. Tightening a gate can raise the retained-set hit rate while reducing K and active-compound recall; the scan is exploratory rather than a newly validated cutoff selection.

Tables added on 2026-10-05, in this supplement's family because they extend the energy-threshold trade-off from the N=213 stress cohort to the full merged benchmark that main Figure 4c now summarises. The merged benchmark is the 352 records with a measured IC50 across the strong and stress cohorts, 195 active at IC50 <= 100 nM (chance 55.4%; 310 registered structures, so records are not all independent molecules). `Figure4_S1_pooled352_core_scores.csv` is the per-record source — the Boltz-2 affinity score and the Leu26, Pair and Triad favourable strengths from both starting routes; `Figure4_S1_pooled352_gate_membership.csv` gives each record's 0/1 membership for every gate so the counts can be recomputed; `Figure4_S1_pooled352_thresholds_all42.csv` is the full threshold scan behind them (Leu26 >1-4, Pair >2-5, Triad >3-6, each route); and `Figure4_S1_pooled352_panelC_values.csv` is the values main panel C draws, with for each gate the retained K, the hit rate, the share of the 195 actives kept, the same-size Boltz-2 selection and the random-at-same-size expectation. On this merged benchmark no non-empty gate exceeds the same-size Boltz-2 selection's hit rate; the two locked gates and the tighter Pair and Triad are shown so the purity gained is read together with the actives it costs. Boltz-2 alone orders the strong cohort almost perfectly, so the merged benchmark is a conservative setting for the residue panels; the cohorts are never pooled into one activity rate elsewhere.

## Figure 4—figure supplement 2. Complete IC50-threshold × energy-threshold sensitivity surface.
Heatmaps show the precision-point difference from same-K Boltz-2 for all 440 combinations (2 routes × 2 panels × 11 energy cutoffs × 10 IC50 activity cutoffs) in N=213. Stars mark four post-hoc Docking-start cells with positive exploratory simultaneous lower bounds at IC50≤25/50 nM (Pair |E|>4 or Triad |E|>6). These cells do not validate the historical 100 nM gate, and the family was inspected retrospectively.

## Figure 4—figure supplement 3. Historical-gate separation and cross-route dependence.
(A) Active fractions among compounds that pass or fail the strict historical gate; labels are active/total. This is a within-cohort separation and is not a matched-budget test. (B) Exact Boltz-start/Docking-start gate-membership overlap. (C) Paired Docking-minus-Boltz differences with 95% bootstrap intervals. The two routes change both input pose and molecular preparation, so the contrast is not a pose-only experiment.

## Figure 4—figure supplement 4. Complete residue-panel context in the N=143 complete-case cohort.
All 43 precomputed methods are evaluated on the same N=143 compounds (70 active) at fixed K=43. The dotted line is random prevalence and the dashed line is the unmodified Triad hit rate (33/43). Single-residue additions, training-ordered larger panels and the equal-weight all-16 panel are post-hoc analyses. L157 is the highest observed Triad addition (35/43), but no fourth-residue improvement has a positive simultaneous lower bound.

Tables added on 2026-09-30, on the same N=143 complete-case cohort as this supplement's figure: `Figure4_S4_triad_plus13_simultaneous_intervals.csv` carries the thirteen Triad additions with their thirteen-way simultaneous bounds, the analysis the main figure's former panel D drew; `Figure4_S4_compound_residue_energy_wide_N143.csv` and `Figure4_S4_compound_hotspot_scores_N143.csv` give the 143 x 16 favorable-strength matrix and the per-compound hotspot scores behind the main figure's current panel D; `Figure4_S4_all_rankings_topK_1_to_143.csv` gives all 14 rankings at all 143 budgets; `Figure4_S4_hotspot_top43_paired_bootstrap.csv` and `Figure4_S4_hotspot_top43_permutation.csv` give the 5,000-replicate paired bootstrap and the 20,000-label permutation behind the K=43 difference, including the scan correction over the thirteen rankings examined; and `Figure4_S4_strict_hotspot_gate_metrics_185.csv`, `Figure4_S4_named_gate_rules_199.csv`, `Figure4_S4_minimum_hotspot_count_gates.csv` and `Figure4_S4_count_total_joint_gate_grid.csv` give the exhaustive strict-intersection gate families, including the 181 of 196 named extensions that retain fewer than 20 compounds and the 100 that retain none. The hotspot rankings and every gate family here were defined after the experiments; none is a prespecified selection rule, and the complete generating package is retained at `draft/Figure/4/raw_data_N143_hotspot_20260930/`.

## Figure 4—figure supplement 5. Retrospective case robustness and mechanism limits.
(A) Real medoids selected from 100 evenly spaced frames of the corrected Boltz-start 20–50 ns production trajectories, after fitting the protein pocket backbone; medoid selection did not optimize an interaction or energy. (B) Single-residue display energies E=−(dH+dIE3S) for L26, F102 and Q107 in both routes. (C) Weak-minus-potent Pair and Triad energy differences in ten contiguous 3 ns IE windows, with full-window dH fixed. These windows are correlated samples from the same trajectory, not independent MD replicates. (D) L26/F102 side-chain contact occupancy and Q107 hydrogen-bond occupancy across all 6,000 Boltz-start frames. (E) Q107 geometry and energy disagree: Q107 hydrogen-bond occupancy favors potent 2-2-109, whereas the isolated Q107 display energy favors weaker 2-2-103 in both routes. The 6→1,340 nM pair is a post-hoc two-site substituent exchange, not a matched molecular pair; the occupancy difference is descriptive and is not a causal energetic explanation.


# Main Figure 5

# Figure 5 supplementary captions (current 2026-09-30 release)

## Figure 5—figure supplement 1 | Protein and assay provenance
(A) Coomassie-stained preparation and (B) Western blot supplied with the laboratory report; the reported >90% purity was not independently densitometrically quantified. (C,D) All 45 sample wells (15 compounds × 1, 10 and 50 µM), one confirmed sample well per compound/concentration. Blank mean was 1,500 RLU and vehicle mean was 89,500 RLU; inhibition was calculated as 100×(89,500−sample)/(89,500−1,500). The report identifies Promega ADP-Glo V6930, whereas the raw UTF-16 export is labelled PlateA_Firefly/PlateB_Renilla and its footer says Dual-GLO. These metadata labels disagree and should be clarified with the laboratory. The nine highlighted compounds are report-defined qualitative preliminary positives, not confirmed inhibitors.

## Figure 5—figure supplement 2 | Retrospective selection and chemical-space audit
All comparisons describe the selected sets retrospectively and were not applied historical selection rules. The 800 inputs are rank positions, not 800 unique molecules. Source-stratified comparisons show which recorded properties differ for the 47 traceable MD candidates and 15 purchased compounds. The ECFP4 projection explains only 14.59% in PC1+PC2. Both selection stages span multiple scaffolds in absolute terms, but neither is more diverse than source-matched random sampling; selected sets are modestly more similar by mean pairwise Tanimoto. Procurement and supplier quote availability contribute to the 47→26→15 transition.

## Figure 5—figure supplement 3 | Full post-assay threshold sensitivity
Pair and Triad strengths use strict > thresholds. PPV, positive recall, same-K historical Boltz performance and retained K are shown across the full preset 0.5-kcal/mol grid. More stringent gates are not monotonically better: Pair >4.5 retains only 2/15, Pair >5 retains none; Triad >5.5 retains 4/15 and Triad >6 retains 2/15. Exact conditional randomization over all 5,005 allocations of nine positive labels gives a preset-grid scan-adjusted p=0.0563 for the maximum +3-TP advantage over same-K Boltz (combined Pair/Triad). Continuous AUC and Spearman results are descriptive for N=15; the score labels do not imply biological replication.

Tables added on 2026-09-30, in this supplement's family because they use its fifteen compounds, its report-defined labels and its same-K Boltz comparison. `Table_S13_same_budget_top9_and_AUC_rerank.csv` is the source of main Figure 5c's two bar charts: the hit rate among each score's own top nine — nine being the number of report positives, so every score has the same budget — and the ROC AUC over all fifteen. Pair and Triad select the same nine compounds and place 8 of the 9 positives among them, against 5 of 9 for the historical Boltz-2 ranking (conditional chance 9/15 = 60.0%); their AUCs are 0.852 and 0.833 against 0.444, the values of Table S5. `Table_S14_same_budget_exact_randomization_summary.csv` gives the exact conditional P of each gain over all 5,005 placements of the nine positive labels: 84 of 5,005 placements reach the +3 top-nine gain (P = 0.017), and 139 of 5,005 reach the larger of the two panels' AUC gains (P = 0.028; Pair alone 0.015, Triad alone 0.026). `Table_S15_same_budget_all5005_label_placements.csv` lists every placement with each score's top-nine hits and AUC, so those counts can be recounted. The budget of nine is one budget, fixed by the number of positives, not a scan; the scan-adjusted p = 0.0563 above answers a different question — the largest advantage found anywhere on the preset threshold grid, corrected for having searched it. Both are post-assay re-analyses of compounds purchased and assayed before the current residue energies were computed; neither is a prospective test of the panel.

## Figure 5—figure supplement 4 | All-compound profiles and discordant examples
Observed three-point single-well profiles and their relation to Pair, Triad, historical Boltz and kinase-reference proximity. #1 has the highest Triad strength yet is report negative; #15 has the strongest 50-µM response but lies below the fixed Pair gate. These examples prevent a monotonic or universal-gate interpretation. Kinase-reference similarity is chemical proximity only and does not establish novelty or selectivity. No IC50 was fitted and no SD/SEM is available.
