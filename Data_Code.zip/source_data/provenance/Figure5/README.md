# Figure 5 supplementary material — synchronized 2026-09-30

Public Supplementary Figure numbers follow first appearance in the synchronized manuscript. The local filename stems remain unchanged so older provenance and reconstruction records are traceable.

| Public number | Stable local source | Content |
|---|---|---|
| Supplementary Fig. 16 | `Figure5_S2_selection_and_chemical_space_audit` | source-adjusted selection, procurement and source-matched diversity nulls |
| Supplementary Fig. 17 | `Figure5_S1_assay_and_protein_provenance` | protein images and every one of the 45 single-well assay observations |
| Supplementary Fig. 18 | `Figure5_S3_full_threshold_and_uncertainty` | full threshold tails, retention/recall, continuous diagnostics and scan correction |
| Supplementary Fig. 19 | `Figure5_S4_all_compounds_and_counterexamples` | all-compound profiles, discordant examples and reference proximity |

The current figure exports are in `Figure5/Supplementary_Figures/`; exact numerical files are in `Figure5/Supplementary_Figures/`. All these files are indexed in Supplementary Table 4 (`Figure5/Supplementary_Table/Supplementary_Table_4_Figure5.xlsx`). Main-panel sources are in Source Data 5 (`Figure5/Main_Figure/source_data/Source_Data_5_Figure5.xlsx`). `Shared/docs/DATA_NUMBERING_INDEX.csv` gives the exact CSV-to-sheet correspondence, scientific scope and source SHA.

Legacy identifiers such as `S01_*`, `Table_S3_*` or `Figure4_S4_*` identify source files/sheets only. They are not additional public Supplementary Table or Figure numbers.

## Interpretation boundary

The frozen current main figure has six panels A–F. C combines the measured inhibition heatmap, post-assay top-nine re-ranking and ROC-AUC. Pair and Triad select the same nine compounds, so the two bars are not independent confirmations. B pairs a retrospective descriptor audit of the 47 candidates with the ECFP4 chemical space of the 47 (the 15 purchased highlighted) and does not reconstruct the historical purchase rule. The author-confirmed original multi-criterion selection rule was fixed before experimental readout. The current recomputed scores, threshold scan and top-nine re-ranking are post-assay analyses on 15 single-well-screened compounds. Supplementary Fig. 16 supports procurement/selection, 17 supports assay/protein provenance, 18 supplies sensitivity/randomization and 19 supplies counterexamples/reference proximity.
