# Recovered inputs of Supplementary Figures 16F and 18F (2026-10-07)

Both files were recovered from the 2026-09-24 Codex workspace as byte-identical copies; no value was read back
from a figure or recomputed. The hand-off folder (its README, provenance JSON and SHA manifest) is kept
unchanged in `Archive/SI16F_SI18F_source_recovery_20261007/`.

| File in this release | Original | SHA-256 |
|---|---|---|
| `Supplementary_Figure_16_…/source_data/47_15_procurement_summary.csv` | `…/outputs/AAK1_FIGURE5_RETROSPECTIVE_47_15_20260924/47_15_procurement_summary.csv` | `fc1612a3eba0a2e2a4214bd7a8c3cfdf29358927b4dbd22dea7f9e65f84cbf11` |
| `Supplementary_Figure_18_…/raw_data/threshold_audit_QA.json` | `…/outputs/AAK1_FIGURE5_TRIAD_THRESHOLD_AUDIT_20260924/QA.json` | `7b44e76551e30aca26acf6ab2fa10a3cbcbf4b1a57369956f80dd9448e178a85` |

`…` = `/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2`.

## Supplementary Fig. 16F — procurement accounting by source

Each source has a `purchased` and a `not_purchased` row; the panel sums `in_quote_table_N` over both rows
per `source_group` and takes `N` of the `purchased` row. The `ALL` rows are totals and are not plotted.

| Source | MD candidates | With a quote record | Purchased |
|---|---:|---:|---:|
| TS1 | 11 | 3 | 3 |
| TS2 | 19 | 10 | 4 |
| EnamineSim | 5 | 4 | 4 |
| Kinase_Library | 12 | 9 | 4 |
| Total | 47 | 26 | 15 |

Historical quote records only; not current stock, price or availability.

## Supplementary Fig. 18F — scan adjustment on the preset 0.5 kcal/mol grid

`QA.json` → `exact_conditional_randomization` → `pair_preset_0p5`, `triad_preset_0p5`,
`pair_plus_triad_preset_0p5` (not the `*_all_unique_and_preset` or `*_observed_unique` families).

| Scan family | Enrichment vs 9/15 baseline | Advantage vs same-K Boltz-2 |
|---|---:|---:|
| Pair | 441/5005 = 0.0881 | 990/5005 = 0.1978 |
| Triad | 105/5005 = 0.0210 | 282/5005 = 0.0563 |
| Pair+Triad | 140/5005 = 0.0280 | 282/5005 = 0.0563 |

Fields: `exact_scan_adjusted_p_for_min_hypergeom_p` and `exact_scan_adjusted_p_for_max_advantage` (the
statistic is the largest extra true-positive count over the scan). The table
`source_data/Table_S16_threshold_scan_exact_adjustment.csv` carries these six values verbatim.

## Supplementary Fig. 16E — orientation

Panel E now draws the 47 candidates with the coordinates of main Figure 5B
(`Figure5/Main_Figure/source_data/Figure5_panelB_chemspace47.csv`). The 2026-09-30 render used a
projection whose second component had the opposite sign; every one of the 47 points matches it to within
0.03 units after flipping PC2, so the two panels show the same points mirrored top-to-bottom. PCA signs are
arbitrary; the SI now follows the main figure.
