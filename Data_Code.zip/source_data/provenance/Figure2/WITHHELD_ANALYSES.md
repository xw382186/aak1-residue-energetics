# Withheld analyses

The following older SI analyses were **not** regenerated because a current identity-corrected numerical table was not available in the active Figure 2 SI directory. They remain excluded instead of being filled with older values or guesses:

- molecular-size controls linked to refreshed physics values;
- paired method-difference bootstrap tables;
- recovery curves and recovery metrics;
- historical label-threshold/association panels;
- probability-head versus endpoint association analyses;
- strict-identity Glide subset and five-method paired differences.

The active package includes the six supplements that can be rebuilt from accepted current tables. Public Supplementary Figs. 1–6 follow the current manuscript sequence. Pre-2026-09-24 rendered figures remain style references and are not publication inputs.
