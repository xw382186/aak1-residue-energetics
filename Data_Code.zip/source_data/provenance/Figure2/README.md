# Figure 2 supplementary material — synchronized 2026-09-30

Public Supplementary Figure numbers follow first appearance in the synchronized manuscript. The local filename stems remain unchanged so older provenance and reconstruction records are traceable.

| Public number | Stable local source | Content |
|---|---|---|
| Supplementary Fig. 1 | `Figure2_S1_current_cohort_calibration` | cohort composition, potency landscape and historical calibration |
| Supplementary Fig. 2 | `Figure2_S6_current_chemical_space_context` | chemical-space, descriptor, scaffold and overlap context |
| Supplementary Fig. 3 | `Figure2_S2_current_global_and_LOGO_robustness` | global/within-source association and leave-one-group-out robustness; the intervals the main panel D no longer draws |
| Supplementary Fig. 4 | `Figure2_S4_current_perturbation_response` | alanine-perturbation response: prediction-rank retention and coordinate coupling, the two alanine-ladder readouts the six-panel main figure does not carry |
| Supplementary Fig. 5 | `Figure2_S5_current_geometry_design_audit` | protein/pocket/ligand displacement and perturbation-design audit |
| Supplementary Fig. 6 | `Figure2_S3_current_secondary_seed_sensitivity` | ten-compound repeat-seed sensitivity |

The current figure exports are in `Figure2/Supplementary_Figures/`; exact numerical files are in `Figure2/Supplementary_Figures/`. All these files are indexed in Supplementary Table 1 (`Figure2/Supplementary_Table/Supplementary_Table_1_Figure2.xlsx`). Main-panel sources are in Source Data 2 (`Figure2/Main_Figure/source_data/Source_Data_2_Figure2.xlsx`). `Shared/docs/DATA_NUMBERING_INDEX.csv` gives the exact CSV-to-sheet correspondence, scientific scope and source SHA.

Legacy identifiers such as `S01_*`, `Table_S3_*` or `Figure4_S4_*` identify source files/sheets only. They are not additional public Supplementary Table or Figure numbers.

## Interpretation boundary

The frozen current main figure has six panels A–F. Panel D shows pooled Spearman ρ without intervals; within-source associations and intervals are in Supplementary Fig. 3. Panel C and prediction-only panel E retain registered stress N=214; B, D and F use endpoint-linked N=213. The numerical mutation comparisons use WT experimental activity labels; no mutant assay is implied. Rank retention and geometry moved to Supplementary Figs. 4–5; the seed check is Supplementary Fig. 6.
