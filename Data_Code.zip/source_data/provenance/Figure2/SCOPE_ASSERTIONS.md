# Scope assertions

1. Endpoint-linked stress analyses use **N=213** after excluding `1-7-6`, whose simulated structure could not be linked to the registered 940 nM experiment.
2. Strong endpoint analyses use **N=139**.
3. Historical calibration uses **1,434** literature measurements across 19 source groups.
4. Coordinate and chemical-space analyses are structure-only and retain the registered stress **N=214**, giving **N=353 source records** with strong N=139. These are not 353 unique chemicals.
5. The secondary-seed analysis is a prediction-only **10-compound pilot** per variant. It is neither the endpoint N=213 set nor a complete repeat of all 214 stress structures.
6. Bootstrap intervals in Supplementary Fig. 3A–B are source-stratified compound-bootstrap intervals. LOGO folds in Supplementary Fig. 3C–D are sensitivity estimates, not confidence intervals.
6a. Supplementary Fig. 4A is **prediction against prediction**: no experimental label enters it, so a retained ranking is not evidence that the model ignored the sequence, and the dashed reference at 1 is a construction, not an observation. Its paired intervals are 5,000 source-stratified paired draws with indices shared across arms. The label-based view of the same perturbation is main panel F, where five of the six paired AUC changes include zero — a failure to detect a change, not a demonstration of equivalence.
6b. The pooled pocket-Cα-RMSD / ligand-centroid-displacement association in Supplementary Fig. 4B is stronger across perturbation arms than within each arm, so arm identity contributes substantially to the pooled association. Neither coordinate measure establishes experimental potency or crystal-pose accuracy.
7. Geometry values are validated remote-collector fits. No independent local coordinate refit or protein-superposition claim is made.
8. Chemical-space p values are exploratory; no causal interpretation is assigned to cohort composition.
