# Figure 2 supplementary captions — synchronized 2026-09-30

Public numbers follow first appearance in the synchronized manuscript. Local filename stems and legacy CSV/sheet identifiers are preserved for provenance. Numerical sources are supplied in Supplementary Table 1; the exact file-to-sheet map is `Shared/docs/DATA_NUMBERING_INDEX.csv`.

## Supplementary Fig. 1 | Cohort composition and historical calibration

**A,** Compound counts and 100 nM active fractions for all 19 literature source groups (1,434 measurements). Colours mark the prespecified strong, stress and other cohorts. **B,** Experimental pIC50 distributions. The 100 nM boundary is pIC50=7. **C,** Historical Boltz-2 calibration over all 1,434 literature measurements; the diagonal is identity and hexbin colour reports density. **D,** Source-level Spearman association versus source-group sample size. Point area scales with group size. Source heterogeneity and sample-size association are descriptive and are not evidence of causation.

## Supplementary Fig. 2 | Chemical-space context

**A,** Morgan-fingerprint PCA for 353 source records (139 strong, 214 structure-only stress). **B,** Standardized descriptor mean differences; positive values indicate larger strong-cohort means. **C,** Cross-cohort overlap under exact-identity and scaffold definitions. **D,** Nearest opposite-cohort similarity under exact-overlap exclusion scenarios. The 353 entries are source records rather than 353 unique chemicals. Descriptor comparisons and exact source-level permutation p values are exploratory; none of the source-permutation descriptor tests remains below 0.05 after BH adjustment.

## Supplementary Fig. 3 | Current global estimates and source-group robustness

**A–B,** Pooled and within-source Spearman correlations for the strong cohort (N=139) and the identity-corrected stress cohort (N=213). Horizontal intervals are source-stratified compound-bootstrap 95% intervals. **C,** Every leave-one-source-group-out pooled estimate versus its full-cohort estimate. **D,** Change in pooled correlation after each source exclusion. LOGO values are sensitivity estimates, not confidence intervals. Glide is included as a comparator; score orientation follows the accepted source tables.

## Supplementary Fig. 4 | Alanine-perturbation response

The two readouts of the alanine ladder that the six-panel main figure does not carry, drawn from the same tables and in the same style as the panels that remain there. **A,** Spearman ρ between each perturbed prediction and the same-batch WT prediction, drawn as the fall from 1, for the strong (N=139) and structure-only stress (N=214) cohorts; the dashed line at 1 is a reference, not an observation, because a ranking compared with itself is 1 by construction, so no marker is drawn on it. This is prediction against prediction and no experimental label enters, so a high value means the order was retained and **not** that the model failed to respond to the sequence — main panel E shows that it did. Intervals are 5,000 source-stratified paired draws with indices shared across arms and compounds. **B,** Pocket Cα RMSD against ligand-centroid displacement, both after a global Cα fit to the same compound's WT prediction, for all 1,059 compound–arm pairs of the structure-only cohorts (strong 139, stress 214); the cross is each arm's median with its interval on both axes, and the ligand axis is logarithmic from 0.005 Å, below the smallest value in the data. Read across the arms the two metrics look tightly coupled (ρ=+0.80); within any single arm they are much weaker (+0.19 to +0.50), so most of the apparent coupling is arm identity. Centroid displacement is not a ligand heavy-atom RMSD and neither axis measures agreement with a crystal pose; coordinate fits are inherited from the validated remote collection and no local refit was performed.

## Supplementary Fig. 5 | Geometry and perturbation-design audit

**A–C,** Protein Cα RMSD, pocket Cα RMSD after global fitting, and ligand-centroid displacement for the strong (N=139) and structure-only stress (N=214) cohorts. **D,** Joint protein and ligand displacement across all 1,059 WT–variant coordinate pairs. Values are the validated remote-collector fits; no independent local coordinate refit was performed. These coordinate diagnostics do not establish experimental effects and should not be read as a protein superposition.

## Supplementary Fig. 6 | Ten-compound secondary-seed sensitivity

**A,** Affinity output for the first and second structure-prediction seeds, shown for WT and three perturbation variants. **B,** Case-level seed-2 minus seed-1 changes. **C,** Median absolute and signed changes. This is a prediction-only pilot of ten stress compounds per variant and does not represent all 213 endpoint-linked or 214 structure-only stress records. Probability-head outputs are not interpreted as 100 nM activity probabilities.
