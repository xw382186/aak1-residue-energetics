# Current Figure 2 numerical source map

`SOURCE_MAP.csv` records every accepted SI CSV at its canonical archive path with its SHA and public Supplementary Figure number. Supplementary Table 1 supplies their workbook sheets. The primary global mapping is local S1→Supplementary Fig. 1; local S6→2; local S2→3; local S4→4; local S5→5; local S3→6.

Endpoint-linked analyses use stress N=213; chemical-space and coordinate/prediction-only comparisons retain registered N=214. Source filenames beginning S01/S02/S03/S07/S08/S10/S11 identify historical source-package sections and are preserved as source identities.
