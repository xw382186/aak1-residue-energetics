# Figure 4 supplementary table index

| SI table | File | Population | Content |
|---|---|---:|---|
| Table S4-1 | `tables/Figure4_S1_threshold_scan_N213_all44.csv` | N=213 | All 44 energy-threshold rows with TP/FP/FN/TN, K, precision, recall, same-K comparator and uncertainty fields. |
| Table S4-2 | `tables/Figure4_S2_IC50_energy_grid_N213_all440.csv` | N=213 | Complete 440-cell IC50 × energy grid; no threshold/cutoff cell omitted. |
| Table S4-3 | `tables/Figure4_S3_fixed_gate_pass_fail_N213.csv`, `Figure4_S3_crossroute_gate_2x2_N213.csv`, `Figure4_S3_crossroute_performance_N213.csv`, `Figure4_S3_crossroute_energy_N213.csv` | N=213 | Historical-gate separation, exact route overlap, and paired route contrasts. |
| Table S4-4 | `tables/Figure4_S4_residue_panel_context_N143_K43_all43.csv` | N=143; K=43 | Complete 43-method residue-panel analysis, including negative/tied additions and larger panels. |
| Table S4-5 | `tables/Figure4_S5_case_*` and `tables/case_geometry/*` | 2 compounds | Retrospective case identity, scores, per-residue terms, ten windows, full-frame contacts/H-bonds, source verification, and the complete 10,785-pair screening denominator. |

| Table S4-6.1 | `tables/Figure4_S4_all185_panels_ranking_K43.csv` | N=143 | hotspot package: data/panel_ranking_K43_all185x3.csv |
| Table S4-6.2 | `tables/Figure4_S4_all_rankings_topK_1_to_143.csv` | N=143 | hotspot package: data/selected_methods_complete_topK_1_to_143.csv |
| Table S4-6.3 | `tables/Figure4_S4_compound_hotspot_scores_N143.csv` | N=143 | hotspot package: data/compound_hotspot_ranking_scores_N143.csv |
| Table S4-6.4 | `tables/Figure4_S4_compound_residue_energy_wide_N143.csv` | N=143 | hotspot package: data/compound_residue_energy_wide_N143.csv |
| Table S4-6.5 | `tables/Figure4_S4_count_total_joint_gate_grid.csv` | N=143 | hotspot package: data/all16_count_and_total_joint_gate_grid.csv |
| Table S4-6.6 | `tables/Figure4_S4_hotspot_top43_paired_bootstrap.csv` | N=143 | hotspot package: data/ranking_top43_paired_bootstrap_5000.csv |
| Table S4-6.7 | `tables/Figure4_S4_hotspot_top43_permutation.csv` | N=143 | hotspot package: data/global_pool_permutation_ranking_top43_20000.csv |
| Table S4-6.8 | `tables/Figure4_S4_minimum_hotspot_count_gates.csv` | N=143 | hotspot package: data/all16_minimum_hotspot_count_gates.csv |
| Table S4-6.9 | `tables/Figure4_S4_named_gate_rules_199.csv` | N=143 | hotspot package: data/named_rule_strict_gate_metrics_all199.csv |
| Table S4-6.10 | `tables/Figure4_S4_strict_hotspot_gate_metrics_185.csv` | N=143 | hotspot package: data/strict_gate_metrics_unique_185.csv |
| Table S4-6.11 | `tables/Figure4_S4_triad_plus13_simultaneous_intervals.csv` | N=143 | the former main panel D, archived with its thirteen-way simultaneous bounds |

Tables S4-6.* were added on 2026-09-30. They sit in supplement 4's family because they use its cohort and its budget; the supplement's own figure was not redrawn and no supplement number moved.

The CSV files are the SI tables. They retain raw precision and all audit columns. Blank values in exhaustive source tables mean “not defined/not applicable,” never zero; publication summaries contain no imputed values.

| Table S4-7.1 | `tables/Figure4_S1_pooled352_core_scores.csv` | N=352 | 352 per-record scores: Boltz-2 affinity and Leu26/Pair/Triad strengths, both routes |
| Table S4-7.2 | `tables/Figure4_S1_pooled352_gate_membership.csv` | N=352 | per-record 0/1 membership for every merged-benchmark gate |
| Table S4-7.3 | `tables/Figure4_S1_pooled352_thresholds_all42.csv` | N=352 | merged threshold scan: Leu26 >1-4, Pair >2-5, Triad >3-6, both routes |
| Table S4-7.4 | `tables/Figure4_S1_pooled352_panelC_values.csv` | N=352 | the values main panel C draws, byte for byte the main figure's source table |

Tables S4-7.* were added on 2026-10-05 for the merged-benchmark panel C; they sit in supplement 1's family because they extend its energy-threshold trade-off to all 352 records. No supplement figure was redrawn and no number moved.

| Table S4-8 | `tables/Figure4_S1_cascade_N213.csv` | N=213 | AI-then-physics cascade behind supplement 1 panel F: for each gate and physics budget M, the actives recovered among the final K=54, with the Boltz-2-alone and physics-alone references. Added 2026-10-06. |
