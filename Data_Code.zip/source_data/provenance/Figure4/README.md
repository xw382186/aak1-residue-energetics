# Figure 4 supplementary-information package — current 2026-10-06

This is the publication-facing SI package paired with the corrected Figure 4. It uses **N=213 (98 active at IC50 ≤100 nM)** for threshold and route analyses, and the separate complete-case **N=143 (70 active; K=43)** cohort for the residue-panel context. The known `1-7-6` structure/experimental-value mismatch is excluded from N=213; that record was already absent from N=143. No historical N=214 result appears in a rendered SI figure.

## Contents

- `Figure4_S1`: all 44 N=213 energy-threshold rows, including precision, retained K, recall and same-K Boltz-2 gain.
- `Figure4_S2`: the complete 440-cell IC50 × energy scan; four post-hoc positive cells are marked without presenting them as validated gates.
- `Figure4_S3`: historical-gate pass/fail separation, exact route membership and paired route contrasts.
- `Figure4_S4`: all 43 N=143/K=43 residue-panel methods, including negative and tied additions and larger panels. Its table family was extended on 2026-09-30 with the thirteen-way simultaneous bounds the main figure's former panel D carried, and with the tables supporting the main figure's current panel D: the per-compound residue matrix and hotspot scores, all 14 rankings at all 143 budgets, the paired bootstrap and label permutation behind the K=43 difference, and the exhaustive strict hotspot-gate families.
- `Figure4_S5`: the retrospective 2-2-109 / 2-2-103 case, its real medoid structures, residue energies, ten same-trajectory IE windows, and full-frame contact/H-bond occupancy.

Every figure is exported as vector PDF/SVG and 600 dpi PNG/TIF. Tables retain raw numeric precision. `CAPTIONS.md`, `SOURCE_MAP.csv`, `SCOPE_ASSERTIONS.md`, `Archive/_pre_reorg_20261007/MANIFEST_SHA256.csv`, and `qa/QA.json` define interpretation and verification boundaries.

## What changed on 2026-09-30

The main figure's panel D was replaced: it now follows the screening budget
across its whole range, ranking the same 143 complete-case records by the
all-16 hotspot contribution sum against Boltz-2, instead of comparing thirteen
candidate fourth residues at one budget. **No supplement was added and no
supplement number moved** — Figure 4 still has five supplements and still holds
Supplementary Figs. 11-15 in the manuscript's sequence — because the analysis
the old panel drew is already inside supplement 4, which evaluates all 43
residue-panel methods on the same 143 records at the same K = 43, those
thirteen among them.

11 tables were added, all in supplement 4's family and all on that
same cohort; `TABLE_INDEX.md` lists them. The five supplement figures are the
verified 2026-09-27 renders, byte for byte — their builder reads sources
outside this project tree, so it was not rerun and nothing was redrawn.
`PROVENANCE_20260930.json` records each carried figure file and its hash.

## What changed on 2026-10-05

Main Figure 4 panels A and C were revised and **no supplement was added or
renumbered** — Figure 4 keeps five supplements and Supplementary Figs. 11-15.

Panel A is unchanged in content and now uses a tighter y window. Panel C no
longer draws the four locked gates on the stress cohort as a forest plot; those
four values are the left-most points of panel A's four curves, and the full
threshold table behind them is this supplement's
`Figure4_S1_threshold_scan_N213_all44.csv`, so nothing was lost or moved to the
supplement. In their place panel C summarises the **merged benchmark** — all
352 records with a measured IC50 across the strong and stress cohorts, 195
active at IC50 <= 100 nM — for the two locked gates and the same two one step
tighter, from both routes, as the hit rate and the share of all actives kept,
each against a same-size Boltz-2 selection and against random.

Four tables joined supplement 1's family, which already holds the full
energy-threshold trade-off: `Figure4_S1_pooled352_core_scores.csv`,
`Figure4_S1_pooled352_gate_membership.csv`,
`Figure4_S1_pooled352_thresholds_all42.csv` and
`Figure4_S1_pooled352_panelC_values.csv`. The five supplement figures and every
2026-09-30 table are carried byte for byte; `PROVENANCE_20261005.json` records
each carried file and its hash, and the 2026-09-30 release was discarded with the other superseded SI releases at the
author's request on 2026-10-07.

The merged benchmark is shown as a conservative setting, never a pooled rate:
Boltz-2 orders the high-performing strong cohort almost perfectly, so pooling
the cohorts lowers the residue panels' apparent margin rather than raising it,
and the strong and stress cohorts are not combined into one activity rate
anywhere.

## What changed on 2026-10-06

Main Figure 4 panel C was revised and **no supplement was added or renumbered** —
Figure 4 keeps five supplements and Supplementary Figs. 11-15.

Panel C no longer draws the merged 352-record benchmark. That chart moved into
**this supplement as new panel E**, and the AI-then-physics cascade it motivates
was added as **new panel F**; supplement 1 now has six panels (A–D unchanged in
content). Main panel C now draws the Boltz-2 complementarity at the widest-gap
budget panel A marks — where the residue gate and a same-size Boltz-2 selection
disagree, the gate's unique picks are active more often, on both routes.

One table joined supplement 1's family: `Figure4_S1_cascade_N213.csv`, the curve
behind panel F. The four merged-benchmark tables added on 2026-10-05 are
unchanged; `Figure4_S1_pooled352_panelC_values.csv` is now the values **panel E**
draws (it is no longer tied to the main figure's panel C table, which is the
complementarity values). Supplements 2–5 and every 2026-10-05 table are carried
byte for byte; `PROVENANCE_20261006.json` records each carried file and its hash,
and the 2026-10-05 release was discarded with the other superseded SI releases at the
author's request on 2026-10-07.
