# Existing strong/stress and merged equal-budget reporting tables

These two CSVs are **unchanged copies of analyses completed on 2026-10-02**, added for symmetric reporting in the manuscript revision of 2026-10-08. No rows, scores, numerical results, activity labels, column names, or original provenance were edited. No MD, ASGBIE, threshold optimization, resampling, or significance testing was run for this addition. The repository copy SHA256 equals the original file SHA256.

The current main figures remain frozen. These tables supplement reporting; they do not substitute for the original figures or transform the cohort comparison into an independent validation.

## Definitions

- Strong:139 experimental/simulation records,97 active atIC50≤100nM.
- Identity-corrected stress:213 records,98 active; conflicting1-7-6activityassignment excluded.
- Merged:352 records,195 active,310 registered molecular identities. These are records, not352 independent molecules; repeated and cross-cohort identities remain represented.
- Top10/20/30% use K=ceil(N×fraction), independently within the candidate pool for each score.
- Each comparison uses **global same-K Boltz-2 selection**, not source-matched quotas.
- Boltz-start and Docking-start residue scores retain their original method labels. Pair=L26+F102;Triad addsQ107.
- A favorable residue sum is ranked in descending order. The original source description retains score directions, strict gates, tie weighting, and activity definitions; these have not been changed.
- A top-K ranking comparison is a separate endpoint from an absolute-energy gate.

## Contents and provenance

### `16_separate_cohorts_context.csv`

- Rows:42 (header excluded).
- Original absolute path:`/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2/outputs/AAK1_STRONG_STRESS_POOLED_SCREENING_20261002/tables/16_separate_cohorts_context.csv`.
- SHA256:`84280e2414e05dd959d322e227a2bb42474f52d17ebc3c233a141f67fa664b41`.
- Both cohorts separately,7 named scores each,top10/20/30%. Strong top30%:Boltz42/42,Leu26 36/42,Pair39/42,Triad38/42. Stress top30%:Boltz37/64,Leu26 andPair47/64,Triad44/64.
- Reporting columns:`evaluation_set`, `method`, `top_fraction`, `N_records`, `total_active`, `retained_K`, `hits`, `hit_rate_pct`, `boltz_same_K_hits`, `gain_vs_boltz_pp`, `selected_strong_records`, `selected_stress_records`.

### `05_top10_20_30_pooled352.csv`

- Rows:21 (header excluded).
- Original absolute path:`/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2/outputs/AAK1_STRONG_STRESS_POOLED_SCREENING_20261002/tables/05_top10_20_30_pooled352.csv`.
- SHA256:`7b0fb10f4b9cf4bbdd5844a21332e4eb1d3c49b3669165de9f9681bc0cb10a71`.
- Merged352-record pool,7 named scores,top10/20/30%. Boltz-startPair counts24/36,56/71,85/106;Boltz counts35/36,60/71,84/106. ThusPair exceedsBoltzbyoneactive record at30%,and trails at10/20%.
- Reporting columns:`evaluation_set`, `method`, `top_fraction`, `N_records`, `total_active`, `retained_K`, `hits`, `hit_rate_pct`, `boltz_same_K_hits`, `gain_vs_boltz_pp`, `selected_strong_records`, `selected_stress_records`.

Original analysis README:`/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2/outputs/AAK1_STRONG_STRESS_POOLED_SCREENING_20261002/README.md`.
Original individual-record source:`/Users/wxmacbookpro/Documents/Codex/2026-09-15/new-chat-2/outputs/AAK1_STRONG_STRESS_POOLED_SCREENING_20261002/tables/01_pooled352_per_record_scores.csv`.
A row-by-row copy receipt is supplied as`COPY_PROVENANCE_SHA256.csv`.
The source-file hashes verify this local copy; they do not constitute a new scientific acceptance audit of remote trajectories.
